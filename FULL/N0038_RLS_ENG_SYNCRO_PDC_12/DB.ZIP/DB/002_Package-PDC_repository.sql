SPOOL 002_Package-PDC_repository.log;
--------------------------------------------------------
--  DDL for Package PCKG_CRTP
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "PCKG_CRTP" wrapped
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
727 20b
UUHiF75+ne7+B4ih1p5vOdykvLUwg82NAK5qfC9AWPjV3EyD8nTnqDkv1gsPXgopMcDRXGVC
fd3dCaj5nVPPjo0OUUCR2wyKtD/kGe35pfIgXBh8/iMTYKS0chfFT9dnnuocqBeI82J/6ARm
CjZ+y5v6L2ir0wzFw7BIS5FLRhr8c6q5hl/VNrj0PDOHQCqgIRad9F1X4kw1OaYM8EE7jJ8N
ADnUm37dk6qCZ8YbkQna2LpKoqt/ilxQ/ZS5nNAo1TAjN5UIpTOrKLssxul4s1uws441rAgu
1FErWKfsAdUNfZQgp1WbpxRfh6ayXUXAmVheG6uVtGv8/MqmCSehyRMIo3Qb6YM4pnusGn1I
dQ4lwHfgBFOsN26fvOHFn/pnKgQV0a4LsjpAe4hXjuiQr0+gnb3Z/IkPw2GSEO8qp9nJkRPZ
QJecEFu6oQbUo5SID5BzCPku7lWRvC5DMRadg+v0HEPlZkyViwns/0vzB7WazX9IbU+lgcry
+Iu2zlDPIw==

/
--------------------------------------------------------
--  DDL for Package PCKG_ENGINE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "PCKG_ENGINE" wrapped
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
1c41 390
FBXx/knpMsxscpOZaI63PbCOf/Iwg82TLvb9fy/NMZ3mXfEq0i/yKWtrW5OrZFxkYzsiaM4a
hL1rjua1tSbxK5/8e5+fv6KvS9TLCOxJ1/8STiElYYk73rJd6AEeg9bYAkYTiCqC04efseGz
S5FgtjgGqkateYm8T2OaWK4WoXgvnT7eVo2nfibJ1eUkw08i//rBll0z/tAPrvkIOinBToZ5
QGGjf4/cHX95bjyxcHPqDaXwfGH8BqWsEqihMAzEk6nc3Qxk/tuKXwIuGBaE/q/SpsdUU3tq
Ws4LazmkBp0eN/A+ZqKtDBrg5VVDoIFnFdZLQQgL9bv9OTt46DPzIyHdqQXLhHyV7vVfqDUh
92QDzEeWLRkWlwCwb+WFtbWw0f+riTPTz0D+qRzmrn3O9A8bJZa3uYOJwnBvPFjFsCTHsceS
dRL8FLqyxojMDIOKUu1eb8irvK18n017C+LUOoj/UOF72x7dvwOyQSPPLmNxk7ABiwRrw5E7
iRan4T2sxR9h4WEzmjq8cNQYvdVJGhtmetXMYu03UNGl7wF0U7KJFJfjUeNWGM4RvQEOYzc9
OUF35tina5SVCmP2pWt62CsugbuDs2QqNWR2bEeqDP0Hm0fe84gKJup7eS0Q8z2BJyclFWdi
bueox+fx0atNhdsplDz+rQm+fPQ99OvV0ooBtHKjaxSTvFUzv+tyKE6/k3Kcu5YoxIIfQHoI
zoSJwYuXsa4fdkkYitJS+BCK4iyY/sZBpone4tkrySZA7XFyh9h5lgPv69zyzLCGiiuls0lx
hq7wacEiPiNC56p7eEWDp50SGuA0XMzxVdMvLqoamZ08tbdryezSlN0INoVffISglEqqK8fY
1W5yiWW85mGxXhfKrToeNThTm7kouyZkAw==

/
--------------------------------------------------------
--  DDL for Package PCKG_FWRK
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "PCKG_FWRK" wrapped
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
1ff6 536
C6LrMOlIpWw/3ejHX1zutcRvlJIwg82TACAFfC/Nig81NhYGpnmSN1GE1sshMqeIDBpnCdxo
AoQ3n4UJ9SmalulYwtgol4lX1OfT6TAj0CO/XaQp4bcA3PtVjpFP/M23tJrYTXGoTqiDGQtX
B/wk/xoVWWsdb5EHlcGBsZa/fQW/9fjBwdkgcx6ampwFB40QSy9uZwmeZ8JLieyKqYqBXlGy
AsVDezcuWCeXyDo1i5ysjkbukhFPT5I0hKVZjRv0votj5l+2h3bz1U6y4/aIRoUB5QrGllpo
BUyuhDDhEEFQr5GJr84RuRtujYuuFMeMzv1yBhHRgGXss2LjbG+WIXhAO/N08HBsAcPMbrMs
VMz/pxd5GjTwWL7zx3gYQ1/VRWMU8e5k2dups61a3vwm3Dj0atnY8I8pwILBRRYI+35s64iu
KnapPu2MCTseDGyuQMtnuaRdO3tvS0U/4A3BAn9VjFA1QJ4Bdkl7r55607IbieT3IH4Di+6f
yK13dzpll1nWc8hANWkyd1i+heQ8/ktr4BssvqX2V1p8DWOlXk/KTk23KaCurOsZuPT0iEPK
r4zJ+lgwMFBv85cKRjFkaacnA3F3t7jPigB+pX6VCZDsJ5rPAIyssaRi8jyO46+B6OZGJYPg
mopbeoSdNkCXXc6TxJpwWmuvRvGGhKR4zJVUCHQ2ydvEoLIkfIA8yck/DREfHFahw/SCEN2T
KY0nr6wX19ypaAhHxCIqdWnAvEI2UejFrpkqjHuEgqHU5WVGnEEmSOb/9hvxsFXD9L/IpVwq
O6vF/DuCy7by0amlengxcWQKGRjraqN/64PCZdnmrLiJnpsmaN5ryfxWmnHUMbpgaKPUBZPU
KXdV1MYz/MGmPL5740UgjBXCDQX/a/MCQnNx9uW+R3aGJIwVbINzknXdNEBzwgGAhzOtPHg7
UxddywsxzLQ13L8MK8xuZgBW30ZBPmi5xIBqGUhTzYhX+Kkg1pE56gU4De6V33cuuCap1ABu
98m9Fl6xrzL4andiaQuIPgJLRKerTRVC83U3LoEzkY9fkgDMjdFEezI+UFOVwZAty3qMQTDU
eptxK+zj0zFD9xfBRhpbdQ1o0SgBX3xgmTjYpURGSLplCTHQYXsCycbtY1+XpBQeM988oxKx
dDWpxenHqnX/YL7dFUZcN8j2EjEaN/1tMSpO2EcxQwCxWQPHw5qq/PraNICd6g5dRQ8D/GaP
/cwOoCEKjeLART/Bl4WBvpZUZiGScwSWAjF/ScjMXvnQZA9lVhMc1n/NdtZRMpi2uTmljrwj
uCjV6+l157w6KJWwMTA=

/
--------------------------------------------------------
--  DDL for Package PCKG_GUI
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "PCKG_GUI" wrapped
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
171ca 1bfa
LbXbyfEIzWfOGkn2C1oDJICgbyEwg81MVfEaTdMisU6OlP1S4BJm3FlHM4q5lZ+KRGP1jQWn
RakAXuq8tbp2acNnoo6K4vz6vH0prxREm4bvoT/YaZus3M6lDI00buxekHObPoxPy+RJ3oMa
4UxLzg+TaUCenzDpFK3vm86lwbtPKKpzEM4Ncs4e60n578DC9gIoNklmDaF/hJPcKIiUoWyh
LKOICISIr30lkSk4zoigJPkIwRc+zp2HaW+VqFr84aTHz1dW3lbswdiFfYjQu9H82fO2XFEU
vStDG9NkAacnGOh7XWroWevkJ7eP6TzZfo2FGOuvzAkZFfIuVtPGNFmHw/f0osxlSNWHGYcn
Zq/yQJvoDN9sIiTe6KpB7Pk6yHdGp5FLIq/YGwL0t0m2hLWJgPzh86riZoVISKgaDsaZAZ+o
cW4wtrIgboQfxDHTNseik17qPuC0XBvbJ0UO9L3kX4ETIKxGnR7D8QpeTXlCsR7lglEwLdmH
Pmri1G7KyScRH5HDKb3JFuigjaWmR+GrYKGWkUKCdZy+AGuC1StRoIgCyc2hwvGRikWlJV3x
363G+cOKxGTQndUyymim6nthbh8Yei3N9Eiuz3K8oNiuwazWEWvpl6wqTVM/gOrBDka+k726
5T6XvhyDXyWHaGVJnzUkRo/TMs+AiIYLDMcb3C2OjMO0P8gTJuZcQ4h4hCtvkDrtV/UrBS0U
WaSrAFrbfTrROYiiEpJLQpbCmqy2Tut7f982VjplI0FJW0s27gpL/HlkiG6C8PwwbRTqzJSQ
QUR5x3q+CJrkYV8/k6IfuUxmPuj6bufEinfBuC837aX5QPY/A64XjvTGEkjIxj2ym85dSEog
8sdaLAxijQbFKfoLbSYpDEO1YUXkmtimHwJl2mvSFV8iFl81wvJ0SAVFsAjlY1EoBgNDhwDV
m1iOOkf0z+iiIoJmT733cs+FF3tdgv2bWHQ6RwLP6OaZTDLgDyxTUzlugr/ufN5TLasx4+9+
ouAC53j18RzTYJu5qnU45p3SKPnVdw08SEfLm9fLzljq0T2R8c3evHvgUX8mSlpxTf/Vv+Gi
MQFjjipBjWUPipMmfxMKCfoxCT5Bffbv6TcgMl/qkisXhckK3LqXSjUhn6Q+lY/MMrSCHA1q
VWXG3Ie+w/NsauaUMC3FxuNkKMHQHIY6jMapIljyi55sQkcHyR5LUUyiG9VjoGVuv4s5yrpx
RpyB0ENL49EqHw5QY4sGttT9F1G21P0XrLZFd3F+5pzsmS5ZY373vYbwgje9jGzJBtNFd3FG
Z5zsbfJ1n452UHZ//jaLMtdE/fUmvlTW0SofhHVh5Yr14ns8inHxbPYec+sbKpr4QNwGPc1T
0reMmNfz8/W+AEV29ej+KVnr7kgynLqtg/p2ToSQintcSp4qkV4/H2LGtfol3zBJQXgx9fFU
PETv6rlj3iiqD/WRiR/iiA3p0Unwpbx3540LXM53maRCeKB7F/KxgkHjS3EXSa5beZufIPiF
cZ/9kJbfo0ez92oRODLYtqvJnJ9r7MCcv969Se7wcrhqTdpBItTTdjib6r90tBndFw9y/n6B
MNkhMjr18mlrKA6qKSUFvsZxuDW3lClFoH8WsiXyRUGvcNioasjibf3uBzU0LrHp8BbbyuUa
EwGx5tPyMelF0fZ0D9aKdSJ56QHK66Mtrk+LaRZe2aglMt4LUKQaBfWM7COOC9iLdUh1fYA9
DrG3cQBUSAzV7Coh0aijngwAl2Q+l6Gfe4KDiSpeqdFEnKpGQPKK7POqDhTzgWZsxHAKKy93
nIei/4USqAho9wyU9sej/ZVW5AmYX5vJB7sRu1ST5vRoxNr1ITcYtkhG/duZ+AJJBZnJ6kPF
7FgLq7hy2V4f0e6qj+pxS8dgWI2G2V7rnn3V+Adhx9+GXve1bcV+Z2EuAfXguBPsh7Rw7PEB
cnOrEfFFXAQVOfNYCv65e6E4SZmYMrQmQsJM4KECMU2JJB9e9BvBql3yE7SOWUayHfMJ0zuT
TDnxFd/9+OXIFd+UKat1GvVlES8gGoEViy91g45HiVGU3znvrPEffwJa9qwj6pHcr6K0ZSfc
n2RHNzKOn8vrmZAXe59JF1Zv47BELUOxAjLp4HsXYl8us8rYHi8LTxFWZnt4hnquafePiKSf
7iYVPEofLlU05l60aZxLq0Nm04eGlXvlFTkY/897EtFOd7AmOThMgELkW0lHFcPfpBilRiMI
r/0AQ9vQE+75iEHCuKqSc35sfgpAh7Tupq1AJMFTJ9kzkf2jOpZ/AwbUlO2aZeLlghzudON7
oMct0dmc7jo2ox2QtMIytbSb9Tl1coLex5KWLGyXjnLt5aoiID660Q+GVKu4s2WjQUkHxsfu
4o/yBxem7IXZ7XLpB8YiQYM9tMbriB9q4uCNbX9k4P+VpQlQmdrk3wga9pSYnhNLnG1860sr
HzV15MDudhnt6LEB6n/zM1HUMYNYc60u9MJ9j//RAvDLB4hJeX4jVp+yGEsf6XIxMQ4RSZ2H
MA+6DOIQWw27jiPXpb8y7LD1CypcmnSCR1aBkXmSU1Mu1PmLY5NRWNllpBImRlsOw6LoEdVh
ebifgzwnhxcdv6xqBYFmcWmzdvMM/7IjkLl4/B10139CJsPoaREnxYIvJRpQ68S+8uLyJL6Z
rlL5p2Msh8Hqz9HRMvABu+H2oD6tQp4atDlsiM/94SsjdbSOhiq5M4fcQVTgR5fdsXIYFzYW
/h7rex8TtnWEWTHa9qdREWlBugn4YtjrScAe/NI1WNxe618rrUXfcq17pMKsxI0zjrNOLaIU
zWZ4zpNXR7LzKvfCHZwpPGH9WoJT4H5eI+Ag+zunHifgmjgbzjx5FvOSXsTC+fmBHuqEqdV4
QXJ3/wluvuXeUe1RGIm9B0TuAE383zngyUZhHDkXK9hyFgwhQTWvrwLNwGRyGf6LO2Rkgi3C
iZ6dRvje/Y3S+Zs85GTXUO1jnr0Fnfkiz4E88QYLEPz9wLc55O+3zBzzG2KXGtjikki4KKRG
cX0m8AMnJyt4nup3YSmi65LhDW2+7myrH5V0hP6M4w1qBOsaUBy2gwGs7qu9ZPOm/UQtCMr9
sgMiDg2ESmrNwEMdcP8XIWR18kneKgnbevyaq14bcbpVFU8zIR5wcteyBK917itofrwpIhkH
UoRkUX6fZKVJJLhSOuLFLv24J9nBsmkAtU5OOURo6rmL5ebrqa5rAS6cmRTIuEvp79AW2/P7
MnP/XQdSbZt6/GCIrozHOi93Jjr7Miy9MsAStWpTcpo3RTXU631xIucy8j9nVYBnkKX0g14l
KOzp5HZ2vk87eNYX13i6llBIa2+ZoFylaAoPQ3xZXSF5EhmIWfg4LgWPLFcx4A8e9u0+SV+p
C6UgjpLwr7xrXRI1XUSz0eSYMci6+PYaj4SJ+yorfajcaKgrGn4McqfIyG2Z+w7nRul3fCdf
hUOAsmNA5kY8odM2t+dp9I7bX+dYU+5HdfPXTaUxnqhCRn79SGGsbKaor0vnxuZ8pmZUEIwm
HpkZkSnwQBlIwWmCW7qtd4Xu3xngBkW0ej3WGc8k7Tolu8sGTgKLT+/tmohqx/+rQ35Bdxpu
IpDavsGMtLRbs09zoEgcgT2xSCWgfYLQ2zp9/SgeWKvNxs7P9WFbuVkyt14wvA3Nv3AxJ37a
3+e229dj3q6idTU/MkmP0/1pdtRE+1kvq+eDAkQGwGdxOeOatQuB+RCS+XJvHviOa8ZO+TRo
Q4j5N8Qzzs2kh4HqPIt0cBjnFhj7UecEGOGoxkoUKI96F5USpltHLFOjfKN8yri2/DpqJRL1
EsLYhQTShfgbXVLS/z1MYjXs2/dNJtFSRaG+bLVtwPPIn+MXHCBGtQMqwzbkUvbkzB84/3BN
AMR7RqkC41QE0NgI/g23U563mdi9+Xf2rJugOP5rjFHSbhZZa9ulY+EW+4nhDjaCp9qrATSu
ylqG7MEZNKVpK/4EZEBwi552zgHBWi+wQxAo9zxcl3faG3ByXVtx015kYWi4Vr80NgG6SIHi
iTtTXQP+elDenp9Y4FdZCGhj4/8Jeuo+6IyOXwW4ijkGxADrKPjbuclPtIqkdEGtQzoVjUKN
44Yj9SrGnuBV/qQeGRh7+IPEVqnN4RF4bpJt2Kbc/rJJEFsahremmQ520Uac5ae5Vb/lHp2H
C/z86+2UgSxTf5SBKRkYQCh4WOxAWxnlkq7XdeyS9f57CQX223ijHJubibJ4uzAsMthp6gdq
GEQdV1RFgXM7DaMH9eg22Z+nxLUgZb8aiIhHDb8T9rp4jCmaz3UC40LuSTYLygQD4Tgbz2hX
Hv5rGZCdxMYbwU0SboxIUkq8aq0lOcFMM3jWgrsFsfgrMx6GBtUjqLPrS1AmP/f8kmg3zLFV
y4DpJKSUczB30cGMZhzIg81Gw9hXEtjKEhrnEqClI8PJNTfEbEbRR0YIDBrZ4P4GdaRUyVtB
MfTeUcDXSn62Uky7IiB0h1LtTtO752AIXRw6zTFQ1/XuEinmiBYlyTQAkxEfHIMC9J+GUYV+
oNUs6VV1iMcPydt5WMy/AZJ8t139KJ/lL+6QX04lEhJgCOKvBzd5Hc9dxLd6L+sIZXFnwk4O
HR/I3UQUuw3hGvU5IObn8GikUYoSIXsz2s1uaLO+VWrEVWoNVdkD8B60uSmxFTmDlEVRXvNF
923MhL0+GSnEABdo+Fm+/ljHu3gpSgAeGb+DsltmxIlHB016Hdbyv5gC3XCJSxyiwBXvrfaw
Bi6NjAZvL456PDV+iODZL7q87rTC5ldII9OqhWp2Lz5GWqiiniQRGrgp3TxnOVUjQhaoom3T
M8YseMWpyqg2vahaMII15gJx5HVaL6bt/ih+zWDKCCnvIkKKhKR/9Askg6kgCgLx6QW1VcOz
GTAr6CkFT3usx6G40b3/bM0Q0fS/zUNqHc1DMhBZTyqdVWmJKgy6pC+RAsrVNpMk8shcQ+xc
R9LnRzZHNkc2R9I5R9JTGFi8+4L7gvuC+4Lt+4IQumpZ86dRUUu3NMkPqSJagF9MURIgtlXe
T33c/em/aD6rEAp9/xLpjEhv8Ji6Ifyfs4X46XMw2SBV8pcHlkykSBGdFjCij/M3gKDQgF0t
hTLUFkN6uDWT+wXSn+gotOhbBdKfY0TisDDNDi/ifRSXgn2D4vSokiX7IqBZbq+HA46w1wir
2NWWzIOg6kAHJ9OBjC4XzWeOWmyDSbHmbUkyIscftrDMXMBgLmRSmViUiADGxckSt38/G3VB
/dNqJe3w6+NEWZc02PpAuz+fF6n/uuLutCGjIKRjjND/LWBDVIxSR8xXz9LwAPxA8GE3jH60
fat75UVKFW6WHBLGaUFq8D1btIg52mpmmEcSuXT2EuLqWuKNeosBm6zr/jQtq7luQNqw7v8p
Te4NV2hQ177K2Dk4KucKEN3rZBO0Dj5t5J5tv0swW22/SzAf/z5lcJ5bk5pfoo/K1XaREF7C
42qOVeCy1ZUGJXlobb2/oxWQp7iwQ7Ka3r6nOEVc9uNG5hSOZmsvvT1Ta9Fm2LdohXjJjx5C
pYF6zoVQuTSouWcr8DYfkYR1flVEMQCsoru89mSOdomk8xWXkvXRfGNbcARwBP0/b6Z3I0kT
Lbam7Hyg26mhjs/bpmB2ojbMoUJRBpy4fMwVwsJTjbdDuMV23AJqJqVqTG6eT8LjWx7jXkHk
0JljF5epMqkyqTKpMisDStRmh9jv2wj2r6kyqTKpMqky4VRbneD/7zHTCGlZJnyGEm7ltoUp
h77fSW7G1k4w2rP6rrgcZLtOd9Cr5stVFW+OtKzhumm5AQIXsn/kuoZ7cLJ8Ro7hPqie3wbK
757RZmvgC00ilULr/jzwuLRfAi/KRozK4TYVzSxqzpBJ4l8o1cCLfYX7cPoeRAQIzP74AEeZ
sNqMHeXZTKgVSWQudfFnkcCxWnEygfmaXPAIk8POHOjE4i9QodaoSqTudgcmWDDN/fU20jdI
8jbLGYDApei3jzI61u6OVxksSJGde37qPx1T3uJndFwes7rqPpmQaDSa7ccvng3Liky6SNDX
1Wl3Zly6b7LF8Y0UC+qMWRDCxEFd8d9RAnQAEMKqVVolUNWNmvWrCt8U+LFZouFsBii66udg
Hxb1+uay70CWZdL3VJmJKztHX/1jAlEtPxDCnXMM//dNUz+AI82J9SBMH9KEdnpjYEOSkSAA
FsEglLBdPoRG3pUlLDt9QuM9oK0Gt/MUKyww9vhKZRviRiK2LrF1ijs+lRZ5OvppYxr4ZA8y
nEbZ0OWy5UBdXAQufy5WBJT6+cnYMb4UEK4cLrQbEvY+8t/Cr03pFBIe53adApaeFysiuRhg
UNsAOUXFZx8O9p3ji90pjUV75Dx80LZvAtZMII798BBL1SF7q9V6q2wigz8DFEIxGZAVmMMR
iZSn3UifvUfjtn7ZVRKl9iQKUb4FmJZuWDDLMg047orLH/8VhKAtS+r7M6YSHo2iuidpKZie
m9Hfv+Nv3ZwG9TgoqNlLQkKXGKhORTSUUfUeEszx4wBAGkfEYsMVmwhF4ouZ6J9wKEypVcvF
VN3w3oqfRNaPGoIheMUAkcMUiRRDYBuQHsXHAHr5CMEXOwsnrnSQcuj/wYQJtqNKPcp1PRpQ
D7u8BBTTY/sq2ywCpE8y9rIeLpbgRzDnn7wV5xsRffGel3p5jmyPZ7xtHT5weE73cp+8yOO7
UZuxQIq544ILqTXNOxuZ2bB2i2Rj8pdFcF2XBQQbdSQxNsfaEVpMw63Fpn+pdTLj3gudpv2p
8P3ft84XjWq+jU8vVxrk0Z/w+k8OTQHau5rlhMLqaa1ggPaYyxeP9Qhu5l/cNres+FiORlY8
5VWW+a9GvcMDrOGaHZpbZisB/HDxP5lAHJ3PrKqPGki/tc90ULswKhkc/gbNUj4Zh3gGle3L
IHKYpan45kmhi79pG3TmZInuDNZt53dSXix+RmROO9FY26y7j++V61/hn6ba0Yq0K62Yarpu
ZId/80hH1sYej0el14dPEewD+A762GqDVZejt+Q1vqXDtMkuNabLeJlbPds7hjdtibX5crX7
DHXe+Q==

/
--------------------------------------------------------
--  DDL for Package PCKG_INIT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "PCKG_INIT" wrapped
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
ff0 227
/Xfre/MNkuMXVSMwIWT0HdnUvRMwg82cLgwdfy9AAP7qRoeDrFvzCA4wdS7of98u5iKi7V2P
NRjKHOS1ddFc8ybY2selUEtGVUu2QP6QQsL9Z+JnjHU5viU9V7ewtlq2s0DYc+zWKkhPNAyI
cW/EL0Mq2+s6OjHmcXH0MR6GTl5VNH4ZyZy3InyilsyN42YCP9k/ZXDXHf+z3oZLqz1v6Zhx
k78EAhVsjhOVoZ1qloZT7YOU7W1veZdNf2GiOUYGTAxg5Z+7DG//DCy5v4h050pSkPVVYD9t
tS+RUMsl1eS+lSwJS7qBM4tLtPY1S4/nBtDxEBqPjia9Zutd8ATK09kSfnnQln7gXOvy7BQw
GGWEFyZniPC24VlNFqisRhQSvZ5lPP2aPZ92XfGFZ7DHkB27fonBrAAHkw/GSOmwVG5mg6Iz
48bKb79aPKKJcAGahBsB7ygQ0iT4Wh9q+b0Sfe+8IqOrW2GX8SbiX3hGBkQxOeUdXxCzcG+C
H9RXZ9TWZWB1CO5+TVLNtB9PqjPXxoy/HxmEWg==

/
--------------------------------------------------------
--  DDL for Package PCKG_PLOG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "PCKG_PLOG" 
IS
    /**
    *  package name : pckg_PLOG
    *<br/>
    *<br/>
    *See : <a href="http://log4plsql.sourceforge.net">http://log4plsql.sourceforge.net</a>
    *<br/>
    *<br/>
    *Objectif : Generic tool of log in a Oracle database
    *same prototype and functionality that log4j.
    *<a href="http://jakarta.apache.org/log4j">http://jakarta.apache.org/log4j </a>
    *<br/><br/><br/>
    *<b> for exemple and documentation See: http://log4plsql.sourceforge.net/docs/UserGuide.html</b>
    *
    * Default table of log level
    * 1 The OFF has the highest possible rank and is intended to turn off logging. <BR/>
    * 2 The FATAL level designates very severe error events that will presumably lead the application to abort.<BR/>
    * 3 The ERROR level designates error events that might still allow the application  to continue running.<BR/>
    * 4 The WARN level designates potentially harmful situations.<BR/>
    * 5 The INFO level designates informational messages that highlight the progress of the application at coarse-grained level.<BR/>
    * 6 The DEBUG Level designates fine-grained informational events that are most useful to debug an application.<BR/>
    * 7 The ALL has the lowest possible rank and is intended to turn on all logging.<BR/>
    *
    *
    *<br/><br/><br/><br/>
    *All data is store in TLOG table<br/>
    * ID         number,<br/>
    * LDate      DATE default sysdate,<br/>
    * LHSECS     number,<br/>
    * LLEVEL     number,<br/>
    * LSECTION   varchar2(2000),<br/>
    * LTEXTE     varchar2(2000),<br/>
    * LUSER      VARCHAR2(30),<br/>
    * CONSTRAINT pk_TLOG PRIMARY KEY (id)<br/>
    *<br/><br/><br/>
    *
    *
    *@headcom
    *<br/>
    *<br/>
    *<br/>
    *History who               date     comment
    *V0     Guillaume Moulard 08-AVR-98 Creation
    *V1     Guillaume Moulard 16-AVR-02 Add DBMS_PIPE funtionnality
    *V1.1   Guillaume Moulard 16-AVR-02 Increase a date log precision for bench user hundredths of seconds of V$TIMER
    *V2.0   Guillaume Moulard 07-MAY-02 Extend call prototype for more by add a default value
    *V2.1   Guillaume Moulard 07-MAY-02 optimisation for purge process
    *V2.1.1 Guillaume Moulard 22-NOV-02 patch bug length message identify by Lu Cheng
    *V2.2   Guillaume Moulard 23-APR-03 use automuns_transaction use Dan Catalin proposition
    *V2.3   Guillaume Moulard 30-APR-03 Add is[Debug|Info|Warn|Error]Enabled requested by Dan Catalin
    *V2.3.1 jan-pieter        27-JUN-03 supp to_char(to_char line ( line 219 )
    *V3     Guillaume Moulard 05-AUG-03 *update default value of PCKG_PLOGPARAM.DEFAULT_LEVEL -> DEBUG
    *                                   *new: log in alert.log, trace file (thank to andreAs for information)
    *                                   *new: log with DBMS_OUTPUT (Wait -> SET SERVEROUTPUT ON)
    *                                   *new: log full_call_stack
    *                                   *upd: now is possible to log in table and in log4j
    *                                   *upd: ctx and init funtion parameter.
    *                                   *new: getLOG4PLSQVersion return string Version
    *                   * use dynamique *upd: create of PLOGPARAM for updatable parameter
    *                                   *new: getLevelInText return the text level for one level
    *                                   **************************************************************
    *                                   I read a very interesting article write by Steven Feuerstein
    *                                   - Handling Exceptional Behavior -
    *                                   this 2 new features is inspired direcly by this article
    *                                   **************************************************************
    *                                   * new: assert procedure
    *                                   * new: new procedure error prototype from log SQLCODE and SQLERRM
    *V3.1   Guillaume Moulard 23-DEC-03 add functions for customize the log level
    *V3.1.1 Guillaume Moulard 29-JAN-04 increase perf : propose by Detlef
    *V3.1.2 Guillaume Moulard 02-FEV-04 *new: Log4JbackgroundProcess create a thread for each database connexion
    *V3.1.2 Guillaume Moulard 02-FEV-04 *new: Log4JbackgroundProcess create a thread for each database connexion
    *V3.1.2.1 Guillaume Moulard 12-FEV-04 *BUG: bad version number, bad log with purge and isXxxxEnabled Tx to Pascal  Mwakuye
    *V3.1.2.2 Guillaume Moulard 27-FEV-04 *BUG: pbs with call stack
    *--V3.2     Greg Woolsey      29-MAR-04 add MDC (Mapped Domain Context) Feature
    *V3.1.2.3   Sharada           29-OUG-06 add log when there is a problem whith a pipe
    *<br/>
    *<br/>
    * Copyright (C) LOG4PLSQL project team. All rights reserved.<br/>
    *<br/>
    * This software is published under the terms of the The LOG4PLSQL <br/>
    * Software License, a copy of which has been included with this<br/>
    * distribution in the LICENSE.txt file.  <br/>
    * see: <http://log4plsql.sourceforge.net>  <br/><br/>
    *
    */

    -------------------------------------------------------------------
    -- Constants (no modification please)
    -------------------------------------------------------------------

    NOLEVEL              CONSTANT NUMBER := -999.99;
    DEFAULTEXTMESS       CONSTANT VARCHAR2(20) := 'GuillaumeMoulard';

    -------------------------------------------------------------------
    -- Constants (tools general parameter)
    -- you can update regard your context
    -------------------------------------------------------------------
    -- in V3 this section is now store in PCKG_PLOGPARAM. Is note necessary for
    -- the end user to update this curent package.

    -------------------------------------------------------------------
    -- Constants (tools internal parameter)
    -------------------------------------------------------------------

    -- The OFF has the highest possible rank and is intended to turn off logging.
    LOFF                 CONSTANT NUMBER := 10;
    -- The FATAL level designates very severe error events that will presumably lead the application to abort.
    LFATAL               CONSTANT NUMBER := 20;
    -- The ERROR level designates error events that might still allow the application  to continue running.
    LERROR               CONSTANT NUMBER := 30;
    -- The WARN level designates potentially harmful situations.
    LWARN                CONSTANT NUMBER := 40;
    -- The INFO level designates informational messages that highlight the progress of the application at coarse-grained level.
    LINFO                CONSTANT NUMBER := 50;
    -- The DEBUG Level designates fine-grained informational events that are most useful to debug an application.
    LDEBUG               CONSTANT NUMBER := 60;
    -- The ALL has the lowest possible rank and is intended to turn on all logging.
    LALL                 CONSTANT NUMBER := 70;

    C_PCKG_OWNER         CONSTANT VARCHAR2(64) := USER;

    -- raise constante
    ERR_CODE_DBMS_PIPE   CONSTANT NUMBER := -20503;
    MES_CODE_DBMS_PIPE   CONSTANT VARCHAR2(100) := 'error DBMS_PIPE.send_message. return code :';

    -------------------------------------------------------------------
    -- Public declaration of package
    -------------------------------------------------------------------
    TYPE LOG_CTX IS RECORD( -- Context de log
        ISDEFAULTINIT      BOOLEAN DEFAULT FALSE
      , LLEVEL             DBG_TLOG.LLEVEL%TYPE
      , LSECTION           DBG_TLOG.LSECTION%TYPE
      , LTEXTE             DBG_TLOG.LTEXTE%TYPE
      , USE_LOG4J          BOOLEAN
      , USE_OUT_TRANS      BOOLEAN
      , USE_LOGTABLE       BOOLEAN
      , USE_ALERT          BOOLEAN
      , USE_TRACE          BOOLEAN
      , USE_DBMS_OUTPUT    BOOLEAN
      , INIT_LSECTION      DBG_TLOG.LSECTION%TYPE
      , INIT_LLEVEL        DBG_TLOG.LLEVEL%TYPE
      , DBMS_PIPE_NAME     VARCHAR2(255)
      , DBMS_OUTPUT_WRAP   PLS_INTEGER
    );

    TYPE T_VARCHAR2 IS TABLE OF VARCHAR2(2048)
                           INDEX BY BINARY_INTEGER;

    -------------------------------------------------------------------
    -- Public Procedure and function
    -------------------------------------------------------------------

    /**
     For use a log debug level
    */
    PROCEDURE DEBUG(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                               );

    PROCEDURE DEBUG(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                               PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                          );

    /**
     For use a log info level
    */
    PROCEDURE INFO(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                              );

    PROCEDURE INFO(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                              PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                         );

    /**
     For use a log warning level
    */
    PROCEDURE WARN(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                              );

    PROCEDURE WARN(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                              PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                         );

    /**
     For use a log error level
     new V3 call without argument or only with one context,  SQLCODE - SQLERRM is log.
    */
    PROCEDURE ERROR(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                               );


    PROCEDURE ERROR(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                               PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                          );

    /**
     For use a log fatal level
    */
    PROCEDURE FATAL(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                               );

    PROCEDURE FATAL(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                               PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                          );

    /**
     Generique procedure (use only for define your application level DEFINE_APPLICATION_LEVEL=TRUE)
    */

    PROCEDURE LOG(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                             PLEVEL IN DBG_TLOG.LLEVEL%TYPE, -- log level
                                                                            PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT DEFAULTEXTMESS -- log text
                                                                                                                                 );

    PROCEDURE LOG(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                             PLEVEL IN DBG_TLOGLEVEL.LCODE%TYPE, -- log level
                                                                                PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT DEFAULTEXTMESS -- log text
                                                                                                                                     );

    PROCEDURE LOG(PLEVEL IN DBG_TLOG.LLEVEL%TYPE, -- log level
                                                 PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT DEFAULTEXTMESS -- log text
                                                                                                      );

    PROCEDURE LOG(PLEVEL IN DBG_TLOGLEVEL.LCODE%TYPE, -- log level
                                                     PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT DEFAULTEXTMESS -- log text
                                                                                                          );



    /**
    context initialisation
    */
    FUNCTION INIT(PSECTION IN DBG_TLOG.LSECTION%TYPE DEFAULT NULL
                , -- root of the tree section
                 PLEVEL IN DBG_TLOG.LLEVEL%TYPE DEFAULT PCKG_PLOGPARAM.DEFAULT_LEVEL
                , -- log level (Use only for debug)
                 PLOG4J IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_USE_LOG4J
                , -- if true the log is send to log4j
                 PLOGTABLE IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_LOG_TABLE
                , -- if true the log is insert into tlog
                 POUT_TRANS IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_LOG_OUT_TRANS
                , -- if true the log is in transactional log
                 PALERT IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_LOG_ALERT
                , -- if true the log is write in alert.log
                 PTRACE IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_LOG_TRACE
                , -- if true the log is write in trace file
                 PDBMS_OUTPUT IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_DBMS_OUTPUT
                , -- if true the log is send in standard output (DBMS_OUTPUT.PUT_LINE)
                 PDBMS_PIPE_NAME IN VARCHAR2 DEFAULT PCKG_PLOGPARAM.DEFAULT_DBMS_PIPE_NAME
                , --
                 PDBMS_OUTPUT_WRAP IN PLS_INTEGER DEFAULT PCKG_PLOGPARAM.DEFAULT_DBMS_OUTPUT_LINE_WRAP)
        RETURN LOG_CTX;



    /**
    <B>Sections management</B> : init a new section
    */
    PROCEDURE SETBEGINSECTION(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                         PSECTION IN DBG_TLOG.LSECTION%TYPE -- log text
                                                                                           );

    /**
    <B>Sections management</B> : get a current section
    */
    FUNCTION GETSECTION(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                  )
        RETURN DBG_TLOG.LSECTION%TYPE;

    /**
    <B>Sections management</B> : get a default section
    */
    FUNCTION GETSECTION
        RETURN DBG_TLOG.LSECTION%TYPE;

    /**
    <B>Sections management</B> : close a Section<BR/>
    without pSECTION : clean all section
    */
    PROCEDURE SETENDSECTION(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                       PSECTION IN DBG_TLOG.LSECTION%TYPE DEFAULT 'EndAllSection' -- log text
                                                                                                                 );



    /**
    <B>Levels Management</B> : increase level<BR/>
     it is possible to dynamically update with setLevell the level of log<BR/>
     call of setLevel without paramettre repositions the levels has that specifier <BR/>
     in the package<BR/>
     erreur possible : -20501, 'Set Level not in LOG predefine constantes'<BR/>
    */
    PROCEDURE SETLEVEL(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                  PLEVEL IN DBG_TLOG.LLEVEL%TYPE DEFAULT NOLEVEL -- Higher level to allot dynamically
                                                                                                );

    PROCEDURE SETLEVEL(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                  PLEVEL IN DBG_TLOGLEVEL.LCODE%TYPE -- Higher level to allot dynamically
                                                                                    );

    /**
    <B>Levels Management</B> : Get a current level
    */
    FUNCTION GETLEVEL(PCTX IN LOG_CTX -- Context
                                     )
        RETURN DBG_TLOG.LLEVEL%TYPE;

    /**
    <B>Levels Management</B> : Get a default level
    */
    FUNCTION GETLEVEL
        RETURN DBG_TLOG.LLEVEL%TYPE;


    /**
    <B>Levels Management</B> : return true if current level is Debug
    */
    FUNCTION ISDEBUGENABLED(PCTX IN LOG_CTX -- Context
                                           )
        RETURN BOOLEAN;

    /**
    <B>Levels Management</B> : return true if default level is Debug
    */
    FUNCTION ISDEBUGENABLED
        RETURN BOOLEAN;



    /**
    <B>Levels Management</B> : return true if current level is Info
    */
    FUNCTION ISINFOENABLED(PCTX IN LOG_CTX -- Context
                                          )
        RETURN BOOLEAN;

    /**
    <B>Levels Management</B> : return true if default level is Info
    */
    FUNCTION ISINFOENABLED
        RETURN BOOLEAN;



    /**
    <B>Levels Management</B> : return true if current level is Warn
    */
    FUNCTION ISWARNENABLED(PCTX IN LOG_CTX -- Context
                                          )
        RETURN BOOLEAN;

    /**
    <B>Levels Management</B> : return true if default level is Warn
    */
    FUNCTION ISWARNENABLED
        RETURN BOOLEAN;

    /**
    <B>Levels Management</B> : return true if current level is Error
    */
    FUNCTION ISERRORENABLED(PCTX IN LOG_CTX -- Context
                                           )
        RETURN BOOLEAN;

    /**
    <B>Levels Management</B> : return true if default level is Error
    */
    FUNCTION ISERRORENABLED
        RETURN BOOLEAN;

    /**
    <B>Levels Management</B> : return true if current level is Fatal
    */
    FUNCTION ISFATALENABLED(PCTX IN LOG_CTX -- Context
                                           )
        RETURN BOOLEAN;

    /**
    <B>Levels Management</B> : return true if default level is Fatal
    */
    FUNCTION ISFATALENABLED
        RETURN BOOLEAN;



    /**
    <B>Transactional management </B> : define a transaction mode<BR/>
    parameter transactional mode <BR/>
    TRUE => Log in transaction <BR/>
    FALSE => Log out off transaction <BR/>
    */
    PROCEDURE SETTRANSACTIONMODE(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                            INTRANSACTION IN BOOLEAN DEFAULT TRUE -- TRUE => Log in transaction
                                                                                                  -- FALSE => Log out off transaction
    );

    /**
    <B>Transactional management </B> : retun a transaction mode<BR/>
    TRUE => Log in transaction <BR/>
    FALSE => Log out off transaction <BR/>
    */
    FUNCTION GETTRANSACTIONMODE(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                          )
        RETURN BOOLEAN;

    /**
    <B>Transactional management </B> : retun a default transaction mode<BR/>
    TRUE => Log in transaction <BR/>
    FALSE => Log out off transaction <BR/>
    */
    FUNCTION GETTRANSACTIONMODE
        RETURN BOOLEAN;


    /**
    <B>USE_LOG4J management </B> : define a USE_LOG4J destination mode<BR/>
    TRUE => Log is send to log4j<BR/>
    FALSE => Log is not send to log4j<BR/>
    */
    PROCEDURE SETUSE_LOG4JMODE(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                          INUSE_LOG4J IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to USE_LOG4J
                                                                                              -- FALSE => Log is not send to USE_LOG4J
    );

    /**
    <B>USE_LOG4J management </B> : retun a USE_LOG4J mode<BR/>
    TRUE => Log is send to USE_LOG4J<BR/>
    FALSE => Log is not send to USE_LOG4J<BR/>
    */
    FUNCTION GETUSE_LOG4JMODE(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                        )
        RETURN BOOLEAN;

    /**
    <B>USE_LOG4J management </B> : retun a USE_LOG4J mode<BR/>
    TRUE => Log is send to USE_LOG4J<BR/>
    FALSE => Log is not send to USE_LOG4J<BR/>
    */
    FUNCTION GETUSE_LOG4JMODE
        RETURN BOOLEAN;


    /**
    <B>LOG_TABLE management </B> : define a LOG_TABLE destination mode<BR/>
    TRUE => Log is send to LOG_TABLE<BR/>
    FALSE => Log is not send to LOG_TABLE<BR/>
    */
    PROCEDURE SETLOG_TABLEMODE(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                          INLOG_TABLE IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to LOG_TABLE
                                                                                              -- FALSE => Log is not send to LOG_TABLE
    );

    /**
    <B>LOG_TABLE management </B> : retun a LOG_TABLE mode<BR/>
    TRUE => Log is send to LOG_TABLE<BR/>
    FALSE => Log is not send to LOG_TABLE<BR/>
    */
    FUNCTION GETLOG_TABLEMODE(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                        )
        RETURN BOOLEAN;

    /**
    <B>LOG_TABLE management </B> : retun a LOG_TABLE mode<BR/>
    TRUE => Log is send to LOG_TABLE<BR/>
    FALSE => Log is not send to LOG_TABLE<BR/>
    */
    FUNCTION GETLOG_TABLEMODE
        RETURN BOOLEAN;

    /**
    <B>LOG_ALERT management </B> : define a LOG_ALERT destination mode<BR/>
    TRUE => Log is send to LOG_ALERT<BR/>
    FALSE => Log is not send to LOG_ALERT<BR/>
    */
    PROCEDURE SETLOG_ALERTMODE(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                          INLOG_ALERT IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to LOG_ALERT
                                                                                              -- FALSE => Log is not send to LOG_ALERT
    );

    /**
    <B>LOG_ALERT management </B> : retun a LOG_ALERT mode<BR/>
    TRUE => Log is send to LOG_ALERT<BR/>
    FALSE => Log is not send to LOG_ALERT<BR/>
    */
    FUNCTION GETLOG_ALERTMODE(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                        )
        RETURN BOOLEAN;

    /**
    <B>LOG_ALERT management </B> : retun a LOG_ALERT mode<BR/>
    TRUE => Log is send to LOG_ALERT<BR/>
    FALSE => Log is not send to LOG_ALERT<BR/>
    */
    FUNCTION GETLOG_ALERTMODE
        RETURN BOOLEAN;


    /**
    <B>LOG_TRACE management </B> : define a LOG_TRACE destination mode<BR/>
    TRUE => Log is send to LOG_TRACE<BR/>
    FALSE => Log is not send to LOG_TRACE<BR/>
    */
    PROCEDURE SETLOG_TRACEMODE(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                          INLOG_TRACE IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to LOG_TRACE
                                                                                              -- FALSE => Log is not send to LOG_TRACE
    );

    /**
    <B>LOG_TRACE management </B> : retun a LOG_TRACE mode<BR/>
    TRUE => Log is send to LOG_TRACE<BR/>
    FALSE => Log is not send to LOG_TRACE<BR/>
    */
    FUNCTION GETLOG_TRACEMODE(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                        )
        RETURN BOOLEAN;

    /**
    <B>LOG_TRACE management </B> : retun a LOG_TRACE mode<BR/>
    TRUE => Log is send to LOG_TRACE<BR/>
    FALSE => Log is not send to LOG_TRACE<BR/>
    */
    FUNCTION GETLOG_TRACEMODE
        RETURN BOOLEAN;


    /**
    <B>DBMS_OUTPUT management </B> : define a DBMS_OUTPUT destination mode<BR/>
    TRUE => Log is send to DBMS_OUTPUT<BR/>
    FALSE => Log is not send to DBMS_OUTPUT<BR/>
    */
    PROCEDURE SETDBMS_OUTPUTMODE(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                            INDBMS_OUTPUT IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to DBMS_OUTPUT
                                                                                                  -- FALSE => Log is not send to DBMS_OUTPUT
    );

    /**
    <B>DBMS_OUTPUT management </B> : retun a DBMS_OUTPUT mode<BR/>
    TRUE => Log is send to DBMS_OUTPUT<BR/>
    FALSE => Log is not send to DBMS_OUTPUT<BR/>
    */
    FUNCTION GETDBMS_OUTPUTMODE(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                          )
        RETURN BOOLEAN;

    /**
    <B>DBMS_OUTPUT management </B> : retun a DBMS_OUTPUT mode<BR/>
    TRUE => Log is send to DBMS_OUTPUT<BR/>
    FALSE => Log is not send to DBMS_OUTPUT<BR/>
    */
    FUNCTION GETDBMS_OUTPUTMODE
        RETURN BOOLEAN;



    /**
    <B>assert</B> log a messge is pCondition is FALSE if pRaiseExceptionIfFALSE = TRUE the message is raise<BR/>
    */
    PROCEDURE ASSERT(PCONDITION IN BOOLEAN
                   , -- error condition
                    PLOGERRORMESSAGEIFFALSE IN VARCHAR2 DEFAULT 'assert condition error'
                   , -- message if pCondition is true
                    PLOGERRORCODEIFFALSE IN NUMBER DEFAULT -20000
                   , -- error code is pCondition is true range -20000 .. -20999
                    PRAISEEXCEPTIONIFFALSE IN BOOLEAN DEFAULT FALSE
                   , -- if true raise pException_in if pCondition is true
                    PLOGERRORREPLACEERROR IN BOOLEAN DEFAULT FALSE -- TRUE, the error is placed on the stack of previous errors.
                                                                  -- If FALSE (the default), the error replaces all previous errors
                                                                  -- see Oracle Documentation RAISE_APPLICATION_ERROR
                     );

    /**
    <B>assert</B> log a messge is pCondition is FALSE if pRaiseExceptionIfFALSE = TRUE the message is raise<BR/>

    */
    PROCEDURE ASSERT(PCTX IN OUT NOCOPY LOG_CTX
                   , -- Context
                    PCONDITION IN  BOOLEAN
                   , -- error condition
                    PLOGERRORMESSAGEIFFALSE IN VARCHAR2 DEFAULT 'assert condition error'
                   , -- message if pCondition is true
                    PLOGERRORCODEIFFALSE IN NUMBER DEFAULT -20000
                   , -- error code is pCondition is true range -20000 .. -20999
                    PRAISEEXCEPTIONIFFALSE IN BOOLEAN DEFAULT FALSE
                   , -- if true raise pException_in if pCondition is true
                    PLOGERRORREPLACEERROR IN BOOLEAN DEFAULT FALSE -- TRUE, the error is placed on the stack of previous errors.
                                                                  -- If FALSE (the default), the error replaces all previous errors
                                                                  -- see Oracle Documentation RAISE_APPLICATION_ERROR
                     );

    /**
    <B>full_call_stack</B> log result of dbms_utility.format_call_stack<BR/>
    some time is necessary for debug code.
    */
    PROCEDURE FULL_CALL_STACK;

    PROCEDURE FULL_CALL_STACK(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                        );

    /**
    <B>getLOG4PLSQVersion</B> return a string with a current version<BR/>
    */
    FUNCTION GETLOG4PLSQVERSION
        RETURN VARCHAR2;


    /**
    <B>getLevelInText</B> return a string with a level in send in parameter<BR/>
    */
    FUNCTION GETLEVELINTEXT(PLEVEL DBG_TLOG.LLEVEL%TYPE DEFAULT PCKG_PLOGPARAM.DEFAULT_LEVEL)
        RETURN VARCHAR2;

    /**
    <B>getTextInLevel</B> return a level with a String in send in parameter<BR/>
    */
    FUNCTION GETTEXTINLEVEL(PCODE DBG_TLOGLEVEL.LCODE%TYPE)
        RETURN DBG_TLOG.LLEVEL%TYPE;


    /**
    <B>DBMS_PIPE_NAME management </B>
    */
    FUNCTION GETDBMS_PIPE_NAME(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                         )
        RETURN VARCHAR2;

    FUNCTION GETDBMS_PIPE_NAME
        RETURN VARCHAR2;


    PROCEDURE SETDBMS_PIPE_NAME(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                           INDBMS_PIPE_NAME IN VARCHAR2);


    -------------------------------------------------------------------
    --
    -------------------------------------------------------------------
    /**
    <B>admin functionality </B> :  delete rows in table TLOG and commit
    */
    PROCEDURE PURGE;

    PROCEDURE PURGE(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                              );

    /**
    <B>admin functionality </B> :  delete rows in table TLOG with date max and commit
    */
    PROCEDURE PURGE(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                               DATEMAX IN DATE -- All record to old as deleted
                                                              );

    PROCEDURE SETPROCPARAMS(PROCEDURE_NAME_IN IN SYS.ALL_ARGUMENTS.OBJECT_NAME%TYPE, ALL_ARGUMENTS_IN IN PCKG_PLOG.T_VARCHAR2);
END PCKG_PLOG;

/
--------------------------------------------------------
--  DDL for Package PCKG_PLOGPARAM
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "PCKG_PLOGPARAM" IS
/**
*  package name : PCKG_PLOGPARAM
*<br/>
*<br/>
*See : <a href="http://log4plsql.sourceforge.net">http://log4plsql.sourceforge.net</a>
*<br/>
*<br/>
*Objectif : Store updatable paramter for pckg_plog.
*<br/><br/><br/><br/>
* This package is create befort PLOG
*<br/><br/><br/>
*
*
*@headcom
*<br/>
*<br/>
*<br/>
*History who               date     comment
*V3     Guillaume Moulard 05-AUG-03 Creation
*V3.2     Greg Woolsey      29-MAR-04 add MDC (Mapped Domain Context) Feature
*<br/>
*<br/>
* Copyright (C) LOG4PLSQL project team. All rights reserved.<br/>
*<br/>
* This software is published under the terms of the The LOG4PLSQL <br/>
* Software License, a copy of which has been included with this<br/>
* distribution in the LICENSE.txt file.  <br/>
* see: <http://log4plsql.sourceforge.net>  <br/><br/>
*
*/



-------------------------------------------------------------------
-- Constants (tools general parameter)
-- you can update regard your context
-------------------------------------------------------------------

-- LERROR default level for production system.
-- DEFAULT_LEVEL         CONSTANT DBG_TLOG.LLEVEL%type     := 30 ; -- LERROR
-- LDEBUG for developement phase
DEFAULT_LEVEL         CONSTANT DBG_TLOG.LLEVEL%type     := 70 ; -- LERROR

-- TRUE default value for Logging in table
DEFAULT_LOG_TABLE     CONSTANT BOOLEAN              := TRUE;

-- if DEFAULT_USE_LOG4J is TRUE log4j Log4JbackgroundProcess are necessary
DEFAULT_USE_LOG4J     CONSTANT BOOLEAN              := FALSE;

-- TRUE default value for Logging out off transactional limits
DEFAULT_LOG_OUT_TRANS CONSTANT BOOLEAN              := TRUE;

-- if DEFAULT_LOG_ALERTLOG is true the log is write in alert.log file
-- execution on sys.DBMS_SYSTEM  package is required, problematic to get this right.
-- That's why related part of code in PCKG_PLOG package is commented with <DBMS_SYSTEM REQUIRED> mark, uncomment it if you would like to use this functionality.
DEFAULT_LOG_ALERT     CONSTANT BOOLEAN              := FALSE;

-- if DEFAULT_LOG_TRACE is true the log is write in trace file
-- execute right on sys.DBMS_SYSTEM  package is required. It sometimes problematic to get this right.
-- That's why related part of code in PCKG_PLOG package is commented with <DBMS_SYSTEM REQUIRED> mark, uncomment it if you would like to use this functionality.
DEFAULT_LOG_TRACE     CONSTANT BOOLEAN              := FALSE;

-- if DEFAULT_DBMS_OUTPUT is true the log is send in standard output (DBMS_OUTPUT.PUT_LINE)
DEFAULT_DBMS_OUTPUT   CONSTANT BOOLEAN              := FALSE;


-- default level for asset
DEFAULT_ASSET_LEVEL   CONSTANT DBG_TLOG.LLEVEL%type            := DEFAULT_LEVEL ;

-- default level for call_stack_level
DEFAULT_FULL_CALL_STACK_LEVEL CONSTANT  DBG_TLOG.LLEVEL%type   := DEFAULT_LEVEL ;

-- use for build a string section
DEFAULT_Section_sep CONSTANT DBG_TLOG.LSECTION%type := '.';

-- default PIPE_NAME
DEFAULT_DBMS_PIPE_NAME CONSTANT VARCHAR2(255) := 'LOG_PIPE';

-- Formats output sent to DBMS_OUTPUT to this width.
DEFAULT_DBMS_OUTPUT_LINE_WRAP  CONSTANT NUMBER := 1024;

END pckg_PLOGPARAM;

/
--------------------------------------------------------
--  DDL for Package PCKG_PMDC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "PCKG_PMDC" 
AS
    /**
    *  package name : PMDC
    *<br/>
    *<br/>
    *See : <a href="http://log4plsql.sourceforge.net">http://log4plsql.sourceforge.net</a>
    *<br/>
    *<br/>
    *Objectif : Generic tool of log in a Oracle database
    *same prototype and functionality that log4j.
    *<a href="http://jakarta.apache.org/log4j">http://jakarta.apache.org/log4j </a>
    *<br/><br/><br/>
    *<b> for exemple and documentation See: http://log4plsql.sourceforge.net/docs/UserGuide.html</b>
    **
    *@headcom
    *<br/>
    *<br/>
    *<br/>
    *History who               date     comment
    *V1     Greg Woolsey      29-MAR-04 add MDC (Mapped Domain Context) Feature
    *<br/>
    *<br/>
    * Copyright (C) LOG4PLSQL project team. All rights reserved.<br/>
    *<br/>
    * This software is published under the terms of the The LOG4PLSQL <br/>
    * Software License, a copy of which has been included with this<br/>
    * distribution in the LICENSE.txt file.  <br/>
    * see: <http://log4plsql.sourceforge.net>  <br/><br/>
    *
    */


    -- puts a key/value pair into the current log context
    -- putting a null vlaue is the same as calling remove(pKey)
    PROCEDURE PUT(PKEY VARCHAR2, PVALUE VARCHAR2);

    -- retrieves the current value of the given log context key
    FUNCTION GET(PKEY VARCHAR2)
        RETURN VARCHAR2;

    -- removes a key from the current log context
    PROCEDURE REMOVE(PKEY VARCHAR2);

    -- returns the string of all mapped context values
    FUNCTION GETVALUESTRING
        RETURN VARCHAR2;

    -- returns the string of all mapped context keys
    FUNCTION GETKEYSTRING
        RETURN VARCHAR2;

    -- returns the key and value string separator character(s).
    FUNCTION GETSEPARATOR
        RETURN VARCHAR2;
END PCKG_PMDC;

/
--------------------------------------------------------
--  DDL for Package PCKG_SNFR
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "PCKG_SNFR" wrapped
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
59f 17d
Sn69/bWz1/cSLyKc6v2o1AlHWJAwg82Jr9wdqC9AALteWSMp3ymvBIY1hjcCk9tMOWWpzJY0
tbrnkXngWTK6hjtGyDiF/sEogo8CbkZgtDCtKXYRXS5J5lsBhWjAFFY8kIwvROkw81ZPNprS
v8TaU6pGzTdoIvWy0ooU5dvnr8TWVslddZqkOCxx4PRYft82AT+XKpsHLVsChCWZRAH0Tfdt
Nx6azM8qfwxc4JxmyLf/nfts2spkqVh5UL7xD86B/22s9Z6dDG5wON9GxgCKSodzA/3ycNTz
XA8LjKdiluq+PIQC9pZuccSiK0a9XErgdQjQqwPrwT5xRcFuub23CK3M2udroFBDOvkX+8iO
drzr8ZiSpgxuPlw=

/
--------------------------------------------------------
--  DDL for Package PCKG_TOOLS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "PCKG_TOOLS" wrapped
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
962 316
NQX+NbnAVbkIRN5LpLuU1I/mhTIwg2MrLm0FfC/NrZ3mVokwOL0FCSO0JdZm2UqrQhQas0jH
JWsHHKO05vi1JhQF9NPayc11Z9KBGf3XAyolic3e1/qQyfiDjAklGTtGTDtaMHWujGf9HBKe
Vglnm1myBcxOLc7kKUF6EGweJCQ/c9K1hw+qtUyq3veNHUDm+yY0Q0cgrby4y0QYQPiXTdSZ
yu7qCV0oFPBRl9S5tqHPdIAXqan2YWh0+vZKIuE0HQhVjHmUp0v1NvQ7Wol5V2LJZ5TqX7aT
SDu16GEiFJkC6a9+85h/bfcDchmEWk31sl0LA2bocjKDf1XyGcLVV15X8UwiqENJL7xNdo6y
RElDNlNt+M0npHD0CYwmoWWjg6UHNIsb4SxJzGkYdU2TqDN1OswzvHEVPK9rgd0lzkBA6oyz
huIr3c+FsdO6IE4yvC3ZkEwRzWYgIGW/YZhzGFLHvn+XMCtvEAu4xXTnQ4csOBO8CBwo7K4M
oEefsHRBd6KtD9Xv7MiUKk2PyXpOfjUNp6yz3/ahwgDG4IMiX+XJ4y7cKmuFUFogjYJf+JDC
VPXNK3wTVXZJ0wVnJA+r9BshC1n/QMArmVPATcfnx+TPBWxkTbdaHMYNHbMbF/8dBJKZY7B1
22S+rSsa1GHgpWAbOF4Nd/t2/ZNvoGSJ3hbcUkE9YfflP6Xlm+6DS0npijQmTU+zGsUcrHDa
IHYRoTd21RISTn1AltnCHSEH0u2RT88g4HqW4lvziqiwCsMEMP4sRCt6kQ==

/
--------------------------------------------------------
--  DDL for Package Body PCKG_CRTP
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "PCKG_CRTP" wrapped
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
6e49 12de
N6Uz7YSM5bgYeZlQzV7v2BYZmBIwg8129iAFV5u8G52sxN2vm3knGlWV+7oPnoXTzU2NbJCi
bNdJr8FTuoZoGlpu7VVq+c79CRrbnH76oR6gS8wh0yp28U4GuFeRBiO7aL1gjLSd5iQUGZih
7mMUOvtEMQh/5qGrErRyXl/CRhAWenjSjz7K+3qU9Az/kJlu0+S852Y2tWA1XejqpealNrCp
UVW7NgItHh+8DHyAoizaw8azFOMO4rW0P84wia5X00Ywc7EXfaAMFxlbGqXPMErHrFG0bbfV
jkPrzLBBjyGQybesUWkvTFMmv7noZEVrm+AsE1OfKcNavVW0CiLKHe5rUMYFqnRf+cGUwzwY
hZDgA5OWSmUGYBon2zrGchA2WSkqbQEgVO9PGkjAh6J/PtRSHPsPpRIoSRTjjNPjDLiyDhBy
m8zMJuZ/n9ZpBxazjoivoR0p5eKdehCBx0/EulM4VM7vxSCGVArdiX+9hvqpjlHCTRvlqTQe
zbj0Y3etlI8OdunsgES9dPxIHZbkcHoZ4UHof7aWx1B2cTc28rfNXe4q8v9UveUnUxEVx4zg
Rpnx4EssxVJgUnbgnIJWtBSLn3c/IpCHeZHR9bwG2Dtb5FvCiu22tJkGSkB9fX1N06jOESCV
2L/DsW1eLJ7W4721MyPxUBs+My0HA1bcuoGg5X1bw9UAaLRcJP+AqMmBMI3eL0Trz4NBfUha
uKu+FFPdspSXYOU5aP6vjlmpYyD97lJdSX+g7Q2ENV0NlBMlS0M+bFZf/ehGepRh9yXnB7Tv
FlJedvcGeXpRg3GeNKaIsAiO83pDK//GvdK2gBlcr1nspph6xnzp6oIWe17JXvtDCWob6KGp
97BZ+7eAcCWgy7nEF8WIRLo+PpDb1d/OHBC3d88UIv9aZwHFSnC8cl4zw2sZ/c0+X8V0F1oc
UfL0ej5mdln/gFJBHE3uxpyzCylrYaf7HCgkeBgh96yvX6UarIuqXWZVUqmtcWLO8+128kvC
IAYWyGO7AqoPRyw8mXeEqvmhc3j8ZHy1socSHczFNEXunCkCuLEexRU64kyOFm3P0ZbwiTji
/aSnv/gpTmojYYcZGQ4F9vXtzjRTvodoR5xtEiGYvmBPICQk2M7BKBFCHd0RAPj+Jy01BCMP
EdIAophz6JE1rUAnbmjWGnOI53i+jgA7x0rCn+Z9ivBc5J+6+n/13/S7vMrVqqncifVgXGTZ
NsWHJaS3NN/Vf1xsmMq3Kxd2WBYxRBOg5oa0oqEP09BwcfNdZPySp24LWFMm/ZG0wufx9ctZ
Xnxh3roD7BBxR7UDNDqUc9+6YmSz/J85Rd+6ljOMxc+effchxgBFfvQCag83fBK7wUhUjYno
pBF193St069XYZ0M6WIXbTy2YNmtHYEBaoWc2CcL89iPPp/EcfjFm2BENwMPuoQkQLG/xMT2
0gUGSO3Oc93N0Wif9QdNn7jdW2UM+BK3bwBR4Bht4/nDOFFiZV2WK5m43zwDmA8fzxVz5RXv
J/jdeY+31DjyEu7KyfEaoR3nSKcebIW1tcWaOO3O0jozSJ/+W0UPmgBHsSi/bfjtX95Wb00+
My9Op9mVJ0Qv1FJmLaP0iFdRiw6Re/bRl4TeI8jWRCulH5ZccGx1LQ05kBARKP41RQvZ5/Zz
Xm5QxUWM+02gJVtkFbygYX42ANLJ8BbG9vryigYUFw4H9iezNV/Bwmrk+xDsc7zkIbprHkNz
I5+CW2RCEG3JCpQDztk6QaJxZYY14/dqk3+l3Xvz0jmQMxMCkFuok/6Xo4bK1+PFwnoZwee4
CquFXkZhQLAjF9gp1ZEJ6TsSpw5JIVkXYWvhPeRl3zxyfrWVcczZVf1aONa8rP99LE4hkBjm
1sCeMnc5OUMjmCiC67SygjBQblCLLWXOaznlIxounxUO6TFeDbL26kbFeCXb1D8SxCHJl/Ny
Ce/FmAn0PNBaeZyEdGIL97Pt9y0qMzQ4NAXVp1WNq3arWl1CC5lBwNgFhReGKS3cHWoi+evy
K9nd/VmwDcef2n72WiypexQ4kfKuaisMLNL/7rInNCxIPNI4UnPVKj0sF/bS7jO56wDsazqk
MFbHfENPFx7Q7QBy4sLzPEJmeICGTvzS6pPPSmaF3QdsWa14BBBKsM9pQBr+YKcpb0clNIOY
QyB+HO2Yh2gtzgkAIOHq2270p3iaZtqf7+2Lpvq2xQvG/9iPzzu0kuHtz6tjRTY8Vi9TuygK
KjK/XVzy68U4lnbYBGYbhuL50E0XMGfCs/BlTcziCv050NFofMb8e6s+9iW212GnkFAMLgXl
hFTpBqJOVPyUxIftNW9sTbw9KM/yHmJE/SZeUvN7Mvq9/PA4EImQ1paOnR76CACt2FSxtulJ
49tEBaCLNd28K8SeZuZVViwBFDJXnghDNis4c7bS0/mhEzPPgzsVYUsRrUjnVp+35CslcluC
5BU7w9K1m7K9QBDup1dtlDOjVwrJ6Lhxd9TSB7J8WS9u1HKIGyHlblMm2tdue91Z/l91zjT3
v/fcL6RAE9ybPkpa1Pt3r4EF22PXpW+ZSFg1uYtLU8I90uaMxOUDblMxneaj0bYrCu/VVmfr
6h3UUXUAfavyBhQo2e2XMF/j2uEMmnbWovW4cCGHhbbp79koI5JVHim0bEhTSQABRbDNfM/a
GMaBPtxjVyJexQFJibkYjAzE0qnZIYQWVeXoW3N6fcFOUK4QrrA7rLyDmKybRHRWgHANptW2
o4tAt1eyhTrD6/rWvKTSzUJ9unTg7Ml5DYpJeUt5PdiNQQ3MITxM2wk0KMX1aWtzJi9M0ipP
mYhIV7Hb5Cp1ZlrINQJHsyiUjbAByNDGSBzxPICsHKpNfT5KjgAxN1Gwe9x3m3zz8WUys2ED
ovIUwu5ZzNnroux80tg4uB43LAXMT7LGEOwokn5Xiowc2/cOk3BhcD/cNcLF6T7ZtFSbfmn5
NyCq7+r08af9Rckun8sg41ZpbPHcsqnJ8nW6IcpJkymyBLTvIxH6V+NmPQumi00KKrqEDZ7d
TfyYIU80U9tUey1e/KkdOdKgIPtB1Pf1IgcdtRodmB+3UZd6sTeueVBfYZuv7GB9FJWLTYgf
Sig+hrAzXWLh8YbMJyb4iCtOpZS2iBO3s/xB9Nvpf5yQ3rD2fmrtD9hvTioJbEMey8zfOqPo
bOZHAaYLiG+DfzhhwRoRDUGNvTNPGneUpnRn2jGv0b1sS4K+Rhk9hurBKj9nRMrtQIIMn1GH
cvkOmL61TFb5A5xiZz1+7SLVwSzTxjjfBB+2WbT+MEe82tNsDbIc0x9o2+PwFL0zNoHPnbGw
KXobdoKlUOOscXcRg9UnFF2wE4GAEYucDz8p3ogHpDRdxvd3fLtkk6oUHbbJU81UQT0Wo38x
aCAti53fuZ67BRhhKViEDyahfbgchHue6yanGk+YdwtHHsPMgYiY8FAQftcl6orDDdLvv3k7
XgCLgp/lqJhIkNWnh3GA4KX0sF47cNOVS3fojikbC5zBY+3fGwHc7jdpibYMm8l5e1YsbC2a
pVihxDpM449njUOyqRhd7LjgV41G7MpjBMuXJAV8IaoXZsk/K+hDdBKV57YOLl1NpMHtfe94
XqJkHeYQoXCPVmMlYKnoz6SS2g1SzHkptKkOIqNcfbRObds3/ZQE3vqiwn4rZZPHt8djN87e
zz4bvCIYlnBrLnIZyKk7xmDqlOae2QlGETjtFjNSi5ClvzMVWlhgPO7l2S6JWDnyV+i6cruF
vCbP6IW5KAw/2Lnh8ouox2gUvR3QoZQTaXlS1VJXWPNs48jvpGUXAX4aR4FAUfD202y+GITo
s5OQ6Xcf5V6w2O5/efJR28mzJkTg/Ly/ZT7JsyBBcYMI5eArYGKEDD8yyaMM/zUsg3xkFSvM
5smo2HUZGJszxwI0tNPijo9EwztS5/Ili+nxuvdDHNeL/cE4MOnH2ZHeWBpSQYX8PvRf1Ctp
C0i8RIpYIjcAAvVE9xtMg9JGWToFi8yk27jQ4Oe3RAy0qWxEemA1ISkNlGfWY8qsjYIlFkaE
unHaQdwd3l4RtTprYdtQhHt9xDRJFlJOmIX5foX+oCzJ311l8Gq4XSO70pC4KrJ5JPi77Rbo
sxKcwWS0hHZbQ5IcjR6+Y02KUXhkM+h4sr3VWzutEdcfs6vvlunZfKk1WEI+Ykh+I1ngl+9I
VQCRDc8Lk2IrzCMZ3mKAgKlo7779J72Zgxy5Z1Uvi/SraRBO1+0HzwfLOstyhtzaEtTWUifg
DP+ETmCKQcKkn4W4UIHgrvTLgIBLRcQRJiP3XCmr4aX3ops6fiqAAzqSOGHlu6qE/tLArPiB
wNyWGDiUYV5PN82iME3eh7dTAIjSf8QUIrONQK7HkO63TAHO9bEEYVMVSzSdo53dyBlA111f
IiEPo+csCnpEXMpYLxk/tJFUvPFZg17TXxlXfk1DlSBJPce++PKaifgGX1Gr4hkhGiAl0c3z
728fTiIQQ2/8Fv2ykaAG7dShDFbN9pUqerTVH1fUPI1ded9pCcoplfNCBKsJ2+JuguQu7EgL
j1C5cVKCGkqjnVsOVl71dvJ13gEtv59PNdfI9/7RNTF9VINlpjiVPgVXEdz/7yA9qUs1boJ7
SsVudABN4fis+1Za4v8c5NaDkzxq1/0gqUGVmir/AEyZWUWT33c1l50kPrDAc1r7nJDLkmv8
zVjAlovEZFvgQ0kuYMaYTFmleekKxgNDGP8tB8gFqF2f58Ms4T1bO0I8Nyf2ULgwX+n/W0Ss
NflDtW2rlIE=

/
--------------------------------------------------------
--  DDL for Package Body PCKG_ENGINE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "PCKG_ENGINE" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
24265 4934
/j+DWwDOU6fw9a0v+FsIPSrjlnswg80Q9seDhWEz+DLOlBDcPT5QX0dwcjQmEAaPXjaRBzbv
ZvRx/x8YtMAVSh0xqRcbXPjGT7wmPb8Nph1YhY3sLWO5Kw88/IceKTKIMkVke+r7MBwzGda1
djIPTC6s7lyqBOQXO7axpuSI6Th4ffCMptvv0kjAlBS3nO5O+g4sSbIJMCW7LpKEprWyxrFy
1ufqoHPOyj8sSa+BkbS+yxE9eJBN+FG2kK3DuURyxuqgq6m1oawKyiODOWIHRVVXrLUoxr0E
QFW40hyir2zPi2mCMLGuG1VBVAVC3TWOTMbqtsNcEQ7bSzi2VUsfTXmJKdumO5wtHxxIGiwD
YSenLCsb+GPaNXesH40AngdSJYgbipnwSZ0SpuJcTITcgccN13i2tCkvKHoSoh/kcdG3NrvT
Mxb4aN4eir/Qlp4pSBRZbb59yorSG+3cFbxfP8GZ9WCMNZ0FoZLuL5upvPaMfEr4clv7qwF+
fT8hHJ/OZkVlCAr5EY7SigHxy25EEojOOzgs3DQ7Wb926a98WDTnxvcmdKMhesnZwg5leiq4
xxAzKDjlgKTkNcP7/xe4lGC7mR4WAvBst7jPgeAE2y1jZFKlo5EfVaNgc3z8Sbt5AY+rFIZT
MIfx/u/XNOSfG/U0ElUTykoyyjyPTFCkSeNffnMHE0J2wRCR15BztUkGB2rubBTN298YFlqP
7KiDLES44COD5rGQv9Mpq56vlsmRF1axmUnuE8rmzyZsBR9zNXKjrPGTUu+xc6j8zNMCHcdr
MM/wkwJQnO12q1GEfzfa8Gy3fCl0GOxqZEkgcDVUNhCaDRG7wMhTp+lqxFn1NYDeJgZCXZ6j
SfHV6iG32AebVq0f39e3YUveUSPufF99d6M89I6MYh+n79fpuBJKFcRzQS2oeb1m668u4W0R
f5HWCGna3MXklInWmNtXqyViWwwcaBw5qkZ5sIIEWSNy936/iAaAVBSkshUKyWX6/L1qawIx
zKKd0KJfb8XO665oM08g9uZ4T1u4ykBgONoG1g/dJibGsmsU88esnSUTBzKe/I+atWDh06so
ItPuT4HJMyG2E/8ssB80dflaT4WRm05x0Uc2ycKOwudAG7CcGbAeMeTvU7rRvKmB0moQnspi
8/qlgVcEW4GA/EikDtxxyAGoAAZFtJk5pX4dnMwwsrXTEhT0MSAPNvN7UjGOHUJFDCh2oVvM
UCntJOWvA4fN3uFQMxAyz4Jn3I1zRzXoe3ZVVpGkBfohFOtyEdP5dRkkGnBSW8A7Hh71rXPx
4utDOBvKQLapbHAwo5/iCKFKRVy2ovhpd46+nPUGRaEhdY9vj35gvsnXyW2gSnI2tO88CUxu
aP9LgAyfeBM8JBt4KNkBew+uImIcywCMaTRIbnPLP0AXotMyRaGMsUKuG3SkR/NuJyg/VxL0
PWkIO1t7f489w1XlBBnrAt5LGZFD8fkypkOJHvNX+1XcbiEw56Y/0O3GD3KSUZVMfXgjC7Tq
OBCfrbHOR5SL7FqUJaMkbGzxuKzbsEBXlkH9gRZFGQgIG3EopPOFAJrshPhqPyW7dJK1DLgs
vnOyOp+W9a9Nk6i9M9T3HPWr+L+E0+z/IC6U7N/QWNP5dc9M2CuCFsBZ+b7OSwl9NWdiDFBG
poF8rKWvistHH/a4xDB1mqyVCYAkzW9UqvLBoyXsO91qxe15HEDCkpwjUTcA3Ic2hEhYXDQe
3rq6Kru6fOPprfJ3YKTeumsgvCgqzTGRFKVmZcET4gqwT43/OqyvmEh85tqwxWDLr3yiBcwX
wIhKOBIlIf0O6Vk2Rfo5Br8Hdhn7takeEuc55GVz9sKSeviSKu09Tg56IoDfidFsvBNMk4r+
PP3CtGh/u5XgrpRlLw/944/FTNb1+VLfruqPOUjCHos3nP2MN/BPACzbhh45iegdFbEx2MSu
f17WXjT7rG/goq4bmR0EKf3dxtMhhPQbSVifAPbzHY24MzPcW0CzxTZrYkOh8FcNqCqoSliz
PBEIge4/GPcYhjd9kmpX49PmG+CqDof+g1vOsb2+iP7HOf4ngwsqnpolwrIoDgWoUOeMHOSa
Tv5wzslQBGd5uGUcqPsxgAPjP953cqM7PKEejvkdsBeuumLOZLnWkhLOx8AQECUeNx+WQYf+
T9RSpNXYTCjFp7Bav6AyzKqjxue8PKbIMYuxQuspKKXND/1u/ChDwEtfQj2tdnRKFzp8T4zm
Xha0VS4X/iliZ7Ax88xEsZo5vg3RIY1wb7Yxsp++q31Ise05mEG4ZKyijMG4rmIxeM8AccL/
yoq8xa3K+eAZ7Ssk3w4K39ZvHetTkxyI39bOAetZGz8zgyFt2Kne/7j7Huz4Dvhl9OwCbVnZ
MeqNb8LR7x4DeT3PyE8GVZxSt6s7ypNt4rpMACV/aclMVOR5HnsG02jCKXiFz4juYL3G4dVY
9AYBTU1UJSindlCJabq9V+DHArjjmFryYQiKyCRfXFA/R67gquerfqvuiMC9v04O6v7SsnSs
2RpwdNi1RntRj9PrNdclqsk76xsUCw7AwAalbWGWvYNFgceA6h+93X1Z7CTPOsjR9wmJkAkH
2uwU+lOx0Lf5SxOmwj0wo33xgjhpAbr47cMbH11HsJ45/+avQSHgRVojeXVPdHJCVcxej3Ku
AxOuj8l7WywJuCQQdZrP8iAohETCAA69wqmsjVeRiErTE0LUMbzFVPSLEzsLpmeXqMg51YBS
fCCOZ02Fm6bH8wkdW9ZwUNBkggpkapq+7CMrtpM0bsOavu1ExCgPvM8d2ZVP1bjEVBwxdBbT
NOgXDq+zxKnV7gpiuWOWvAJfyT8xmdHahvsoZs4594WxVAqbZDIlX2QfcORHjveqQHnudBOd
T/UG6jRCUaXReMQL0AA6NpfcHOLgbVtac+4wfC8c42RSW0uB5cny0pZCRfV1t6dDHvLBhdbs
uFfg7lu/bMY/j2rzLYCOiE3U2VmgordpORxbCQIqR8y20LNgh7HbyMpfqeLDJDkRdECCeeSB
n0Xc++1y7bVAuBkxYlSqrBOx/IUwxP2HD/62ua8yL0xERDRuqVJW5Tmy8iZRSyXm5UaNMX87
FgKiQYBojfZ/QD3ntjRmohP39OaD0akUpNWxrbh65zXm13Fb5/yzxIYfz8Hqtrn+x8zp6V0g
fs4+pcdqERwjrDjCznsnBp3MXrafnbb4YigwnZFsyDLimxlOqcAMjNHoRYCMRAFqOJhyrs5b
K3jFDQbPbbof4t6ahmMu8AABLDz2oGjqvu2WCuOpNdbsmT74sOQHlLFuHMCTCXWj2XXcjdgX
0n5/yHtlN39PIptuq6tQdsxDn3ncc5Q2+w5V32e82JP+Khbj0NE+oBDU6CLFlZeB9AkXSDXG
lCpElXzXZy40i6Q584i89e37ReChTTy/gC5OpFs1qMLTVYf9PxgFnvq+3wY80/SLUy+uNF1U
thwBgKMulbJpzAj1bJhmqL06e4gy+z8EmwRBTxd5A1ycVHZBVx9hwurMVxyo9U/MRluPGRSK
NaidOsGRd2BEE3vylyklWpeRS5fFQwcdtaTXsfae4xRP1ZXrxVzHQQ957VH0p8VYRu9jSvXJ
wHdDsQedn/yHE5TMM16jUWiXkdoTSHm0vFP6/FoTJ2Eim9yjxOrR7fIJLpwyJ+eBnkNUDQ6n
uzo9kTJhca6TwJpUn8GLmerRJNdxKv6tGfLMj0nhGKZmld/g+4UgSS6zLtP+qP+6AkSblt0o
TrvClgby9OJJk8do4K85Y+s1z5Yq5drfekOPBOBr5EW39Q82o/bKnv0hw0Q1AqbSI50Oih4h
5HGPhoEr6N0Ko5hR5U6Svl+Kahlf1gT8ImL17jf5tv2ORFI3oX9jZGjFkhXSap1U0Ibog8FT
JtKrImWB/ZbwAZOFja2OR44m2CbijnuTKtBzrOWFtuLXVS4pCHffytQjRjOlRFzY3ucnpCIW
znAb1+VV16daJ2exQQbNWbpeKyUZpyUhx3kCHTOZDNUe0JhrCQIJzBvTca5rdg2rwSgY9l2q
Twp8rBl2Y/hLcWKn5zGAK7mP3+2+T9GwHjHgSnkvbw9ez+vWDteB9YFC5rKPp9vRnu0npcQ1
GWvIGbkO7084hhbL71ED8oCAD7+NheKJ8Y8BorvYc+QoYObKiDINoOmXwpgRksQ65Vy+uD2D
Rg5gfpwKlZxk3eEf8EVhRWlwXtQoPrIuqYxc4SKncFJJoVxelBAQE0Vhmdr9gsd71+/Toty1
tFmTittsFBl9jlUBHlowL0DvY3IBV0iAbhfnyvse6bAVISm82AW+oS7X/c2A6ZGxn0RsqeqB
Tgvs2iPi1gYMxTiY8qD+Ksj/KiiqNbcnf7f60VNs3KqCPovHBe3EvmDWH1wI8QzA4tyJQy7F
v3xCRU6jEDNtSJrOSIv21aezuDiVreKJaTZCLL01doi1dinYzfR9YjOk7PRC7JR3kIxNHNjo
YiAinLMA89NiFObun/Ae9Tp/bJ83MwolLsneWwXhvwwn/BqLpyG/cPkxSJZmBfSgQkVO8u9a
4xsN7Ce6ZLErqV5EV3Pt+0mkSomzceDFj5FLSHkiAwnKkXNUTN1ak+BnlxyIFvhSDpbzOfHX
EaV7XQiET/EK8eS9wh+7KPh/BvSlXFVeCsJTa0JVivdyftHeNBuuXk/pstceF9DPuMDFsX0P
i3+jAS+EaqDQFBNQCIqh5HKcC6osRzy4qg9HK0zvp8FrgxEyFPwwwafAdWCrPGa474Cvs6W5
83hUfOBvV1MQrweuTvurNUlFqw9qHcXoRNtSQuXO40dPzdwp5Qwjfy5qTHClNOsQY1jF0WWD
+ia57d2KCM5CbqLwzoGmAP6vPuSAUar8xZvYywoOJIFEQkHiKISKXjnjmBDzuCt/HtDG2JzI
ejlbyStHQKhd3z5xld/kv5+O5AdbRLgEHhj4xbnae7mEf16p7uZhJA9jDHTZyRwAd/rFmOBE
AzojUnRrsqrFpdNyIwLm51Mjjl6qF78fXbI0lziNVtIw9MVE0U0nAqglz/LLjF8XV8Co6PvX
DD9j2Hit7HzqVCu7Pg88SSx+LJFmPzFHKzFbFmE2GDfnLAYB8+3UayOUv0Tq9dBAjUtFvyCK
JeK7QTGTBVpCIv1Qi7xO36ubLTct1tXaf4Sfay8fqhCZiZa+sNqYTZij8qaCEVa6SrrkvL79
skLhrWqV6DAfqGxSUio2JCKu5F8br4LS1WUs1qq0CmlKyB1qSy9rz/UEfxZ0GEROmbmTlgT1
Ge93EW42f86UbnPLtU4aRBJrohQNM2M12k5h664vSIFmm6/6qhckQSf6GJyen6nZiLM5YmT1
oOHSgFKgrM/xDAWVadUF8ZSkFe+RVlcpRO8WBTZquRK0r4fMMDZo+1TcmBPJeEY6+F/5XAVh
AJ4ARN/12fUj+NfJob+JM1JX00Kh1a0KaQcukGDXZsxK1ckfj4VY9JnabuzmhunA/bFbmNLp
mW/ZcXFtlcLTYnHyvFEydhrFD4N18pPKyZva+YNhG+Nj/5BHm7jD/Io4yaqMslk5LdrZ1Aeq
PFWsapo82+/yRP0gcxsFWh4MGwKGABUnBgQV6+ZoqUefW6gNom8YLBloZ/YHQogUVR+nkI1N
1yHR8FLvgZOHfPgSTjwpx5NhR2x+fkPHOg1HbIoSUbuRb8Gcf/kIOiGRi2Y61BepYr05xVZ3
qrJqNoYzwd8FvpxtKINUS/jE9NpTOCXFc5zTSDkloL82TITTMYorKaSy0zIUpG6EZiWf8x3z
gFD6ZNkx4K26ql7WnrM7QwR7vqOusSgnaO/CxKTZCWSdED2WKp9YIqzcGc++kGhyiydJA6T5
BHsmf96OF4ISQnSQKhN5wM8ap61A4mQfKCwk1+uNl1yKfQBASOhXSXae5QrUAcnBnbkjLaq9
q7Kt1x7puvSlQIbKuHkNrjLC38KJieHoTKAyUoGNi6N3L7fZ4yOoOffCaNkn0/dROuYpqMK0
zyJnrwgIPbOS62VMEKNomqwBe2y7ItHdI/uLKQ/2NnARooim4uYW5cvWv3WiPeHyR9qkolE5
thRSyLsfeE/7gx+v1+A/vySYkyycBzVBNIHemDLijKiok379buw8+qmMyFRJjxePrXFKXfp1
EbB2/H4ecFO94+KC2DngbgEiP5s5UvdD7n/nJWzmCj1giTpsabJuttTy31i+rp6G/wavSI71
I9WwWrIZZ3aOMXupNbVcj9M5MSGPWuJZo4kiho0eXQS5kPMpxe+2KOmMMLqWsXglyATdWN9d
jQ/7/w3SJGmRWWnVfgu3EH7Em6RVC1w6SrlJh/TNpLsQVltWe8JdjC4ex/ZoHKTLZblHhUDm
wso9gbbqM13m87xGXh6Zw5uzLenvOSU0fKr/PE+isWxGpR7kKrQ3Eo6w7AigJVUnRqoa2fiV
0m+XOXhp50aeykXrdTvJbTo40X9BAB6858oFyacpt/9csCQ0U02IwOwMCCcyCEcOuDx8I4AR
FXVr9iQuqK2obbNSZ4YqN0zhoMv7HFDPoWFNnIRMsZEp6dxS0WEmrrxI0WqbAhNttAZ+E6Uy
bI1fPWQrtG0/RwFcghXZmVHXOSA+kXGThG/OVWI7VbFP8tARYifxzSeM98x4XIATo7VMhw/p
xP4z8sBGXlaspaF9VSTDaZk/ofDNXLStlbomztXPjewUtlLyFxOZEtxK3hoCxbfimmWPM3FT
BYpCxVI2Id57WE52EUIlqXh1qkJF3CrrDZarKrh6h28yxFByp2XZAusNfwjuOntewfba/MV4
vdrs1sawA6RZgSDkJtYosJo3yA0Oth3cMNPhTR/TSxLePsk07UsbQM8IFHqjKdh4Kuu+VlpP
KvD1Rrrf3G68iXeAEGsZY1cMdi0FnU1i6M8Jup6qXueOD8d/UY4fNMmpjV+BQyrlUlRtQHUh
Uu6JXDwZ3x5Ud2I8beLJqFSEXyQaowJAyqebGMzj3luzR8hzHIcFyAWmjSfp76ArUNshr5Ji
ZOFh7tFJ7rI5Wmc34YlhyFiLJqqLtWBqGxH/jJk75aKVVkPOvlDZmkEa8W0p3pyaL3G1S/Kv
anZsUmBFy1O60bypEyl7c1Opu/NvCDIY7hiKk16pLJf7KLodKSeei1NOGwQ1Sq7dXMhZ1GpS
dtJQNm4MP3K5x9jc7GUyC1cXAs3K4ymCJMTXjHQwwyOqDavHaxEiRQ50/AMP9QkEVzgEtQsn
1ytittvR3TcYm+Vr0Ca+BmASnUzb1fsxJINCylvvUDiYdbthtOJ2V66xUP7/I2CzkQc0sOKX
UoJP/8KvWFs78aP0cDgToVbpS5XiAR/v2pfcy1njs2vuFWKJbJLhUvgru+BleCCFZDwDMTAt
06VAt+LmPSArWLD43p+qmW8xMtt+RKcpnRzJ2dIzyAmyAUU1UPS3YISqVvyvdK5Lhz0a3kmN
IewUixUZU4JXH7DlH8tq4yttkgCOK2Clt/fZaTzJQyebY0FQ+88NsGkY1G7axCfjaRpx2smV
8Or8vGS7eS4STpp8kk0RljaMpXksC6R92oPTsjJbeszo2/g9dfGw/Tmckqc9WskrSTw7e6x6
oy229hoFs3H7Egekg/Pei58ledRDTKBCh7dpmdx61wV/7xtBawcBAQDQQT+zL6A9zoKSLnUF
GAJnV2EFUt6E5AufA0EQ+32sdg83eLK/jxOrpH4gSkpqdqnsI7zeclvNMbgruN9f40ESdwcd
xDH4DjgvBnSFDbCtHBGvJcEdOxckyhFrUbbm/GqVIsvjNLW8a5gHAGYara2PiO60t7u7yLj9
BABsWY/fZKEIwUbzi58iFmjS99dybcBJ1G8X1N/oJ9okeNte7/htkKSXvveTUSrSE0a4LUBr
k/BL+h/m2dAyi6vQAYsEG9/KTxTMF3VDlB/7upEkYYepBUR67CttB0MuGD+hnKovwbh+Waek
cK5smHpIcXchcjI4YVdqyDg0X4xPJfhcB76XO+6VGz+27EtW8vSWUttyrpLSgmEqxkD260N4
3wgUgP6yiwJ0/RdWj9ybuvpbRFcJ10qZKcFD2xoqJZA5LN55XD3lvef0Bca0ZzB/ijjt+Zj/
U7JEsVUzm1lex2HehitRzDZik9GSfswI+nF7l2hI2EWtKPIfw5pJtvK2x+CO/4F+dZmgSs8W
PyC2YOTisFUY9NXYVKzz18AFhzr3mVxi8jc5hadb9kSo26mz4H6nEGSLfZiJEsUyBt1WiRhA
RqJLl+/Y+htp3Mv7Oq7Z5Ew087rhYYIWGQnJE+KQjR6rvN6+Ef2YefxIK3JXp08c3i93qbOv
fggV301AQsPyguh/g+/gAaRcfiaqrYFpL3zkCb14cjLXafe8XCcjj1t1Uks9yte9/qVMhmBZ
rv5HrEUEkX9FWmV48t+93wfy/zclSL8tLnG8rPYB9l8iYDZgx3jEFqJHEWu+NaOCa/lgaykW
MdpYrX3wVdjXwSGHg4vXJWjJ72ONVbnIE4ATtxjp53zab+V2i0Nl49RPaWIoF2BVVpB6sjek
/dWl3zbEKD4VeS8hx7+dzrYYPa5VjKCKR8dBASnHWb4ycNWI8GmT1B2Jsvj7sgVuF1bEn3eR
dgm3UKSVPXVhPqc/ZDYl/4kUhG+EwM2ikIhd+q9SyDrVPg12RZ8RQkTRs7zf+CyceHFDkSMM
GnLzWqLhgY0I2JpmRLDYdb2haN+xOnQMcazlbIF2w3dMzP6nwJdB43ETyQp9kZ18hc6nC5iP
og1B5YiCwAg/fOrnrqB+Nytyd3YsBQchxiSzeBci/rXfk+n2la85If2RQXMGT20o7FkfV1nv
vR1SkcDQPpk5uVKMkQmZwluNcn6vPR40KdJbkMFzNVghH3Fzm68w31nRNR6n/wE1Hu0cW4ap
q1qJO23NybO9XGFRqK0C4Vijguld15SRX48b+jav5RbTbRUg1ofZqa2I6B1o2i9EMPYyHuZv
PLyCMAVCLK7yPTK7+SDLVXi5M8UY6lCjf2npS+VldB7rV2BxwCiW9ozj3mNFRxskCrsVNAKT
hKLA1zYb16GmeJexLkGq9In1wOytFJib37nxtoL45gY2hKGIpceh0SXwFVefX0rU/1t6IiGZ
n4jIrpxwKL2QLfPstJvzFcLsUqWrhcCzQrLHAtFpaeRCM4H2n5EL9qeIDQv6exLIuDVXnB+I
MIIbTi53857OUIJYQ/zAV1Hu9LOIKJiWEZDrrBVStSfjjcvDUyLkDV6WTS9EyGYGFArz0Jjn
DsXlbIWBS0HHV1cPbzo4AdbMQSnbYw3cGOhmrnASrz+Wbl+RdrIp4O53P0vim0sRSBFI5iFi
XbFRnkLC5tLW/C1JlVyTReYrKhIJcZwBfJEyA0kZhyZFXMwy6T0SUScfpjRpbBo1BJ3VY8jS
Qu8NuMeVuMc9SAMUP61Pfo4eIbWbGy1aWBjEOHAxeaCTw9ooKKO8SPep/GH+zZN4YlrfFo71
UWydkQ5xnVldo6O09HrPrWRP7UtMPvUlZ6BbMcsNlAduSFkt+tN4jb3YbsEwhoQcBSmF6M2K
ssUAMECNt8AkgYA0rPCxXp+5HJAg7p8wvLOmyigqbrCUV4XOzSbcpx7Sb4DSsWx6OAv+l0yR
fdI6C4f+stGHdjwQAmCqidlKe8lxn0h9GS1xV3mdnAASp0yBTHEWc8hMVP58UU8xKGeI3SIu
6o+E7P+vsUPhMQWwxDa10/Hz+tLozkXudsAGtE8AjMWoo67efbgSH7angQuJgGQrU+2/Wzh2
hSkzniZGXqT3eKUTNe+qrPE9MwdzzulQHe4KRbArAeULh3gSXYKbY3vYsCZyd8Y0PzOFB5K+
sEbRBvXAKbTr//qMaZmkckERgg9KcxB8umpzEH+6MtccQKgts8o0JyX8EQV3fqxCrVnvsvb3
V1ovBeDr91M3rVN4SuEcw/zg1Oi9WVDne7M9znsEG3+Ems5SQiPJC6oT1oHn+byVIZC+AgTA
HGaP5/8p+ia57d2KCM5CbqLwzoGmAP6vPuSxe/hV6+pdk6QrNar8mZt6TCxABKSm25y+Fh+u
ldgkHAOH5psEdnWTrVvYkAiaMcylLByOI6tglP5caL/1aAcLNRFkkIzSIpCLUrhYlqzQZmLK
hPkFlXpEba35EIHeRaIC6Apy1T3Q0jFEH1/BfPp5aHoL17wtOjukr7PDBbTfqi2wgSG8ESlP
mevvKsLwx348QDE1K3R2Fu578RVycjfClsf1gnHYJLPIdtkHvihIwndGpWRZuw+kIi0wUqxn
i5Vv8AeQVroBece4tEpbgnZ1URtVnDmlQXCdoI7mP4bobGpXKpLFAdisc0dwA1n+jrYAAP+s
k8iI8lcjkUAPdnJuGSKdQ1YL0iOmRWgtax4bv1gFBFNIwB1FKVyPG2A7E6ugSJFHJyqRAf1Q
9DFd61uBtSa6GZs5qXrvS8hRjywO9dSuiHI5te1M/b4iGfQ3mVyU8CMTxDz63HwvLyH8Fzsr
HhoynrU9ONa77nL6gYGhZOrGp24CicqTsXUQQY1UrNIUbzzCO5ko1X5IHY7sCEjfTzt82z+Z
bMQynqdtJKFp8fX5UjnpDTFoVcYtNIo0trdKHF29FmMxjDi2+1m7v+/+8h7fjI9Llx0iLoax
9UpjnNLRTOhOE45D5XGvk+mCEtpMrq8GOHOBOC7xoldu1RKOI/NIskVSNtFqWpbkddC2+K/u
n6LOBF7/yzZPVANCDfBKpiUrYe5qYSUTrpkUdFirVoPBmZ/S4dXzjmaCrKB7osgGkY6ic8g2
DYlBKUPpjVkng5gjbV2HBZvhOBPZ1sAfW+gMHfDTLQveDG0/ivnVOXeGfyIagNochgw5iWpE
7hZT57Qswq/RpsOlmuHk/dYz2cbjRIqa5xH14Yh4RM7Vi5KYf5xve2i2xymm+C7Oi4pwz4Y5
R+pxXlLXSFM5pIB3azZsPzWsLHcnwi1LKAgBdc+DhaJS0vvOuy5J5sIxky2j/zpp3aoE63Ti
rH0mt7Gwrj0d/A+p+QwemHcB7cHlmK9Jvh05Jip0mO59ALgCfhS/dOICZU4bkgF+g7L/AITr
KFG+0k5ioMn4OAJ1wBO24OjNy4Yaglm0W6uuP0knUUrlV5CJXlcISuNg/2e4oI/BwPQUMJxQ
WzHEfTxWKVB2bf2ZwtHMjqb51J3oi5d20Za/JtpZFF1BiXwWJeHGSbfYCxukACDz1wFtjrYD
0bkrJihLeX7y/2xTl01kMI1/ZkEA1zz59w4CPO8NE3laNCJYDDZiAJ7ruhrVik+J+Sq6O+q1
xwR6lT8X27ltReZ6NeWbF7GEKun6SdGGVjyId/eVSUvW09s3ljKFRC+eFpCYbnW7N4n5Wv4u
M/KT6j7RvVCBfFK8JtU6OPOWh1cZlIdjFG5lQ7iJk1zEAKSSGMj1cnju6X7u3q1IhOtqJMVi
foAouuvb6PXMrN+O2TBhZF5zk8+cLL2lDR3RlmJMdynGN02auiWLUuD/62HUCoeOAbjzM+MH
Bl3DrJQh6ik1lCHqNceUIeo3dJQh6jXHlLHPKFB2loPeLa1eZwRGS76MhEJpdcCBm858TYeI
Wm2Zjl7Too5Hk4+d0+2UsisMP+rLq17867qoTyd2WNf3255H2Hm9fntnE+FeezUT0Y/JvTDr
K8PhLAxq0HumZR42G2lZBr6kfzP8bGTs2NuqqO92LlVWJ/e+0VZrw2A8VLf/pXMF/xKb48jT
D0YpxDHQo0Z+yYOtz2b/jxEhfb/atMI5cvToYiUxFMkJrrWrRL40HCrbYRSgVLErQA3kGim0
MSQ0LDbhyYAF7w1ySt2AJ0+kjdB3Pz8OIiVb0ujw2nNG9du5KNLqx4jTxD/gWvo0PlrjyOvt
4fmSEr3o2j5R+yszqs13QlZLH/VbpNE4A1OT56Vl3j54U6LCqBrFwFFYS8lhO/hon0NOBQ6k
Eitow/UIN1Oyj6Zwz7x0mMBVK4SjiZt6lAqG9apvwPkLI7XIrJWkyP/iZOtD0gxF3JxbvNvT
5FD1/lTgnfaSCuFo8sjnTpz30zrhMkwKbdc9PdViCTT2Ul4FzSGITErbQcXRgAb2rhThZlDj
ByjQxLeYbtjKRVXzC8+D4tkWOFVWix769fnNcil45pGAjw31PkaoRIHZ3KovWm12YAlrGR6h
ePxJuNFbgeC51dyJPsAqlmthmay9tuEU+1WWg49FTstzo7j4Q2+U7Y9qSK9QYnv2OHT18QqW
E566RSISLVEd2+4vPnZTTerjweIz/Lln0v8HTuwQbq67KUjQc1HrmDF2Ou7YvZj/TSCFZXOx
hEWjuwIBMo6vYGM0kYx37SbWccZ+HtUDAGLVfSn95npgv6YSXjrfON70ESjoQHVIOEhnaMp0
6xWUg2jWUwqRdV3QadyGOUxC6zh2lWLheOsjhKnP8W3BXm4MTqDe6Eff2kdvXTECDA4Wk3Hf
bdfff2hh8zx/oMc32OMbAwWw3XbK/eLaBQN+AvzDC1hHi0TXkx9fIMi580TXrVbFmha9vOpQ
6AHuOmFXMYy4R+FSFsanK02W09mQSof5bx7Ex8c8JfCMr4lFVYOlQLR32+gt86T7svSwy3co
C7Tsc89V09TJD6R8Bw0x6ihWOEiXcbuNU/za3QG+wAzKFv4CBifL7nB5/xu6/QxXDOEb3t01
koNZfBbvdokfL99j7s0LaMVr+wFjFUR3a4C1Zk7kKzy7qT+a08IWAfHIqKIIO7atyZHnLN+Q
Nl5Zq018N4CDX6iiuKK8uxDJA+88hksWX5Z4Hp4F/PZiLIuBx7p6qe07kMlv0XGEli1xPI6h
B5FF+YnhFgkiXe4sWgnY7/Sf7xtLlUwKPhJ+SKzXjL05T/l2rYCv99Tz/y36SOHN98tUos/H
tB2rm6nJk9otIPSsOtbT7QwP1gwP2oju8wr6MmUztsCYPuqtI7L/qAS0+y8/DKbLYHf+6z0j
5oJ6rsHEInWMhWm03qklEmAGihl9fAWWveinzfWBwRa9OV6NU151ZsUGEo2v6Ryz7yBGoc5T
cOQz3Jv+Ma0dnO7nw+gr5EGwS2GNaHY3ZwESGYZwA9KQXbWdXdjPDibIQmdmjH1Dojk9XKMl
joNKQWUUds2H9ZczIeQAZdjFi9eLv5l8mAv92Z4C6uwZx1EcH+W7BBQAIodP3DzrNOva5OM3
W+kQhAag1r1abt7MN7HyuWfj4OABof9I62Qp5N+Qms+28LIb7XA2KXwEn9Abdsos85l9e6OC
EpFSvdTQKd8PvzwXp7p3AfQSRlWQwAzR/0R0bkEAeQ2PJLMfdDQwCNJFtSFKHkG/P49VGphU
0ev93BRP2OoHGRZTyDc6NGquNw+vMbulJK6jMarc7sOElFmtAP2uetNxafg5B3T13tqZvU2C
VPcyw+5jIjAZOCtUGNWrwUJayxQSwO6Evv9TlbIyy2+e6akUnk15B4ST7enxYBLHXy0pmL4N
kqJh1UhHRtehRU/6HOjdEbzO+OgarEj6Npm359M3PLzg3+stNPesyEJZG3i839HjIGpaCAUG
KZb/c+rITiDV/a2BEvy3aorqjSyb6HiHjbeTQ/40Ep0Xed2pLOvzReC5GL7VnR7Nc+K1c7uS
JF6JxwsA7XMzsQ+qPSw985gGgxj2tSs/mqz+Tfq7mPhmfbzsNM0Be4Hoh7MFkukgKWhfgeCs
PQect1d9QGqHNL72pTzR/5hSwBn0E041Ud8JoUvdnZNmIu0HTgXcJRCzmfM4FDXSORI85f87
GCwhuMcCOWM0azU+BxFLN64hfJjp/hm8j+HyCRZMGBtAnb863yM9NNtSLBS/6GBzP3/tkA4e
yTZ8C2Q7+izrEpvb1tAj7YuBMraocjKuWFeFy27q3wQ0qy3B14ofisPwRUaY8UbuyugQ+vIh
/JG3JrUW0cYSpTDXEMwqBuoeaMDVMNqY2fGpz1qxqlFHd3goDM5wsjwDlrTF+7o+qamRcZMk
VsEHn5uGPpm5gbfBNZvf50CyRoVdHKm6GQPO/FypWyNz2QyUJbFBerr4bwnCaxKMA/ZrJsrs
06C1Ft/a+P7pbiTPOsjRSW2Y+sXtk0cgLfprXfFNkF5y161cAGW8/bXDYx66t/cl4BC1mfnG
XXIpkovrzQaGkd8HCqbq8ghnXJI+NyYjCLmTBXveGMLlIOloFDvIKwIAut5n2p2Nwrruclxo
17vTSOLOvuFkP8qFOvjpddVgOwSBLxYDRu6U2x9VRFA0KiU0Ync0AFc07/UweKWl/wjunhwZ
lnpx+01b+2nG23keye00T3zP3ukOG8qpv8pbg7HVS3UXheAc1058S45O7H/m8lixdNDlgxAv
0DnZ2GcT8koKpomeZybTnMPyCQLJihzXTVPoBuztBEv6tBVDMLTpF45TVmFw7+wOSZW+i40L
W5A8zE8NHqCc4sV5y2KFJMKj1WfnI2LS2IH4JDTHO3y6tN8H51OgO+qVNyukeFj8vj65bIn+
m57PQmw/Xum82Duxr83t+ejfD3tV+cVMXtWUdh9tVCaplWqS3TPvsXM4hriLrhv4SR2ELJfh
lzQaWJSehdhpxcfKr3bnxmu08GvwJpDhXv0jZ/0nu6IMbA9pXLPyLjs2ufIuVUpSxQAN4BMs
gK7toGip/Q13/i3pXlziYZWZtPBctMazOJrGjRy6KS2NHLopLZrtmXL3JkvpH5p5bZmuYwgr
qyBjCCtREmxF6qsgld+UBXro1NkhZ7dV/j1Tljlm3ku0rLQzRUZYZf9GZ2pYIGmcQ9GVMgxY
k4yOOUJam8I8i8+0R5vUubr9Cob/2To133itmjcI+OLYmr+R+bz4zhZsfJzm7zACN9LJpZ68
j+FWiWeO8me9Y382tjDIF+76Gwzyj7fBKa/smOhIy/h1/BXT8gEi7rf7OjiLFd3ny7MhW0Wt
z2b/DnUMugVvbXqQ+sVxMCdrHmrby+P69DCmT7BgWjfdUMi36yzbcme3FTiwzQOGHveDwSXH
JPL4OqjOc3sjWtK1fbkUpzBsIfMHyOI3XRGmj35kV/BVwelPh4qqMATp3DIK6FM9bGo9SRXX
HUadbzPvxxsVFRTM5i9+8VZWP3n6os5F3vI+Af/T59WU6Ft4iwcN3a1gzXegjMfaYeTvJsjk
T1e2ubgtOV6OgBef1RsGRbpW3vE45le+L9AeVWIci8TXkr4/cUBuxJpVqbj5Rzv0g44Mh9wo
zFrGmIXqqlqsz1aDaZwppq1IVrMmFFKuH+z8Z5AZqW4uMLzmPQJYyxjdENqFlt8PeCDrYBOv
GJafZ+DU53AGkhavndux5C6dn2yeKzXaDMuCkew6LoO2FxPe1lGJ/w+ELYnGzg0H4yPO9rC5
ib1fSH9xZhLCVXY/DDcdtgM6+ibkUK4EoQIjZElVTU9nGAR3bermhR0BB8+lnm06bq6ZZ2ag
3sj1GB95yGPLoLF/wCalXqU4ecBIQ8as+zlqrFYAkHVPngWLeZZh9muieLjzifOBts0N/O5y
czAz82PqFMH5dp5RxClVfkEZkmnG772I3uzNAZJkB/UNIm+n1zG9SNihHeR0XXr8rUwWF7zH
i79MPL8Kirp7PZj27P7APhktr6bmMUFMWnbYQyPtuW7RnJmTGevxEOLfdSVaQyfWJkZO8X6g
Vv1iLlhDPp2iE6XXM7S9nZmIv2zPdpeO+z70CaJYakEptiGZhgY412PAQx+SWiU/8sVLkYdj
Xjc902PEH85Rkydtr5TCNpWI6iYSqVZzALfcBtMTr/xOigrZhw5k7c91sdBOFndHJekFAez1
9CU+K576EHM+RKU0RqBPY2BJqUFKl/6YthbX45MmUngy+P29LYbxz5adW8To4XjqR2XFrGFM
IX58yTJHQSZaN+lDgjlcB81YmJpCHQ0H/077q4E+Vz5736VV/jBXiihkuNSP8/lQuHoEdSgi
+2x+2mfZ9Zp8+9SAv989GFSy6fhPesiPK+utjurBtlP6j6Kmk/ylvvUPUs5qY8PhMHmLIPGZ
d/9UQkWuooDOtZ1140tnhq0iqcAK5KVbsVzSvgZEJhWlGWwXNMWrE07ULLlTKl3Iv60Rv/EM
+d3GzRtCQ2yiMT7E5Ai57gaVZZea4apzm426le8Bmh7/mGBHFIEUM54hHWyQgp199V8tN6qk
n4ZoaEBAzYYceUP3wD+iBT+/LXHoeG71AJNkSt6Au9v7r/Y6galPNp2sA5ruqkGgwrVuFWyp
q3XAcXhBMDCG65018qdeBXXNey1/wZjVUjPUGBtCVJ59cuopwC7/+YGsF0HvU1cE1DWJyL5D
ezx8sF94xdrcApkJ+vaXupuXCp4TYsY0a3mwUdRoTjn4F7BRlZMp12//QURqRxQ4A2FgbbQr
r0nTz+4nOm9Ajv3VcXYk6qvY6dht7gV8oysVefwIsbSJJNSNX5X/KQHH0uHN17U3n8g4JCm/
OXO1lQDiLJG/Xkbvs5KSuDgyChqdXASa7QcIPdSd4tPvXEdMf7+UYM6ADBjDf96VGvhKo9hX
ipBeOCGcoZSWk6vX7wRRmDtAbbEG34jIYZsWVWt4KadBGpilZlU3Wyn/7YCTqBv6eY/fxWl3
mlUB0sal3ImE+XqXgIpK9q/Pku4cHdSaKx7S2bP4TagdJyqa9/qVpkHLdpiZQbKpmv29uGaS
LFCVvZaWx+/ihIuHxAYKaBhgKZI4rYAMkjgjTojPWPkq+PGIOwZtP3qToUk/ldd1wBCgtW5c
RUi+Vl1dRU7L4qzO2B9xn9TWopjdtL2rn55zKgQ21j/P8C4oa6Bi4iHES/i6yfCdlUI7lzdc
9LmUMCtD3eXmO1xHXDfqXBoNGPa8DyGhUIYIcFmPzGQs6n3MAhzN0wBRFFyvgJTPoLbOTXi6
c1POsyma0yQY6yrfylYddjeB4aC8F9JNXKjplAnD9EOUCcOo6ZTHXHsgAo5cWsyVKoCsjsyQ
TCiUbJDqNRu3e/vpCY8j2CqYqasHW3UO2yIZnpwmqeXGROWf1sMIjnOGotSWX5tKbcohNWIJ
a0zQ9J95qdEpcJRuOEQpU5F2yCamvuF9pFeqE15ZV6IwKq+U1zZYzS+egoljjwW+yZ365r5r
rg26oiXYKXP8nOsg50OjriSwV5eLwFKWU4Wntllhn9BipmYBdJmO15AgFllJctJ79JlRKCmn
nBiOnmWL7CjMxDQ7x2oVMiRjeBQUFWrXLkVm+xqbcCZbh9Tg4mXUo6DAPSIbGf/WlXGF6Qk0
Lzba6e7rGpGGGtqtjk3Tey7qhAm20gXHF7xUqvKc0uLh2B9tclfOBGx2pXydAiDrOsYxepSE
ldU4pkMizejWfym0dMyBpJodlR9LrPHVFr4lBdUWvqzx1YvlDl2e8uJT6AarmYlH1icjyjrl
tYuA+/HVps5N+3BB09WmU+a//gHZMCr4hNBmc5BiiJmvhER1651WpsvZDurRtD3RUIaeDCZL
ifK4O0uJngwmdQoVCcVWYwbsGPZuFTdSkj6kbazoULg4V1yy2cPrhV4J79JRRuzR5mJsJ5cp
7PJcp9PNieIPOCrGXz2KOdiz0yMCg7gOLjtHP5JXEdf/vNFDv1WTmNN878FL8jXcw5gTobYv
jKx8AqZfPmJxSkVTQ79eM2hhRVuxMKJjcZ+CuiuCDRoqCvICWHV8tqSHZoU82pB76cpVeR6r
NfWxLGlEUEyqNe8wb72Qb3SRrhXoHPh8jxzhEN7S37Y8zKMP1Xc93694xUDOQQTms90z3S9l
h8xAGXIz8ruVU6LpzZQN2guyo4GXNntxRFc9OHo3rHTYf6/RSbLS6Hp9cMI9j9JWsWBp6pJp
I8tFUqHnOPYENyFQ8O/MC0qsDM5HDXtDLdcy/kyv59qs08sXku4RtWvvC8sJDrKdNwf7jm1+
sk8iqLJP37p7WuBQkGfpVsvv3sDnQue6n/+iFWnb2TPJn/ZzDxa4dJ2hTMtphxKnj19h1gq3
xs+SgnnNVgejGQJWmGIMZMnYB0H9/GvqgyO9wC62vIX8Q2SgKlLFfzjoVC7kl7TX0Wgp4hV9
ACbV9YIS6R6DacrvjhTsUKVZYqx7Q4nZsjIM0lC2CpxT8cEpf9WQAKU12esFxG5h3b2pR0RL
D/JH/dBG7xYPQ4q4iGAYrregZH2CtTqPMlBdqOeBOzYRhctpkuSfloRXJVH1/7iWj4I3jOSz
7HSq5zFnZHAkEYM6e80JTPlwy4vdSuuL+g4FuMqXpSbwmfEo8Xx229cM9YsuQVv6BcoE39tx
XbwY+0IfJcwm0hOu8+Oz/bL1hNkxZgk+Qz0BNbkmai9BvYb7T4+OkBrIiQRjfuAbFbD7lf2t
iWPj0jYXEjBM1Xq+fdTQFthTuDy4UiuuZk1XKp6c1fIb7RpTFI5Dbpeo5gIF5tc1BBiYzA8h
QBZ2eoPhdpIvNGBqnKRv+kj7qt64SSPXFva9B8fXZlSjJceSdbkc7mzE+DwYQyEL93hhiIGI
XIQiP1V2ObvTVwKbY8Th3rlHaOl7MdwaE6PqlLRDQD8fQGI9n2l5Wz2fyiBb3Dl7ZbBPpEDr
VVlSxSJkzjQGx6gClhcJGtZ6/wMU1k3KK9XjpShPtZ21HX2GYOI=

/
--------------------------------------------------------
--  DDL for Package Body PCKG_FWRK
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "PCKG_FWRK" wrapped
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
24989 4632
ynmEHvKPMVOkoOJLWYaUSt6Qnfkwg80Q+MerrWGl/h6l6n2YXMSpiAYNLUmY2l9e6Q55t3Cl
zdRCipZM2/XT0/1xqQC3d3OGZBo/KTIUgR39SddIzXtVJfeje8F9NPX/6cT+RRL8DpyG+RLS
Dx/tsbD5+rr+gao9OYey7poC2rmtcwyxNRlEEIb+/24Z9rV5mv4bVfpjsX3alpauc6/n7rVm
5CS2wXdStVdg+KCdKbHm/5iv27uBCJqG2b2r8BKGbf4R9UL5JVJ5qFO5vr/8t7l2yHhMxL88
MgUzcCOGvO9q+ntY7nBd3QPeCWezm/EPsuSVYiOc4nifsyaCCJCzPjcifUmWfxoPPzqVx0Dc
0F997YMMg6Ajtr8wszKYwRLSqnN4VWuuGzdFHJsZErbBaCwycqQp69xoCK03QzBBtSfk0x2N
7HRg78bpZNQwsfoWIqTdWFfiB/HMQ2z9tnbe4+tmx2fGTRwueqLYRSOvmIwi0/gLiq2LIjSh
p113pA+HDpy790IAeymjsG25tmgowdRzI4bzQe4R8YoRhjrMtjhfZB0UCbuFUJC/vBKtm0nW
x3ot9yR2bigbzjhyvnV01IxKwqRgG6rP4cQu+TDWW5/Rjm2cR85wnRB3inykRWprmqqhfc6R
R/UOdO7gVyJVE85SF2G6aESW0dB2iZnI6TEXE4aQWiJJC8edJFets3i7nQBO+FX0S0zjeuAT
ssZVvC6YGREG0NS3t68Rj5CtEObnh3sjtJtj1syZVCh6APmvIH2mo5s5sWXbG8G7j/xItg57
kpq1bLRaYazg7/kXEJY/q4YRF9oD477abfeoncvqD9utZVL+SDfiuSseQ54Qnt8/S84hDzb5
zyuaJXYe43RzZnFNuBxH29x8wfUohSkai09qCM6sCypdHbMFgoB9pZo2H9ScjD8H9teq/uC8
zjY/9Twolu6G80MGs7NQagNPIVBkTZO2QjqRdFHPYgWzqR//MuD/NVPuGfSuPH+RAj90RTcx
Ms5N9InC4e5OVgzGO2jW0k8VeMvcyqwQqKZPj/CNYAvf9wV6rNR9Jy0IH9nXxjrgvPl2R+SW
2Sj24W8AEjcVpxHtWEi5PBUrwTG58WFuBZ9FtrcIMH3uO6VuQbUlWDQybszvAB1Jh23niOLW
6sh8ujSCwR8u25sPld5uDvBrTEZliNtGBPRhZhZLEaJdRg8/zGHwAR2DN/OnjgyQ/RD57Eji
InKnT1DPLb0r/usepOmo7l0/p9Gnxthv1Fu6VmuwQsvDCFa4lbbIQ3m/Jdoe0PrhcHCRUUZi
PZSaDL7jVvU0aaVJl2CJ48bKHYsSw+WljgXsv/ZOIGSrCcWy7j+3f3MDqGUgOCSrgR5D9Yty
6BMOGeaBBSknI4YLivBPS44827KSc+1OTu3+zuogrNXzmSCT6FKYnrlzZsd/zXDi63AyxLRH
IOEhE6rkBJ2jrrsdT3a2MEVP5I8i3XAicrETkJVf9c0tK4YymkZob4zZJrs0qMHbMd0TIRUk
SUGujar5v+TmIl7YiREN4PCuM6/6DrFseyjJXWjjME3W4Q62q2nPOTnXL6E3NUsh5pPTS8Oz
WEA5cwtFeGg+XH53NQ8qG6SBMTj7tBwZEL98QrsoCCyEP658irMTa6KvCZxg0lWByR4P1+HH
UnG/ihgRqDtI7YXnjj2v82Ccajg4fRAg2lB/zb6rZWJ7/swsqUw50vQFze0cj4S+qilA23IL
k399auKcfRsGW44HIlHxRsA48qnc11ncD61zBlBymLvPEfmVa7+aRv388bKQXwdKBaSBZhlU
y/UYjcFmigkO/hucVBjb8V1j29cM3f6CsQj/1Gr5KzwQ5JuUbyk9W8y9ziIrQWvfF3YNJzjp
I0IS/UfmCBpK3NbpSxXAaHRiH/ek2KL0FdYBnNM8Zm8R+0ET8jQCVyCgIydx9ypVXQdEC7B4
IiTGw9NlXLl99J2HimpNr1Mqs26MOFQXrLQ+Ui8m92Y/TJGI0x/xwEZ9Mn8pZoF8Pjlahx/9
1lIkJtTjDx/9RgjcJjn0D9WOKl/VVOmLT21yhZ306Y3MOzDWUpshTAnkrIUYKbbY6JVgeiE/
1yneisVjcwaAYlF704wu76ugPtIuIiLN/SQnaxdbGjKDP7jxBrl/jHBaG9sl8EWzisR+e9wf
z/gdldqgc/cGc46J+He3lDJs5WSpXd79RbuypQ3BWeOGbCF4KtMsQsDY0z14Mtdw9PtyRR5B
h+Cf/UF40qZwnWP6t2lZCfScZNR1mGDObmxJgLGw+ecEloiXEp/K2FuuqhlDDCAG3zS1iPHB
YvWptf1F55XcVoHui11PwO+nR/yMf3+sMvOQ2NQGVMyz0GDpSTAFB9Ci6Ync1HUUcXJKZ4PQ
YMr1p2tEjGbQGHph3BxdqfvmXFG7N1G8NBlYXgmP6j4tD0MCqo1v+zMRNXCpHkqBaxfwTvJm
TTB8k1FjftZjVEflF+fel6uziZYOvRhXZt9l5AItzKzQL8JfrsKZrglESb6cjPN/X2Bq8WT9
Iz+UTxoJeA0i7T1VBoDQLvEkksmSxKoNcY8kJijHBwaJ9fNEoSE3rNIn6RXcWahJGAj8Dc81
SfFwsL94ZFFLwqQFbJgRZaeAAJBaZZQPH3C2TZ7f2HR4CkNf80JTUE9MX5kxWHXIVn6JDr3s
0ckh3EZjcayImJRVAR/ua44jDOf4hZRQzHzDanZGNZVQDNiGxi16MJzQ9y5nQK13UUwFhy/p
ZSCqz8DhlQl1jBQwfA2bFcqbOVddskyF/YnIeGjKIMo1GS83NP+1NEhzNMv4NOLONNwzNLlO
NEpSA9kF8YxG+bk6q2IkP2jVi/n/HrTRi8L/i18rgcQyWuuWjqSznRGd1cRbRakgvnWxUw4k
U6mw/sZOfSv5aJdPmB35aJdruvfMQy3ldkWUQsNdLXkH0R7cgjr1gNa2xmIG12J9xmJq1rqs
u58ehwX3Tjy/kHgLUQ2316luxCYePO20E/UPy6Qy8UppPWp5hclPv7Lw40jpIb+ZMDgT+viZ
VXWGDB/Vm4zHU/THwFGdV5TfAxFlBEJK2lLjNVtIIby4aOIm9x717QjnuKIvHrDBMxVyF7+X
CHolus1BL9TUmKGUzNVJvg2/biVNjQ9og6hBs7ZIKXfRPQsOM/PDrXh3uQvInQQ0heAk2heb
Zs7ZD0T+2WSvR51MYmTjgl0I7bdvtxTEUrtIvT+zoLL5IzINWD9Ty1NAryNbcTucH/M43q23
hYpLiTXclkDvpBNHQH/VDCgHUIDl2lZN6ioAMBXLg7fjktSVXhaKF1JX9xkpr9v/rhBpszqV
B8Mh2s5HZju+TsXA0x7QS9Eq8FIAdDtYt1Z+ZACDWihzs/H7wWIgDiR0QZyPB1Z91keKqqCl
AOGLUgMFzMretUMSI123gp2nPdcWcph2H4x8gM9XxBMN2Mtg81o7UxJ/0PZ/0Lp/0Ax/0Np/
0NV/0P1/0Jl/0Ph80B580AV80Nl80Jh80ApQfRuiTT/zGKQUh5E68ztkIlt4XqB1GXA4IYYC
nVANEVCegXMe45ei6dSx9uzo7iSusX2EL1Zp9YnNqHh14pyZwt/u7wZW13iCY9MRKtUZqBOk
rDppl7lF17thKkV+PYxDwOijmL8DML/HIxdOEsmZMAHHI5Feu/ZDAOVHho1CNJscXF3M98Zh
7YB3aH6l/bJg1voO2nbkB0HBlSAdp/UsS0f9N2wZvdhIRJskunJb0AFnG4HZzMSANoxQeqtM
xg5Y8scBoXJBGwAgQfVQCuATjHZaQtEN79l9T/CWTH0MtT3D3yAFeLvaarkSelj+QeCktWLE
v5C9i1milFO4aK9TICe1wh6yIz+RxL1OxvYFT9D41raYM4wIuhrG1qp477Bvsunbkr2TcP/a
Av//g4Cqbij5yuh/SG3xNIGmpTO7ckMxKDQE9+lx9x9AzmowtPQ/PrsJfkB7LF/RSUqwQBPI
8Cz8l8kVWhcVqqX/GWBVi6RZfdRxMH9L7Rcyr39jNWvp6PZKec1ixmG4+vfBYfX1c2zGn72/
dr//9oUPpWbit497U4MOd1zthMR8ahBXcLjyOCmhyJ7Arin3fWdtolvh02wLfczBDl8eLSmL
R/mS5Nv+OUsljb4qH+Jqj93WuXLPf5rOT5yu42gpXxevgdL9YNggHlWE2Gp0W6HFkAHmZIRi
I6T80ND1WQDopKfQ3hGUfqyVybxxDgVwKg//nyD+SmWKQRbVF4Nq780cHCn+aXaTnbeAp9qh
ljGC8tRtCxPFYvqe1MAwdpHob9hLMP+XXRUkMo3F8Vg+qwHRo7Pfp9iFSQJDidtlLyUHKSM/
6awaK/2inquKPIEyRHENQYUWSEfuSUZvQPntEduRtQITUoRyPiGy5d7lIAU1X8usn0fXXM9z
w0q0E0N++fPUS4BYU4Mw3crMRzKpDQc74TAVwjtdeOPGHtiZvjaRCfBdhEs6bTA9+uBkvzgN
Ji2mxERtw+493NiIsnC/j2NRsYAx+XWm7jwu0ijSZMGA+PhENtA6q+neJJ+uXc4A1oX3qw5l
vf2d9gLwmoFJTHvoh0fOEJnhhopIKmObBtfPLdbC+U5WwrxwhtmgN3IN/c5oygiZ7x7ECDpv
YQiEqQ+5GTNzx9BiYcZ2NlGtMyx9j30RD5jtNJQ9ya61JlXrqvz+icuwmoWqSPbvKWuBffuX
wjK6v3AtO1xclDVc4386LE6zxjjif1LTldW68fEBqg9r+4e7OtIj+QCRqRNDm9WjlrOBwAgp
CEM/iBhdbspMgj/WCYroui09Y2M8FJtm58l9Iz+CmnqvDSo/NqBTsu9RanX/Hh4LnKZendkN
6l3ANu3LRn+LtlGc7y++djfLvyfWn00Wmqeem3ntBE86ZTmq+QHcNhfaAla/V37up8frhC+m
3EXWa+tyDw5yz9WiAHAZr2HDsCASKpJh6k8gEg06YeqcIBIqOmHq0CASDc5h6gcgEirOYeqq
IBIN/mHqvyASKv5H+lsDdgEp7RPQ6zoyfArBItZhXlwgBZSBGBt8oIiox9cATV2H91xo4K28
O6cGBZ+IvDucjwXcCdRZk4gBsmSX21RVwGdcAQDDTGMKTU1F1cNMYwqFjGbQ02QlCKt17vKk
9sw7lx4xGLNjhxoekO4Q57LIXbkTrYCGCu1QdZlddhQN9EsOEOL28/0aLsqP3/qVGqCOCc61
ylonC5m2X695dFiID81MU9Z/fxzWsiPBEE9+lOTeSHLGxeJIQtH/RRx03XVQZXEPWcP/KbQQ
ZHkaoUL0JAF67M5Vs/jETATjHmkM0c682tvtAJp3X+z43cTbyuOaahL4YW1C/313JMevGxCw
BbAUGt7r7VME1Lmk1zMa3/dLV4SgZCYx5lUD/pdqA6UjuamcFTpgFEH7x5XttNYOyxJaEVcn
QXyzXb1HujmM82/zh/AubyhLWYjBnFmAWU2r1VM5q8QTNkRZ3UaJLm9LOS5m7h0U/iyHEXWI
adAeQ5UCht9ahF/qRkFabA2lOAAz+amQC8+ynYJg/0rsA+Uu/2DR1WLl+0xXsRqEJCZPYwwo
ES5Hq6EogcRwKQ30dE8mQTeXEUh9FRKkdPC2gOYio4aTY0CofICZl/VHymo3t3OJmfPrSpBm
7w/XlynFuaAyuY4Hbd/u53jIqFqvSXFUE0Db3hz/CKJHlT6brcin1dHqUr4Y2VxxSsGtU6EJ
Zh61DNgmWUob8U9EJB1aSwaRlEn4qK2TK9HJanpfaNVJwQZ9E8ZLS8Qns9kGSRUwydzTTldF
RYm0QRt4obyMEmVSaHyRWBfFg2+UIDrMMJk0qXed3Q/kvfeP5PR8GlXIY31W0/v8BHARDnyB
wZkyITJ7gEMNJqWaKtbI+khS1Phe4YIBqIGSxnwYjZW+DYr6rPfZVhrxOaqmSrJ/YSw1V/I8
fIpNVP/C49WkoS5alQysLbYF+hVwIaL4yogi0gjysoPoOQfoOYCXOeRskzIRXe9Jyl2CL7m2
JCRdEKfAL2X+Mbw2HteB5BKpvEZ4tLk8EQ00KG8UR/geG1REfRyzRSevySqdkqvIl8u/ser7
ktwY2lbozFN47FEFQ1xLNZmqMsRUC3adWPmk+fQ4ZKEBGEPhEJM/3dff2f10RNaSIu2QZLM9
wSAsueVl5myN88D+NcaYCLmruZm4hIaQA00eDp1jmzU+K7ETO4yKjdZ1+X2A5auiYf3DX2EJ
JIV8Ue5Kjrk704RhCS7n0EQW4FzMqJhR5mR8nf9eFBeaDo8pe7H6Pu5yF8Y6W//Pr2BTmKAH
NKUUR5PvEQ9k4CcX8xgQ/usemMq1pQ4aIKtzoSsWwtFvEpieuRBMlbRvkzSiAvMexsk7qtsV
xe1B8zVlUJu3nUclrsPzofcVBRuFWklZmtGdGdfjFBCYRZi9K20gfRhvZvjPB0hkfyQxVmR/
QmJL0l/pwYF2Yqy7EZIyx3jth0dY6MPmP3HudcIdUWm2intKIBIb7IIBb6gKQ4flCTJm2Yp+
wo4E/NKovV6vDvd01qFOI0UZzjg+GSMDJpeN75tkF5Hsn4tYF02v1+wTL1iePDk5AGSvVp5B
JdL5tywX4Qp4s2SFR7cGKaImmSO2VtSHV0goqr1yDottLpCRddq0miDfeV5HoqOgdbgWcrH1
yqXNNs8xmr3LQlpANv7Tip+O0ww2BnjxNhujDg+30N6LLhNRelYMhWPx1V4Yky53PKthaZQo
9WZBk0x6qUQN8cNgwJp7CZ6UDck7oGA5RkUS4nGoQoI3BIGAwrCjSZMZzxxgACXsO6PkP9U3
TotFD+3pnzvoadZBeRkut+IQpsXhQoJKdTK5HVVEHYwZ7fCQchOu2000uxhU1pvBLPoTTJG6
1NZUAgCF9mcWJ6KPScjVXlukIteGDLfnOdWgOnpMDo+7BY8nhB7zgCC32y1OMhn6uS8cozsu
/pIjOup8hiIAlujb8UwZvo5lMFSrAJurIhwZzlJweeRLgql9Xhm0SaA3O8pbQArg6dM8jlqA
XlYxWa/DZQWhjmqTDINuDTZ0cUvCjVZkrGTr+N6RVr74RXFxRG1CEZ6vceTLS42gnxXcwgHH
gJgOvox5lFSbRwm5J23A6kt1OhMTI8vHNnyCme+E+ZP81736ij8M1OShWfvNrOipn39eZxL4
6KmfUl5n+N5Y4YPQAZ6m+Fh3VZ84MsRz5/xImMhFmfZBI/A98WSM5D6WqiECwnO0ngGYDuah
NOttQzkQbpaLHnIUjyfwFSN/9NyTluXIbEuhlxLDw0na2PXCZfXCn/p7kxIee5OYJfochEna
WfVlymXkNw1/dxm9EF/j47lrL2Ka5vgu0sF/yiTFji1qw/OZjJGhUnwTJfMkGtS4VGkLV1bo
f3ZIDwtXkSFA1s+rau63JQSPCHT7TQdgvhC6q2o4OPDufJ3Uyi2Jcfxq7oxNKEKkh65a6rhm
a3WHreO5Kl2UVWKfg/Lic/a8OlnBt6pm0NjbdqcO28/KRKLqr9L8glLWXMIi1R4sp1YeLEhM
PCTYkXMHjYEmTaqJGTOsTqh923OvgJfji1Eu7oYbVLPhGJ3eu/65AEqR0FJKe1Qbzt2KKmd4
bRKgH0yJ6kKh+Qh2bc2OsE/uAiFoCz8ttbfyzoBEbOSM4NP5szNs5IwG0/mzrqjuJFNJj01L
carS50GpjElslx8Xa63SpraYEOb5RozGb5XQlzNJRx+zmmuBJO3l8Z5ElQB0xU06pLKtpfon
YXhOlVUbVLtruZQtuEDECPmF2tl5yKPock0kkxB9TZEQfREeklDMYygAyCI2iRYKSZN8xmQe
XDLC5bh05eW3a+V7k+npXDpj5XuT6RyUQolUkF8NeqwN+ksbhjKupNg2jj7yK9irk70BhRix
LAXc7n9XlA7OgrA5kWGXxUkOzgP/800hawXBdI6qacuvzhJxF6ky/7Si9LXP66SbVV+D5cuJ
BgZk3m8AVndZGvrB7EREAXWsBykNqvRyyqrPwBXLQRCenmlArwJGYQQMD8strHZyZtmPe2lA
k6IYqvezXMp0jNNX9B83wHC7foobbSTPEPc0GV6g+CAJCdz3Z/4lY8iYMP0bvNo/mUNQ6eDi
mCEm0VjPhrEbRd3kI+ZXvrut793stBWkB/9Yr10x8v2ykoMbLb2hBVqc9N/eGqH1lA1QWAtR
GqCev6TN1WHQA5hAuIROiC5QxeyXU6puRYbZmdKbAJJ/b7Ph/Smeku/ECNH6H46CgW8jHz+j
9REGqsaaNaAAVko0bbBHM/TxZMZMdSnbO+wvvXchfZpJ6tRg7b2Yi/Ppd55wnuNJzGYPMpsP
y61QfyNb756xz1DQ/QovG97sVk5SRV38i9s0lago1yek7O0ZLXJ0VSnoLRC3W0BKRzPCVQLG
YeNNleaL+qcIUNsYQnFfS2DwX2UKfJu2tgNXu7z2pR22F8nSKEvrcBSfq1/d3AF/usjjZbfM
G+aXWfIC9CamrUNmFgpeCpVW6m268G/a2XqwYJpY9VtqpKjqPS0I1ZXuOaLG0hNeR992mlJ9
0PmR37FsWoMn1UGRhm9vJQeOaV5xdPRqAVargYHZb1sVfaizTR95tj7d6Z373lQMNVLZG2hX
J+U7Hsigl/FubSngXshmzd02bn3qKsvTs2HgFSJZFAYEfD1ZF5/CoOLJriXywKiEO73ZmZNe
jPTUdeyrC8TQKsxHx2zcrFomHhv8I4WU35LzDW5JuH0YF+hz95POU//Pi9+Mjb+AxlvlZo7Q
ukjg1QPj16+kDiVAxYSWEZJQAtqW6A/Jx6BUGbdlH/bkMW2P+M0nIw00T9FaiJ4J2QYFjJwO
qdfp5WhJGJ9x/wyvxmecpb9D0xuSe5xU0PpEQLVZGnrfPsnVoX+002V/CNKoebLErZqdR7ET
QpkCjVpQe+d4xYOUoDSQP+34ZWS/FOcxM7CJ+BohRWpzENDlAXXo/j6zav2AoJQ0XXd+8lkC
26mh+Zr3bdwK1tkCDZ5kKfFsnlEyrx7fmVDTVeK5+i5xIwif8MnrlcT9q+Ba5aCgUIpkciFN
ni7MS6Ni6vk9X50t2rpRE4FJ5CM1SPhIp44ljkJdp/9VMktFamQ5bTroGfvodTKC8mjTKeA2
GqN+mZ0qMOLUzjD6+pUh9e3kRkisgSOSPmdPfz6mDHGRWNnurqecHOBJRCq8SwlfzwebheYP
wvkpBoHws5KIW57pNelZwG5vw8GA529Pi22pCRvuRN4CgFH3GDjQAsGemnd8GeuFIlAOZJ0v
CRUbSexJpQCn7N5A861ibjCR045tuau0ESmTS5k0tfNrLStb/3wvdrmry5Em2ZG68oC/Hls8
i2V0rL4AK6SklWNvn3Mbh71N5wJpA68VR66IeG7K4t+4Vx7TZzXUki+GX+OeQO/21veCgjLK
uDGOYW5CdsrbMQSPbkLKygSjngJh8xunVFm8GBoB0gGSMvTTPYsF3PTTylNN3QPt9Kx4ndyi
C5UtPZX6bovL7e5qe1INfjYtWa07ZeN8mwq+ghF2oQFV1sk5fJ4MvUnmF+HoYeylwr995F43
CZFgGId0ANjEKufKIhn77Vc5FQvSI6S97BWrkJLrS2ZRBD528v10C3a35dAxW1zUvARbjHvl
egQO6J4jLcBKDkDZAUsjVs3Xh6oM8QEC8pt7K/Et8u2ePOtybcrFQHuaNnWUC6SkHvwRDeQc
2MGxXvXQi5nkrGjF+PT17WoHd4HLT1/iv864RRnuhCkjByiMHqQiU+K/zt1FGe6EKSMHKOIe
pCJG4r/OyEVBa52jzdrYd7zyzetVqUSiyEsvZydny7nWlcn+R8aN/+opzwU9OlQ7rghIfa1L
xE2ymIQs6+pGXD5XuqJ1uCLmo1zU42lD61Xq+0A9ERfaUU+IIaAHsbMYLXfCgaCQd3ccaeoS
o4ODHfz2KOgtAED/M6WjBR38edBrvgDIuTOpg7pSc803IVMHJe4cWm0SVwC5+yq+8fW+BoNo
hucsq6kC9UUGo0zz7eIOyepnxNVNVY3omo3Y7o3YhikNNM4AEz5Ho4TDM1788FSW2YgpvSkr
0NgCrIOOUosN7xcZT0WOOSoRwSyHN3N/bm2j5fJqqoRj33T7y/FaGXzIexiMhzY4cLiO03Ye
nRHyt0j/sLFOuziBQz62QqQVTDbZKA+s+GkohzbE2fhDMkvnSAmQVJR65CF00I2CA8DJK/9H
l1iTrYLVF8lDR8+mRFMlqdWyUyWpxPxDdIFckSxF40TkiKf8wQPeFAiqT/9Lz6oHvIz4IFSy
U5goyVSPtTRfQ+QFQ1W/5HUvKVUfyrQ0AugsvPNsBtnk2sevbwqZrmaXLeTjNoc9OxXzzv84
wKeGotD5Ke+xW0mkRieTFixLTD5Bl3yOLZveGBxWeih19VPP3IYWcxDSGpUXaCArPv4KfoVN
8r7QwmNov8Zq7tlIuw11m5iX2w/z6o30nS9Vw72S1eU6rU1ALlByGsDQ9mxSJjqve2N+oQnk
D+m323ShA166E/GJAvI380ank1sGGBPhhBR5wuEXVdOmilOhHFDWMExnhdZHHmtWdZ5HTCcT
Mnw8nESoaXcUghHoDuVveE6suROzvE+IzTHC2FBRgC5lcnsmaJ6oWbRm1XEBAepwuQkFR3eX
nNYCfSp5jVi721y6JpY1+iBabdhwQ+bC3Xc6QJMH7vz/4e8UecLhBwol4e8m2l2IK1x3K4JN
tHpOyOYAcREW6JPJ5TgKmuZ308T6nnEW1pmpF6NDV5CQRloOXjH6P9J1Gr2WT3yvp6hEysYu
wsdc6BgW9QTbecLh6kXiNzUaYfV84MuGx5n0y5O4Jusrdhp2IjFHRG7DHLGKKommnCdBrNzI
saCPGvLVpZEIt7LEuLIWeYFJWv2FVETFgHOwaI1PzuyufmtPWtr3ECEbXEDd8TQ7pDPZRO2i
KLpj27hQ05Tbyeg0vBWvoW4k37hXVaLhjNhkAWmiV8rxkg4dUTwqVzCho6oKVZGBnhxZGm+R
Z54EWSSZSOlZEw8aWmjE4WopOeR+TX4gvjhfZt3799u/pC8N2HLvMsWwusoNyndO22CkRqdP
nPKddnSH0t/daYUpdkuil2FYL5bxx7h3ZSGmgO+4DGfpiIhudhZpTsqIk7TO7fGPRwuTVjOD
VqSW78e4BDo8dICOQOkr4uK3TY3PRIewIhFf4NFbbFJRBWfuoqPpQpg1mkofSxXVmWDxVzJw
dwbeW5noMHl1o9Wzux8RATYmoPI/loktWRSr4Izc1wOk8HDmFBL6g4PMlxxTPvaWzU02mWhA
fxKfkWuoJ3wvB/eV+wYAzHXv2uWCJKD6xjzbSvx6rqc2ESUXKzuW4qPAy7ehYytFSs/U0wQt
OzuMAABSDI2B2B1295GBrfjqgHv7+odgM0/Lz6DzMVwhWjKJBx9I+oOJe4u3vf6msumk64iO
Mit1EntQk4RFpYvsSptWqPbXtHF73TU3Ewg8t0owy0ZdBlqFE8iQsBpFRjK2wNzN8ye8WcwW
KlZ9vtFI2GWOhTSNR/Drc61MFr34E5Y8ryeEubtWsn9hQ8CjeeSKcF2t0b4qeIjvkNXlyQo/
wZhy3c5t2BKRNBLTmJ/YE8HtmfFFD4raEdlI3nFsMyyMYsZERSrYE7qnKSWYHIr3R3bY53u9
2JiIlyOTupuCMsTV/gFLOwW77Lx0dRk2QQJsV4hN0f2dLbJpnGLZPABdE1lpZULfVI25NvdV
/SbSVF43nBSADo1KhGEEocxOI6avYe4yYmBWRodqz9iV49ZQFHAcPfLbZ49jsrXeCMAsoIim
+sQUQigRGob9Ymnd6yFhj71iNc/WK6GEu2KH4NbMPftSWgeGq3t5LWWrpYcu1rPddPufJ1xW
MpRTK5UJ6i13XFYy6XFcVjKUDEzM17bQY0Dh73vUyCd5ZYgB1dFjWWFLZq0HXyNGzzfEGNt/
ps6gzDPzzvWW/PubRCvZrYdwfUIrQa6KUUCkxPSG4jOC8KZswMzQYyeQIHEia5lLKX51HZRS
+bM7F6vpiNOwHFnNwEdFp1kbH7hEx491yLzpsuzejmRU6HQoRecMsjND4y3DFCP77pnRaF/Z
KyHoS9hNFQmGntlfVmhIfmsQBDhAyuZvJGUC88nLZkeI5uc5L8LGS8XI5qrJB/n1uVO7dYYx
Vkr2kHh6AL9iqZ4HIYZ1NuT4GLTmbYYxdiGp2Ddl9gqygkvhhaSVLTVfrWq6EZ291Cuixia5
XWlP7Qhn3czRy56iq6N2r/T0lgCYuu5raKDj0vrAihWHJwt1je60RHabRzHeORscoAhFpbCg
xfvexnaGASLJlU37r1KusoVgMBUt5ZszSVkNnnXCdBJTvTweKbBwseEsZwJ/xlXZipxMZQGK
2Xa1yK3hrFwKmxl8SnX2SgwO6eJOkTRSjSm5LhVTwg/drEiZNYcLHeGDzgsN41yn67TUCrLv
rAILtMnWsv+hc9QtudmXZFSIUtWd4EPq2OQYlFJcP5WXZFTM167u6pFcJFADWgp/S8B5hIWi
FCqFQ9HVSNCWam8P7KS8Vv3P+jO/EreY8LNMgzqwMCAsNJVI3fZQwx5fRZYH3CypayflB8ar
zbKlI2UWpSVkdPK/Q7GL1GSrUZK8ZNdM3ohB/Oig1+neiPG4LoOLi510Rp3+D5OEQvZNlWL/
23CSPrQOlcCCtVednm2E17EWVFkkcQ9bA1sNjasRq7+CK9UJMtL4SWq9D5jnghQZguGW1D3c
2DUo+c/6igKcOM81l7DwoRDoe/gq+YsFeY+Grif8II3xdDWP6QkIbMSfrycNcQAZUS2x45aW
pcUhwmtfX8WgR5QX4R7ahGiUkFOGx5QX00ZtV7MktztP71o8Kyv8X8w04YHOfmsJ5l4XRoZh
wCO1vde5K6iIfqexrydFU578um8z8IH99Xin8AzG0emDXNl2GsLIK9midX0GuZIjsJxtsF20
JzNnBIiXG4gIUscDx3VNReRIAgfgxhVUhdH/Su5PJ/d0tFtT9WTfCvZPAOscmpCZ9ikq2ipe
bA1dKYMDzVyPBrg39mq+SGAX7R+Qe9uoeLCvRN6+iDP+EcQytcKJ2Wv64D6kSo3WLcKLK8tg
MVvCRK4LQwnYhSbAPiOfNgk6y9WbzjrPB/FB89l+SZyMHC6iHycTzNFTVHv2S5WeTe8bjV9M
F8ApG3LNbpMrP1a0N2NujDtOxW2xxZiYGP5e9F8HcwI/ogEUQXqxM/mzneykY/XYN0k9o0CP
OABGMzPGSfWT7dIMnzGWFRNou0giNtWg5FqEYbHQjOsS/1ApLhabh0ob8BnVIJaiXiu3Gqud
4LNYG9gBdRYT90ykagqhyThlWlFgLat0c/cnjCkhL9dUiLBCkTLKiESHfOISrXtJGpId8EI+
J8KaJqJV/FZk/5slokxAYUGkw9O46SqUPV2Mq8B2Pun6SgkbbwB8a4xsQXFWow2lsyQ0eiwI
cgZxUu8rZ8+fyqGzcXXsrRtHVoATRhHujNhGEfa9e4zOfj7a/UQX9iYxFmVqm5u1cXu5EhNs
r0u0Cee4ajeAuSJs7DZofJWWS+7R9B7YyFjxr5lfc3teEkWrkVlm24dV3P5IsAop8KoqhMbu
pb168LZpM+lJmbR6yVVjFD0LTCqc9a/6ceByHVgomr5cZP74EsHBErsIZIcgPA286hzFN2/i
TORUHrF0s7vQC7NsXtCOLyK3ngA4tt0GCnsOvxpxN9jt2L9oVRk51cmIfWOCNILuTiNM7B3G
fGOTd4gkvCf5vWBNpDSiRDRPh5pEfYYnQraSMD5FevEbfTTHI5y2W7L/cpD5qZES0L9izLXT
PN31bXL7MwFSMqE3kn1UdJSPI1rKd6uQ08Q7YBr7pN1X+loyqDOmdtHNUksHtU67cxBcrmBz
Nt4KJdHVrb7AGgR3hQfBSTmb3/FSY4orouROUxKJRZBgClw2qdkmLxU2EnsAv4B3kzr2xQ0z
83eDVdKIWCGwCpXJriUiZR7cZZ7T3Q7LAsaJu1RHPKN5nsppjYdcW5DJ2drc9mW3cnLlNVzF
NWwuw+hOl+7DzC7pKmxXbqnWK2JREkrBsxbIaZ0b/+Vg7HXPxETAlWjVODTT1EQ4eve8sQ82
lufKkWTWgYO1wuSp2oXmKjmsDzpO2y4a3PmZMMvgUI1Qur3tPQhMpJqNULrMLukqY6KT+sIO
xXmIvtIcGVmB7QhjBcfkvIJ2NKgXcIxvwXLj0X5gCHdp6E0rssi7Gs+HoQzMUF6RiuCDm8JB
y8WW0jdC3QQmaIk52DkPkMiVwNvJtazqV/MjJ6VEnpNm6TRa5fq1AS+0Kr3dL8gdX3SLU7a1
JIb3tpyGAB+Y9cPwatolZeSgUnKkWUs/38MQmHe0MkBM7DuIchBG+DIH1rVpPdw9daDj5R0M
yLcY4Ud41D05/1uMDL5lrHpS4r678DlJSUoMEa4xeoMQsCBOkBker5UCwiZRCEPj8WHBrRDH
C2jSQ1Ct/pC/GiFlnWU+5VInCSP4bosWnKOVIcApI86OX8ikuy9c7ZptjsZoj+Psy5Jir8wv
7QSQbZaH6WyAabGER6zVZzSDDPzgA/C3ByeFid1EtImEbTtJs0worLpWMAlgg+12+lC35tSb
1RtPU01GzLZgU6vjTN1rx2Wvqx8mkZQIEtKeOMWlM9tYt3pgEhjDnj5GOXhrEfZR6QC7vPYU
LIMaD+zP35DKpCJFMwYI+rI5jPOL7/XnlZT9e7qL1HTHEBu8Ltax95EyytwEwOQh/M6vEXx7
O8T8s9Xf7LK13FUIQ0QjOofiF1DPKjj5Agc/lB9koTwH9iwnvpfSycYmR/P8+LMk3Hy5mIk+
2/1gn4AudDA6xoaZwJJNm9txVTuslYuS/ZL2vpJ7D8/m2ekWusCP/tNmKXeb+gwV8/GT8Bvz
xRWJosVqka5OxndTBJTUG2zPkoHAe4QDKRv6bdYi0ephLA9Uh6JC08FuSqEniCP/0Hxe8Cj4
yE1Y6MDSWaIn0m/9J+SX7mUqonwHOfjRFHrxDjzHErasje6st44N08uCiolmmMCIlGN25/Po
BTB+g31fmpSQIJj5XLi1RiA9jK4mmUb3Qe6KlCR5m1YJphdzMj8S/Udppf7JKu2D2L+2ta0E
ELB4ikUlo5UGZ1OekZvgbTfFiNysesHB23CuCKZZs5H0gmyort5UkQfcfoQZwl9nOEqSNqex
sdmdhb7zqLMkPGuzXFw6tmBWMoZ7knrtKFAHylQUU4NUViZSvyKEBJMXr4HkIlREA4ssCTCl
T6rUgoH6+30sNDCoy7YcjHQ8UAuOYGbhgH9cWTeyZl1f3EkXNjuVjSfhE5u6JQcT20FG0Ncb
krZt4fj45XcFZ90qoBdFRpPAW0sqVQzNGinLYY7MBXDbeOPJGLB3tjeq8s73N6a95w5uGGZG
eiNZe/pMd4JfRz+b2Tw11WiRlIdQNFwVS8UM89erTSbmYuM9NlD94qtW/u8zyi08kE0W461d
V1cE3TUM6PDjHT5A26R0fgzhxuo3YTZb3mnmPcF0UJGUxTubetuqdDoNr0tawGV/PYx3Y/MD
GTYf/NcrmD7wlbGbp4tihN4m8/tGZ10BJig3gaseIt4rw/mZXBDOnrOfhqLUkFkQ5raZU7eX
IsPM3LZBVIFrOgh3aqkQzl0SzxdNrvFtri7flyL8XTeopkwsfwdwehS0sHi+isuEu4xXAC+/
/3HG2v0o+Ii8F+SblG9qd13LuXJU+t4GIp5gVut/haivzPggcsocnAf6bJ+r/UG9qzJ3MuuV
lr2Z8J4yNPqCQhne/UL7V9rtIYbODeRjGM+tWZ19DRi1oT71tEjeBqHprj5ry5qCoQAmfcVD
Me6Y1GQTxY26UEcJXtjceAshA4HJQm082Zg9XA5c1KUKey1xWWTqr/UzYo0CrfcWE/ErIQ0g
P/g2ID7xzbXM26xFXJHOnAUUMz86lH5VHwXl9f9a7jQEn4DxUQ4JKu8utk5CJWNEGD3wh7HH
5k/1zhB1Dyhg9zGa2hnQWaMYlJKBOiKNCly7hSNe1uUGTFjHvf41KrcRB45O55qOkJUR5GFt
k+d6H001ZWxN+3oDBL6Pb8pKPcr44QvW/j7Avv+hssJiXUvVX1W8htMKMuaIEMYef4XR1bVr
8XYLe7PIjVRkJfCI4t+8sm/bWS/+jYFh2IsaBmuTPhPo4fiRehwjVOCwW+RCvyXaTu8jjYEK
EaqCQf5SZDDzM2bOLq3ZH02xhIrMADwmHo/0L7L3iFyVRHe4E6TrdNM8EyDk49SOyjdrk0ri
NkFpbOsEqWPa4WXPy+foY/2MJqCtTUgDB5/nCEXRA47GfvyypjIECXFWs/xIUhIATASyvM6N
oC8yIUxHaQZ6Oh09UrVXB0D0ZnXPq32K2BDSxjqPKHIKDG33kIiOZPJwlrxN3wx8VaXuTf0V
kuK5K9uxb9FVF1aPswJfT+IfTtAs1lzSBvz8J77s94cTbJJ8TMcCYp5XGcA6VfWJFX/Rvbtm
LUntYNGTju8ssrYizNZKldIG9rJ8oLA6WuMyE08+N+Jl8l6YMLQtSSwa9CWVvTNauMUboWbM
fsCi8D/+EFf+QJF+hHLOlkjfqunN79LVI+JWO866ntJ0csWZw+/dFuTbq5EuLb/PfvIugzT5
Ab8WpZY4f4EeW0EDzOSEPtlYF8h+ChMQNk7gAzdnUBVqK/5ZEg7myx3Ecr7zrYCXRf2+QD6Z
tS7V0GVrqt74qcLMooiYrMLToWEAl/JXpikRipTb+EmVTu1XK5l3wMUPeX4sNhv8JjBOwZmN
VnkLvxiViSHNZW/T6tkKcO3//e+lL9Swq8IYRPSzqfQPjoaaiS3ekrSmYBfQ4OFpruM552O2
5PWWCkXcpa/ZrbB8w9HsXmKcKamdwmeVZ9/OTkSDeCsXmEFkeDb3SIseKrbvSz9Lyrdmfxst
8JY6EVyiqf+0F5Qr4Dc16QjnZ+jPXgLz1e8jWAvciUGf+OO2HhG3ISVG26fP5wkMe71AaEcg
40r2GNHeDLNsa1Vfahzgeutrt2W8FK71vf2TFbLn26cWhAxnHYngulbvgH1BBBs2MsPU8ab3
FENG9xbgWoOfoefupvFbyyzudOnGWyfZL7rKxBx43ED3ZPGpDJapZeZpQzDV75JjX6Z1en98
QweviRy9XsB8WZMIfFmzNVx2X62OG0RQ4S2ouo5Z/2d1bi18rWo4wGDbXXQY+ogft4IhGxf1
Wf+mWG5/Za1qkcBgl110pz5shxsXhVk6zIJDRP+R45A6YzCKWTelWOTzIQKsERiVs13LY8zn
XOSdteS2wCW4CVcK8NHvD5c9wY/81aNwVahKLZOquiCsE4Ce7KHb210jb7cnyvoX741o6d8q
v0MYmFqTwB8+J7mXlL/zccDqTLicHyoMvFYbwRQWEqZce6ybxmmRZhaqL1zT4SId+wkayi/l
/FFAkmycEKY+JSjKf/s36fpIPuk1z/I+A458RzVZ0B0bxu4ttkdtjPK5N9IxAEcmAMBDaibn
fSnTLy6PLWo2FMHdN/qMc49dOPcz6GZKGFdh5nbMJkxXnfLOPQk/gK+8NQKw28+oG+P0mx5G
iMknhXV/QIKJCDHgId7gqSaTG+P6p4gbgPIEXByAZ8Hugnzh/LLIDzZQFxTIxQ1EWZNmE90R
ew6OGx4ZS7Bn7zpDWXcWMCk8rxBL7CC8a/bkxjLtXvl6DdzEVyRtU0Aqr8cKcV3sioCG2GFS
sKvBQRj0CHVrl9zNHxseUcBL8hXYy7P8L9dsOMKwaLhU+pCU+sMUCy5ls3kh37tRuHvuKucQ
nbW7taZUZ8wp

/
--------------------------------------------------------
--  DDL for Package Body PCKG_GUI
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "PCKG_GUI" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
97c42 a2f3
T8xi+Ov5RFkG92LaoWVtjRDdhckwg83tOMeG36fR5D9Mc565O+zxiVyOmLdYv98A3JRis2FF
PgmoPr/PnU1uSHIaF9qf5QVYMTGDLKr7L6b7L6b708IB+Boz/3le3ajnj3aPenKvrxuHNPBy
t30hD4fptRcDMBK82pri+XIW0YDzkiBeXW2RvmLxTWiPLJ+cCl1VuWb0nKEtusYKfvGRwZg9
wMSXZtKqfbVc+kIJyEVMtddRefQaUOzM9YgfbW1TMENUQlhuSHJCeZIGu65R78aSF94N1Qpm
9LGYVodJwyVRxQmSMNHkkgf8J7cw5z+3T2EaURfHMzTQenHpSSgk/o3qlbDeUXk4Tm1kR9fp
cWHb9wcQvJ/zjPvXbdVVHwOaz10bJDvlVeC+2cSUkv21IKeWm9dciXmxsP+C3z4YMkIZbwat
v/d16bxZQHgbTAH6pTyRnIHDBNF9dsQH2fyWJhjZxIFGLIMbka/R6tmRvtrtq1bV14ZDSPQb
mnChzviXTACDHRf7lAl+A34Cfn8l0MC4Tk1HAzCNUUGZPtOTd0NctGDiwlxC8+VYMPDV8QNm
Ppaf6eP3yQs0dLTd6UGLBRVWJ/KRO/LRwBpz0LWX+S207oFBfWTOJelBjVxuXHH5Xa6aLu+g
d0qyE6wI9lxdAQmJCnoD43r5XmKbMD8UwyCrQr4LyfL8L4e1PSy1IRBijYthhWshsX7tiu8m
pT6HwXer6BXX+VqWOpgkDJXZxTGgYJBvT3Ys7ZLcxaSwKUhCGL81F62WLt9SEyEkT+raM2Yt
0wqp7D00rLlPpS92oQLEWplQhc3foS1awuUcADQEIAbhgXkCOZ/c+fQZjWa+lJOJLXYlSgO/
lQU6Mbl6NW1kcfZlSpZy/ToXCFGXmTPsCFartZ9zOpKxVSTiJM0iGRnQsLN4swj3vHlcQRvp
bmLxAA3w2bEhCkhQ3qzJE2vQsx5dW7XzpBM5UmaNFKuvM74ulFLV79CcSwA1JJGcKRpCrOz/
WQGJnaSuY6PPeCXDC9BQ4I27hdK2GdqNCk55Wl6QAOzpDyyMFaPwcGMx1pP1FB9sg2fYFczS
MgPkSgLm2ZH31OkDmYmA4bXqG97C3bacEMZRg9uZOOBw902/p9k6IwCd5rXpHx9kvPg/7ZK8
VsZeldGMk4n22KkJ/NiFsc36BPd42emaTBTpACATYPOMArxFOo8zBi8X2U3R7VRgSeDEnpCE
q888U/JJsy3SujL3kWKzCnS+AVxza9sw715lqEpw9GFWHvfrZemyIhkGX3H+3l1EXCkrHM2/
aAKMDehNn9knXVPwTHuc6fEt3FOUhxtDUVR5Sy4IHo7YW0rNoT/bVWU9iWBeEBOJfSy2OJAs
MUb6bcQNEUJcJ3dnVZ5jKUGZ5xsnXYvGk21Mn4HkX/aFy4Hkegw/5Wl4rpSU2L96HoHlI2IA
gLayJrARtB+hEp/KmfdrpBzfNgi5VprJ2UikK6fjZNAPxG1a9um+AGIK4An5dQbBA30Ec080
BXzYb005+V663HFv1JMc7pbjhR+ihn2qtZyfZOgD3TY3veG20i8b4wScdjHIUdLExWQcmuXI
6IawQvvfRH6etImAYT4R8b1jyLuzrAwrbINHw5t4xNjwj5LtFeIsaj/U8rZTIAdVsF6vsGpK
QfrHCxVoEGFeA3Kf5c5+Ws7lhQMqOX9mSVlkgU+b8NN6tXP0pfuPKTehNrfOiXoAjPfaG2BK
hDw3inacxElesaC/d7aQCT6EJ5rOhHxScAbd2wCTtrBRTiNGh39Amgakmnv/YVKrkNQ9BubQ
5LtbmpxWTb0Z/tbOmHD5kl6/XV6/30ea2cKfWAyM+nSR3xJY/yKL6wVGkhPMD178edwSWHc/
yQ3roDN/ZEEbPD1He4iXUAJoR+IHKTIhnT8btJFAMjSsWLq4jx/YnxU3FwSsnpLK1oStW3wS
cDPdigABAxcGZTRWtApqwnC55Dm0lksPcJ1B5XPxQrb8mPRhoQC0UYCY/3Zm/XgT9Q1NHf3q
2Z+ihlnSPrCzD9y4tGOYAJQL3r11Seski9cnHls+YFhzSQePtx/nwnlNFb8EXN1S/iEUBZ5s
iQWBNgcb1MDkFstpoKY5J8Od2icvE/PWUwJv5KC6XTHguo6hYP+XiaaU3ewd9svYrWsOrMvC
/NC08SVOYPNhJDltg8grhXPiG7PqsyGjkY1B4mV2CyW26g31IbfMLU3PjLsmeDqXZS20NxWk
K+15iGIZBFZaQWt4R94mtnFK+X9lMXFxNhBbIlr0st9zGi1BVITCPlUNrFdIDrypkhhBLJi1
SX58HmqJa81jwKJOiHXZkm3U1AZaI0Cc9H0HtuQgNKRgqo1wTK9FrDIQ9DyBtUkFzM/ies7J
w3vY+Xd+CrOsmwsO6JE+Uy8DhbXL2lRLLXALD1Pwc4Ixr2WY8yMoCsmlMBiYtL3R71Q8hj5U
DEuncGIPUQ3krn5icsQK48nTGJ4ufcXEiZ7GGniNRTSiSDVzCIX0KwkPfDnHNovnR7PHfIDG
gG6S1DrQR7phU1n8ysWVFOmqr3+moteMUjQ7mzJxO2+GFqHMRKu8IhvX49l9Se37t2WSRA1x
8meEF+V2tLg3Ah2Z/jRWdvoo1AkQYLDq3BNiTjGhbN4Racdc0cjWUy73mtU0Y4bkFHVWfJNw
wkHo+mWDVvG0ZrWl7uudUZ2ac+TpKpPs2y0ywoCQOGoIGKAaegCRGi6O3ydYoPRgwps7129S
5uEuCnqu2TqI/A6VuSEmGWyh3z6aR+tT2J8FLhCl8enFKwoyrMMn7VhgD9Xg2XhDcUdTiBDp
QwfcLHuQ+Q4JHJHqEnG7AdC0G6efwwrQd5/97oVcp2xENe8TCTYycY0RHnEGlhwpyoCnyiJ7
qJAVtdhYu8Kvy66iyrPkm0jb65T822K0SGlbrjYVPxgndyitoRrssEiPXiZ88G/NAdycYIgX
8TVghMQliI2wx+r7DMVWJksaIi6Wjz0sPrmjSVos1QpkIgipCvYOqS0uyzPtojp4ZAQMkI/s
ZiH8ZXEzMKoJOI60UELsrSTvwTgGz3RumEJOfEhB6NexS5NH7E/Mx9/eVTk7agQy+XpId+wa
0NV4+uAyYWVEnkAwAQcqxw0BkoUShGgAfmBwguET90mYiPsQRBBEEAARED1zVRnDusAGoNJT
71vcT0fz0YjvkotFiBHANEfw0CZS34K5G9Q9NFcTb5YDBhcJX4vbxolX7PfRtuBc+agknxN0
W8ezOMVoR0YnZvW+C3sqcz2GEUW63ARQx1DHUMfMcgjxIFMtyKgCkvhKCCSnoZRkJdO52jye
QPhK7rwLmHUdRbtTYaCsdWattjJ6pYEm+FMkPXPhXDPQ9S26fm3TeYhdtYkgeGh3FhBKM0DX
lfFH3AjgDPCVOD2yb4A7YuyU7kNi2VEKxkcH6BzEyicAMVlagY7aazxd1Ge5GzEUfew+/BCR
zPj/DOACWI/1Ln6dEuAqH5UVVbDuuSINxXL+Vjzh6tgYPSMl0SHpT3tB3HkYGh/viUuFcPIB
pzUMVJHjghlWgBYByGzVCofxw9TKBwrihzb4WLHfGa4SQcP1efMLvpuym1b9HhKnH+8d+y6A
wAG4rsn3fHfvAyACJDHSTmbQXl0xFLbxj0pPNG4GMR8qqpgrcm3pJW9mADKOMljvYmlsoSgA
JL3G+Rrq/Ac9rqTpLQRJxWpk9t5XiWmItSmS8xRbniB6Otkt/N7slhnfMilPSo0Ddr4FvfzY
YKmlhcxajeqFKIw9+izvhM/bGliSIIukAw8l1nhO3FzIq7Q22K2Oi6hK4Amre6rUenEvOvFM
kiViXCWOXGHWqzK8NSXKQ0TLg0Nolg2HiCPG6PWQIA61w6Io/S5v5bTx3iuzuUFN628+AHCz
aNz0wzKU9ysCuYk+EQNmxF5ygcLQf3I+DCUKzww6HmNkhledzk9zEarZhFKti5b5wb9dTzfU
P2s7l6ouWmIZUoUrss3fwgTNeFH1gd+zuVsAAQOyQdxLSzoeqJQgOlkJKZ9LB8Nh+yGhb9/j
QSX6StxJp3mBekMqE1mQaUKZxfQilpvNG3vt0/4/JdGunU/ZbWzA3dsnly7e4d0337DPuz4P
RyaywxHMHN1mpm2mVqyLp7rnHKbHpoumR/s2KKlB1kGdNI833xfo0KTKxiiGIc39V1AkJ3Bp
hd0/BkSsOZk28I7nHBsvFmBwlvvh+1Ed5kY5NuOZ59OOcOPnyuz4Taj7R5969XqpzkMvL7hL
+/sv86bz+y/zpYpm4aIJjqrEQfOQ9DHmYADeJZOR+mYliU27BWe8Bs79BmWesUh3NFgt6Mjn
1CVgttllbaDn+HgIMKsq0NgqXBs3d5QsnzzJijlk3oMLCKNuD8pchQ88m4Vy5fEN5EIVA0m3
spgopG/s4ZmAEgKMRRXruqgWO6ghb7gupnv7fTZxtrgucMvddqaxNnG2fa19OhlTG0Adv7Yu
Mt0+dglVSbuOr6hcVxpFriL8jz4+qx7L2I5LCd3y+9VE2I5LCd3y+9UyddiJZ7/nwWcC7xLU
Bs9Kc7hm3NHK7anS4SWZUJZnnanS4SWZR/t1HcrtqdLhAFsAKK4jPdHsHbvpzAP7R7FnufZX
+A2A+dV6HW9BHQUomW/xWwUstm8YmZnUQAIGahV/4Fty9C0Uut0Y+9Vv45S3iNUOiakJ4fK9
FmwOicvjCWacOMcdEtOkrjcc4SPnfajd9KZJ4SPnfah8W3DLqRzhI+fSdtLPKNIvMjRFvWbs
aKrnJCFfHKtHy83Qdp7/skSwQDMVdEQUQDPUmURRAuYt5jdaa3BuUDhe5ors83BGqfPhYOcE
qHBGqfPhYH2+guaXqO9hvaaj5xGoDgKmLOHP5xGoDgLddqmtpqPnEahQx1BOpaAvgb52VGsU
h4fN5XaxBPX1EVckjkAUg4JeoCxFESRus/njjFCKsz8+Gsh6CWllPhSMjqcrI55o8XC+qXDh
rL3nG8p1qXDhrL3n6BcufIiTSe7nJfctL4xj+aQwPo9jqZzhqZ6mxY9jqZzhx6aLpjA+j2Nn
cjVy/tkMvQ47jW7g/xcP3OUklCptJ1RGNbciKlu46vhr2KxlXDW95Y80w8p7J5ZWw6abPjbB
jqknnhV8iONs6E7Q28UtsSQhWNsk/XUasN0U+grWFRQuh6QQ/sE+fK7degCCiyZYgU3RtYbz
+j57iDMuDzF974A5xdeGQ/+j4F7Ym+BcTIiZVjzZpCsqx4JtlctCLGG5S3zp00hIza7aZGyl
mYsfQwVObXRiQovQ1wMnHxfqu+BO9hhGMArUmoaOPdS5QO11kId3D78UjjAfZOWUZfYfAi2F
061621qjl9sTLkXmAG1Vqtmmn3wmKROVeiLXmWXxEguBJcT9+hHusYMRACaKvd4aQhz7/jMJ
U3jtIUiB+g726ojK/KYtHdvL43vK/N12qa2mUcvje1DHUE4OoqROL96U/QwHtTWkxSOr4KWI
wi8HhScBZjdBhJFGV/Rhu4wREnttYbBqERJ68G/kV4NBcoxEAMhvM6KjUO/eN3IaWFNqYWye
WWZFUuMfoTSi1PakZGUoq2m1+1X1yiCeAZB7fSQSCG+asUxxUTqKlbqKQe0wbSVebZlDJiac
+NS30OuzUjIIVy6/2V40dG5DNM7JCDPPxDX2ijSDLeXgbCv7hJMV/7dWyuFYSbY/wA27rolb
tfOkE4Mq9/Lxk/o84rHdSSIoIgimV2c1s2kBkuoRnmkU+3mOD81hVL00I2RWoHvRkwoulR9C
bmYfSViJBYEUhjENsDBK6dea4j1O4PegAlqupOlMixHiCvEaB0FPoNmc2dLyc0uSJowWg5xZ
QA+xJevq5gHksB6AyAxSQob6D0pcruvPCGEmDLX12G5DhbvcaRcq4UaASublNObLiDvc+RFc
Gs9Vol1q2qCv0AUrq7QUfvUWX3Si8Jm9rRw6VU82pBhK9F4xY5ZVCWwuzAHaTczB/RSyCYeP
Dkz/cwkejWu/fvKxOjmSrunSS7ORSe+6ZdfFg1W2oqE9HEsRSLCi5UUYWgrmv5eOoJP3BSbB
IzHGdUaJbClcvCyTu9xoxFHnTEqLYTrPsQtF7TrkEMD4YrxYWHdNCtIajKpNa58Ns5HjTAGe
6CTsvegjb5Q6mEzNyK7ozD/0z236G9HllEAXjOvVvieHynKOJGzvnB8UwGM/48xV3sOR0Tuf
T/EwIjPsJwDJ7HlFpC6Q/JQUh2d7bD9meSza24UkTx86n9YSurTU7HjYz35mLeMMaISZ4ASI
WEyWliBNE7HrcsdKGaVSp5B2yWtzZP7kGxnN+Krz/bBznfTwTeYhIVq9OxhMogKK9pfILU8E
qtG3ngvHFH3tbrjyrBKVSSTjfVVWFTtKbU7Ne/rl8W/InQFF0IUHZq7r6zAIKymeLmeilkF3
9Bay07b78jN2jYp0shCSWvKLjq6PTSRkHC6qaGayZxJnEhXe0Jcl/TpR3Ogcu2NbTtJqk5LK
5JI/MYHtuB4SODz+1ApbyT3+lyZbkXeEmyn7MdIOcSN4t9xWletDs6FON+m/C7M3b1ujdhEI
gPKXxcgZJCqlua5O6SvwVtLdok3G9mLIXg8uUWRR3hoKGaEqwDXTYIrzUT3xFjg8YtI6rziK
S9gM5yIbfF62HJO7+rlZgBkVJ44Zh8zdPJPn5tLrTcEWETIR7ZcbJWjsIycdkC68arD4Ze9/
XzlOSe5BldViApZ8merCRTQc++2m0uFQmWeWpu2m8jnS4VCZDgBnlnXO4WG69a1bU9oiNp81
dLnhP+HOvY9JQaQkNX7XjKW2J+85pDMFpB2h7vIJfBMZuauPIanrptzvBLCvjrISYorQ7WP4
ceKXJ40+r7mMSoJvY06oSS18G71FmRdCDcETs/yLDr+IA0mXLASQVNAyvXDPgp9JBlrmIa3d
7ab+4WiZuJYWiN3tpv6sM6Zo9tuChxIO7WSmzUSgH1CHZxIsps0QMucRuwo4EbvVZxL7zUSg
H1CHZxL7zVXvg5m4lt3tpv7haJm4lhaI3e2m/qwzpmj2piE0URKdRDQfpYfdEvu7EKY0/gWE
3RKdpED+P5kwZLK7RN0fpg+mz08qj9m7Movq27H46pn5DAjq7zOeCOKmqay/vaYWpg4Okaap
4aaegx2D6yymc2GCGY1sCKunV0LKm612oGjv4Igc4nTQXLlbTXT0CbkoUXQCrjkdSYSot+5w
oZkb+oG1s6ahGawcERRkmWkUkYQ5EfMOlbDxsr7/E3vvJhBtlPuUyfds1cJ11z1JmHmQnFQw
bV6UnVnZ9xs6LQ0JtYnbIiYHEugEuY3yMN0CyOYnaItMOzjr9Qh3MOsZpX5TqdPWmcsWfw7b
qdPW8fvydBZ/EXIDhPRcfdvL8+sKzjlghcvLyJDMxvRrpAA2dCjQVfb1iiKsC/7z/ZhkULRL
9y34dF+yHx/9fFbfccN+hQ60y+RYq5zd56BJNi797vvmHrxr/QfisBwtCKECYWXHm64h8IWK
HttjOyvotujfVPHcNINwYns39owAfdtLMidk9uhNsffpO5RWrnGiIzldkhWLc7jHpv/7V6qs
3b5MzNcP74kl1qVZUqHPlnMLT1cAbaWkWDOMLmhkY1oXGAdYNqS6l5GY4BM4xFLksggcs4wy
5LY/VGBdeAxVIdEKVZ8DX9USutcR/l99L8V3R4gh8jF4CDCrKtB7/BiGR/ZtKKT8hpOWPSog
VTAAZaFCbJvqgPCbntfoDeRYFQOzfOCMbUelynxuoW0/oulf5MZgOEM6X9o5gdkh8uogtjuk
MvG0NnLElb3oJZNvE8p7k3eRe9nTSQrcQXCgbpGb9E2eC8l3oRjYrOUW+k0TXfTHYHziYOAm
iOix3cX7CjbY00vy3cU38fsKNtjTEShL8qMWoJXVTBR/g8zTBx27V0mKLLqketiOn5hQEG/u
myoZ7dmCOYfahprAcwMDHOEnpqiTuRQVdAwI+3Jbwlw1BBh8XaIvhxU38efXqFNQ55d2Knzn
gzFWyOc7mnYvfRzK9SB2qw59NWkh1naB6911OMqL0lBWo9sBCSDqhec8ztfkX4WTcRRtxJi/
DMW4JXcTZmSB44oRUNGo/YChGBpf91z9th1IoNiO2Qm05RY8sNVwu4yth8YEt6IYA7RvRKNg
pcJpSu/+FHv8qlH+0ZYfKl1QY2cuiiG9eUiXWYyyo0HlkI4E8ItC3JrbH/fM2hSY85IOHYaC
eih7WoGq5lRlEiCyuvSQP+YiMfap//+K7xRzy4SOkeNQB7wcNWXzpaemUB1nKKYAaWWm0qZQ
Hc1C+6lBBlkycEJDBlHUm7QkflSHXtTz8oRDB3BC4BDdm6bZx6+bPAjFHtQI7Fho1AjsmnfD
S6ZdAHjKrnVbp2nmAIkHmtQ/vl9ed66USlnwP0v7KDlOKZ5XzqmyCUxecGlO3mYa72REYg7c
JS8dy3eyJaEK1v3hjsLZTxv/hp5qrWe4m/yeHY8kpjnIsksquHGmuh1+sksqaWXdPKa6Hc1C
ybSrTqr8cn/m9upsAjx9JNhQq5aG435rm9YOKmsiZ/amO75n9n5Ke932z9/2jyr5BV7nt4zw
9tzLJ8uSDWXhcHIEnaAy0qSqv+BzhSAxZb1LGS9UZFiqkAhCfkvJGKzfDsYmdDDKQ4Ty9DsB
7GHEaffHhdMgjC9hIV66KnPQPB55Ny7yXqXQEnmQ6guleyeji3Y3DiGtCoUpukrcPtYE+hDp
2+Xm9mew+/fc1MOdUmqwsz4itxLlzyn0kilIr4nSGkhz+mVmDEpS3xASJYdp6ZI1h7udJPPD
w5OX+iDkxgMao3F1DdZnN/EQE3+CbEXLCiF/l86EzdnoQrzzf9SCSLknTcI7PvxJ+ij5hIPJ
YRvAHoyNSfIy+zjnsZa9c35iOXWLY75y2/eBfw8o9jSDQMF1/JLAXAaEl9kIWpnrQMRWO/6p
MRL/ya53wNXzYwUM4cooEVumm6aFHcoo8jmpeqabDgByLMiw+GeSrZLjsc3J9ItZt9bHZ2Bd
NTHIBxtly7ft32mLg3yT9oQB2JDp5vllaJhzJ4YFuiN3YD8y0whHGkGN684hoZXPR0GpnSyb
mr06CpdmcPnDGWyjUytCyfG/5LCjGQjkWsYffaaqLBqaLAZ4OPiV32pUQJ78eDH4i6BGrIvr
sAnFo+6S3yZzVv7s4113oTnXMc/3CzSGOqhjnwig90V7UYJivAfBdMMk7yZh6RtOt9cX5PdK
ZtwOFraI8Oy98IIUeOJeP5sXqzWihl+spWTlyuRZjqKJZNfXaTXO6tH7tVIvLevksDIJbklW
0V4Rv9VEQ2FxAcF9tQ9IhqABVONlxa0c3iNn+f7DGarihidS91R2U3vBFuxgjch0jV88vex7
EyGHFLbejlJgannsShc24G48WK7H4R14QwgdYw78hytVeboBEfPiXSIRY1OJutcTgqQNPldu
dPNtERAf2XcWEJwFsbqdk2g3Xphte6vWWjFCrAuj1aC1T4WGN/6kwOC4oC5RmPf3Uw7bmYoN
DIu9jX7Yp8NTkEh2HzzBvOkTLML2o+JvUo0fMpTDIzQcDGPIHS3v2h2hyUaXWBfakI8wIxPo
gh6zCDBo7aAGIZhMvc+Nm1rR3A9Z1PQoiRpiKpseUYhBedsNEsTMsN7iu8Y9I51TYy0ytWnN
boWDFuWes4Tov7fGBLEx7/B31kpy0g3YnJzavB9w5fTSCZzpVKXDFO8VQUoh3KEUH5Rv7fez
OhHyTrDvA22ojsmugMnq5hbXQUpH+EgroyN7AkZTqbGmY6aJ4WmeDpFnPqZjpoNOXz5ElDrP
12dccyptcqxptOs742sgonQQ/QYiSOZ0v5kGvEhnNvmFZsYwBWsOdDfQcFNMnxY0qilS62vo
OlUfpJ4hOb6uZD7i7bRQhzREYp8fnNF8oB8gVboRlhlF2GliGTJmlU4h8mS3FsiGRLmyzyP+
Obm7ZiTVqX4uYwtws3duHG163Pfdosckg3gcHxr6/nmhRklxvkTn78pfqXzhFefyOefvyl8O
AJZzl2JJRi2vZrO8nZY0tCy6djZWOalY5nBZ+6boyn0Jtgtc/gEPBKCUBkdEOoSggiGGK0It
5eKJ3y3G/8BvHkPL/shmBwCftWHgNaw69/TIIvAkn7Vlik+bEYqHBIpZUwQQBNF6t9GhLBju
/84NKewmXTepC8EgEj/3bAEm5wZyVUlnQVyYV5gjH9lPSXq/p5WMQUNgocxy0cAGju0NaJSh
k5XpbCoM+fqEgVqJITeGjlX2P7inM9GHXNWR65aeoStOtJMlZfSc22c+UUbB/8Ls2UNS/sfM
wORTHhQBST6JoZcdRZBAUrpMXUReQ8nn+gsXPpvudNECW0CYhQQjYGoC86VXWDeDICSn8wbD
QFuPzbKfE0qRoEoMfR8McWS+PRnAV69ToqPLG6WNLT053lLb07QdLXsPL7o9Yyrz6hcoGq4R
PDWBtl1jyM/7qhQQppOmKsajRirIoBy1bCuObwBjUcK57oPX7zKmOiexq2fevgvWhRzl4FqI
zXqP1aS2a0FA3ivEKxBCN+8sFUFajBbYJ5cWxR6riIWLWBaiItsLcbNLNjNnK4LelG3YbQRv
ZiQr69AIQwzMdAFz5SqMQhYY8zxiQ9aJY5mZ3hyh6GdUS5Hz/PFcx8PkMfZYKWvVjYPLQi1m
ue8SUf+W7l333vfgTgwAwKIfG/BAvfa2iPObsIGgCRI1I8VJjWmMEhxeBsn5oks6NcsWPoDp
fltCYOg7Gf1IfWyhimuYBLyO4+C0hL9/FfHKEIiqigg4kd7IvJ4kUh/KVvNRiYstmBbeJi8C
9CTO9O+DjBgVKAAiyJakJf4tsBzWltjKJc54clUCCI2iidscRW3MK47MdeS3xl2O6m+TCOws
aJW91V8W2EKK0fJx3qKTFce/ONcY7xgGrnPo3h6ObBJ9f/GBnhTwykJd0QY3csllgiT8Mw1s
9rnDQTHJsBVH4ZgNRrqTxEBwx/zDwn9Y3JXpjH1xr5XtjTtBulvfG0cmeoLD3AIBhF1Xuqte
hsNrf0nclURt7sNBE0TBN8CtXBZ97V7M/mr/WSqQflvzmqqqY8P+g8M+Mu2fCScDc9+uJwqQ
eC7y6XIQ8QkFEgsaJrs0/Qm6uQ0dCYCXx3KMw/6DfRYyEor2o4Jox++Md/5omBYNEL/V8jKd
pBjJvFcgDHc/v5rwFiraJWxNs1I2Enqa4osoiYD7eIWo1qzJmLZlEKyPqdVYto61g/7dQgOr
iiQXFe+LMny+OuJ5uFW4g/0O++dx/Y9F9A14Z5liV9DWTjxTCwSOaRVCdHEzgzPq9u50sf6Y
u4/N8HymqOLXpQh0Rf1RZxYi8Ljv69hqa/sPboBqPQIpaaFifobYjblB9+2Iq93GDbLiGaft
+2BNhQ2IPz9xB1gl1lm5mUCYqhEg429BwHlAmLHeIEYctMB5AgeC9iBAy9PHeUYDB2h5SyMb
h8CBRdqgogLubg1q+tCqwD5PqxQ1FUSrlp0IMekobpLrUb9W+EXwwcW+8fALTUVCwusbRXDx
hGxTgPADanGcOJPlOSCMF7PrWl+UcNXk5xOagDGKItLL/syfoNCgqhBGpB6GisssOCTOERKd
gIMpAJf/uVLfwNAtxxJG7YPWu3LKs4a2DNJXI6dbLdCPyt9220DWtLgv/Yl0y+BqNX5QHFfj
VXvygUWC2YZeetbt0EdKNet7OdcpBHprCw5+ShKhQ+dbipSoM2jwTQcsllKMz8Pr1d4LC+wn
TnSI/Zir7/wEFDBGNtDIj39arICYUVidYBYNtZH3n7wyPC5K/3t1R5NbzVceXecX3+YgPPq8
13ZNwpNbZCoeGLfsMgPDA8vy3ovbtUd2heyTSQNlHug1yUxuldjWcHWTMaYHkRpF1sInGwnY
euZd4t8dJnABWZhRBDpX8WdDz0CACV4TwwgUN+KNd0pC+rau332Rnjzbk9EkTWuekd//k/HP
wISUSZNME1kilK5GQ0fxDGH6wPv0kTedpvnhzpmPlmf6qZ2m+eGgW9P6wMhQzezFXYZ+OXFc
Kl//UK0G2qi3QQdGOJyHzdAcMVsMwijCkQ9uoVT8kU908ldmbMpP00orvfriV/FWB1I1b2G4
+7uFJ7NJe6vhBKuGsOFDm3c+nN/0ZiT7P4umzlhzTN1DyPQMR7EBalApN5UdRQ0MqQGNbo6q
OmsqgaT2Brf31W5GhMcHWE6j9rmrNLyoeMr6b+q8JVQfZp02ravarUTGY+/zcM4gE+7b61Ls
IzyG7Rrew3Ech5ox2nmevxX7iShXvWc6pkPW8fuJKGkiESgR0P6QuDAT/MCWaKg1kqimQmfg
+GUWc1qJYdk9DyuCH+kjUQcOa/5WQspHHLFi3i1DPDsMartxwECEADdQ1tZnYpwYoM+Bh+pf
Wj8jSaA3UnZiVlE99/v+iY4RwOs2bXmNvaf2D5c0PZKsiCACYq1T5Po59mtez1IMnw4mQvBO
qJGsh9n1b7YzJ0l+0M8P2v7PeIspuW6n8niIcQ+akKR113K2cj9QKQnqD7TrMb4K0662xJot
EwBHBNdREbUQKKH24RQ7+w4ENLimGPsWOQ4EiXSp4KYYNRKHZ/+rHw5UGC8sGNMo1uNcJGjE
M2f1QqotGa8d7daAQrts29pwz/4ZrJgdCL1rhUZnWeZ8q+5QXot09IYr64sRZ2fnBkDKuR+O
2zvbgJmq5s4zgiiaQNhXLoiFGO8gbEFnK3Z/JapaJ3arJnK7lRT7+UEyo2tzuXjkVEUOIMNF
0/+WaM5CKfFJFlSOnasVcv3TnAezNehBWOzUdgnSpkwdVARQKmexqfH7TB31shEoEXJQjgBf
CinjKSSm5cl8MeFTmIKUi6TvJF7t2EEJfXoeLNgkegkkEak/E3+pfeTtosHZ+TBPUM+vpMRq
juaJwmmwALVqRobVq/PFb52v2IlAmOnumU8mXnOnZiQ3jxJzDruom7wqXJVL+Dxx0u09mBc0
ENB4YQcAaRrtv3XtoYBAlbSYTeO/9RDQGewA3eNHUQD+DbpZEAxcqG6830Gmcqy7maVW3QOm
cqzx+3qZpVYRctlT+zwqiUFgDHklV/119QEwPI2mWHfWkUgxINGB7RRemgzfge1jXihurhBk
vT0diwi9WIVJcBtPDibPdgPlttZOfSY9Uu9AQytJZsqve9uLhH68oR3Kr5IMbVCWm79amQbT
Qn67UFTxoimV32ro8eQS9yADnjuzmSrcE9T6nhtMLaDakawF8zwycdjxYTTvHVN2pfK6Wwji
pk3hDp6pxablDpGmTeEOnoMdCOI5F53v2r2Dwobt/Khn5YRljaZRnuPFyuVbSk2eM4tSgm5Q
YHSFwBWiZ2G2Z8MsFmZ2JZCmdSNLcMVgKNwI2fwufuszk4mLbcSS5CwnYTdFp2+tQz5E236O
M6DhZbjFKi+PXqmu+yJEzo6PXmllqa77IkTN+87DhjHaQ3RXyqYq5+S94+ogUEUgdkt97HTI
6+H2+OfuGYMviAenTw7w/jVKrO1DFnwSCGtejloY1idNGJFNPH295e+MVnNOiLjtNWXppJ6Q
13BdF9xgHCsLXUh2drZJX2jwGYWz4vBoWR+RC2fyJlz6gC6VDifYHvhuF225Y/G8mLyzeSU+
ZB68D8whtuIus+y34ii/LuSP4WgcVMvjvLc4YZqvT80yZ+7UYFMt83wQplmm61tZLIl0fBDd
0jUSZxJxx1nndbxsG5LgVR2Vu0Ro/pX81oBJB55ay5TWdmWKMDAaUn2PBjiKl2fmAQQHZYnf
LZU5D9gsSXbO4FVJ4c7gcyM2zDQvlfiKUTCoIv461MHfabSF8oM8eI/wftqkE8hEq4bFMVxj
Okg0wMzYkbRnTBfCDF4auHmqvccDSgPOeq/aFUpwOAiYfH1K+H5+bY5IRZ4VRvsJNlrzyump
jjX6pgk2WvOgWxVGRP4PLARZYdDtUTcSQKb+0Pikq4raVxW/EVS7pVSHDEvlCy4jF1MXTK8o
/B/vHgf0vpXZ8SjCRPo59LeBRqnkCE/fzl6cRxhMP0AkZVVjCsLxDAYO7WrmGFO73MIv3FFk
ZrP2Y8zEO2Srvq3XjKdkaH37SnCNiRXBuSAxJn6/kiisXGXpvPEg698SJQILVz4KFz3Ld2pU
ZB10Ui2yQSq3ignwR3kGwEN/lcwB2sL04FrmQlwGWpWTIfn4MHvAISOMSmNHzvjgusgTbuU9
ezUlPBP3EyYhb/3vug2JfOugWXCfAJeKI8sDBxXTpqU3/jamLKbPpqU38fvdW6YsEXKC0IgU
unexkOeaufXr/oWqtYz51krOW1eDLAZaqqmM5DVKpf6A+dKzfqD7V1lfLshVZSYGXKMj5iNV
40Fbbgfs89K0EtV73P6vZA9HPkKHBxxOikYFZsDTIRh3S4mVsJiWeCzU8WoY0KCZqjiFyRw9
RIyYBSMCfkIVGlTSTp38T7pK9XhosdW8FkGWPAwHS6Qjj3sYLqjaCGhoZV5Q3F8rByy/hSNT
NoqphCiYbLh9r2tbBxyJdHYjuH01EoeshNButh4QFgEJp11xptNXFI2aSyE/1l7Ozbsz8Y94
nDadDZGWeKc2NDuRIHiNNpcxBMUPCw5x8K+bIavcHGXwlh1PAPV6zxarbkrICoc46kBeX5uw
v5pgCa7c4Bq3nion3Pn0i6tYT5DBqztAsE51jK+89UG/IXX3/9bQYLqzQjkJF5T1144qJMIW
P/4+8poLiXP/zBU1lzixazTSx4n8bnjZ8/IAHoJYBoHrzpjq2fef1yfR9GGJS2xEkD7+WbqX
dVE8yYFShcKDPX1hvlkclr880xPgjR8K/JdUcC2HuUscWBOTVp9DXN4ey2X11A/N9NxCqsL0
EWKRg249lpfEwR+IowvXLBMXPdH/4hmVi7GOBP+WxYa7UhgnnJji4DHitMnUD7EIrs6/xwya
lQonAn486ThWwlkGbC2pp2UIybcGRugUnnJ6qXpja7yiksl/0K5OrF8aOmCfYe2zdnTitRK3
BZvR6CB48ekVZD2cYP0hASVw1OEqJXrQBNeoP1a+1Fqcvvf5B8d130DyPCeRGsIEWCYWTO0u
oNnj1jQb/RG6dSq3sCvTPLK3FAslDDsUPAIb3hXs7sr3VFuQFskIpJHjKcwFrBo9xm1twMnH
2wTJBj4OskyyQQ6tTzuYXldecuEDAVUCWI+5yoaTRkfjE2ngZJ/Z5ZiR8WKQl+6UdHk8dgkL
mMYieCzQHxAH33d0Gq1no7gf1zjX8f4XVmDvgfCd1b1NhHNNcuH2rC9f6dF5AHuGA6tCJiT/
A12wnjJrGOnEBAVwX4lAI/zWbpimwagwSXxbcMvddk2L3fTa68iR0GspSHSIfa19rX2+TcH8
vs/zrsRgu8KsL+34oIy/9qVfMhv9XBgmrcIXVzl1jLrDjpwU5F1WSq9x5VYzaJMv1mrDNYq+
A8rLYCbxzij/UQRUGvLgcrVQaHTScOrPLWDS8FIiQArtoIqeKBeLcKPYbTiLq+bmMulcJ/X7
cxRN6YINs8c4p5mCgaJuA9eghEMCiFclosuxRa5ky+up3gT/9Gxo8GT7Lx90NeovH3RSry8f
dPI5Uq8vH3SDToqGrDH/PONvcHgkGSsftnfYXNRVn3hJlM2qhoMp8Uzjsz/KrDel3WkRcMpW
fATTDg50whLUb3oOC5cb/8dTIKMWgJtQpLgRyv5MYybd3xjNHD0agwWnldEu0bfDnN7Qz50i
nRwczWGAGGMtx9h3RqCkCXHnExi/tCxj34QuUer+5OUUH0XycHkfOzhDlsY6BX0eI3MBzRJV
vL2TiqGDjgzxKpbhMm4Zc82GefVOOk5VF3Kn46xC4tGl7jjWNiJ6zqWPatbxNygoInoRcoIz
7lic6SSiOk+n2q7gHbilMCwGnSwpKBnPmv7ZXSLNeGQho1U/NLeWchcusYguIKoc3oRKcwiO
EEk/mS4YcbtgzjzZf2u8mt7dHID7Lq2BEzcneGMyEJEt17hGNI4lakh9OySq3G0WWxYpXjp+
5aVBJoMUQ2nijqRRAD2TGylKttfA613OOWMJwk3xbAA0qO30A0fNTm6y+zs6p955i5SzBrqq
aBsFkerV4JhFIdIwBpdzs0e36pu0uCsZ3twthFcu7kUA6J+5bzatUfAiih5vWbBfV8sa+MxX
P12fP4XPOfojz/pOhfOEUYP388Xbd3QmlFJLD/KoMrd7+ZIdul32ocxzNSbidcscsVKIZAmD
+e8qIzNZeKSVu3c/CnrVhfvMSk58lEHphoy1dq4y/mylSkuQJ7YS+xA4mEbr55+gK+T1nDlt
Q9qD2IitmrPHiDVC/FjQGN9UO75ZtNEgk5M0XXjQTQt3deSLGbK+TypRun9U7zsNL5hGdmyg
pGN5ZrChg/rvx4jAuHeHokq1JVvzbZChLbgN2SFP3J8WEbUqsAV80o0UV3XY+gjhu18bg58I
BSG0h/tC04vZFMjBLXDqfLO1aTojzrhpa2Gem0q/kcdHxe7FoB+rBfBA6QSOe4/kvUFEBnxH
MCAeI42fUVACw0Fo0O8QtCpPEjLW9PZjfpZgK5rpfaszfpEIk2YtrAAwcVLDVKS6fL78E6XF
ijFNBajuMrQDJsmeGIDRl5Jnphw79DpQvLO3CFNVRK6eHvcQbSKYmkTWG1jN27xDpP+V8MH/
gRXqwZNuex+7ItxIV1TmKjWq7fMPcEUHtHlxkFu3T83jYGqA1wFNdtRbeY4RSDdSgAr5dwiY
gcOd2azkrDzzmD3e6JAhDTYdykfzM4lKKl5lXBKiDXDFUIHfn151OkwLIkJQe/5J7qSBEU4y
wu3CvofyRJmPQR9njXuxJXPi8ouwrsvVqWS8rdg1gxBVzYFyv0+7ZKr59bZzc7nB4+SUVeT+
1/iauyAiR/0sN4qFezRuSjnSkCZV8QAXwmry/ADrpJGSJ6y3Wq4uUvGIorc2UUwYODcvb49b
qEZE5lTKRkSJit2EVH6OyQ7nPdfB2jS7gxDkDopL/PZISCA/+bGwfTOS69e1aGhgtcdzJMSx
nWAPUZgonVVzhoYHHp2qz7XzcxCqELX4nBMPwcwrH+QfEI7ul8P2FpVXemvGM9nXwX1q1w8k
GRnPZ/2V/nidVao0mJBr6hnkGwoWRh03bOEMjhZ241sndUpOj+Gw3rwwmAw/8m/tx+QKLT7/
PtcHQzMo94YAWqz+LzFVpOFGz+AQfveUzUtGn6Vfrf/7wWtrqNFgQs0Ob3/hWlb0IqObWC7M
Kn4aru/HMOn3wwVmC9VIVfDk7Zq8e3vxC+DPIkWkfF0slhq1fEznp142K4zEhmqeq/OwaP4J
e/Sn/ZpQsSAwdbfRRRpzt/Ynusda9NMBAhNwnmLubhRI6PIU5zH22lgQWSlO/63zEvJbwNj/
EVFcGfvrfZYkogtlm/rAfhkE+h6nq/6z0xgbb3P+VL7cabozVodjBh7wN2aigPyu21cWQb0h
HxhGj9mofhFMHrKI4FEwE2LRo9PQc2w9R2cMCVX4C6pC6ZuG3z7VoY8vQp7Rl10xhPZFvDqe
iJUNwO423mzCewCDFpUfKsr+sQBAjESxPFFKknSiElhn8aPQEnT0GKYoOTcq56VpL1TWpig5
NyrnS8s2K5O334BFWW/ecX0mcSNCpr38BfzEw9X9r9VoZUtu2qJW5wxfU0eKp/o5zS23flIN
2kw0VXBS4nMBrsK5iDNNtdDYVNnJPsKHJnwaENweF3cX6Sr5sRocHzOZ632ariH2UQLRxnPW
5NHPhEv2VhySuzSFxBOSSFXo1g/EGLdMdUHkJIQD6hkkjPFhKW6Lvq1VyZyZeJF/L6R7vOLn
sk8SROR9LjAPRS6Bkjmrkz0VM8Q75TikcAlcEicNGmbU0BdZ+OrSDFuzPGXUi1nh043KC7LX
epHB/9fjHW5XI71JSnZydr7aNKSAShz+27MLj1tFhmAisPCSLN/AJPZ3wU3MT7dg1NZg3Oez
CiQlJvEQttAo0nZKS7v30ZhlGY4a5haCOKnJPFrsaoRUz+6Uf/cmb0ze0jWYAn5OLvBvz3LF
hUKfui1w6TTmDArXl1NGmBElTl/P+6SAfLCBsyieBgT7bu8kPu7dE8jd8POgLXH1Q5mx0vv2
4fsqOGfsc6Yha69Y3d1ZEWnUtsjezbU9pVwDnCafF51YdjxARlhAeXi2G19SJpsiw49v5H7n
J/k661X4tZL4VXILJk3RVK0Y1Cfr/EJfIJiP6x5dB9wSKbb6WdzCLaF9GwWUnqhRuqdQzaQZ
OYk0X/+/xOowFoBibq4/gDr/lxXbggG4p7vlAIpEWdpuD93FUzRwxXK4mhEwwRa/T30y0E31
TxHHnBbA2d8EZhVDmy9mYbF4NaIwhgbmolcWiNs4IuCiU9Om+dmBnH3BExMFfZLrwRMeKLUY
hZ+IT0e6VYAsnaIsII2mu0WrSrW8WNCog9qsESBLZa6CgxPOYWERuzJxNPDZq9LNpLsAXRXG
ERF3v3VTu2f3mjjgnR1VtQQYA7KAMRgDsnW6cEj4gsR7oxG34OuFmCt8c3uSgOQRZWSj6wmA
0lN34dw6rVKXVZFS1+LJCopokNXfVBUACJWr/6eHCF2vBWA14wWLUi85xEJ2RtuUHFuowAVh
YufHPUlp0zB3B4yVYNDpRnNzucEPZCS1sYGcnYeq5PVOr5Aox9/L+A7UUy64tv9t2r3BbxUu
V5a5hTR/Eu7yvi2bSPXxcFxoh4+Qmb1ToY8bNxM2SNNToaYhNxM2SNOJdFOhhStE5GylnHD0
HE+djjgJW6u3SIlbL1gdJkfukckWe4IEa4gYJXSAJxzFO6EXLC8TZ365jbR6mxTfCNJo3smw
tp3e4nQhwdlRrbMhWHxFEjx2FpCSwEHNvjbYSUtB3SPhHq1ugeQw+AjZlt0S4bu9NEmlQd0S
4bu9NEmma90S4bu98jl+HaVB3RLhu72nfSmlQfUdiv/PpwWV4C/4iKn7smqsQJHm1sJrqIiz
S9h9r4KMMJ/h2p6KfYcxzJoLTzAJUbGSm1FFJ93jFa+uJNPDLeNnRuHznqIWL2uv41CWnZ2q
KJEWyGtnQOGInpEWyGtnQOF7npEWyGsOkWc1poiekRbIa3D0QQSIGKhe/aijyrF70eU/VhEP
/Memmq11XXb/fsvogh24dVtgcSWTNn5sS41ztPJw/stBVR4U/nu7FcNTACch9ZNMbLMp/HnT
8LXdK6Akzp04mhcWzMcCePaHfkgt0ltPEFk7icxdx1l3WmN0kC5+8oWdGB1Z2N30fAyN164u
yee3CZAJEYSE4HSXGNMsWqNhLuv3n+0GOTaUFbVno35zy9xq90FfdLodGkp+5ixYJD1XnBJS
3Lk0t5ASks/Wdkty/kVeMMmb3lmYRS2OEY6DCw4eu39J2qv23GlILbeVy2MQhRK4fowm5LP2
ljYFH5UzosIQs34gorrfSCP2swEkgHJQVFq2jbVeDbIGjgA/GCOHSQT5wMeujT+qlxnSa228
LNZKuzXG8Gvp3eD72ERWb0tU3eA38e1Xbx7XVXKzJCQZteCMwvz4lPpMGJ5JAqpBgOntEBVD
SLu5jB6uT7n5Qk6okh5VwX35H9LIGRUE+9ZEdG9Ua0mXcMz+GtZh5uASLSsAoQr5bj1plyd8
CyqJS6v/6qQcTALJKEtc3Sv7uoHgclHNbeJ73rgTagvlYNF9Uh/AfqLwTPML1aN2yz5K678I
XPphtkEhwdYs6Qk4Bpqq7SkibaCqRrSQRKxOmbg/+2g1Zz/7OkRdH4l0yA9XnaZ9llRmS6L5
fbunEm2jpb8TkOg6BmJuk6mCmR1ncHttpkQ5jlMsnnbpEr6q5QCWkGXYDdU1Pw0fB963oY/W
2uv6QBnhQj122zWHDbnnGf8gQDQnVVLGhxJ/HatzMMPUu8QkqkUStQ99D8gussImvjRbwia+
5wd+JzwfZ98qcO/7QTbf07RacO81+qnwNt/TtFpLonD0QEv3jspDk/y6Rl1DxULq7z5asvEw
7bobE85nSI1RYuAQm+N4XpBjPdzespIkawWLFWRGCwhvcg4/zJ9tZvxslOp3oZVy+KE75zlk
9nlODCT6E21Tfr1sKPiqtWZg1kEf6kUicJ06DAfZlzS6QGHpBRqORpT6iH/mGHNSGneQU/Uf
e0wgHTKKMEW0YmHp9DzHKSRqv+eZhWMnItLboGm8Ld0jYVyowipv5QpTEVJ2Gm3o22tTfu97
bceV0EWY6KQRj4j2UNVoZ/1SuBagAyzh3y+mHgeqDcOmu4xjSUA6cqIDWwN9Tfb8jMUF1xs+
G1PgXNg8t59rPvycCHfllCN/5r1tdOjFyYigRjVA2CQjPgmI1nbiVCPziheHuj2C09X1jhCk
kEmUDY8La8O8NUGjC29ywDI37vvzQxOtg7lRcwpXy8xxGLdwkVSt3yCLaNinmQw+XRD9Ag45
jqFF6+LS5ucC4NuzQHv6b+pNYfef38ZcoBRR36uVS84Y6Mfco/ILTf2GTJ1hqq5GvOvSfJm0
TRfUZtBed536otX2K8YFWbAy8gyQBqElTuD0fkMplGFhCf3boTx+vVCihk59KnD5puGmiyh1
JHD5DpEHSjod3LKDHYPrLLA8apZk2vv2ioREZwoH5j0DWjkJ5B4o1E3+vWm7+5AZHSHtSXF7
FhbtgKJ7BHaky23LOaJbomuYyhEnzBwoqosbO5bOWURafNyZwURdiMjBnAJ61Q7ipUlw/5Yd
x4sHfIbxKKp4g2jMJ17Ym+BcTJMYVjzZpEGcYb+UbUxCXKtyq3dkFRDJOu2IbwyoUqqzzEc0
+E0k1YAQqxfqu+ATygVVV6DjPvpYyaJaFJB+M4OVGZUKJwKgM1FLjqMbCPEEmfY+VaguTOoy
adMIYUWFbVuPVn2DLBhL3bBa2jGeeeV66kHmTTTeog3lPHbpC4CD4XyCa9O26NSF2EYbmCxp
06n+pmz7iTZp0w6RZ6GmbPuDTvE+vUqFWM7n5hyPAPniVJAPw0M2DVKNUiGamVFu6VQGGyIX
EQMXzTii5gQvrS+sdjkiywKkuqmGI3f66HqOfmi9BArH/71iSHhU4YfOoM2sVJU+/AKne4Ya
Qec+cIzWS8wipbQFY7Xf8HjFZuQ6o27/SFCk+s4U8qKVzNC6ZSIyrBDTj8RxjT3FhLWRu2dV
cYddu9QE/m0fmW4cbRapK81EokS1BwFLe0Lsd5S/WtBRUevk9TVW7L9uHzqfhJpGGVIZOkp6
hLJYmWKi7ULRAASyfmtQe+DHEbbMHmHB7xLZaYSnOntg6/TD5i4FQQyu9YFCV8XZj4S4bN/V
uio2VrCIIFKJYqGvOXLVdS5yft+9BGz9AQk1fOrWyQ7sk8upYKUGphE2DvOpYGllpqv7ETbN
QkJnjBhddWlgTP9ePtfe0OQE4OHDX0POsR+2UTMnqfGGyOQP0H3Bpvt3LvLbH2/aHr+qr6ZQ
CYICxmQo+2IaCfZMTRFFcycN1Kih9qwRqMZf2xOlB/Hkvx/awOprUAbe9qlNncP3eRdlqPAi
Euo0kE/N/8zGyNyopxsmUKx7iGSGfv2wmOtTo3EOSG2cGhkEQr+dTKq8+TL+0B6umCix/ngL
XPS4aVXArQ9kwep9nQh3jpNdaPGuv7EstArPD9HwuqtPG96CC137G6SgLuvGHbhcpZ+NqPij
Pd46COQq7Jr3T76BVkrJXYWxHNrqcMfqbmwqVjf5qGJ87x6SfyX9vwUfWgoHayIgGR7WoeH4
ifvztN7hBMIkfF0CHagOcaas0rETnJ6pqTw0cKWEhvOjrhCd+q7ZVZM08rdD0XIlCmuT8gdJ
PrLxD/WdKen+8Uz1lvrp/qe6Ibgns+3Jb7J1VCGRh7Op3unWyZQqNovzDC1ZxZHVl92wvqTQ
xwph5YZB3O2PSph7slsVugBQEEXaCWlPrTpJ7AI7DBsNsO076OVOpcSvqzJB4XgEbv+Gj2Bt
JUJlcRd49deOzeaRf5lVF9kQKJz+2kzLqIlq5hYPkr5SMv8TQ+djQYGI9Qg2IxA1xlrQtKP/
7cLhpBez8B+Xl2xlz9MTcfObslJOl4swn6I/gjxZhsJRxIijgxYPNtX5WXKK39bU0/RgM4Qe
NOhXUjBV4gOKCXl6EGPs6C6IZOmLW2TgehBy2ZzqETyFQgnv7jGFBKsn7S3E2sIlKYuHq6Ix
MhJk0zY+aHBfaqAe11/Au6SZLY6wyr3sXW+4Go1ikIsrwEcjGnU92R7HVmhW9NekkBQnb6Rs
9MdUSS58SsvTOnRc6X/ri8qEPKFcyJHJTOHqcybL95HvmOCgxyazORqUMSN37XNkv7PaXQL1
H8msmD4NiLzegy4WoXEtuitVbLd+KcPLHmyDjfUf21hJGD3UAlx+IhxkSMt5Wj/bT2QlxrKt
FlOA77cvMet/b4SfJaBTdxufE+gSzi34+SWT/qQagkUPBDFFkA5xTYDBk5teAkVpREi6w8l8
l2C2TYNbyZ81WITIgnDL3XaprWnXN7b6Gr0mEHQuv4y3Z3I1cjVy6QDqtyhNzlJ4f2DRkgyn
hFotOEa0cGV+qqJUuNNWV/thH5vVyggNeCXVL+6UGIqeovVE777LE49R31uFYsrEqWjhwJmF
YsrEqWjhwB4p97p+7x2Kb0u63Uj7R0R8H0u63Ug3rabHpopvS7oOwQ7B7jFi/McygroFVqbE
lAZRrlNNttH8Rm17/v9CpHselc3zpYfdEvu7RDQfpYfdEvu7RDSxtobt+ZsdLw9nz/sIROcE
ynBnz/sIRIumR/svD2fPN0HWQbu3zgbOLQhhB5VEkv0+CEpZxvmgsS+X9spVlEYp52rANjhX
4S39WiTOj+WchzBMlY+ifvUPl8pyoMvmahNHUPuPIo/EJKV5RRk3OBxgyAJrZp75rk/yRje4
Qzt3Pznm4+M48B1Yochlob92wrcp5zNU6kmTw/rxUX8GElej6+XDtySFcWuuJlbSL2Jrn4QJ
eW1fn5Q9qej9+VoX+2CFy23ej8jN4E7y+d33ooldzSKrDcgAY2pLR8yZZfaHoN3IWPt872l2
lqG76HaG84B71OL9JowUbyB4ZmBMC2GDPHbQFEtF+YoLOgO9GBfO/4u2SpAk7lP4tts8tgJg
QBdIvrFaI/D1+vP5u11bYejwogqDcQGitYRD1NtFPUAuxVYZutuZ60o99dUpDC6u3H2KJ9c7
IxUR6JnN4GPWYz6MT4iLJn9B/AJKmCvvoPTEDr47wgtqqfaAz1b+xMDXtikgVZgCYgd8X4ox
WgO+49uskmIOwgdwATK6NTKM3W3CF+9OP6mcAXLLfSXTU/qUZZVtXO6b0/3xnni+rPEAU/Gv
LuKEgVtIwETNQkfZWZEUlUSD2Xjt9+373Rl8cZY22B82PZn7/AKv0n7IQboyIbaFivFks4GY
WCpxDgN66f7zhs8RUi0b47gEWX1blDMCmfjmQPeZfk3Wc1HLfWQ/azmUpal2KEQijkyPexXy
UD0+QCTCLULZXTYi8qYa6LHSNUArFiUsStKsFMbFHhLJBLssiZRjPTUiMOiZ4jFVEBkWsHiD
MeF+EoRPPy8RW46SQ3OWeCy8aJpz37lFbZyx9JJwUVVTjKk+e0p1RLeKWxAzN2cS5muOGqT9
SFefauntCLMiV94oNKAoSIOZJM1lb8mEa9xy7wM1fd/PyesOghRyrzl1Vqa5aCuxJUH17lt3
3P2/KWYWDJzCWrTjphPxneslU9a+wopw/5tmxUpLXmVSGUfStNhU/mLfAokd7CV6IIC5fcQb
EU/qdvpPa8zqwZDwUr/rFwe2kZyMminSMcR0wrr5YQpkc56XimWmzHgzgxCAcmJnJNk82UWB
DbgAO3EPDLES9o+YAKWDZs55tjkW953i9WoMc/X6+2Ej3XPmtSszzNEo5z1MOm73XK5D0qK6
TI2xH6oyXEgPWWH2CowFuUsXMIRQi/FPocPUEaAsqVkMEQIQ1kCFnnOs3zeUkrKrBuVtoMLb
w3qmk0Q1jmcdHbJ0NY4vovuDTjasFqU8O4LjZgXiHl+y+iOCVtpwIXo1cI4UgHCOfAxxjmXM
cY586nGOIUxxotAwydUhHeddrDOCEEorAiLDbNyuV7qBWXIrAD0DzJCAGGCQaZO6wWDW3ipb
e804rvPzTYoz/g+1P/5Oc2SdgSShGmrdhRwMC742yK0WkDkXUo9Wy4qz7lbLbpX7BL2JdHAU
qfdnEkGCXxR7j2SQsxouCdj7LuEh3srsoBdpvXIJpo2mw3tWab1pbCDDKcQTcp3h2NLbOGOA
QbmYQ5OjAC2ttfymSRBV0HxO+2lEZ5SmXKbD+2lEbB1nlKZcUBymw1yl+udNZknhzVDCTja7
4tUacZu+G6jG8O8bSZK2MLWKTEy+b7GY+aeKi5wK6XFD6Q+oUdbrsLwG3iEwGlvKenYJb1W3
vON5fAStjkZ2yyJB6d7P7BpFMTys8LpnuHieaAliPh5K4Rl778RBSzu9A2Pyo8xwoKM7ttKt
9sC7ZsfCOoTz3NtBRVB5EayNWueatutO1Y4MqnRNA7LH7Gk/Xa7Ftg6igiZmnOqiSHjo7jcr
ihfvJZCVdSpw8K5sBT2N3IuzsAbg7fVTnekmOLzUork6zBedtEryumSOIVaZp+8ZcXhx/+Ku
PXeyzT5sGQIlGXLUCmV/KT3uQePPl3zLitD7FbPmVzliih5fBkEDhleGCpiajA/itVK2VZrp
D0giVTSd0CJMtc9OPkXt+YEbkjqLZL9PIFH+nXGa+c2LDNJy0E8iaxezgSCdEJIwTvuxvrVD
G6NB/8afxoFTmZu+tpqSCJl5l9cHQsMZmuQ8FDEwZ4BvidKV5mc1yHcfSlGskqasgw8gh8Uj
nqNO8ffrb3AL5i6cEapaFXbIqxQIq9EQzyucIvF/zZk1+HAYjFvj6VzoxTZr5i/8NzlrUVjs
w/SJ46BBA8w6YLN6byfqvFiZgxhow5O/2qzBfjTqkct1To+d2w5LyUGBNTBDfXo6ghKMnXo5
SDR2+Ofe6bXMqBWml2qAW9gqcYZ/MQY+bx9b+0rGZO3sdxiKHhN6abaSsYILDhvfS6rsZy6l
cLtoqex9Ffm9+yruByemUdB8QgiRFRqwL3Lnr2amQIR679uCrPE1eu/bgqwzevbD3Pt8dqit
0v7dFNaEckZbVy8ciiEwU4yPr/83W3o2Io7CCgEOoV8LGebjngKmuVvh2+X7fMrdqa6yOdtO
bzuZoWFTZa83b1ZpHzhaKErFJ9Dl/Hk1crrT7LXkpVr4k4f+6zTJ0rP9h/VqKC6mOJFG5wJr
AWlrGLafvz+ZWvXlZUjLL8TBNx4SDU6VgYFkxow/WuhbwykH6SM38D8RUSxx5zDKjzepW+Ec
5zDKFoiPN6lbrDOmHE01gnt/NV2L0jYdEoyphI+d7lMPpt0gVyUf4QYeqnbkcB0IUFv75Dml
BTgZllE1mlD+o++lzrhu40WSfgu7RXKrJD+PTACRLneQfKIhXdzk3+PE1jDa3bHdQvvPsqUq
3bFn+qYPHc+yoMGVhvaF6bj7PDlgg7KeA/2rCx8b3dFp9Ux1UEVpUjJqm3ybuEU45ssqyErc
EqkIptQS8nyHvzaQHNke45C2xd6gP2d3aF70nOuErGqsQ6AOh9rc/0Qxgl+UYmSIZeMM1lMh
3dfdPvtodLiCaWXd16Z4Hc37zQjd13HWJZ9cz0XV8QM3HwQovLxX20OV7uLRyzBSUlP2bYSH
o3rSSrZlcBHUT9QBZWlZ6TRoOGWsa/X4qSlNQPvDW2lVt6z8J5WigsSAipD74oRDbAo3xSYr
23EDf45N7JEqh2XyH4i4RcnS9XyQ6/ppZFeE+31eB7SBEMter+QJ3p9TvMzs6bijb2mhZ2yv
Qx3D02mhaWVnbPuNNs37zb1t8glW20ZZh+Lxv9p3S9O1KOLD2kwdr/ovzpHK4/HjrQwyoRlG
tpXgSsDh387Z6o8Ay89acKEkLVPo3FY/GV5+mR1drBMPIxgZcXDQCffyHMt94V1NScFCUmMe
OTO6KAhrjx5L559pL9p8SkwSj11g6jWrwnyr1QbwRJgOr5BpS3AluflhU7XkPj+qtQi5Kwd9
6G1V4LqJEViLhVG52ssGnsGE+39OsoNRKqS/PEVpUzn1fxhXu1OPBGIgTkUHmD94GdltbXx1
/3HgOrnhEsnN0443les5si7tJzwgX+AmuIdWsxFuh/dyJ7mzhxtD5n39NZZpZAjcJUd6JKAB
yrThVJl+kfv2+9hEiXQ06d2jZxJnEqw4YjnkGv1Ir6+ZfSwewjQW1am6pkj7U0SPbyBT6cJm
Eje65C+cm/mSIu34BZKL2Zxt0A+5kHwf85/3vMGB+2AZJuiAGE/4uXLr1t0nR9fpnSB4Exp1
cJqdxSse9Ange23UCz5nalu7rwTywPTQb+KnySFAfjxpbddsVNaKbH67FsyCGFwyAdH3Qz38
dFup8xZbE8+6bfxko6NpTWav8yoR9mkMoJTpZGGo4NkB94mn/Nka5e8bOw4ESGTopuk0S1Hz
hfbwh5RPSZhtXJM+dZwvn7RZ7Mm4UFn64CHqUfWB395yKoLPYBM8LHrWUGylXKbcHVeyjyFp
ZanrptwdzUI/uOwGvZ9q3lP1wFhcprD7bjm4q93eHY8hBooLB864Lw1dLHjE/oTKKvkuqeUA
XsPNJanOffOW/bSNiwgJLJYNW0ZInFGqGp+lO7Z82CQ/BKkHjmNLv8qDTVSqZJ6gDQ9r7VuD
jNszS2Eh0dUjqTFlcM7boDrBlenCMBNW2pWPjLGkUQbZRbNE+4THXVTbMWYtnEntLZ/F7U1h
UkXvn7ElEh/pCYddJgEvTut4Wj57G0GkTGKYoBrVK8jvsIFf4WiOuF648vt4RGiOiXTILN0u
+3hEzUJxaMOm5g+CoubQbtRtRNwNRonVNwV2Qe55yxXOM5htNW2JKehyjGji5d8GvkMSErQU
3tLVXT6MPPOrAeGkMu/HcM6Qm/d9Fzr0ihBhl4xIhNeIE7/VebhkHmBGOc32hyrvxtN4CEIl
EZv85FHlN+fkE7TRm7b6It+Pm0SatRrqvRBPp6GAB1/YUc+Yok76FfrceXgNCnxHYBYckKBg
nc2knx1/eevCxqqmih0SJ6kQpjP7tFuJdHAsqRBnEkGtiu86kzlTF5iTK6b+pmgLH91uCj8N
6QeKyuK5w0kAj4QoqSgq6ZUxGvVKo8OQe5aOMiX+pMUW5N4e3zUUENJUtGrFhPaiAsH2SEBw
G8uF//UU/G/U6lAkG8DGoUAKAQfoZA1vRC8EZ3BwEpnndMp8DpGp3abhHYMdg+sdN8wQR7FK
pnTcJct4Z7kpNoNrGaatLw6IyyV68w451VupKq5v2Pt36VB0OuWAsbiOb21l99bMXegewxwP
R8aDpKFPcMViAm+QfVC23dym2jfwPnBJqZCp8Tf+W7S9ESgRciJLtooz7WEcVPKaSPw2AO1r
t/sO+nxTFDZp0zZmvftKRjfpWVgwUMqMLHZr40g2FX8xyxOjuf5GPc1G2a8jYw2T4pcnjWuq
PPR/WrGAUoizh1XuFB/ojnbP2Eec9fTgyFRTGpkrUrghr7M2gLaJdHYuuCE1EoeHn3Rh3oqf
f5Ofg6g2c3yfP3wqLOOcKOmXW+Bd1rMIW8Ejwj5bGcELME9TwRBucujLzk+Pqqy1vflJzk8O
kY+qrLW9gx2DCzMkMbwIMpxbo0MFTm1WPtnnz2mlNSyFW0O3uaF7azJ/HGfttsFWv5F10ddR
jGrnwxx9NNMDXChhjPjyuRzlBpvNSncuxaDCxLuWDvuFDTB+LdzUkZ8heIhr3lxrMqp0y3xX
3Y+m1h10y3wWiFfdj6bWM6kzdaRwueA0n+5wMcnHfRDiaiDHssCc9t2Z2oSHsYilwv8O6jIc
FIDZ6BSloNCv68IZ/kMnEyOP4qyYnrnFUwqP4qzxN5ieucURKBHQkGQBEoAStHz6j06G3zHL
56scBujL9WnWU+g4biXKuRHKgNIOcVDJGDdOOlD/SbCNTAByyUvdwTZPts/cpa2vwTZsHU+2
z9xQHFAct3IxiqvNGRu9BoTsyFCPJMpaN8oQkbvDkPGPjCLj0KtyAiL+GPviHje/nhk+MLCP
kKy/nvI5GT4wsA4ADgAbu8NVBtrOTYH7ZV2Qy05pB5Kw+zTrcLzeV3IhdQ+rUNUAek+JrjWl
WizsKjuYPy3Smwx5xgkxDVesfVz06MXs4gUhRK5vepOlka+3RK5viXR6k6WRNRJnElZBVr90
WRfMsbBSDVO0lZwIxVXtrWJbzkvWdrRrGR5WewzVs1Kw8Taqh5H3hT2MHKxSyKDFlJoBl0H+
9wcKfV3uwbyb5c4hLqBifj8IjaHToQoGhWoiD9m3/BG8dXOL73g2CfPn6OfWzEbhFnR923v/
n1mxECBnn7xEMb1haS5KtsmoZx8GnBbeLTDcVmutwp3XkCdDm+7ZkNQ/hSHA2T9NDenvqDQ0
AUn1gXV/UHeGM2c7SdXtw66zIw0b6nm+E5FEsSpedwaFUdtKnF4S7lk7Y3eB8fzWopDYtiiU
MUjfoX+vEVpc2Dy3n2spVqvQsF4FFHdt8/JUkUu93qc1DASRhbdelunFC8hqsOWHNvgxm2wG
biqq8GkY2fw3dKcg42XYp4IzruRCPLaOU1ApBs05XHw4N1rDEGJ71DRKSlmxcYzg16jLoIwB
ObPDvCmem+EimFD+F3/8NxZM7S6ggnehZvgjkFc403vZFbb/FG3cYBeTflMum0YpjxS3R4SQ
fN81kBohnmu2bCZtvedvklVEHUCYha/BOVQEcDipAjX6pm85VASgwToVFcWlJTe970/JL2bk
47HIu0SZy202B5U3aozda3yPc8rduOs0JLlt0jrKqQ8n6pJqvFqmj7wHGPjhpR6rSOeFlsqd
h4WWj7yp+OG5mVOWVz2p+OG5mfI5U5aPvA4ADgBKU5aVTKBNIAnNPOqYZqGGJzJYibeDtzjO
CoKeKm0YXYCg7tifCOA19pjh1IR8mu64cKZ8uFeOfaY2YS96cguMl2fQAr4uTHFxGhz5yZxM
SqDRIHrqnqNxcUNuC8eXLW83xjRYMl69G0IIW15yUEuOgFNtIda3izpg/Lpdtg0NuJsnbxB4
jZcNPMzkmp/WnyP0HWfMrkbl/VEvyHQ4TTp2xUq0C2V5pwVXMgAH7ddQSv26ov714BVdPdxV
SrV9R0ER9XArLLTpyUKxgMIuqqf6OZNOFLpx3lz6gZ1OZppIJ0vdtH0mChEhBumU7bpcHzTV
s6VOr/WU1l9cQPj3oJ5YRQrp7A5j3gIbeh/8JWcYrDJEoTxEH1Ixr3/3eUnWXicWyeRbGEbz
jHwbg++myxngUONFvaElZS1iNzBrnGYY6cF3r3zPmUA133QdoASKamoxWyZMWt+0BxwzNeT9
IBSmBDlk+HA0ue28oYe9+wI5jqshq7ghZ2s1EmcSFYxQnoq0iEJxbCSB3M6aJLkwbypTxCDX
+/vZ+6yThNvCOecBstP6J6jz5Abq/i++GMFDVBJT7dEtU4XqmagV8ZnPMqI2Bo4/ZvJulJjk
dCmVUV+Df23grzLk68sqxy1idbG6/J6epOt36YGn1TSWdwcPP7/ST6ol38uNVO5QjIUDh9oc
KykYu/l6jbau5bPEM5vNzuoSOp9uO+3P2vJhurx2ygUI7RORLRheQ7KnmzYM8qfAGgO+z7yh
GFMJ1k1EgxpBBTYeBIToORer6PBPUYd6HBPERv913kmH5cby/bx+XawwvSxYp2CnWtTWupqR
F20pqhHa3U/wejsAJmIk/a2WvOYdtAP3mga66m9B8DQrhytPJP06YkU0exLfm7pSQhAzWdaU
pttb0dcMqc7UGAGo3JaPP6n4N+wdwPtTLBEoEXKEYE/gihodzgXJag6dOKER+Gqq1k6xOfoX
qxuQ3sh+6BBmkyyOlwuCst16pk6mRxI3cBmFmRr2HfUJNpMfekk0nNLvZaLHJ9DIXaT8PXtM
EjTd7ACoDHVN0xFYY9nsgBEso+L0V4ic/WSuvs1O00DfE9rCVnxSVFQKTmkffdrZUICRhINW
mH3QCHdkTBT7WhAzkGoHPLal+GfzDfZCFJ7AgI4dUW2o99S8Te+pX48kr/vHqc6mBh1sHeMo
yiJQQcGeCH+dUdpF0G7LI1bIKKlFc/sy+Oe+77dEuHvdKaawEjdXpDpBXGHlBHBAtS75W/CL
/LUbMGa3YxSmNhr7N5I1Z6svTXg2Gvs3kuZnqy9NeDYa+zejL1BNN64xMSd67Be7GMROgtNg
TZEpkF8qG7/EegwKCFarsT7PlvTThlvP47Aw+Ys51teu0JnN7ktjm/nfXdXtgnuznYyyNrE9
heUHiYde6a9XLVyPse2ZiHoANwutkne96d9R289DpL5R3fw9M1NbPfmMGfRIDnwz9n1neShK
PYfvwjIju8vT2tbdIspkW+MeHSVFqUupFaxtmRZWDkupFazx+56ZFlYRcgznoBT4M0iOb83N
HIZfKm6JP6tT1ewcqUXh/J5NHpmiTJwRduXb8d58xZpNoeTspp1j32uMD4skQz1AorfstUZX
hM1jV+vGlXdLXM1gd9v5eNIic2kQIG1YgpVQWSuA/KuIePbGcLxwztiEqIMDwvYzpCsUuBIi
M18dPNfqxjo5r7xyyrR4pgPAd5VR2xMuReYTKGX3nPioaUEYvEJ80VabhzjDiRn1SV5noQ8a
8fGrDR13Lr/JusOMn7breofxl66sCPUFkK3eT1A4I7Ih9bZQ7BDJwJKfA7ZZoxIbZPJlAdG2
cwnv+c9oQSaW3paA+MMpzCXwCUklvLcj4j2TS1/dZWbR7wSIUnFgl5XpwmjoWjXf6T++oxvZ
VSmNtcXh9yhn1TVdHaIiZ10dFoiiImddHRFygkrPV4a6JAtohFwOtSAIb9xPAJrrF+iPW3Iv
53te1Gb65VMazBqwx/riQS5Lk/UUSAq49WrfTMk9SKSdLlC1kV0Q1xwKTDwmXeha3zR0vs14
THsfTBtDFb58vfpQH9Fhk16fje43V5bxJSZXCYctVEmhmtDlLOa0ExESq1k3VtwN2fHNBXq6
FDE9BlGYyyWUX8J9h+88OpJUO6DFoaq+6qMOvcYmrcTymWWAgp7MBj5m/yMufctKMSb2L1nH
3pmXuFeeGpWA9/b5BYHBHg+/tVP5oPi4EKqCK2tR3hJppdjtaPqIQaBPELgpJjDONmU2kyr0
vBjozBJR8BotR7LrUneeZBEZJfPJCBvENQGRirjGJV+ubXhjvHzU8wI0aU12cwtdCGCbYVY6
JgZk2SGBswqrCM5MiPiE5nN0Ru16jIMOtm/X81E8KvujuqWEA9QLvat5k41lfDyfNgZcWATq
L5xZu+jUkEZIbqrriVjRtonrM3Sxo7AzjnhlHX5d12riy+Vhrpvy/B9lraCfAz2VMzhL9UtI
Y7uzarSndbIH1JFKX+6TVhcZJmAtzo1vOJhOW525jtl9K9a8ANAThtgwW4GVJNLk4DT42g6W
n/h067x3M6i8I+t+2dKZOzL3TAGTCfViI0wM2Pibgy1AQs9S7RJ5qi33jquOVWoGo/kJDxEL
VRuzhO4l1OoYaV6y8UtkSCn3S8wgZI0G/SNHxoLeXhHDFsrYprI2FScvOAGDexOwJgaMMa3l
CDMzksGueLNzTNI6/gV9sR4FmmQk6SQPmp21bEXt+MFWkjqLc4G7D0hRlr+dGaKqnfg6DPVz
iHMytQjrSXGGM4bNmovMgToPs8b4fbabeSRyUZoiVXGqvljQzVdzUlvmIEi0NByztqa5+1Oq
VIMMu8V7Cgb3TJS3qmjP+bFzllqMUdAPUOxXbfky/hLS+ZLfks/++Z3UhgUIzk6kCZidGRCn
0muEs0p7js0YvF3EcnidOFU5XB1c2udc6zc5/0XJsKfG9t/6mpq15hf5gXPGmAV97ytGmJ0Q
vDqbARxjv7EsUWyjPVGYBa61FaM6Q4vr1/j4EyhMCgXVaXtpRcFr9QSDMFYNmLxzLxBTOpv5
Tsaa/OAONw43ltwdY18QKFE3Y4rNzI1tP/lzIkU6uxP+nYIBNO2YgLyPgRdQgFDGweXQG8oi
U2DgR+kl0cxsWyfqHmzxuGmWaWTWaZb39PwJCiD45T0PJBk/5JsM/hiBO2TcDZqmGEQYgRYY
RMFxZ/Bn8I9umW7H+82tqcfR0nDmwaEfzww5kc56aHRP0ebsDlOJsgZwoVY03KdjNpf/Uibg
6awW+anH8iNMtLm4q8ZzdstBxsuwuDPA+UDaXhGHp40zdtlDSsaNuoZ3E6XHJU+r+y5l5wqm
w9hsOPdc9wghWv4+lOs6iUOYbXu38DDPjCoFEdDqkRNuWTMwoB2Uk9HBHoHknnN4QUp0x1W+
bE+54iRL6jq8z4MQ0ukA0pulABRhzLO4I30RtwY+MexJ21qRAiNI8g9UqvJN+gWSxnsQSApU
/pPv19nL1QEKg/uRZlDbFjvLEZtbLJc171cPNsFt5HIfYwFmXCHGkgz0P/W727W+kdMn6PHf
f5DCriexdsgK4qRAvFAcb6verliSkUuGpAaN1Udutth7VafZzifYOxrZ+ZQ6AcTH3HhAz0P/
82U8dihZDsEIxROHJUhO1wyLkKrYrkEtHDrbkl2yx/ooG/sW5WvI2F/CxCvl5cHKpapANF2X
7iEFvSRMGHxtXRvBn7EMEZd5z1O9SQanH+pMIkhmuCfsE0I3sHztpmvQcEP4MLIytlQsJzXo
Kcath07IwAPWguzNUbll6VUx177AIwMZCV+j/6HRSCqNT4HBeIwwGs35VNLq79crxxoqwQho
Kc6w9csHljB+bdhm/a+xV5/+kRKicbGtHgjFsYE7PUeAoz3xq/PnvE2z1cXtp5mcqAhMtHvH
gmqsM8iZgxzDOoUQqoMyMorH6hmmvv9VINBEeYjiYozf5/TooVyW/hi+btKCkBo+Ck5WltMG
jJxBKak6YK+WKtH9v53JwuSFRTsc7EUFNg8gKghxocknp/w8VjK0pogXDXOV67DtlLhPSpt2
txtKfP3bqMkde0KFLjbuU3OHfYKtIbuZRfstELH1dN9X20oCpsxUXgTTArUu+ReUsAq1E1kV
GqOxv5+dfh6SUn2QuEwkohDH4h6AZL+DMnPde1Y7roWK7ElBVx4c1MJfI66RTzM63CNPpw09
FbABAMOFClJibE4nbsTmI2EuzJNyYTrlxBeGjh2PMVcrBbBSS9QiIsVnZJV87Ab5eJEEj/v7
ObE3uWAvP1hWJVNaowhYkY66ce1ZwF5ooJSzXZfT5ZS9LuLxSssUrHZBdyeU0ErAeZzHBuZE
zrnycBFbFYDc9YBJdEYi7YL+7HNOY9F9MzspxpgjyuIslp+pQ2VJXGx+EGOn6o1qV69N5oV/
Zs1foqD66IZE1Msg29UtS0XK9iQ+fcdGIMwgRzcK9co//WW3NcllhVk55ZJoKCXFLT4SrUE/
cylO14EHqul4tXMI2XMf8fRfSQdaSLUzCDMbo2IH/OqbOoLxEtNreE8nGZ7yOfIzV/I5Byc1
8Gfwj2liduVEza1GhA11iWWkJu1xbLtaaFDRD9Es+VrNGShVQWPOSwz3abhYGKhnn3Mw0eTy
/xxF8pUIheVa0n7/QRKZakMyFaXHljhcz+wbg2EqnTC9aHHbAQxvQn1z920Esg+HcSkiiXOL
Vo7cw9nbb72z85GO+ojMwBqDU7cQcq1tkRWlhHLxY4j2S7H1N63QZequycUPqFVPSfGK5rqR
QSf/fWs8MeDwMnA9sjw1O2Kj++5DYoQOCsaOh17QHjSjrjx5JkFRaCcu4tvAePrl2PboTcL3
6QuNbbIyW8YpaHU0e5K5cl4HbS8s/n3Vo0n2wva3jm1GpISxrtGr5Qx7FSnT3c6bNEKvkzRN
m6ztgCJ0cwgzP3rwvCZkArMh4pezPCr/b/q8q8YPDt6xNXY6zYA8dF0nkswqUZXCF8dQq0nD
AZg1A5Hm8dOOCoEaTOdPt+pKpQpA8pZgFjj3r1+nkzliOMio/XztjiZfNct4FyPzihfZnOOf
1+Qq5j7RDMe3bw1wMO3aIhi8Ssijs4FUoq1Ospv2EzK5Vup4W25I0ZpHHra46KIvoKa5FAzz
OCdU8jLbqrdliP/dWhUnvKi8ViNGriwOBwGiPwN3LobCgz3MFDxh/HIDsUSl3Q7m13dn1vcQ
tu/rtHr8TdXLSWRiIvVN0EnEw7E06kOBhXFdjYUPpCqX1SETPJsXnnJoRauTo6D7O5sB9B9T
4dfU9BGx949lNZhhbPGQ5KAx7pontq1lRsUht6DvwTVzTwBONzREKUeqZ4HGAJmsjnQ3mVE+
GEmey5bmtUcrMb5/NjsKQ+R6xT86nq20bdMN2bTnJfzxCtUnNbCb8SuG8uTSv0xttTHMLl/5
fSulhWY7/30JQ0KjUVXh7H+Y6xojnBQxokF5A+OQ5uUrHjYyRyOC6Z8veGBuMrPqs5GWEowp
0gdvynAMzDhKO5UPVVY5wvOVg+OJUqtjCsT0n/Cf8YU5D0ncVECQAX8KGrfpnAsXk1ECd/q2
b6JJWGiSJhW0080U6WH45RbeanAiBW4fDKDXJO0nPOpx6WhBKhwho/o65rI35qmhhA5QvB0C
qd9EbB0GWxFeDi41Ehz3340wnrZ5GM8c/MRQVbVlofjCsNahdy9Z3lfcYsoNb0o4maGgKrgM
beq5qBTwrrfDSWr3O8dmfXv6rVXPb1d7xU7TYla0B3iFeuJeN0rQwYB7P66Am84vevldSlmK
47KofPbCGmeppikhZzcVB5ShDWJlrU9S1ZnFN/xdX+LFvhY9rRaSXQlq34Wu29aDwKOtOPxf
0gRHoi/pfAQCDTA7WJcS5Fsw0ktM4dAceiOlfTX63Yxb0BygwToj0nvB6AUtZLcUKJv8B77S
1nM6Z//PFq4iyP0sRwdP6fLnxCCBa+L4P3YweyCvEiy57cTWEigxEupm5EYk2uSfwyVdoJl/
1SWZ3Uxbv6Qz5o/i1pjL8jnLW1MeDgAOAO5VMvyXVBAyBjhkA04yKim7fu8P0YCYMIcxZLkb
0dm8u/AfmYqYyhNQxpmk5/M2++cV3R013ftbEcoECrmL93gD64vQKL/UkABSrnhofda3Xw5h
74nQELJNfcdSRGL6AQsJm15Oe2KHsKlbIRkrH4XUjsucBHCPZEuku2nyBjm8x4nsG5yh5RsP
pCbddJgQapFbq214/Hz21Jq6sQGge9hheaJb/23PmDGU+jFGFyeA1NUPxk2yXcQmCLZUhFwL
rT0WYB6jIkGYtLQOzB64KKH+xSGyvvybE4EfDQgohEOTE2K9B/v6qXlmyoipkabx+/I5WjnK
iA4Acrb6EXFni431+4gUinC0OKmoqWAOAzavStNG2qEvisqvqB2yTF0kqbISNv2Rn5BrOTmf
kDg28Z0RtkOPvIOQs/NTT0th1vi9uUlTTw6Rjz+s+L2DTsBorvJjBdM3W2brN4nLLGRIobtf
B+XPV6peWD41ENcryxEp/Q/WrvzutzOFe5d6CZEgGL6iN542TWIAFE4wYiaomPHVqwBMdxv2
QJW+j66Mi8cotPHhSj24oftbQYJ+DN3HOXKIehdpZaVur8c5zUKLrY+RBjzwvpV/t7evQmhA
UsTWZiUmqXpMuTaoyG3RVwLPtHZlHPicYGbZN9uYv+lBa4iElGsxSxxAv5rAVfrBLlFkZn/I
7EbgTtAsDXEz3zViwOsyw3ub00T2yhLx2Oo7Shp2rFXoat7bDdJgeYpCvwVfOI/pNMW3PA65
qHsSx3ND2SS7IqrjGbXAEPjEEyjHuIE4LETiIlOSDpGP2IpqPeqxIQMbPsWM0nXYfIa/T7tI
tW9VEJIvc2DqoKosnZ8JbxPifp1oz0oiaOSBhs3XB32LnZqa5J+1CLmfbxC+nTouK6Spgt3m
qQK0Xspn7f6kKQum/KJCbW2RvoQcYiLWJFYtc1A0My8Y+S/uRKcv1tLNOZrK+N37Oc3efXaW
Z/3kfbPhB0a29dSmfYThGOSk/HNk0IxTXxHEuaehvgTeZqa4x07reE2jJrLyZAHpqq30G8NF
9dpSYqK+mcgrO5kJSKpfu6Tpt+NVeFq5/GfJ9XYuUijFu4tGnbTkh+q8ADceAq+GW9Asej+l
zjX6qWhbIASgW6DGornEVW2xYd0wNEIUw+pSAuhQ3RMZQA+Bb0YPKFpLB5G0HQmKNbsS2lb+
VEHIj6u76yqLdtrcdrAjFQ0FRWjUJgn2E+5p9FcugSW8ZpSNmhvkXAg0iEwfwdoYRojzleBu
mHeDU3FZr/gCO0QwnY9zrP6Z8jkZljCdDgCW1/iN7QfccsS0yRMh/yOY7R3kVThKSOcoeOP2
/RWwsoZHHG4fDEkfU0soBhXR6gENl1Akhq3Nzsu7CZuWHpvoHT3wZ8pUOHM5H7ZxWbh/Nfrd
lTYftqDB6UV19YR9/A/xzUlXWI+Rudf6FIJ0etdbCCFJ8Af0Kw5S0jLtjpXHejmVGH4PsI/P
rE691dpXT4/PrPE3Tr3/SREoEa5UwV56u2OumlwH4erp02TMgvqkY2oGElsH/uYz2FvwipDu
jPRUUpIBe4xeB1NjcxR8mmMXMqgJoE+pISIuCeICrHSArlXGF9BxA/cNPSWnyFae97dHxoz+
v/zvXiV/IeQI3hC1EpikZEoaKw5Yl2NzBZ09qqjegTan9xjJKyX593uOk2B3Y8drtCzlCi7m
PDqLWNIn3wzXJRHz0fQdqfCOOMKjNipjU1Z/h0PIL/cyCW5JVuvsuQujvlDEQ8XaxnHP2hFu
GmXGUo8gi4G0QUt/T5cF2zJx7mrVkJOxuEgqVl9KpKvxNnML91nOMP/I2QMu6whfRsSuF1NT
fFrg8IstCaGBNgq5M7PZFY2l/ngGRm69YursKnmBuscPMOuHoaebjVVzj6VVBkBYg9F37gSb
+v+2z2Dt5gWB9HrRVmIQjLkR6oR4dO+zxcaZipEMK/uNfl8Cw84uP+VaO3gM5h9aQ8SREgNx
YgbFlvzyTeQwAKfya6S1Slax8Xfnjcd10vVBhpMZQT3Yx8aGUv7m6W7nCesmVvH01CYcFiIJ
8YPIKbQmZhx5Ch4zSJCTKWgFUMO7VV+nkjxzolwyZia2sas1PljT3OS6ZE+wvO3OBO/+Fu8q
EGLV/EPLvlYweHESYsPMvv2CJZJv8Uw4roCrH2bxbZ5t7oV9GyFjOuv3MfMvngOw707JDxbX
QUpH+JMroyN7ELL+QqYG4RqmyOFnnqnx+z6mGqYRcoKuqTE5ji6g3dPNtoTC4YTn+1MuxyxT
tcp3vJYPLy8RKNYDHsE6xwIx9APQLYJrpF0ef59AIiaDp8ejrKn/HaaSqoS1LY2IczpzoXzP
+fi2HXsPxlVs2Ux5Y1oUh5MGIBPHEanyj59ZzhUag2+IzUTlo9cf+ffLuDMueiJWpe06H+zZ
oY3noaJcZ/FJqJTMgbGs0fdCQHfgSGDATK8F3ISPN82fl5vWP5icxQBlNHb457Mdxob/NQlg
+pm6Tqn38KZ99mRk9YBVaB860Wn/Mu2/FYrkPBDaGsG+kgXzJHJMqaQv0nGnLjCopkCP8Ptw
56mopkAOkaYE4XDng07P+4QAZeAVmeqTvczbL+l0N903CKHthzUEfKL+Is19h5znPbatb98Y
CAZdLFjZ/L5bpoR8ljZOezlOGE4DroUn4w6uCuB6ftLYzD0c0XaNQKWrCzAeNTNpLucpAsiH
5ylERhyPKGd9+2tbbB1f8y8jZ301Ehyka7EL1jzDt11RfV2wkS07WgSPUPbk4WiGH4tmJBRD
VjuiB22XtntNAkQjbR/MvRv9Bx/CwXNjBhh7Js5CJCaRqQ07eT8pSULH85xia104tbsP2xFQ
x10iJ5Kpc4uWALRDSjUgv3RC7Qu0+KQukwz0MVQbXDTy2XAmDEw+L5Du/MpnI/fKOzZNenxU
uaZ/xIviLU/3q14ufqoJa5/X+iSIPJYG0qsTbB3IYhNjPEgdYyMKGgrGX0roHMTaJwAx2FqB
jphRPF3JjJQj0QQoTILpBS+TWdYhfHnm2aIn+noME+cpW2502y6SrxsGz5FjMdaTFE4X7CYH
5X54Exp1jxhcLaOugwLoBA0T3HnraZZgFjj3r+gakzliOPeo/x8DdmuJNad6PYHxGmU5rc8G
HulLT0J5Mm+2EzKOEKSQSZQNcgv+z9t6/VI6QE1fItaFX3N+FeWhN8t6E4nuyDstokAI3qz7
qoQ0G9IRpLVGLKfzOtdUgvDZJ+rBVi2g8yyPULVf+KSU3jl5K099dWDX7/YuUgalRQZq/4Mw
kvIqLhOrh21HKIcC5AFiD4drkwOnJK4w6J17eNPc2aDOcTOaE2hvB2R2FBhvIPIQOKDyTlIY
3Lit2Q7e+WoU6zax03ZYt30we2WUi+gxXQmP5oqRjovwyOLc1H01YZf/xgMIiKMzt0NUQjUQ
3O/xi3qtKwutc6kPd3WmjdarFxHY6MxFIxMRsqDWeugVezisRJ+J2xsK3NMNakrxomOzobbY
Ldai4tPlFskMpJGFYGeUFDEynH78+XcChYDxYn7sT7Fa+wlqfgD8GeWxuhmkm4hFmYKvXDFM
b9fPeGtaeW0nxNhFDBsxJSZ23zbLjmbUdDCeEP7QxtkmhP3xLAjBCjMa9IUvcVj3fy8uwAxf
lcg43zvJDS6a6CkcP4oimSoeIgYhjP2J9zsFCNgZaxyQF/qulLw65jVVo9KRfJLpagPSN/RM
aQYvFJl1HXxbcMvDx4+ijt4Ea8ZQ9Xh759J20nbScXfHKjLtrIHs52L86xvbeRLcom9Lbxli
tqXwqMbfblpt3BXm7HXI8slaxYg5k+O4Gy4p4JF4lxRVUnrMi4i0C0ykxHd/cj4PdC752Mhc
1/uponH7J56ZDwkHi9Y2Gj1XVHPa8NYsXpSFcv/s44df3SEJuCRr8cIGvGGwUa/2nt55EIkO
hsqsHn82z9yPizOSwa54D/mBQ/mLsUrvHVNTvMFaq82a4iQPtUX4xoGwVcYFEmiUMO8ww5q1
sB4mf0G3hZ5WYen3kTZ01cYLJZPwTf6dcaobAvY0cd+fMnwygF2gEmigx3egrkeggNugrjSg
dmIAEACsdGwvcTkIci+1dAhyDpEvtXQIcg4Aclf5k5sD2mlRQ+U2dedwUR1G9H1HNm7nuFHB
47akJNVufWrGlhJEGEr7FuEO56lmtAIdaTZn8xaIpummjjczqTNG+xhNsHnmGPzwfMCzyIbw
hsgby1DmD3yFQPu+dxxfc0apz+HKADWmHGprATJ6LOSPwoOpByKg2Lyqzq9Dh8H2LudeJImh
0CEAZRElcgF2fX+SrV/UhGNtV0x+61Pybv+JPKZUjLfOeQ3NyaYEJCnp0BzUARrkFfZyXewR
EewVFTqzk/hskWIR7WcYR2wNVLH3yAl0r41OIdCctNWvxryn2TojAJ3mtekfH2S8+D/tkrxW
xl41ZZZVhQFl3m3ybjjAbd8uoj/mJz5yXd+9efqffvJHSlqVizdjy+xLNDBWovhhDCXvXzQh
cwU8HMB3Ld6yOl7RT5acNs/mY7MkQszSuzzdUZS/t9TqmAMhIsZj250Nam3XG2VM6QmHip56
YJo8Bj3BoGUiNPK1rcwXG2Wex0RgoFnpd191utpzIaLpb8n0J2CD6XEbgbkAQQx1fSiAMnsl
hhahzPfvwswtR4ihPMJsmd6wmy9iUhSeeiWdgNo5JQzT8DQ05QErReFdRBebamRKOv2y1sZy
HAp9EWjYSPqT6dykxJdu3+jFtkDsN2OXfLF83oLdSbDkT8u7o4W7o32aArV+7RfuTkFj5EFj
mxzfuJFD/8jMxZbcTlNUYYdF0kLeZp0hzIfySKxwIPFgLYGD28ENF5v2ciFkDbyK2HNlnxza
K5EpuMej3qMLin4MtCG/Zkv9FBCsqC2vdL3GB/Q6ZThUIbizwJhBIfJAcmSZwSXQBZcnoy/j
wgaRmLdkIW2p+S5f1oRVr0oN/Q9N0dOQ0ykIMKfkWPcXqq3uvhxfmhuWlrkx50dY527CL/UX
yleWm80be+0lsnr6BWecWVblDW2t856gJ06h6P9/a1jAv66F0b6XTo4uWExYVp+woYHRocL0
btMLby2thzs8vSP4I4LwvKe3Nw6W8JZyv4W78H9x/RDpY0/t1Rlm7sG97RRFzD36VNipQH43
gtgg8eA3GUbHVwyib4MqELakLKQusCSFs3TNDVoDIN2CLrARkaN9G9vF2cgsZ8OntdySEFwr
Cun0nb8ay9rBGK5av6UaSc68gyOemdafUXnQpaP4z8ehMrORGy/SJ6stcX9xOLBKt7fNcvVe
Tka1g+V1HwzSLlpNRdAg30cRwbraM7aHQp6+84/IFHbxaLWo+ktf/V1gpsemi4/0Ex2F8KYj
yyP5NIFxcH+y9Up/s3g/Lr4FbykU5U4iZWGzB5MFW6+95MkvP152Bgdyl1a8c/PCf3gP+V+T
10XS6UrzQWY9Yd6b/H19WvqIBaJzYOwwMO7BKzASHTjpReXoL/4MQS9lJeohyYlIxs0F4P43
/KRggfnNiyLlhLG/xLGdGaK/qvAZtfk6TtfNENI6/rr3tQFNxMjypyj5Xxc5Q4yA334lRxO9
t948R9BYfF1lTeqM/oHmMhWx1WuhDHcaGDzmIGv3AB862uCekcihK6xvqmzRxEUikkO52RDS
+MGuC9446BAVPfc/IbUToH5R2e1HGOcQEfKFDEZaD0AkRE4fFwm+RZirdrmiw4eRIRMkFv1U
mtdX8xkSZv7T5Rqfq+IbrFie5lrOkgLOPs67Pnm6952ECl30dqAKHnl3s7Mgsf6dz4ht0dtl
kxpSa7nhKfFLbDM0RWl4udWB+6SpZPXWaqoBJckwD2AbuzEYsEDpT69nct5GxIfzi+UKlDVy
zA9Ley67pb1K2gewMOKYG9Hendgy7y5UHTyrYzv13VhTtq+Li+lOb0Kgk17cNg2MYy7WcQuF
Bi/lC1TQ7/boMBQefVoIjqE59TyckGyqaBuVjWOJfjr0YQ7QPkoIy14k7yV66sQGl08y7H93
th4ywnHuA3sRB16umSPj6L7fnAoIzoEw3xyuKTfstXMPJnFSesG2GG9+eQhpjTFU4utZraP0
djYJ9Ch7fBseYIhXJ+mhA9s7JC3qNFIGtE3WqHsGeQu6rlaRlYPstlL31+0mNL2C7s19txPy
5gzD2PsQ8xzpCD4j6Mai6cH605fb0oeMuc8r2tiCZ7+muftTW1CkZ7+prabHpvVbUKQOwQ7B
r31Kb/A35e5PkxVb0sG1/rWmhFEYqw==

/
--------------------------------------------------------
--  DDL for Package Body PCKG_INIT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "PCKG_INIT" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
253f2 3a6c
YW449Wr9JNUXQfnNRcow80nG1uwwg80Q9seG32GPP6Rznkc7RWw+zPaKFHiYt0pe6V6gO0j0
CVrlmO0PVBjXQTxgYjKTwBsxRST54Y+ZpggUbF6fhCq329NBW8F2dm7BaFKae7EcU27wSK+q
R1XEsQi0LIC1s1IVy6lPQnzH7bNmpWdXxp2Pql+Q+s61IwBynRz4h3ocr5b75E+ddYcj+wRC
6v/g0zeCeqxdgqkulh+xkyCmtfNCsYel6wLc6rsdcV/arLUAuqLdT74DOnlh4fD/NXyyZAt3
t/y1/71o/UnO3PY2v9+b5YQEVjisDklxhCzQ95AdkvUaT1Fc+SxIX8uWM5AmgC7N/+R8wORN
dU3+higQpjcZOxxS/jIycbuEcXDpijrvzgIe14wIR8EhPx9qEP98TU3pkYBz7HkEQixm5Tgt
hU4Duz99t81qhRPq+9VIJFitjDBdotLmUB+R1bHQV8aVk+KGB7uowpmwtffsaFhySQuxNWms
0gmIp36tWNvcuO11Iz+Ob4bgl26uybFqFv/BTfX9TGajRez76cTC6hnWVF6+Vka2F5EeKbTQ
jDEGktT+FcgFuSXWdjV8In7pqghiV6pitDXQJ1jgsP4XwP5Trmcf5P6q711gumqFsrWKy04g
x4mqEG5cyFa7Wl5devdXGW6xY6nJ3qb7SaP5vIPkmeQtcSQbcPjziYX5ATpL5G6Ktwe59zwF
RBGUnRrB8dH0VAt9Lnof93dovW4+ohW9hysHFWGILg7b0OqvfhgwK45Z4HqsH0I1+tOv+P2W
pRizf3vdlJTvMt4iimdIjWFG3ZEot1srz293PAl+1e74XpILIW3zUoHjTNK6N8Q2SQQc9SPj
+383Bx/SRf3vWwBxXnT6qeRCDZMQh+KvP/jOZK4TkcQd/vrGPRu+WwouRd2FvZrTCn6Ufcj3
/hZLxlhHPBfucnxzy0QjGbxlDh+pmMo1tO77e0WQElr5HjIIIX96q7sjb2jUaWn0rDEa2oU/
MIKY2M8f/wCcse8FrlYE0yUb/iGzpF5aRTfBe7Yf+edSbF/UubZPkwdF27MYQBWNs1FXph+d
pvtoN7xZQT+PaTp4YGqJm0IiWTPwMRYaDkFKCc8Ley+oZBcdQ5p1SqLnuTFaOngQrLTU6kQv
+dwi3lH90DkBj1+EZGbqnOdGRooIjaYBAlf78cNwRSC9eYBB2lLh0IPeqA1ySThHH4Le8/EZ
iq37TPxY9/94N3YWnY7mhTt8xuNu2fRba8dEdv9/wepGgqJ5CJQ3VMxSrUxvmv2P5zJ/r/mP
JQ7HvFHZODWvR+l3Fw5pFcHaiM/UP31EzJc8ClAm2EumN/gbCYQ4yN/WwNDHKUZB3AX1J/BA
t1j4b5rTpGwa9OtgTNrmfQkTUdBoEF4eRwqwubx//A/RO9T6qq7tb8L+MAeIGVv5dPTo3M8q
us4h7+J8Y1/WAV5ngwrkl80JHev8OHGkR4LUZx1Z2G33rjdYWxVQOXXyhwvbmqLVmwaPZZsM
/s00ag/jEZTP95C/eQBVRPoSARsekdCH87Ug+AXLz8+0P9G/AJuLL9xBuxngpqlzm8QyJf+G
NbjRR54owKKG19FC3cqTeTO6q1vd1VOX3daWW1bFcA4NHS/RT4QMimu1BApsVTW8tjthg6AP
dApVg/Rva2Bq9LZgCOD/fRFGO62SdswFQnxBRIZ9K4wm2qSVWmg8MVSmRAYFaSg0Tv0wEBGg
650qwoLZD0/s15T+DC1flxNx4WXOivCktTPtjAPj3dbn86KrYpC9dn9fgdrOUkulKoMukChN
Y/8ZGdqGEYoPxng3YIb3wV+lXi4KDWkIFM+ri187mu6e3z6644S7sWu7EOMZrbdKbtVNExXa
dcqf2JBfoTO0PSnUIMc/nznOnc5t+qKltg/wDErFfbQuuSJ5r0e7nj9kLW/6rky/35B7+Voh
upysa+7x/yjS7RHkuyienvSsjQeDXABpGy/S56KxmKoEUsNi/fi7GwBH6O77OrW4RRClgjQT
mcdsGTXq3LBauxbx6TYAZNYx4MvRICkQgaiyvcNlIyWZ0wc7iuABH9WYVDFDbJfRpJQyXhWe
XUBV3KQ/cEOJds8r8j73dZZRWvWhLoGOY/zJxKpap0+/pvoboBEVtlujd8FU890Ypis2S2bd
7ump5r7KBuueDEBBPwYExCJu6mDZUzdfrOuNDCnfkKKiO87qrfBvj7fMybNaotDW5YSwMMbA
4dt5EeDh7M1H3G+fnPdvSMpJFmiiNWBFFTne+QbZ/WfGtN8zEJapoGxOZGsBQGl804l8BDKP
RDVt5qfQw2Y4ochLXmJjZhyA4NOK51x7rQCFoHvPOvYIQz++rt3RMc3gFjeVnXP5RDThv9mB
VYYjvg95eIW7LdL61qpwrc1c84ymQrQVma8z0F04vofE7wdj06FDX5a9ZO1NNJav6Ugvn4w6
yB6VsO5jW/if5edaZtUV6JXPuUR9MBgx+B8xv5VoVB88a9AN5JRST5mNeIcH1Nsl5BA1h46U
5FFxmfgxd03anZXMf31CcMvo39K1sISoi+VFZ4IG90sFSXslhKhYpr4JoDd5lNEmLrggadEQ
3WjlB5XZlk+n2s5DnF1IgVIygI9s9C1y5x9PLyg+cUXKsy6ZZM5K1F+ExzEyIUEjP+eW4pn1
pdigsPTxdhpdmf9CgiojHHW9b+LJ7upf9WWgqBA8KNamjhwTkDQJ1kS5t5b6iyIxaHNE0Jh3
h0J/eQPgjpNjW2kT/FbXLvPaOKDHwvCQ6MJKk0/iGeJBo0o83603W73o/0ai6k5CHSBRsDhl
CX5TeLezaTScNTFn5BtPWz8UpIwRyhyEUb5pBZr6v2ZBXyjveHU13BGbaKITHyQZGHlrCz6H
uB+JAVFqENUGQZJhMHdjdcg/locRV/twp21Ks8/UBtJEulma2/BU8zQJXu30AeYP1bbmSR2x
70Ookf291cDh4BQqdX0cVOJQqa7U4pHdUDi6IWT631fKNBnrMpxX4OAy4ejJZ0NJFxAaP1/A
JXgtTADuRfbOKzg5W0IJ/nD4ac4PgdqB1NmTA5s83mFFbvLOvzjc7ETAUQ6dbuIUBG3oFPrs
MeNamsW63usTEb6HtjOK1TANQHhYkwUZLg87qX4wY2lM0ruJalWsM58jKcRel1hBhoEULVEq
vg7A7IJTa55lO6rp9A8wW0UOpSrDNsPJehD8GYPZhSf2o3c8UyBgauj+mXA0NlpMxXYPdFe+
4YCA9Gojy8hnaiKm7zKgUrJjGCMI0hWV7FZTEfyJwukecNgJcxoGaVghRwEJiLqgz5ebJuuP
Xu43Oo7wj3VcAjvCxVOvq/nySfrdFaw3WGDyIRcn5u1n8xEgrVhDkZavIujgIVuMIKSZWJdj
06+nn/zb7/xTMhg76oWVJXA/7zMwemAamyRLfoXCqNlAzn5aAZWnl5SBdWdePJXBbjYee6BW
jhRPxKrKy9IBmK7f+D3Asp/6kgtDkP4GJYJ/d8s36b687DWzTOKxBOMoBZhd+QioPgnl6Pkj
MOwhJ2SkaVyC5StvyYLlJ3TS5ILlwEu/4tSjpVINk80i7nflYph7rMoxAOL+WaubdPLNGsqc
kNMvwUls63yMCS+dpju3VOI8+nOmFKriS31Xdsu9QeBFTpKYIEYQjn1avB2vnGbEiBOyHR8H
L58FWn6F0VEbSTtq3/alhSN0LRv+2hArnCyr+u5W1grXj/Uwo72bnN2XtBRkGJwiwCojWrlh
KP7l27BRSbWhvE46u7EgjiIbCczt3qzTfxoKjwCkdTwdkWJ9veXNjpqnsduu3nbMOtfK/ukI
YHAzYQybUptBFvhDD7LFdPApunFvAZrkCvswMv9oBJXwoege4mgEW8FmMYPQRwryuCyqUeTP
SiReP+xZvIrCuOo8lLPytQ0OsiL+QaXBUG0v+NQ4CzhkXV19QtAtQx/CwCv8D+qJytmrUBIp
nYtl5CeLQm4yQe0i202hyBkKuynNFn0oRO1fhC9Wz6qKD++wxPowe0pFfmabG9IR3LdlRV3h
DsvsPbCzhtcbDj0L3IWwMQv/Fg5MTJI9Du5JGgtBpRsmiMwQB0cbtwzGENklmTWzwVyjZlp7
cXFAzFCZqpAOu1uPdgEzaip2ATZ0E4wkQ8ODgRdNUIwdpRw2Bgftqw8GPTBE0BAlJT3j+hc5
PgIW8uoHSLz28EilBvs/RaPlLcPH9eU1H2kNnlJhjSdi/DrbCP3Da+JcqkXJQykbKrD9wxMi
uJApFbK480bIbHES8/LUQEqoQA+NrszfALreFSjBr3weZVq1wO6QdmtuxVykYhNgYgOSBjq4
6Wy0nV7rHmmM59PAKqLVGmK0/HdG3VYfq/cPh55BsRtcvDL8z4yTRTnpmLKXnxMfud+WVUxi
GZA13HqbJCY4DFCe7OsKZ7RBk5AwZ6GZjuEBLrlFXL557Xm6IPiVsQX/1Wt5sf5YYXtcK4AZ
9Uo6PSkwtI9slM+gPzED1TD3OcFa4fNMsLcxftFl1Y2e+fiRW7UQxFso0BOWHkPoq/cJaBNU
MZY53tro6PEQajyvQj+ywvDn6JBhjNFa+4m4rAMhSBe+qmhrUWiwSxArruNCfiETLhXulOiw
MPyiuS7LBMJF5A5Gsams8rUGbrArGuKWg8I3rRka8Up1zVI/n9SxbybMA9t4QWizbzS9x7bt
YYc5VABJG4lPcRavniN9wadyexGLU5zaJax6VWKm7eESe1E1WhrxIQl5AWeoCYC+XaAwFvQL
43PzFwfF4F/vg1nJYscr9+Bix4unrQoFxNsBDYkrxCAm1AnXXvwz6weQWgosMBZ2YzfgneJI
nbwjnWtAnVjxtaUjP2BVqgR5xyPYegKCHsrDGNWWodrNkvP+ilfZn+SlAKIy+mY/Gqep+3pM
RlSqFCx7DTsCUrk+YyerMPMafsNbF7lEhjFaJfW5RmsjIIyTRxQZb9Y35RWMaCutkactplX6
hj7lISGQXklAcWrgw/LjIpiX9GKspgo44SDhtSrxR3Lf8B0UStRtvhrQu+3BZq5FdPZaMLxA
RjmnNjn31RZTaGgKg4lTsboQou42mHPiKNzUZe459TEC+0rcy29ZKkCvk08XDXB42shQQSVL
+7EJJzHtCuMWpOYq5pFf2K9DZsfrB7nMuFbv2xHitGduutOeTd7/R5C4EZHwzA7JQ8lXAOux
dRj0lrjjEi0qYaw+3et33zP/zgTdJ1tFolCJcIYQ9k3YqgSFaZMZ7pSpHyQAYshE7lFTbq4J
0yHVrOQtz1QNddpDGEnATKnHGzbft2PuMOq3MVZ9gSPzjslMUIQQzG/WdyI8kEqYc+qptQUR
Ifwz+JputaVqk7UsJ0UO5o2+HlYEEEg/+AWa+dSsH+JUwqvn2Ycou4oFTvl4rCpzHWTOKnYA
KjE97ESuUYKEbFMoLjHuUzKzIW7/qIiQbMDJmTmR/1C+1TKgxSY0lyhXqF8JRbA4h2sS/ME/
BX+gubBdub+4xFVoZLgqZOo22UVNNKKjGj8npB96/2S2Cx5JtTkezZsi1FzXjzGKJGxwW7ui
S2g3lij6LArNhst+ePoDGEs9iyk0sXn/Me6zrsY/0JJSpjqi/xvKHt74Mo9nuHDNe9fDPxu+
McQ+twE6ywauqd6A1BP3ZemUWvBjmSeg6NNAX8mqiyAOBUpfNaSkDwz0cgNmSOTPa3rnXNhx
CK3BtdsI9qgidlx88NFd+0DKPZdSLGN32u9qQbMVWMPb/STh6D4dEZ9A8pQk2Lm2pUI6F/KB
cnoLqfnWA2m4ImQHybyKhCR8TlLQgUvYrLqlDkf9YbXUzMpp5ZQiAIr05vObS20kIcsIwKqr
78jh/EYt7kLzSL6lhNbtdjpU29kdRanP2eg7JMNUWWayDLCs2lomLERK/YFg/3kYy5UMmEvf
NVLwrt1zIs45DoC4XJfOYQTOyWHn/PDkjPVxFpKWwFufA/edRLVsFLb1e/IpBwfCaOuUyj4n
9ay7fdeGwZqP7O7J3wUQ9yHVO0Ez6sIg+GICdjASL2KSWs8yOthK1ZjhZpDL563zwAalRVGJ
oYt7ubzuMHP/z1f8fPY34PwVa901Vzu4O08S3/A0mQcCBWRQm4uZcrlJq/uoRqOA7czChOa1
/O+pHqL03uq1JDtHP8RoqZrTuJ1VoOVhArvsD5He/LjVgy43UpU1W0mbrd2W6RwDqBLz6hwe
Q14uRRWhzjU20WkvQHS9qIVqhsnWtt55uW2CtGNiIiS5M0ITubZDLMxbV6XgcNOgHXkmzjbf
yMnkieWpvTIh1SvvPAZG88Hi1uRLztZetNeiO1azlsdjzezGRhz/M8hKqloWsFO58/pqIk86
+pGL+y1S6KcmPYpjx3x0tqNY0MS9t1S+WT0fSCRJJqVTz1oRLTbyt5aAsx8bEjTQCfwoTBYK
YhuHqUASeBxCjM7CY2hBe1PUBgTxjlJiAs/9VdwA31wBrmaFpR4fitM5S17GB5YtztNb8WF+
hgodMV+Za+z9Wx0mLxtogJp7k+CvcjqbAe1FatMPNOZlynU0kLci5WIdjZMulE1pZ59oEeT/
jEOGI1gBChRWL59BvUE9yISr4GvyV4nhE5/wSGyzEpUk2gypJX0E1LRn1MsQfHXq3RvDTsq4
C7KFZJkg7g1Yn6yM/7M8honaTem7lQX5F6VqtfeVYpwjGCeUq3oQ+Aj5UY0yqWkEd6lpQa/v
RLbPgE817nTkpZ0mOY02HNgVN9fP1x2T2Za9+asSzk8tYEbT8+WRK15WeSQ8/zuPNMfUtolp
D9qIHZGSkwH31L1vtBSZ4pbVAu8+bMlQBjQppqxomfX5RKQtvHDOcRRIhKaPt0IjKY7j5rAB
4knLs79MXUYg9Jm7jhrKyaEY2gStXWlkydJMb0IxjsPp8UnkUGMn86BS18WeTT2uihrEAcJf
ZRkAzv6wPVVJYJlLENujwSv7bAe3TZICy4VG6GHlvgsNhK1uJaDm7QMitCKpBxrk6DL+6WMX
++pZ69IbEZLbymjLNkreDmAN4tlDVbvQDxEyFv/OISg0v3GNhAzTDuLT92SsLw9rADJWDIGM
0n4kX0W6cvjtmrNpQGXGMd4OJTsS0333SJ/LzBGuNfWedkRqbWsrvjEVcQW1IVNiAcrGcaDn
lOa76tJTEry0yPy3fZ2dAe2VbMjX+3DncYsNNhqj7beBnNhk3dog16glyYsA8t32U5o/r2VB
xDqx5WLqjJLOMOi2mIb/5HH+KCwhOF7IYzquKZcjj5QjtC2OT0PBebPgFQrtsV4eVWngCTT1
XIKkjQ9/ddyEXHvDeQ1ByWU8+8/XXxevV0WNxMCwjARDOAnYJLiGpd/DrHk/hkYYa7jNabLI
a7a47htkF687RQH12urX2rpxms6HTVdEWl7Mis7Eu6SV2PtlZET3NPeCN4bdCuawO3LbaLjs
ylEH8I66MLtn4IFkhhNnGUhdre9urAw9aZEFZVAhH5yh8oxaWYiSGQfnwDRKbtw9LinhH1cM
KNdr9UUIBW5PkDdKaQzXten34AQoxasNE2gQg6xYmpTk0YqAgn3ikbNR82ns4DAB40WfPuOr
0bvkZ5pt1LUZz53xT9vUcffzrA8ZDYAO7RkuNZdZXFziNxjCjM/rjHZgdbpqjIG17vX4XKjq
j4RgPKqoYT0HNjLKvmaBEaAJAo3F2MM4YxiMWpSklEPM4DbgWpB7oCds4+U27vQTz42b1jTf
NFKTMAhEcYPAWM/omHOEwuRHcVBiq37NKn5kOBKynV32UzAjbVPvz27ZTcO7gT9GEx/c1e8A
aGdgMikVYzac3GZRKuQKbkeeffoW2BEUZtF/zlBvQ0ZGBVBd+yEFiJbpYN9TN27guLZELX2H
KZH7XPk7y6lgqLEtuxI3URzYITykEGkzmnhZbLRpTL3fbYdy3mQJIitemMnDrmHIJ7iHQ3T+
bCf0saSH8RDciMRmwk+4k4xGdpsH0AVbN3GgVdi1e6Q141THctuztLTQiFXO3EhxZVhAfQEh
uo8uiertszJdGVlghAgGWwEdf9WQWz8UpIwRyhyEYX+k6WZwV1v0Ybn9+q9NJ/K2zzY35miO
UrbTK3WWhTXqwvt3s1nMJvr4L30CaNB7nH7te3X01+hNIJB4K6Ox0gzCvq7fv6r72yfcJcMn
WIUDC2bTAtYcW7PKgYRQpN9WXQU1STUZXeysHawWYkWP8zJGH1aEXUnmLrVOlmBO/VLYhnzw
t8LWVKc4k9TzkzlPyZYWOwg3vWE+E+7HrazXWrFx1kxGQrSFA9LehiyqKR3Qm89eTJKkpNq+
g5m8N1t6hnMiMzXQwUIfarK/W3GwNDD1KvRFc/leOk4xJ+tn/bN53q66eaMreezXlBRgLkV+
q4FtbuRQVVfLNbkkKLFfTtm/lJTH8IWzbhQBkfpVqqRWCq5RxhMuZ+XGbsiuwsZuzGdFRV0K
NRWuWtRWPpx4yumXYbg07Ul5vX66VxkJ8GPsSWJ2T2/zHzxKKB0f/U4TlNBkTAC8NTrO6IGG
/W/IJPVEOtPaWJ6x9fB5UgFCMjU65NiYe+kGPQ3uDQwVA7KVAkWyHscFwmjGdawW2deqh7zI
51Ulzi2h+ZBFE8m5JjDprQ2RHP33amwOYV9mXcAjfZV/ToYl1famur43eGJtWEC8giggySlP
2OADIXbd8GrMB2777+SpCCNVu////4eQkGq1qPCGYuQ07NwP7gkm7Dl0aq7XvqGKxf9lBXCA
DmuBF/MVgXyeve24/nLiGdTAct6bfqUPbohjGODuf8os5fU0/CDSa9N/CdfLXAr3GN3ABoMG
0pfKbmLhse9xa4NsVtw/4s81rEdxKTkJA/pYR0iTyE1BC8Du1hA7BaDATasQaayKJoxVe5oK
YLou1iY36W/yk+rqLadeRfQd2jErzSJPDdyueErmNzFcQ5QFTM5tULbpmyE6XCNgHbx04qte
KRjYflAC4a8Ec1bsUfFXRYzJ7qRENWa2kz8UQ8QwGvVuif4apISqzzJDRAL6HCYV97NFcn8R
kxKnPVdUEivvEqdcrLoGwvx6CjbEwwsmiz6Nj76KFnessCIBovP/QPyliyMIhBaFKOg+JImX
5FRFTtYRxtVX3V63AxytYxrrwtztVHBxVD8bSiwPrYb0xkxjPe0kIFXaWJIQvoeG4IAoBZhd
+Qio+xTLoAn843Gm1wz7BrTF/uqseegstEm16Ixw8UL4ihNK7Czo120ge6tflh73quuzj1KT
nOT9N//1/wBqUeU49pRtx875c6w+o1ZHwK5kqr6jXgokGEfAd9NffkFx5PFzMu5Z1LN5hxvi
Q1++fvo92Kk5xaYtqkd+uvd4bCjolVbV9deI9buHRSDBys/HkzJDcplPCs/O9yd0OgiwzfhX
Xvcl8J2KHPDBhC4yuN5urBDSMv/DeMxLvFmaLP/Wa8nJdSd6ssfOuLKSG9oyVpb4oYE7KaMt
IdMw6jAdkmoOUw+ghnDuhpQPcFMBqoGvW1yFRKIbGxWL1tHSJVk2nMPjR1vt79mYp0F2TfYI
H0lvC39PEqXusvhd5X0i32Dc1CAAUHOuobTK7Axkvyqr48Tp8Jcurfb6MZcz+12WVjDb/+fy
AhY96z5SlH+AONMalOOEyrJlPgQbJV3sfBqIKkQWNwSr/QY9roap5r9Gsi3nZDTKQW5rJI+M
BCIb4TAs1+HSeEIMLarGufDBvAJMnR4zKqHTOF/nupJcXfyUQJQAkUA2LKahLEYVbt78lOAu
s3j+Ot3yVXZpeZoZTcC5D0OrhprxqjvfJn0tEjmcKslFIx/f/7ms7NTSTsw1gBVoKiEesOuF
fQSQAzR/XexLzC9RURb2t9F4Q0sQJ/COE1Kaz3ghnhTi4VoMJu9Gp+7SRH28CkSY7Lghvvp+
RlFcT7pt4vBpoPMY3+YI1dBpoLkEM8mgQAEeSjhVf1Y9oI9KzC2gmXNlGM9NVFN6415ghNBf
1LkEBwiVV+Pv1OsSOHZHKIwGo2uGcTiPh1IEW5nFAYKq9F+2QC39OXLz75rzK2qiOFI1Q4cz
7Sx/2whZ6rvWxGoKzoPWVy7G7oFF9Ww6w7309YW0l4i1LXHG+Eyc3EM8xOLKO0WsiajqCrJS
n8oxaNZz/MfCBZYkqqEdZHWGPyL6aLhVF6F948xFDSdCUugUVOwd6448cv0VGNNLLjXyd9E8
qX4cZoUZRHno79duog0VVaDWVTk5YZU0fZkUOQEMTME2kOZlZwqnWnu0zoO/G5fJkkMkqdz8
69ifqUvdp+XYgE3MPNZTugLWFuaGFXjTJLbkAy+Fg2PC9cVgRpcY8xXmKJGzRshi7KnxyPJt
rQnJBZkQjHnuOJV+ZJSWxhjjB5bJuOeL1dHOs8gf6t3J13AreTjXcN9LsyclO9xQJyU7G1UJ
106zGuuSUmurAKVxFwYG6tlXX9TisiB696XUCO6OHiOXgZ4bpY0elHlTcUKHzOCxCZHZiTHi
LFyvcU3rlfq2TkkrawM+LIu19HHlJkStxLg1CBJyErqfLnLtW5ZfAyKwCPWLgHh+hrsx1E7d
CuJZF8yj1EAfZH6WKu7AF2XmTN2hKY39icUwmkjofyOTrM8Lycu5mJGQaM371jLZ1xAmns+D
zbdZ4lEtau6jNr3SAp7ZZlgU7QPLrguNOk+2RFiZrsFpTCZbCi4v4oADMRRHiguG9qo5lrhu
qSg7dTwa0q8Ml/BYa1Bzm5ZLg6mqSfq73ok2sjpPJcf/KnqKr8PxNmHTwzXCgWj8oRzVkhCf
AqpkiqmzIq/wyVaHwgGgXEZ0PdRTOdpu4nsuGS7SNtNBR8HX+bZuHk+15EmUuvYbIXg2UkN7
5L2W4488tuWJoPWCsA2ycx2xbajiGrgAAgyhLU1l49nKkusUsu+Bbhb0Ddwkz7hgpGTU+xTy
cTq6eQwLn30hzSYB3QvND4w5A4iB639Of2+wv7F/zzB7iazDxO8ZMXcvBEAI61MfUtAT7rT4
/RvPeJ2Ggucf6JX7xiluAf2pwUeH4LVn5IJgm/y7rRvL3omnIRovU4PRmlw3TT0bPt/L66om
YC+1Sn953f7QcmT8UMeGDJasSwgS0hUDXNI3tgkEEXxwgTB1f15dXfsOiRrlnUEm82tq17pM
zzHvP7nDR1WaUPApiyEYb02TQcmfxeGPWwP+OlWxWwO/pS5KGO9gC3F1+ZthXyWVNZgWi/0/
k5Ju8DRQ16SepSwEiTeW8utiL4MyLOakh2fKiD+WzyF9beR2Qk/anpYOA87iWaJtfvwpYc6f
uCWva08NdORtJYoxcimwzskGTOn1QTmt+YlUfzIiDkkuUj8QCOmMv3BgcjvJSbF9lRscO6Zb
/XX9yy6WXhvfeFv9dvISX2Yq5P3bj14Mz3bRcR8caj3gZb7pb1LTARg2pZQpO8BhyA6CYEHE
7XAgoIQOVJL/SWlfvk1nlL1cZqeVlWFS8xmkU0f7z5FdIhBFVFSt6uMHAn5m29sG7mYSK3//
rJLQJmCuPq9l9Wg2KpA2gUw2MqQ2Miwno/83eyA5YsZn78RnVb+mbjpvQZxvpeXCImuztpCw
ii+USUkA0SmI9ChgMKsG72lqTJ5+REZbwPmTAYuQ7NPKlWGWtKE65YiH88hvTEoC2X+gL/UU
H+x0ZY0UiMBDuCBCxKpx4q8jmDS7sApv9vSuNTVx6iR+UavfPJ66AqXHw+cTfayNOMvmAqW2
ILzTm2eWWWO2K22Ue0WHYu3i6Mvqrg8KJhNcfTgy9eLAk6EMnOVreEM5WXx79Msk1DWfqR3s
IJe648sgaUMNmark+6wqO3hAT9Zf3wOaZAAvMuQNxmuzjDN8WCP3mkzIVgybHavxonW8oFwY
f+TfcTE3s2XJuz+yemaloMa+VO+WB1ly9MVJ8I5A7IuI14gEjme2fYhSdMZy99ZuZwhvDK6A
rYRKeBGRAj4WTIKKhKhg6aHcYZcv1isjbT3R3naOx4IawyREcYaejLuRkT3DemPiaJkq/fMK
BBgWdiwp2KTRzVR2P/lX2LFzuIVzvH/AhsbUApvTXIyfLIndCqDoXf90s1UxFdAjmtJe+tEy
2Nvai+dCwL5cFqAVLFC7+gCOYikHLG7Y0ABbr4TAxBBTmg1JmoObP99d3WCvMRZX/UQX9Nlg
rzEWVwwqcm0nhRZT8mm2li+5I3/JC4t+Iq0jiV7ZSb+pX8BuXiTPk51J2QDGvSAM158B1vIO
dpbBbiy8BxH/E7vGvIfh2tSSK8hWLnORj5r3xxmQCS9osY3ASjttK1ER2T1Qo/Td7Hv54dz1
KaK5Ls9LuFbPfHciXmjrf8LEkSsfBltqw9xEoUtSRjP6hjgYUCQbhJz6Ba0x6IzNTQiSPgNg
vfE1Pa8lg21cXDlR7PY9RAau/06nON4zhHRj43pjXRMxAbRclJLzpuiaf0+Z6gkjo7Rtx9r8
att19Gv2joXT800VGjHmSA5IqaAVqH0pQl0Wk0lCDf/YHJMtHvd4B9MmwZjE3vo7b9Wfnv8C
k+41Slpd/dY1pZ7IKl2jVt+FgfE1DHcMsvJTAicNPcvbdgSNPndZ5JPODRp+gLANn3R9piI8
xgNwdlUnITKwjAQAgjLfb2ccx/38Nx+wS3cRnCtFdzZie4IwaiOxA48rA62X+1EdQIiRR0qq
+BmziFelSwJUjGOCN+9ALT9b7WfMfqRgYjKliu0dTx75Ms+2ESEcQv/nCqSgo/1sbj2hrRPx
I3YjncsQzhmqxv55SRZMVXdjwlDgkySnp9ddMobEa9mQwhnpZ4kIK/dyM3FQLRNoEIPhUkqD
q/b35Hfp1HEWnOPJHgl8Nsm6f3OHoA27KEUB+m2iQz3pvVAAZQfCPFVrTDGnWY5+dWx1SUIT
6biNh/N3vJLIK4XbIdTxWwnTo75ql6QruUvAxsf32nvFGGM28Ce+MC6rxGVgy7xkzBXI6vOP
Fufs/FvyjfpItchWJLum8dURLay/jcRNgC2xxO28zYF5ZCDtHpgwd20wZArFJ+tBh6b/Voxp
aGdgnCmDY3d13GZRNeQKbpueppd9OxEUUcL11cCDFXkRe/vszUcUprRMYCpTN24ruLZEAn2X
OeLChS/Kjr1LrU9F1Ly7RPW5WJcHvAaEr1ppynAhfh+rAk8lWVZsO2vF9TLS9TB20xsJ6Tkm
AFIql1be4wyPIjrxfrm311UPJo/DFNb6Vq1e/qf3ddyF55WUQXWBKZfMgdsUkjO/wB0mCEai
6k5CHSBRv4b9TPK515EUYg4rIS/H60KPgCV/GDllSnqrl59NjCU2dAuoyDbwljlubpXDMXSs
9FMA4N8UUHwFyGpLXdNNjFgV60YkUdYvwFr8icLpHnBWM5lnEB4ifSUXdk+hAUc9mz7ZsNzW
rgJbi14hrAsrlGGX5Y859uNXSfrdFaw3WPx6E4IqYIrmem1SOC1uR8DCb61YXY1kxhX1iNev
ff0Ft07wa9Y+QekfX2Od7wGu0tov0E1O09sowuR+TSmzCkdwP+8zMHpgiZOgYv3CfoXCqITf
28EdH4l/pd1ZDj4eBsfcrDKko2+e8XIFJLi9u80iMYrq2Sq0bB7Qjb8ZbcfPyU2k4W23DgKm
iZhxZH9uHGG/+nOGhAlX1wc3bVwxO47aFx81gHLhjiYK7krp1NnoLLSWtWBosHTx1/iRmlpF
yDgt3pwG/d6WZnTfHo2q781gNrzJVZsgdYpiOof53EA4w4xzkFJ9XOFegZd01wJ1HSLi3wpV
sF28BQkq4mU571qf0B4AtsSnsMbegN3IbrJwFR7ZTW+OwfiZyDfPvqNJ/h3I5L4V07S4V4oc
rUUP8oUNSwzVWRMPp7PJw8Ip1X5gY6OIjVThlIwbWESL+LHxFHyUkoQbsVLnwvyyFvSVkXqk
gEzpowTvIyGwoYhMwPtpW9f8630IybZQ/H9JXeuKfxeOUOLRcydQpbYlfwzZRIGDzxEzJ6BY
kH4iIQwqpydBFiyrSZqUloirSOEsh/8Unx/M63oRgV4OKvo/PFcIk+tuF0l1uUfoewMm/0Eh
PTHMKziCkAAHWRffvjFOoUgbl2NjkDxHL3jLyOpHFFLDmQ5DaIOu4IOt6VS09UzfTJwusT3d
ZIXUVYv9A1LEApyc8JhE30yxLQnebr0HDYiYxZoFX0zfC5yUANh9OOko1SN6O30IaIKfAHh/
ahvNZkREE6DZGY8zOcR4U+2vrirenC4xAV6fsy5+l+IYku5jY4qs5swpBrb2YCDEyq2IufS0
5+9bg031c4ffxe3FfkFpw0UUiWiyyTgR29UKr82JBiv3q9ZkYmk5v06YjrYlR7nmhLpx7zaH
QT/W1/lrd6sFieOnWzGJ499sUS70ETqJQ17fbFEYXDGJ41s4J99sUUORD8YKcuiioD7zYv3C
fn324ITfbFEu9M42PvNetTZ6Cfy0UMshuA5Wo1BpU0vsOtNEK7jrjhjPMzjsXPck8vCibVE3
R8eWGGB7KfVflF3KTmWD21+BtoKrF95dbtsMWrER6/qD9cLfkNguSfh0zl46ywdfnnoUvwUH
ElxpDX01P/FkuPkem/0Ccg3DyEj8P2JA9ZQ0sB3rI6nYRAATJbTJDgM+8HnyCxMltOghYT7w
DPwNPvDNPRG3A4OJ1KcnVj16zPILe+p/lhN/SSl/m4cnbrF1CgEhR7hHsXvs6KtvxWbXAxxt
DbeyHzKjWMjpVzheZgWJhd9sm68JZiSqQzsl0Gs/P1n5UIHGAyOLaqQkjVPETEwDXMUFeKlc
xbpjwlzFumPCXMW6Y8LtqzsjR8WNYj1U5UIle0JUAM5F1quOGeS4bbUeqqa/D8nD

/
--------------------------------------------------------
--  DDL for Package Body PCKG_PLOG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "PCKG_PLOG" 
IS
    -------------------------------------------------------------------
    --
    --  Nom package        : pckg_PLOG
    --
    --  Objectif           : plog code
    --
    --  Version            : 3.0
    -------------------------------------------------------------------
    -- see package spec for history
    -------------------------------------------------------------------


    -------------------------------------------------------------------
    -- Variable global priv? au package
    -------------------------------------------------------------------
    /*
     * Copyright (C) LOG4PLSQL project team. All rights reserved.
     *
     * This software is published under the terms of the The LOG4PLSQL
     * Software License, a copy of which has been included with this
     * distribution in the LICENSE.txt file.
     * see: <http://log4plsql.sourceforge.net>  */

    -------------------------------------------------------------------

    LOG4PLSQL_VERSION   VARCHAR2(200) := '3.1.2.3';


    -------------------------------------------------------------------
    -- Code priv? au package
    -------------------------------------------------------------------
    -------------------------------------------------------------------

    --------------------------------------------------------------------
    FUNCTION GETNEXTID(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                 )
        RETURN DBG_TLOG.ID%TYPE
    IS
        TEMP   NUMBER;
    BEGIN
        SELECT   SLOG.NEXTVAL INTO TEMP FROM DUAL;

        RETURN TEMP;
    END GETNEXTID;


    ----------------------------------------------------------------------
    --function instrLast(ch1 varchar2, ch2 varchar2) return number
    --is
    --ret number := 0;
    --begin
    --    FOR i IN REVERSE 0..length(Ch1) LOOP
    --        if instr(substr(ch1,i),ch2) > 0 then
    --           return i;
    --        end if;
    --    end loop;
    --    return ret;
    --end;

    --------------------------------------------------------------------
    FUNCTION CALLEURNAME
        RETURN VARCHAR2
    IS
        ENDOFLINE    CONSTANT CHAR(1) := CHR(10);
        ENDOFFIELD   CONSTANT CHAR(1) := CHR(32);
        NBRLINE      NUMBER;
        PTFINLIGNE   NUMBER;
        PTDEBLIGNE   NUMBER;
        PTDEBCODE    NUMBER;
        PT1          NUMBER;
        CPT          NUMBER;
        ALLLINES     VARCHAR2(4000);
        RESULTAT     VARCHAR2(4000);
        LINE         VARCHAR2(4000);
        USERCODE     VARCHAR2(4000);
        MYNAME       VARCHAR2(2000) := '.PCKG_PLOG';
    BEGIN
        ALLLINES := DBMS_UTILITY.FORMAT_CALL_STACK;
        CPT := 2;
        PTFINLIGNE := LENGTH(ALLLINES);
        PTDEBLIGNE := PTFINLIGNE;

        WHILE PTFINLIGNE > 0
          AND PTDEBLIGNE > 83
        LOOP
            PTDEBLIGNE :=
                INSTR(ALLLINES
                    , ENDOFLINE
                    , -1
                    , CPT)
                + 1;
            CPT := CPT + 1;
            -- traite ligne
            LINE := SUBSTR(ALLLINES, PTDEBLIGNE, PTFINLIGNE - PTDEBLIGNE);
            PTDEBCODE :=
                INSTR(LINE
                    , ENDOFFIELD
                    , -1
                    , 1);
            USERCODE := SUBSTR(LINE, PTDEBCODE + 1);

            IF INSTR(USERCODE, MYNAME) = 0
            THEN
                IF CPT > 3
                THEN
                    RESULTAT := RESULTAT || '.';
                END IF;

                RESULTAT := RESULTAT || USERCODE;
            END IF;

            PTFINLIGNE := PTDEBLIGNE - 1;
        END LOOP;

        RETURN RESULTAT;
    END CALLEURNAME;


    --------------------------------------------------------------------
    FUNCTION GETDEFAULTCONTEXT
        -- Cette fonction est priv?, Elle retourne le contexte par default
        -- quand il n'est pas pr?ciss?
        RETURN LOG_CTX
    IS
        NEWCTX     LOG_CTX;
        LSECTION   DBG_TLOG.LSECTION%TYPE;
    BEGIN
        LSECTION := CALLEURNAME;
        NEWCTX := INIT(PSECTION => LSECTION);
        RETURN NEWCTX;
    END GETDEFAULTCONTEXT;



    --------------------------------------------------------------------
    PROCEDURE CHECKANDINITCTX(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                        )
    IS
        LSECTION   DBG_TLOG.LSECTION%TYPE;
    BEGIN
        IF PCTX.ISDEFAULTINIT = FALSE
        THEN
            LSECTION := CALLEURNAME;
            PCTX := INIT(PSECTION => LSECTION);
        END IF;
    END;



    --------------------------------------------------------------------
    PROCEDURE ADDROW(PID IN DBG_TLOG.ID%TYPE
                   , PLDATE IN DBG_TLOG.LDATE%TYPE
                   , PLHSECS IN DBG_TLOG.LHSECS%TYPE
                   , PLLEVEL IN DBG_TLOG.LLEVEL%TYPE
                   , PLSECTION IN DBG_TLOG.LSECTION%TYPE
                   , PLUSER IN DBG_TLOG.LUSER%TYPE
                   , PLTEXTE IN DBG_TLOG.LTEXTE%TYPE)
    IS
        G_LAST_ERRID   NUMBER(12, 0);
    BEGIN
        INSERT INTO DBG_TLOG(ID
                           , LDATE
                           , LHSECS
                           , LLEVEL
                           , LSECTION
                           , LUSER
                           , LTEXTE)
          VALUES   (PID
                  , PLDATE
                  , PLHSECS
                  , PLLEVEL
                  , PLSECTION
                  , PLUSER
                  , PLTEXTE);

        COMMIT;
    END;

    --------------------------------------------------------------------
    PROCEDURE ADDROWAUTONOMOUS(PID IN DBG_TLOG.ID%TYPE
                             , PLDATE IN DBG_TLOG.LDATE%TYPE
                             , PLHSECS IN DBG_TLOG.LHSECS%TYPE
                             , PLLEVEL IN DBG_TLOG.LLEVEL%TYPE
                             , PLSECTION IN DBG_TLOG.LSECTION%TYPE
                             , PLUSER IN DBG_TLOG.LUSER%TYPE
                             , PLTEXTE IN DBG_TLOG.LTEXTE%TYPE)
    IS
        PRAGMA AUTONOMOUS_TRANSACTION;
    BEGIN
        ADDROW(PID         => PID
             , PLDATE      => PLDATE
             , PLHSECS     => PLHSECS
             , PLLEVEL     => PLLEVEL
             , PLSECTION   => PLSECTION
             , PLUSER      => PLUSER
             , PLTEXTE     => PLTEXTE);
        COMMIT;
    EXCEPTION
        WHEN OTHERS
        THEN
            PCKG_PLOG.ERROR;
            ROLLBACK;
            RAISE;
    END;

    --------------------------------------------------------------------
    PROCEDURE LOG -- procedure priv? pour int?grer les donn?es dans la table
                  -- RAISE : -20503 'error DBMS_PIPE.send_message.
    (PCTX IN OUT NOCOPY LOG_CTX
   , -- Context
    PID IN         DBG_TLOG.ID%TYPE
   , PLDATE IN     DBG_TLOG.LDATE%TYPE
   , PLHSECS IN    DBG_TLOG.LHSECS%TYPE
   , PLLEVEL IN    DBG_TLOG.LLEVEL%TYPE
   , PLSECTION IN  DBG_TLOG.LSECTION%TYPE
   , PLUSER IN     DBG_TLOG.LUSER%TYPE
   , PLTEXTE IN    DBG_TLOG.LTEXTE%TYPE)
    IS
        RET       NUMBER;
        LLTEXTE   DBG_TLOG.LTEXTE%TYPE;
        PT        NUMBER;
    BEGIN
        IF PCTX.ISDEFAULTINIT = FALSE
        THEN
            PCKG_PLOG.ERROR('please is necessary to use pckg_plog.init for yours contexte.');
        END IF;

        IF PLTEXTE IS NULL
        THEN
            LLTEXTE := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
        ELSE
            BEGIN
                LLTEXTE := PLTEXTE;
            EXCEPTION
                WHEN VALUE_ERROR
                THEN
                    ASSERT(PCTX, LENGTH(PLTEXTE) <= 2000, 'Log Message id:' || PID || ' too long. ');
                    LLTEXTE := SUBSTR(PLTEXTE, 0, 2000);
                WHEN OTHERS
                THEN
                    PCKG_PLOG.FATAL();
            END;
        END IF;

        IF PCTX.USE_LOGTABLE = TRUE
        THEN
            IF PCTX.USE_OUT_TRANS = FALSE
            THEN
                ADDROW(PID         => PID
                     , PLDATE      => PLDATE
                     , PLHSECS     => PLHSECS
                     , PLLEVEL     => PLLEVEL
                     , PLSECTION   => PLSECTION
                     , PLUSER      => PLUSER
                     , PLTEXTE     => LLTEXTE);
            ELSE
                ADDROWAUTONOMOUS(PID         => PID
                               , PLDATE      => PLDATE
                               , PLHSECS     => PLHSECS
                               , PLLEVEL     => PLLEVEL
                               , PLSECTION   => PLSECTION
                               , PLUSER      => PLUSER
                               , PLTEXTE     => LLTEXTE);
            END IF;
        END IF;

        IF PCTX.USE_LOG4J = TRUE
        THEN
            DBMS_PIPE.PACK_MESSAGE(PID); -- SEQUENTIAL ID
            DBMS_PIPE.PACK_MESSAGE(PLDATE); -- TIMESTAMP OF LOG STATEMENT
            DBMS_PIPE.PACK_MESSAGE(MOD(PLHSECS, 100)); -- HUNDREDTHS OF SECONDS FOR TIMESTAMP
            DBMS_PIPE.PACK_MESSAGE(PLLEVEL); -- LOG LEVEL
            DBMS_PIPE.PACK_MESSAGE(PLSECTION); -- LOG SECTION - ANALOGUE TO LOG4J Logger NAME
            DBMS_PIPE.PACK_MESSAGE(LLTEXTE); -- LOG MESSAGE
            DBMS_PIPE.PACK_MESSAGE(PLUSER); -- CALLING USER
            DBMS_PIPE.PACK_MESSAGE('SAVE_IN_LOG'); -- MESSAGE TYPE?
            --DBMS_PIPE.pack_message(PMDC.getKeyString);      -- MAPPED DOMAIN CONTEXT KEYS FOR LOG4J
            --DBMS_PIPE.pack_message(PMDC.getValueString);    -- MAPPED DOMAIN CONTEXT VALUES FOR LOG4J
            --DBMS_PIPE.pack_message(PMDC.getSeparator);      -- MAPPED DOMAIN CONTEXT SEPARATOR FOR LOG4J

            --   ret := DBMS_PIPE.send_message(pCTX.DBMS_PIPE_NAME);
            --   IF RET <> 0 then
            --        raise_application_error(ERR_CODE_DBMS_PIPE, MES_CODE_DBMS_PIPE || RET);
            --   END IF;

            RET := DBMS_PIPE.SEND_MESSAGE(PCTX.DBMS_PIPE_NAME, 30, 1000000000);

            IF RET = 1
            THEN
                RET := DBMS_PIPE.SEND_MESSAGE(PCTX.DBMS_PIPE_NAME, 30, 1000000000);

                IF RET = 1
                THEN
                    DBMS_PIPE.PURGE(PCTX.DBMS_PIPE_NAME);
                ELSIF RET <> 0
                THEN
                    RAISE_APPLICATION_ERROR(ERR_CODE_DBMS_PIPE, MES_CODE_DBMS_PIPE || RET);
                END IF;
            END IF;
        END IF;

/* <DBMS_SYSTEM REQUIRED> -- execution on sys.DBMS_SYSTEM package is required, uncomment if you've this right.

        IF PCTX.USE_ALERT = TRUE
        THEN
            SYS.DBMS_SYSTEM.KSDWRT(
                2
              ,    'PCKG_PLOG:'
                || TO_CHAR(PLDATE, 'YYYY-MM-DD HH24:MI:SS')
                || ':'
                || LTRIM(TO_CHAR(MOD(PLHSECS, 100), '09'))
                || ' user: '
                || PLUSER
                || ' level: '
                || GETLEVELINTEXT(PLLEVEL)
                || ' logid: '
                || PID
                || ' '
                || PLSECTION);
            SYS.DBMS_SYSTEM.KSDWRT(2, SUBSTR(LLTEXTE, 0, 1000));

            IF (LENGTH(LLTEXTE) >= 1000)
            THEN
                SYS.DBMS_SYSTEM.KSDWRT(2, SUBSTR(LLTEXTE, 1000));
            END IF;
        END IF;

        IF PCTX.USE_TRACE = TRUE
        THEN
            SYS.DBMS_SYSTEM.KSDWRT(
                1
              ,    'PCKG_PLOG:'
                || TO_CHAR(PLDATE, 'YYYY-MM-DD HH24:MI:SS')
                || ':'
                || LTRIM(TO_CHAR(MOD(PLHSECS, 100), '09'))
                || ' user: '
                || PLUSER
                || ' level: '
                || GETLEVELINTEXT(PLLEVEL)
                || ' logid: '
                || PID
                || ' '
                || PLSECTION);
            SYS.DBMS_SYSTEM.KSDWRT(1, SUBSTR(LLTEXTE, 0, 1000));

            IF (LENGTH(LLTEXTE) >= 1000)
            THEN
                SYS.DBMS_SYSTEM.KSDWRT(1, SUBSTR(LLTEXTE, 1000));
            END IF;
        END IF;
</DBMS_SYSTEM REQUIRED>*/

        IF PCTX.USE_DBMS_OUTPUT = TRUE
        THEN
            DECLARE
                PT         NUMBER;
                HDR        VARCHAR2(4000);
                HDR_LEN    PLS_INTEGER;
                LINE_LEN   PLS_INTEGER;
                WRAP       NUMBER := PCTX.DBMS_OUTPUT_WRAP; --length to wrap long text.
            BEGIN
                HDR := TO_CHAR(PLDATE, 'HH24:MI:SS') || ':' || LTRIM(TO_CHAR(MOD(PLHSECS, 100), '09')) || '-' || GETLEVELINTEXT(PLLEVEL) || '-' || PLSECTION || '  ';
                HDR_LEN := LENGTH(HDR);
                LINE_LEN := WRAP - HDR_LEN;
                SYS.DBMS_OUTPUT.PUT(HDR);
                PT := 1;

                WHILE PT <= LENGTH(LLTEXTE)
                LOOP
                    IF PT = 1
                    THEN
                        SYS.DBMS_OUTPUT.PUT_LINE(SUBSTR(LLTEXTE, PT, LINE_LEN));
                    ELSE
                        SYS.DBMS_OUTPUT.PUT_LINE(LPAD(' ', HDR_LEN) || SUBSTR(LLTEXTE, PT, LINE_LEN));
                    END IF;

                    PT := PT + LINE_LEN;
                END LOOP;
            END;
        END IF;
    END LOG;



    -------------------------------------------------------------------
    -------------------------------------------------------------------
    -- Code public du package
    -------------------------------------------------------------------
    -------------------------------------------------------------------


    --------------------------------------------------------------------
    FUNCTION INIT -- initialisation du contexte
                 (PSECTION IN DBG_TLOG.LSECTION%TYPE DEFAULT NULL
                , -- log section
                 PLEVEL IN DBG_TLOG.LLEVEL%TYPE DEFAULT PCKG_PLOGPARAM.DEFAULT_LEVEL
                , -- log level (Use only for debug)
                 PLOG4J IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_USE_LOG4J
                , -- if true the log is send to log4j
                 PLOGTABLE IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_LOG_TABLE
                , -- if true the log is insert into tlog
                 POUT_TRANS IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_LOG_OUT_TRANS
                , -- if true the log is in transactional log
                 PALERT IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_LOG_ALERT
                , -- if true the log is write in alert.log
                 PTRACE IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_LOG_TRACE
                , -- if true the log is write in trace file
                 PDBMS_OUTPUT IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_DBMS_OUTPUT
                , -- if true the log is send in standard output (DBMS_OUTPUT.PUT_LINE)
                 PDBMS_PIPE_NAME IN VARCHAR2 DEFAULT PCKG_PLOGPARAM.DEFAULT_DBMS_PIPE_NAME
                , -- name of pipe to log to for Log4J output
                 PDBMS_OUTPUT_WRAP IN PLS_INTEGER DEFAULT PCKG_PLOGPARAM.DEFAULT_DBMS_OUTPUT_LINE_WRAP -- length to wrap output to when using DBMS_OUTPUT
                                                                                                      )
        RETURN LOG_CTX
    IS
        PCTX   LOG_CTX;
    BEGIN
        PCTX.ISDEFAULTINIT := TRUE;
        PCTX.LSECTION := NVL(PSECTION, CALLEURNAME);
        PCTX.INIT_LSECTION := PSECTION;
        PCTX.LLEVEL := PLEVEL;
        PCTX.INIT_LLEVEL := PLEVEL;
        PCTX.USE_LOG4J := PLOG4J;
        PCTX.USE_OUT_TRANS := POUT_TRANS;
        PCTX.USE_LOGTABLE := PLOGTABLE;
        PCTX.USE_ALERT := PALERT;
        PCTX.USE_TRACE := PTRACE;
        PCTX.USE_DBMS_OUTPUT := PDBMS_OUTPUT;
        PCTX.DBMS_PIPE_NAME := PDBMS_PIPE_NAME;
        PCTX.DBMS_OUTPUT_WRAP := PDBMS_OUTPUT_WRAP;

        RETURN PCTX;
    END INIT;

    --------------------------------------------------------------------
    PROCEDURE SETBEGINSECTION -- initialisation d'un debut de niveaux hierarchique de log
                             (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                         PSECTION IN DBG_TLOG.LSECTION%TYPE -- Texte du log
                                                                                           )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        PCTX.LSECTION := PCTX.LSECTION || PCKG_PLOGPARAM.DEFAULT_SECTION_SEP || PSECTION;
    END SETBEGINSECTION;

    --------------------------------------------------------------------
    FUNCTION GETSECTION -- renvoie la section en cours
                       (PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                  )
        RETURN DBG_TLOG.LSECTION%TYPE
    IS
    BEGIN
        RETURN PCTX.LSECTION;
    END GETSECTION;


    --------------------------------------------------------------------
    FUNCTION GETSECTION
        -- renvoie la section en cours
        RETURN DBG_TLOG.LSECTION%TYPE
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETSECTION(PCTX => GENERIQUECTX);
    END GETSECTION;


    --------------------------------------------------------------------
    PROCEDURE SETENDSECTION -- fin d'un niveau hierarchique de log et dee  tout c'est sup?rieur
                            -- par default [/]
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                PSECTION IN DBG_TLOG.LSECTION%TYPE DEFAULT 'EndAllSection' -- Texte du log
                                                                                          )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);

        IF PSECTION = 'EndAllSection'
        THEN
            PCTX.LSECTION := NVL(PCTX.INIT_LSECTION, CALLEURNAME);
            RETURN;
        END IF;

        PCTX.LSECTION := SUBSTR(PCTX.LSECTION, 1, INSTR(UPPER(PCTX.LSECTION), UPPER(PSECTION), -1) - 2);
    END SETENDSECTION;



    -------------------------------------------------------------------
    PROCEDURE SETTRANSACTIONMODE -- utlisation des log dans ou en dehors des transactions
                                 -- TRUE => Les log sont dans la transaction
                                 -- FALSE => les log sont en dehors de la transaction
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                INTRANSACTION IN BOOLEAN DEFAULT TRUE -- TRUE => Les log sont dans la transaction,
                                                                      -- FALSE => les log sont en dehors de la transaction
    )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        PCTX.USE_OUT_TRANS := INTRANSACTION;
    END SETTRANSACTIONMODE;


    -------------------------------------------------------------------
    FUNCTION GETTRANSACTIONMODE -- TRUE => Les log sont dans la transaction
                                -- FALSE => les log sont en dehors de la transaction
    (PCTX IN OUT NOCOPY LOG_CTX -- Context
                               )
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN PCTX.USE_OUT_TRANS;
    END GETTRANSACTIONMODE;

    -------------------------------------------------------------------
    FUNCTION GETTRANSACTIONMODE
        RETURN BOOLEAN
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETTRANSACTIONMODE(PCTX => GENERIQUECTX);
    END GETTRANSACTIONMODE;


    -------------------------------------------------------------------
    PROCEDURE SETUSE_LOG4JMODE --TRUE => Log is send to USE_LOG4J
                               --FALSE => Log is not send to USE_LOG4J
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                INUSE_LOG4J IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to USE_LOG4J,
                                                                    -- FALSE => Log is not send to USE_LOG4J
    )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        PCTX.USE_LOG4J := INUSE_LOG4J;
    END SETUSE_LOG4JMODE;


    -------------------------------------------------------------------
    FUNCTION GETUSE_LOG4JMODE --TRUE => Log is send to USE_LOG4J
                              --FALSE => Log is not send to USE_LOG4J
    (PCTX IN OUT NOCOPY LOG_CTX -- Context
                               )
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN PCTX.USE_LOG4J;
    END GETUSE_LOG4JMODE;

    -------------------------------------------------------------------
    FUNCTION GETUSE_LOG4JMODE
        RETURN BOOLEAN
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETTRANSACTIONMODE(PCTX => GENERIQUECTX);
    END GETUSE_LOG4JMODE;


    -------------------------------------------------------------------
    PROCEDURE SETLOG_TABLEMODE --TRUE => Log is send to LOG_TABLEMODE
                               --FALSE => Log is not send to LOG_TABLEMODE
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                INLOG_TABLE IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to LOG_TABLEMODE,
                                                                    -- FALSE => Log is not send to LOG_TABLEMODE
    )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        PCTX.USE_LOGTABLE := INLOG_TABLE;
    END SETLOG_TABLEMODE;


    -------------------------------------------------------------------
    FUNCTION GETLOG_TABLEMODE --TRUE => Log is send to LOG_TABLEMODE
                              --FALSE => Log is not send to LOG_TABLEMODE
    (PCTX IN OUT NOCOPY LOG_CTX -- Context
                               )
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN PCTX.USE_LOGTABLE;
    END GETLOG_TABLEMODE;

    -------------------------------------------------------------------
    FUNCTION GETLOG_TABLEMODE
        RETURN BOOLEAN
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETTRANSACTIONMODE(PCTX => GENERIQUECTX);
    END GETLOG_TABLEMODE;



    -------------------------------------------------------------------
    PROCEDURE SETLOG_ALERTMODE --TRUE => Log is send to LOG_ALERT
                               --FALSE => Log is not send to LOG_ALERT
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                INLOG_ALERT IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to LOG_ALERT,
                                                                    -- FALSE => Log is not send to LOG_ALERT
    )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        PCTX.USE_ALERT := INLOG_ALERT;
    END SETLOG_ALERTMODE;


    -------------------------------------------------------------------
    FUNCTION GETLOG_ALERTMODE --TRUE => Log is send to LOG_ALERT
                              --FALSE => Log is not send to LOG_ALERT
    (PCTX IN OUT NOCOPY LOG_CTX -- Context
                               )
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN PCTX.USE_ALERT;
    END GETLOG_ALERTMODE;

    -------------------------------------------------------------------
    FUNCTION GETLOG_ALERTMODE
        RETURN BOOLEAN
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETTRANSACTIONMODE(PCTX => GENERIQUECTX);
    END GETLOG_ALERTMODE;



    -------------------------------------------------------------------
    PROCEDURE SETLOG_TRACEMODE --TRUE => Log is send to LOG_TRACE
                               --FALSE => Log is not send to LOG_TRACE
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                INLOG_TRACE IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to LOG_TRACE,
                                                                    -- FALSE => Log is not send to LOG_TRACE
    )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        PCTX.USE_TRACE := INLOG_TRACE;
    END SETLOG_TRACEMODE;


    -------------------------------------------------------------------
    FUNCTION GETLOG_TRACEMODE --TRUE => Log is send to LOG_TRACE
                              --FALSE => Log is not send to LOG_TRACE
    (PCTX IN OUT NOCOPY LOG_CTX -- Context
                               )
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN PCTX.USE_TRACE;
    END GETLOG_TRACEMODE;

    -------------------------------------------------------------------
    FUNCTION GETLOG_TRACEMODE
        RETURN BOOLEAN
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETTRANSACTIONMODE(PCTX => GENERIQUECTX);
    END GETLOG_TRACEMODE;


    -------------------------------------------------------------------
    PROCEDURE SETDBMS_OUTPUTMODE --TRUE => Log is send to DBMS_OUTPUT
                                 --FALSE => Log is not send to DBMS_OUTPUT
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                INDBMS_OUTPUT IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to DBMS_OUTPUT,
                                                                      -- FALSE => Log is not send to DBMS_OUTPUT
    )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        PCTX.USE_DBMS_OUTPUT := INDBMS_OUTPUT;
    END SETDBMS_OUTPUTMODE;


    -------------------------------------------------------------------
    FUNCTION GETDBMS_OUTPUTMODE --TRUE => Log is send to DBMS_OUTPUT
                                --FALSE => Log is not send to DBMS_OUTPUT
    (PCTX IN OUT NOCOPY LOG_CTX -- Context
                               )
        RETURN BOOLEAN
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        RETURN PCTX.USE_DBMS_OUTPUT;
    END GETDBMS_OUTPUTMODE;

    -------------------------------------------------------------------
    FUNCTION GETDBMS_OUTPUTMODE
        RETURN BOOLEAN
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETTRANSACTIONMODE(PCTX => GENERIQUECTX);
    END GETDBMS_OUTPUTMODE;



    -------------------------------------------------------------------
    PROCEDURE SETLEVEL -- il est possible de modifier avec setLevell  dynamiquement le niveau de log
                       -- l'appel de setLevel sans paramettre re-poossitionne le niveaux a celuis specifier
                       -- dans le package.
                       -- erreur possible : -20501, 'Set Level not in LOG predefine constantes'
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                PLEVEL IN DBG_TLOG.LLEVEL%TYPE DEFAULT NOLEVEL -- Level sup?rieur attribuer dynamiquement
                                                                              )
    IS
        NBRL   NUMBER;
    BEGIN
        CHECKANDINITCTX(PCTX);

        IF PLEVEL = NOLEVEL
        THEN
            PCTX.LLEVEL := PCTX.INIT_LLEVEL;
        END IF;

        SELECT   COUNT( * )
          INTO   NBRL
          FROM   DBG_TLOGLEVEL
         WHERE   DBG_TLOGLEVEL.LLEVEL = PLEVEL;

        IF NBRL > 0
        THEN
            PCTX.LLEVEL := PLEVEL;
        ELSE
            RAISE_APPLICATION_ERROR(-20501, 'SetLevel (' || PLEVEL || ') not in TLOGLEVEL table');
        END IF;
    EXCEPTION
        WHEN OTHERS
        THEN
            PCKG_PLOG.ERROR;
    END SETLEVEL;

    PROCEDURE SETLEVEL -- il est possible de modifier avec setLevell  dynamiquement le niveau de log
                       -- l'appel de setLevel sans paramettre re-poossitionne le niveaux a celuis specifier
                       -- dans le package.
                       -- erreur possible : -20501, 'Set Level not in LOG predefine constantes'
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                PLEVEL IN DBG_TLOGLEVEL.LCODE%TYPE -- Level sup?rieur attribuer dynamiquement
                                                                  )
    IS
        NBRL   NUMBER;
    BEGIN
        SETLEVEL(PCTX, GETTEXTINLEVEL(PLEVEL));
    END SETLEVEL;


    -------------------------------------------------------------------
    FUNCTION GETLEVEL -- Retourne le level courant
                     (PCTX IN LOG_CTX -- Context
                                     )
        RETURN DBG_TLOG.LLEVEL%TYPE
    IS
    BEGIN
        RETURN PCTX.LLEVEL;
    END GETLEVEL;

    FUNCTION GETLEVEL
        RETURN DBG_TLOG.LLEVEL%TYPE
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETLEVEL(PCTX => GENERIQUECTX);
    END GETLEVEL;


    -------------------------------------------------------------------------
    FUNCTION ISLEVELENABLED -- fonction outil appeler par les is[Debug|Info|Warn|Error]Enabled
                           (PCTX IN LOG_CTX, -- Context
                                            PLEVEL IN DBG_TLOG.LLEVEL%TYPE -- Level a tester
                                                                          )
        RETURN BOOLEAN
    IS
    BEGIN
        IF GETLEVEL(PCTX) >= PLEVEL
        THEN
            RETURN TRUE;
        ELSE
            RETURN FALSE;
        END IF;
    END ISLEVELENABLED;

    FUNCTION ISLEVELENABLED(PLEVEL IN DBG_TLOG.LLEVEL%TYPE -- Level a tester
                                                          )
        RETURN BOOLEAN
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN ISLEVELENABLED(PCTX => GENERIQUECTX, PLEVEL => PLEVEL);
    END ISLEVELENABLED;

    -------------------------------------------------------------------
    FUNCTION ISFATALENABLED
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(GETTEXTINLEVEL('FATAL'));
    END;

    FUNCTION ISERRORENABLED
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(GETTEXTINLEVEL('ERROR'));
    END;

    FUNCTION ISWARNENABLED
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(GETTEXTINLEVEL('WARN'));
    END;

    FUNCTION ISINFOENABLED
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(GETTEXTINLEVEL('INFO'));
    END;

    FUNCTION ISDEBUGENABLED
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(GETTEXTINLEVEL('DEBUG'));
    END;

    FUNCTION ISFATALENABLED(PCTX IN LOG_CTX)
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(PCTX, GETTEXTINLEVEL('FATAL'));
    END;

    FUNCTION ISERRORENABLED(PCTX IN LOG_CTX)
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(PCTX, GETTEXTINLEVEL('ERROR'));
    END;

    FUNCTION ISWARNENABLED(PCTX IN LOG_CTX)
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(PCTX, GETTEXTINLEVEL('WARN'));
    END;

    FUNCTION ISINFOENABLED(PCTX IN LOG_CTX)
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(PCTX, GETTEXTINLEVEL('INFO'));
    END;

    FUNCTION ISDEBUGENABLED(PCTX IN LOG_CTX)
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(PCTX, GETTEXTINLEVEL('DEBUG'));
    END;



    --------------------------------------------------------------------
    PROCEDURE PURGE
    --  Purge de la log
    IS
        TEMPLOGCTX   PCKG_PLOG.LOG_CTX;
    BEGIN
        PURGE(TEMPLOGCTX);
    END PURGE;

    --------------------------------------------------------------------
    PROCEDURE PURGE --  Purge de la log
                   (PCTX IN OUT NOCOPY LOG_CTX -- Context
                                              )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);

        EXECUTE IMMEDIATE ('truncate table dbg_tlog');

        PURGE(PCTX, SYSDATE + 1);
    END PURGE;


    --------------------------------------------------------------------
    PROCEDURE PURGE --  Purge de la log avec date max
                   (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                               DATEMAX IN DATE -- Tout les enregistrements supperieur a
                                                               -- la date sont purg?
    )
    IS
        TEMPLOGCTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.INIT(PSECTION => 'pckg_plog.purge', PLEVEL => PCKG_PLOG.LINFO);
    BEGIN
        CHECKANDINITCTX(PCTX);

        DELETE FROM   DBG_TLOG
              WHERE   LDATE < DATEMAX;

        INFO(TEMPLOGCTX, 'Purge by user:' || USER);
    END PURGE;



    --------------------------------------------------------------------
    PROCEDURE LOG(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                             PLEVEL IN DBG_TLOG.LLEVEL%TYPE, -- log level
                                                                            PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT DEFAULTEXTMESS -- log text
                                                                                                                                 )
    IS
        LID         DBG_TLOG.ID%TYPE;
        LLSECTION   DBG_TLOG.LSECTION%TYPE := GETSECTION(PCTX);
        LLHSECS     DBG_TLOG.LHSECS%TYPE;
        M           VARCHAR2(100);
    BEGIN
        CHECKANDINITCTX(PCTX);

        IF PLEVEL > GETLEVEL(PCTX)
        THEN
            RETURN;
        END IF;

        LID := GETNEXTID(PCTX);

        LOG(PCTX        => PCTX
          , PID         => LID
          , PLDATE      => SYSDATE
          , PLHSECS     => DBMS_UTILITY.GET_TIME
          , PLLEVEL     => PLEVEL
          , PLSECTION   => LLSECTION
          , PLUSER      => USER
          , PLTEXTE     => PTEXTE);
    END LOG;

    PROCEDURE LOG(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                             PLEVEL IN DBG_TLOGLEVEL.LCODE%TYPE, -- log level
                                                                                PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT DEFAULTEXTMESS -- log text
                                                                                                                                     )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL(PLEVEL), PCTX => PCTX, PTEXTE => PTEXTE);
    END LOG;


    PROCEDURE LOG(PLEVEL IN DBG_TLOG.LLEVEL%TYPE, -- log level
                                                 PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT DEFAULTEXTMESS -- log text
                                                                                                      )
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        LOG(PLEVEL => PLEVEL, PCTX => GENERIQUECTX, PTEXTE => PTEXTE);
    END LOG;

    PROCEDURE LOG(PLEVEL IN DBG_TLOGLEVEL.LCODE%TYPE, -- log level
                                                     PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT DEFAULTEXTMESS -- log text
                                                                                                          )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL(PLEVEL), PTEXTE => PTEXTE);
    END LOG;

    --------------------------------------------------------------------
    PROCEDURE DEBUG(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                               PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                          )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('DEBUG'), PCTX => PCTX, PTEXTE => PTEXTE);
    END DEBUG;

    PROCEDURE DEBUG(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                               )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('DEBUG'), PTEXTE => PTEXTE);
    END DEBUG;

    --------------------------------------------------------------------
    PROCEDURE INFO(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                              PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                         )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('INFO'), PCTX => PCTX, PTEXTE => PTEXTE);
    END INFO;

    PROCEDURE INFO(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                              )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('INFO'), PTEXTE => PTEXTE);
    END INFO;

    --------------------------------------------------------------------
    PROCEDURE WARN(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                              PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                         )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('WARN'), PCTX => PCTX, PTEXTE => PTEXTE);
    END WARN;

    PROCEDURE WARN(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                              )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('WARN'), PTEXTE => PTEXTE);
    END WARN;

    --------------------------------------------------------------------
    PROCEDURE ERROR(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                               PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                          )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('ERROR'), PCTX => PCTX, PTEXTE => PTEXTE);
    END ERROR;

    PROCEDURE ERROR(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                               )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('ERROR'), PTEXTE => PTEXTE);
    END ERROR;

    --------------------------------------------------------------------
    PROCEDURE FATAL(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                               PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                          )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('FATAL'), PCTX => PCTX, PTEXTE => PTEXTE);
    END FATAL;

    PROCEDURE FATAL(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                               )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('FATAL'), PTEXTE => PTEXTE);
    END FATAL;

    --------------------------------------------------------------------
    PROCEDURE ASSERT(PCTX IN OUT NOCOPY LOG_CTX
                   , -- Context
                    PCONDITION IN  BOOLEAN
                   , -- error condition
                    PLOGERRORMESSAGEIFFALSE IN VARCHAR2 DEFAULT 'assert condition error'
                   , -- message if pCondition is true
                    PLOGERRORCODEIFFALSE IN NUMBER DEFAULT -20000
                   , -- error code is pCondition is true range -20000 .. -20999
                    PRAISEEXCEPTIONIFFALSE IN BOOLEAN DEFAULT FALSE
                   , -- if true raise pException_in if pCondition is true
                    PLOGERRORREPLACEERROR IN BOOLEAN DEFAULT FALSE -- TRUE, the error is placed on the stack of previous errors.
                                                                  -- If FALSE (the default), the error replaces all previous errors
                                                                  -- see Oracle Documentation RAISE_APPLICATION_ERROR

                     )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);

        IF NOT ISLEVELENABLED(PCTX, PCKG_PLOGPARAM.DEFAULT_ASSET_LEVEL)
        THEN
            RETURN;
        END IF;

        IF NOT PCONDITION
        THEN
            LOG(PLEVEL => PCKG_PLOGPARAM.DEFAULT_ASSET_LEVEL, PCTX => PCTX, PTEXTE => 'AAS' || PLOGERRORCODEIFFALSE || ': ' || PLOGERRORMESSAGEIFFALSE);

            IF PRAISEEXCEPTIONIFFALSE
            THEN
                RAISE_APPLICATION_ERROR(PLOGERRORCODEIFFALSE, PLOGERRORMESSAGEIFFALSE, PLOGERRORREPLACEERROR);
            END IF;
        END IF;
    END ASSERT;


    PROCEDURE ASSERT(PCONDITION IN BOOLEAN
                   , -- error condition
                    PLOGERRORMESSAGEIFFALSE IN VARCHAR2 DEFAULT 'assert condition error'
                   , -- message if pCondition is true
                    PLOGERRORCODEIFFALSE IN NUMBER DEFAULT -20000
                   , -- error code is pCondition is true range -20000 .. -20999
                    PRAISEEXCEPTIONIFFALSE IN BOOLEAN DEFAULT FALSE
                   , -- if true raise pException_in if pCondition is true
                    PLOGERRORREPLACEERROR IN BOOLEAN DEFAULT FALSE -- TRUE, the error is placed on the stack of previous errors.
                                                                  -- If FALSE (the default), the error replaces all previous errors
                                                                  -- see Oracle Documentation RAISE_APPLICATION_ERROR
                     )
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        ASSERT(PCTX                      => GENERIQUECTX
             , PCONDITION                => PCONDITION
             , PLOGERRORCODEIFFALSE      => PLOGERRORCODEIFFALSE
             , PLOGERRORMESSAGEIFFALSE   => PLOGERRORMESSAGEIFFALSE
             , PRAISEEXCEPTIONIFFALSE    => PRAISEEXCEPTIONIFFALSE
             , PLOGERRORREPLACEERROR     => PLOGERRORREPLACEERROR);
    END ASSERT;

    --------------------------------------------------------------------
    PROCEDURE FULL_CALL_STACK
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        FULL_CALL_STACK(PCTX => GENERIQUECTX);
    END FULL_CALL_STACK;


    PROCEDURE FULL_CALL_STACK(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                        )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        LOG(PLEVEL => PCKG_PLOGPARAM.DEFAULT_FULL_CALL_STACK_LEVEL, PCTX => PCTX, PTEXTE => DBMS_UTILITY.FORMAT_CALL_STACK);
    END FULL_CALL_STACK;

    --------------------------------------------------------------------
    FUNCTION GETLOG4PLSQVERSION
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN LOG4PLSQL_VERSION;
    END GETLOG4PLSQVERSION;

    --------------------------------------------------------------------
    FUNCTION GETLEVELINTEXT(PLEVEL DBG_TLOG.LLEVEL%TYPE DEFAULT PCKG_PLOGPARAM.DEFAULT_LEVEL)
        RETURN VARCHAR2
    IS
        RET   VARCHAR2(1000);
    BEGIN
        SELECT   LCODE
          INTO   RET
          FROM   DBG_TLOGLEVEL
         WHERE   LLEVEL = PLEVEL;

        RETURN RET;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 'UNDEFINED';
    END GETLEVELINTEXT;

    --------------------------------------------------------------------
    FUNCTION GETTEXTINLEVEL(PCODE DBG_TLOGLEVEL.LCODE%TYPE)
        RETURN DBG_TLOG.LLEVEL%TYPE
    IS
        RET   DBG_TLOG.LLEVEL%TYPE;
    BEGIN
        SELECT   LLEVEL
          INTO   RET
          FROM   DBG_TLOGLEVEL
         WHERE   LCODE = PCODE;

        RETURN RET;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN PCKG_PLOGPARAM.DEFAULT_LEVEL;
    END GETTEXTINLEVEL;



    FUNCTION GETDBMS_PIPE_NAME(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                         )
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN PCTX.DBMS_PIPE_NAME;
    END GETDBMS_PIPE_NAME;

    FUNCTION GETDBMS_PIPE_NAME
        RETURN VARCHAR2
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETDBMS_PIPE_NAME(PCTX => GENERIQUECTX);
    END GETDBMS_PIPE_NAME;


    PROCEDURE SETDBMS_PIPE_NAME(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                           INDBMS_PIPE_NAME IN VARCHAR2)
    IS
    BEGIN
        PCTX.DBMS_PIPE_NAME := INDBMS_PIPE_NAME;
    END SETDBMS_PIPE_NAME;

    PROCEDURE SETPROCPARAMS(PROCEDURE_NAME_IN IN SYS.ALL_ARGUMENTS.OBJECT_NAME%TYPE, ALL_ARGUMENTS_IN IN PCKG_PLOG.T_VARCHAR2)
    IS
        IERROR    PLS_INTEGER := 1;
        PLHSECS   DBG_TLOG.LHSECS%TYPE;

        CURSOR C1
        IS
              SELECT   A.ARGUMENT_NAME, A.DATA_TYPE
                FROM   SYS.ALL_ARGUMENTS A
               WHERE   UPPER(A.OBJECT_NAME) = UPPER(PROCEDURE_NAME_IN)
                   AND A.OWNER = C_PCKG_OWNER
                   AND A.DATA_TYPE != 'PL/SQL TABLE'
            ORDER BY   A.POSITION;
    BEGIN
        SELECT   MAX(DBG_TLOG.LHSECS) INTO PLHSECS FROM DBG_TLOG;

        FOR R1 IN ALL_ARGUMENTS_IN.FIRST .. ALL_ARGUMENTS_IN.LAST
        LOOP
            EXIT WHEN IERROR > ALL_ARGUMENTS_IN.COUNT;

            INSERT INTO DBG_TLOG_ATTRS(ERRID
                                              , ATTR_TYPE
                                              , ATTR_NAME
                                              , FMT_TYPE
                                              , CVALUE)
              VALUES   (PLHSECS
                      , 'Arg'
                      , 'ARGUMENT' --R1.ARGUMENT_NAME
                      , PROCEDURE_NAME_IN
                      , ALL_ARGUMENTS_IN(IERROR));

            IERROR := IERROR + 1;
        END LOOP;

        COMMIT;
    END SETPROCPARAMS;
--------------------------------------------------------------------
--------------------------------------------------------------------
END PCKG_PLOG;

/
--------------------------------------------------------
--  DDL for Package Body PCKG_PLOGPARAM
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "PCKG_PLOGPARAM" IS

END pckg_PLOGPARAM;

/
--------------------------------------------------------
--  DDL for Package Body PCKG_PMDC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "PCKG_PMDC" 
AS
    -------------------------------------------------------------------
    --
    --  Nom package        : PMDC
    --
    --  Objectif           : MDC Features
    --
    --  Version            : 1.0
    -------------------------------------------------------------------
    -- see package spec for history
    -------------------------------------------------------------------


    -------------------------------------------------------------------
    -- Variable global priv? au package
    -------------------------------------------------------------------
    /*
     * Copyright (C) LOG4PLSQL project team. All rights reserved.
     *
     * This software is published under the terms of the The LOG4PLSQL
     * Software License, a copy of which has been included with this
     * distribution in the LICENSE.txt file.
     * see: <http://log4plsql.sourceforge.net>  */

    -------------------------------------------------------------------





    GSEPARATOR   CONSTANT VARCHAR2(1) := CHR(29);
    GSEPLENGTH   PLS_INTEGER := LENGTH(GSEPARATOR);

    GKEYS        VARCHAR2(4096) := GSEPARATOR;
    GVALUES      VARCHAR2(4096) := GSEPARATOR;

    --
    FUNCTION GETPOS(PKEY VARCHAR2)
        RETURN PLS_INTEGER
    IS
        CNT   PLS_INTEGER := 0;
        POS   PLS_INTEGER := 0;
        SEP   PLS_INTEGER := 1;
    BEGIN
        IF GKEYS = GSEPARATOR
        THEN
            RETURN 0;
        END IF;

        POS := INSTR(GKEYS, PKEY || GSEPARATOR);

        IF POS = 0
        THEN
            RETURN 0;
        END IF;

        --
        WHILE SEP > 0
          AND SEP <= POS
        LOOP
            CNT := CNT + 1;
            SEP := INSTR(GKEYS, GSEPARATOR, SEP + GSEPLENGTH);
        END LOOP;

        RETURN CNT;
    END GETPOS;

    --
    PROCEDURE PUT(PKEY VARCHAR2, PVALUE VARCHAR2)
    IS
        IDX        PLS_INTEGER := 0;
        POSSTART   PLS_INTEGER := 0;
    BEGIN
        IDX := GETPOS(PKEY);

        IF IDX = 0
        THEN -- new key, add to end
            GKEYS := GKEYS || PKEY || GSEPARATOR;
            GVALUES := GVALUES || PVALUE || GSEPARATOR;
        ELSE -- replace value for existing key
            POSSTART :=
                INSTR(GVALUES
                    , GSEPARATOR
                    , 1
                    , IDX);
            GVALUES :=
                   SUBSTR(GVALUES, 1, POSSTART + (GSEPLENGTH - 1))
                || PVALUE
                || SUBSTR(GVALUES, INSTR(GVALUES
                                       , GSEPARATOR
                                       , POSSTART + GSEPLENGTH
                                       , 1));
        END IF;
    END PUT;

    --
    FUNCTION GET(PKEY VARCHAR2)
        RETURN VARCHAR2
    IS
        IDX      PLS_INTEGER := 0;
        LSTART   PLS_INTEGER := 0;
        LEND     PLS_INTEGER := 0;
    BEGIN
        IDX := GETPOS(PKEY);

        IF IDX = 0
        THEN
            RETURN '';
        END IF;

        --
        LSTART :=
            INSTR(GVALUES
                , GSEPARATOR
                , 1
                , IDX);
        LEND :=
            INSTR(GVALUES
                , GSEPARATOR
                , LSTART + GSEPLENGTH
                , 1);
        RETURN SUBSTR(GVALUES, LSTART + GSEPLENGTH, LEND - LSTART - GSEPLENGTH);
    END GET;

    --
    PROCEDURE REMOVE(PKEY VARCHAR2)
    IS
        IDX      PLS_INTEGER := 0;
        LSTART   PLS_INTEGER := 0;
        LEND     PLS_INTEGER := 0;
    BEGIN
        IDX := GETPOS(PKEY);

        IF IDX = 0
        THEN
            RETURN;
        END IF; -- key doesn't exist, nothing to do.

        --
        LSTART :=
            INSTR(GVALUES
                , GSEPARATOR
                , 1
                , IDX);
        LEND :=
            INSTR(GVALUES
                , GSEPARATOR
                , LSTART + GSEPLENGTH
                , 1);
        GVALUES := SUBSTR(GVALUES, 1, LSTART) || SUBSTR(GVALUES, LEND + GSEPLENGTH);
        --
        LSTART :=
            INSTR(GKEYS
                , GSEPARATOR
                , 1
                , IDX);
        LEND :=
            INSTR(GKEYS
                , GSEPARATOR
                , LSTART + GSEPLENGTH
                , 1);
        GKEYS := SUBSTR(GKEYS, 1, LSTART) || SUBSTR(GKEYS, LEND + GSEPLENGTH);
    END REMOVE;

    --
    FUNCTION GETKEYSTRING
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN GKEYS;
    END GETKEYSTRING;

    --
    FUNCTION GETVALUESTRING
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN GVALUES;
    END GETVALUESTRING;

    --
    FUNCTION GETSEPARATOR
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN GSEPARATOR;
    END GETSEPARATOR;
--
END PCKG_PMDC;

/
--------------------------------------------------------
--  DDL for Package Body PCKG_SNFR
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "PCKG_SNFR" wrapped
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
5d28 ed4
81NPiTzps3DsojIJREt2L5wTW14wg8129iAFYJsiTupWnnaibF9w+Kzh8OWmjr7xEU5rhvHe
aJZGcotjOc/AytWVDX3QnTFD9r++DAniEMurnjVm94IDA06D7kd8ugW+S7EEYu/+0xDEMtE8
iL3qCL9AgHQdrxf9gMuf6wTvwgHEZQXGUvFzdgK0FMyr2leZ1keZ8+Q6cMb/1EpyBMnGxubR
h+ge05mvD72Hhs5V4ZDSjAbQh/Gt0c/QJTYC97Z5lsx1OQx2KGdKhqnYghg+jyjBdhZX920F
FEpwr/7m2ME4lxGp4cV2jIZeasMPbl/lVpnNpsTqv1HIFJ91d/ZYmp2QZsj4GjtV+jQudqpH
BiFH05bdDjRH/uGWN23LGRuHjv+NuEtqVqMpOB6WLGXxjztgSCpqsEkXILDHy/ozc0dMCQuj
6dPTA8E7LDsXoSvzj8zVoEfHQ4HytxrCrVj9dsuK9h4FaxiA8prkNXD/9O3bx34P+0ziykhj
0z9AhHgMrNx9fJL6OeppqD4OPtgf4kRRI4M/kZhY9kme/VHqQlBl56DpTRSK4Jr4qQt6dHvU
Itg5E+GUAt2dzRIkBXfPd49XcV5yq4WeY1TjX6DdJkOssDa6NVjedoZ8+uGWWWz6512cBLRQ
dYi0tzDuKns9kwM+Z28/GLUTD6qtXRGs+c7WknsNuIsepcdlCuIr83D5enHDsxO/zmYWH7lm
QiFDEpAsUMEKcz2qm4S8qnV6tgu2oh/PD1qwVJDHh6wQilAOuhPYqBF8081YmL4Y7/zf3NP4
Q3OLi679fMFAEQQORAYoYKgjEV03ublkSFDXlBYzJ7/Wm1WwBUxBVRk0S25uzX72xp+mr+sX
s93A/xcNtyZG6saybU5g1h+MuGfA4encx49COOdr/noGNE1AItCnha0gpAPMtEVdyIi97T2e
xo4mpfFEj//lD9Y8C+HdvUq94wtQwo1Q3aS0wMU3lCza9YF9bJ23oxq2hHythGgpzDwfEP+/
fZLZ+e4/tWUbPEJ9+zMT6zVJTJnCIiC6v9KA9Db84MbERAisqet1on9RWyQAREYScVEbrWlY
xVSDblD1fqwm34TDimJrxdVyH8JXNb3tAqP4P4FzvRUiDmFs4bVZ9y6Dv/lWH3ukdzQRjcMt
Gh1QxyveXihrPeWe1ulS0V2RWU9/hz6pbU0ZXd+Z1/pplTe0AufCNNiTOYJm3AvDVmxn4Rme
dMX/xbdRKObyTpuMTaSfFOq8VRDl962qP18PJPeqeBktxcKlFBjPZbotZ6dEnwZ+/FmDXdCy
3BQD03CeFSR5XugrJqCZMlqzWFB71EvRocj6O2hhzESzKXEDeixGiV32mIupDXdF4bHMEyXT
wkUrzAhE+FuVxUj1QPyMdT05bUoqFCs+nHcSFAM2bV3Doguds/Yrbp3NubPBmAqkkv5zQQF5
iNmDdR+pirTvyiBytrGQRK+K0yIRA60S+NGlGfNlWLwanGEmuCgHfjiQRmz7hLQsZ9jQ8t5Z
QGCPT5tqNzlXWuozOrmpP761wpysaC1REqyP1Nhau+w742MhCmWuEcCKRgSXgLFaz3EqRf9h
GzgqIbCr1fDnreiFAEwBUU4rhZPznJrA3rxm5B6fcXplGy2ymi6xvFa0eApbipIp/e3zeCKQ
vOYXIKhDUFL+RaiYN+uS50XWEaeu+dYmq6tMGI02hCZZeA1z+/mfGuOT0QpwmEpUAuP3YBwn
OsuogwwgqX6tI65Wk1x0xUQpot7niu3xnFYf2JmjYPakcHr6WooUMyXGRE790BRA/0kHARPf
2jzlm2isH22g+zLM6OOHyQpugYbmX1X1pLyHW6KR82c59p4XKSkv2EHSLp61KC+5ZMfS2T0d
g1UsUJ3AMMDt+rtIqtf+OrKSYiRLGKG9Mvip4v7EBwUeCto2wU49TLwkDpq7v61q1794OteR
GS38CEml60HbntftOjV55Wgg3M1xqh24aii8MXEtUJFEs/R+Z2KzRC41MKBFJrOPXJzYewM+
OuzyUzIkHbihRRShfqcU5dpvGpNemZAVT1E/ILhb3lV0Bq7XpxB6OqgPSItYXvRg+XKdaWNL
F4cmwy0OhwLJlctZoW2D7Ynk33xHL1nNeay2ozHJMVt/Hv8U2eB1OjTB9ppvUQVLhjKrZ4nv
bKlTviaPgA0PPUzFvAZgDMohl4Mxntw26iBNNE5Bl6iTpXIJyF1PIu3ilFFdkKbcqmE3jkhX
ve+DSy3zhlgoIoM9YCT42fgxnlYVtST4WH3y8zCy/qklKYQXls2EX5MjtpuQs9ZgKCM+KGXl
x+UA2H/BYDWD79qg7lygFXG3P/5o2PxflO9XhBfq5f8xs04i3gS0Xayn8rQDUE+M+9M/dgJS
/H306EpBz4rjA1BSuU1Y2tNguvw7AOFsxzVhEBZ60QCKTZWy7Bo4UL35ddLZrgREg9/wOmsJ
sFovK95V5tRc0YHXcgZNg7Upp92vN+cbGuKu7Ud2Z6mGKtHy3uF451k+bIdTYOhrTUiXCNzH
NLQ2Kh+RdgxCQabygQMCqXbxR24W51F8Hg7Z1H9usst+Q3PxSrxYfqgJR00Wu8xoPKYMx9pZ
ECzuPeU+nuURhccAlWGB57d5XyaxvrfhXyvfXlEG5PF8I4datBQ3NuurpuUXqcXt2sAQw4IT
jCwcBsnHojXr3nZRt5g/WP8t79d0UFKGgNYEfUGE/AYLznrxSBvefXEJcmB1B1418cdjYVrv
/ejVkGsflMf5IqnHJt6yAOnxk91mG+4tq9PrPKugj7fK3wqpTOntRUtS3knJtgTYxchUO3U4
Ugiv5WIlxW4Z5VTCNiRhGiACKKMNsPoBn6XNjrZFDz9Vk9eOWD607L1fKv/g92Vmk/DOjwqF
ymzREJZYFIKkE1n/o4iwum8uj1Lyf7XMAy6BTbLGL43lYh1u0WEdwwyrdzn4rACPUtOMA7+k
NyyTz1b8dRvFsmugJ2xGykKmiss6hQY4Eu6eO1zI7HDQq+sdhZLatRT8OxFrQ7uPYOk6zDFO
9HnQLtBSDT2fXDxQQbUborIw1MZckVG+6iuHcPqakSelYtqEFni4Pk1I8g1Ko8+0xcZq/yrz
EfmBhakzmxIUykPrxpmsHfFWnAqCemRZU8Y8ycjrxlyEvgaQuR+4Un1xp3tdjhYA8Ym3yxWM
1OZiwsExuk64sjiFDIslA/60Hv3VTQtkuwESEFJd+AwFvlCuh19i3bNz1DnU76OpHXH2inRK
Sip7p+WChYFei0yQNcDueQMhkXjnr7nO8rVteLFBRQ0bCjCKZHND+PYL6x4eIx4yhZhjDQfL
Qq/DsVsKeyikYlFRPD53bSFkt00FplVV7Lwr1Mi88LyNN0Y5/1GY8N9f0P+8SmgLUN8giWN8
lLE7/gPQHq+lilCLNnYN6Lkw/MLI4Q5yWUWKqdW9PDxn45++HFx0318cTmkEvSl/8Rw9KlEG
J+4kvE/YfnLG7MQazjYJ+AZkj7vD95KmfNKUcDcVsYEcuFWFPpdLGJyn08O/pNyu3FaOtFax
ym382R6qoJoyxdmlcSkSqG2nKPXTC64hzw5unn1YAFAGX2pbze4d7K9IxjHWUjOP9pAAyITc
mTJ2os4rOfPOLp/QZiHTBFdfZ8nQBIB1pH/IfP0h8WfJ1gfTFO3SX2y4ox6kWS+gg4Ls3Slx
WqbstSysmGWACwcy2KLQpDwIeZctjXuSMc7fQ7SCpAB9/SlYl/BlPGAW+RLwnXMoxf1NBQ==


/
--------------------------------------------------------
--  DDL for Package Body PCKG_TOOLS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "PCKG_TOOLS" wrapped
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
9d98 1103
4Ydk8mPboX4v1o8EEPuH3SPh06cwg81MHiBo39OdZDGdrBa4yIni/p+QcRzBx6Y720zVs9XT
AcZPRnH2aGMRCXHNcboOquQIbPSOoTtdsYNiHzk01bIHXXpXnYjMCblbu+RiNh5WeluaXa+Y
efDCVtGdWOlDdI9y6PIdjgE+tHdsdPwqohcv6NEY01QgGFYmjI6PnVCAuMt9zIm9xnqXRs+e
4+VmRN6N2Dg10JschRfJzqDBE5Y1kB+TabA/4QWEk6NmJOmPd5astp1X9Q96/t0kSjfvsjGt
Cb6QPGysrS8kYrc9m6W+vxTIklJxBx5iQWgbjAdNoJtXBdFpVSG2/SHbMo7ChMwYj29vkX7Z
Si8/42mkRgbKdcg28VFal3mQXFqkwe6bOtWuZrLCLxigYikDhFh8SgkAONBJQZ4rbF54OuiI
qEmvRcE2YNOXRB5j71K1IlsMrsZtt1i9rnNT8ejKn0VABRYqfR0KZyKlYlRYic3yiUegj2Qf
mhDtRabLznO/4Inbjk3MBk//Ua2Ddfyz2CDARsadluKOs3uAvyFwZ0UQatTZ1HwOD2imDE+Z
pKrvK+7osC1dM8fmhMtwuwzAnAoZMittPQa4vnF7x49G7mahb8HOhjBBByg0lbW/8tYDg7BW
q4Q88lG6i9T/TX+S7QqcMHdV3sQUT/erGQMhzvzCup3srQhpi0VIcqPLjuqb3V6l/JVOQyVq
x7hDvCiS7AjOgzkkNnxJNcTNCIo2BlChEggeLitjOBKe7l6CfzCls6TYRvNtUjmukwCxRATP
Rdg8bMVomxBZSnKvnrUtEbQgd0CrJfwQWT/lonl1qOWhgqyZz2dJqPZaJ3iVymCIRE/5s6T+
JZ6budonRqr+ACqriilNHWc0PrOMv5EOMXANxuII9b3z9Jy+D86hKfFkfNieWoZJ+4nGINvj
e1uRdz8tO9N1UfG2hcfzRVH5tzjqPpcTrf/uGXYHSkF2154e3zx5uWh5yodBYzYYcuZa58Qv
LaYrY7MHq41WuBnyi8TaCP3y+JId/Y348P/kG4sQ7wO8kK2afV+uaqH/0kdCHCuURBDQ3xMn
G7hkUMJ5hxUEOaKFSGSjUQIl2T3htTuHncOvIZZjoibB+502qGYrifSeZnXzRo0sClOgjEUB
V96zGrJtby7cgLdvWaNkLXAJAgEjovquwsqh+jFDNjlgjlShFtQ3lxML8lIRb16524kovWUz
2MllZu9DmNQEtdQMI8TnZCXFSmLdwmsVQBgmpva0x1bbwj9OF9ZUZvKzhNjTpwFz37qGWM4W
xcyOidE6MXRRvYvHX+MGxaGVC/jiHt7USGu0hZsZ+J5vwQuirEIt7ZQlM20XZEVzHyjzBSq2
FHowPrmbBwwZDiqRFaK43KNaHZwfnJyBKCRzCrw0kjCBKZv867+cGmLOQyQfJA9p0V1dnNBP
lt0thmlKUWovQc7HGtVZh48xqbU/7c46eKUp2T2uUfX+XmNGLHBpqOdRFDc4ouK6eKyM6WCh
tUX8Ubglpx95jsTMaKcfYjMNh07KS2Q5pPyoS6pFY+rYczJHW8hj0zONi8o/i2cRRv9lLfPz
G6FaW6vHymW8eBmPewBsVHegE3obmx6p/HAKIV/jDhuyLd6CEInwh5LXdtiogKHfg1FVtKRd
Xp/x0KEkdVVfaFkiUoQ6Dd+NroNUIsDHOtuyi4zC8fS++tHuJiJNyF6G7wWj+BrxW4LVnDDZ
HLCk8mq6Zs2t/mlgAV0+XAOlaeVRTWycd9/HMFEVXqQx1lvO7lKu7sboPm3F+hNMzj6J17Nn
xpLDfRyh5qH0lSptS7iY/Rdv7HnMIvHAabzi8UBBxk6u1OrwYEbnzk01zOWtfXhqTa2w2E1b
EzCXaneuufG50jGu0zvHEVkKfQ9F4zFPp+MtjPCrAIzTF3Janm4iYFdF6a6E5YuekIjVUs7J
ye2HIZ8+O3Wr2TzwkAUzg3BodfKhBNSIV5M4pZKBAWnCC6L8aH+5HJ+cKdGCFmUG37X4zoax
mdZOaJp0Acu2dt66Z+RkohiA15StMGaRr+xK3/5cl8KcwHmjSOvAEj6xkvCBExOnA1QNNQ+v
gxr7r0yxPjhV2EAq7eMyc8U8KtlUseULVU3IKr7xbLIXfqgeYeVUaJ9+iNmnLX6I2act7M+a
gDctCSriaZR0XOX5FALFPmukDjSaJXLcPQcdlW4tDW5QPMC5wqfvkzyJ4IW8J6ifutDXfX5g
F8SBVGQth8e3e+dy6oECLyfItGdoi23C0EyhvIa/QgV+s8861Xtyu80rFZ/YzBHEZNBovBmF
X+Rl9qVSeuKsTNs8uq8iQVQ3Q726rf8a7FkbvQ8xe5YmrJspWrhH1eOEw0LLmer81pfUHcbk
cZq/AKSieeNW5g0tPNSjbWli5g2HTmcvJx/sQMrFHi16+p5dni2qeyuUBFXFfkS2s/Z4X72x
8eiHWUUZPRrenLfUh67sIzXeipRj80vqL2G9pv7XBvsL7hEdIxx8wg55rFCs9RGvtEcQtWNw
AIpv6FCY/9gOuIIpSGk/LnDclRarz3EVBV7XvHdmx1DwVL5u3tFr9uwFw5Ws0ZlFfuXgXpQe
KihWXPdRidH29GHeQJgbxCWn4k/BUo7OfuumsgV0MdMx2KChbVDgqMJFsXuYtC1ioNBWoG3m
hlTAaVjQJl1IfOMAPWgQoXVFRZjuNKZORD1ppyc6kJ8U2nzU/hiAHso7tO2Vwt/FBU1+LdiV
wjz2HOenjWq3y9s5TeMeZQoYpjxJk/Rx+ZA4VO6KUQA1f/Dh3ukJFX2HOH6qb2+XSkbColQG
ArKQ0yy2z80+tRw4CqZxHcPJw8+CefejrWqv5crPl+DoPlpePDtJ4ImDPyAmxOkrQ3AQ0cui
W0wxUpmTeaUNr7HmK5mTO7F654WDB8BAgPULorqNKkRsQBfHavUMFGaUC4RTCAoEN2McvOBg
mfdO7eBULQttD4AG6swRskYlJwh/N1TWbIqMOf3O7Ux0ZxhSr7qhJYMAxSWA9KybvMVYkPLn
Xs2L9oTv8+oLjN2KPYOWucKTInzsbyvTpJFv+L6yfWgDDzHun9J6qxdoGrbu+i0lrWrxcQ6D
gPWtGS3euyKa8gGxPR47CsNY8Mwqco0QkdkWkGpBnFDbtY+nY5rYfk3SdAwEpNhFz7MX3wPU
pk7MnEtKrUIobgWfR0pY6rrrezH1bzSUEoIQRQKOKIxNCcC3rYehpOQq8AkI+tHNzZKR3X73
jwziCJuj7426un5YzNUSPDl7kGH/3MGWYi3kU5/Q9auDlYEowIwcXAEH9IoGI8Zt1bZTTKNj
11PDG8QDS8DWHIcz28tJVuW3Qpnavs6zGSOrjdLeJq1vWVosgiWndMB6PWYIs03EQjpjETpc
8cgY2hImdfzUO0Mhlut+I7t7geycdYKHHSB8D8sneZFVUj2hbb2iLJ/mtTT/34GIRrtxmwDg
CENgZK3ror2SZ3Ylvc18YiG/43opll/y/X7voW9FRH/qIrQd7kNjW84ggSO+9Yv//posz/nP
pf35VxnE1SD5CVRPjPBKeMvVw4lAPw/l+JpPeu5RQlHfrxeVv/lhZuh7LyFnLBbwee9XJi3r
wS1PYSCTAdRq0DOa8upjTVewvy/ncoP2GA/b0Eg6KjKwMvexQivCSS86gzCWAmf3zwDweufh
jeRY93p0aj5duP5wTWVyaw/Sflz+Z6CnicWdY6QULsKOkKCg1hrxjAShiITeS2oaLQ9Rp891
w+yc9MOGtKsJJ8HsfLSAo3XeGKD7A2tugZwPkPCf6ml7SeAfzDSMN0D2hGpqTLL0VfwTImqq
1i70sh4TvLQ9jqurvMlqzQ3DWf141NUWCKzJ7msgP8uku+cEBd/fa3l2kLJhefAPBVehOf0T
7C2cwx798v84dbm4uq+6RjNdFjgFfJtguKuObsV4pIyHcSU0UWdfwU3+Ngxhiwz2lzlTitzE
QbXIuo+ldckQNuXvh14G5mzUA12WcsMHuzgsYM6/xcyBepdetNLk1Lc1wmH5aFYAkQo/u+B+
ccuZylKSaBv63RQ5sxa1yMDjoNJ7nHrfrQVV3H1+BkbhYu0ey/yKpmSvjz4wocALKOROMAeo
ERIEiqZOM90THqWkZWy4eopTED94PY52ZrtMR2m5IqSj28rE6UjPX0kc+3NijBHulzz/KaWR
0GW4TyNFE40+QLNV7FnVRCl72B2dqr3wjR20ekWvMsRmDB25/vLJorQlX/5TLoSYL1AsQ0CG
2HiXx9u/Pkuw99xJ6At5q66ToL737OR216WIened5CwEaJ92

/
