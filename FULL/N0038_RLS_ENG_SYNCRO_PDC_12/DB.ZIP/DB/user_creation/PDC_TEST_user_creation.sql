CREATE USER PDC_TEST
  IDENTIFIED BY PDC_TEST
  DEFAULT TABLESPACE USERS
  TEMPORARY TABLESPACE TEMP;

ALTER USER PDC_TEST QUOTA UNLIMITED ON USERS;


GRANT create session TO PDC_TEST;
GRANT create table TO PDC_TEST;
GRANT create view TO PDC_TEST;
GRANT create any trigger TO PDC_TEST;
GRANT create any procedure TO PDC_TEST;
GRANT create sequence TO PDC_TEST;
GRANT create synonym TO PDC_TEST;
grant execute on sys.dbms_pipe to PDC_TEST;
grant execute on sys.dbms_system to PDC_TEST;
grant execute on sys.dbms_utility to PDC_TEST;
grant execute on sys.dbms_output to PDC_TEST;
