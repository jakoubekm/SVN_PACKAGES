SPOOL 001_Object_structure-PDC_repository.log;
--------------------------------------------------------
--  DDL for Sequence CHANGE_CONTROL_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "CHANGE_CONTROL_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence ERR_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "ERR_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence JOB_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "JOB_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LKP_APPLICATION_APP_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "LKP_APPLICATION_APP_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence MAN_BATCH_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "MAN_BATCH_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence PROC_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PROC_LOG_SEQ"  MINVALUE 1 MAXVALUE 999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  CYCLE ;
--------------------------------------------------------
--  DDL for Sequence SLOG
--------------------------------------------------------

   CREATE SEQUENCE  "SLOG"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  CYCLE ;
--------------------------------------------------------
--  DDL for Sequence STAT_LOG_EVENT_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "STAT_LOG_EVENT_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence STREAM_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "STREAM_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Table CTRL_JOB
--------------------------------------------------------

  CREATE TABLE "CTRL_JOB" 
   (	"JOB_NAME" VARCHAR2(128 BYTE), 
	"STREAM_NAME" VARCHAR2(128 BYTE), 
	"PRIORITY" NUMBER(38,0), 
	"CMD_LINE" VARCHAR2(1024 BYTE), 
	"SRC_SYS_ID" NUMBER(38,0), 
	"PHASE" VARCHAR2(32 BYTE), 
	"TABLE_NAME" VARCHAR2(128 BYTE), 
	"JOB_CATEGORY" VARCHAR2(32 BYTE), 
	"JOB_TYPE" VARCHAR2(32 BYTE), 
	"TOUGHNESS" VARCHAR2(32 BYTE), 
	"CONT_ANYWAY" NUMBER(38,0), 
	"MAX_RUNS" NUMBER(38,0), 
	"ALWAYS_RESTART" NUMBER(38,0), 
	"STATUS_BEGIN" NUMBER(38,0), 
	"WAITING_HR" NUMBER(38,0), 
	"DEADLINE_HR" NUMBER(38,0), 
	"ENGINE_ID" NUMBER(38,0), 
	"JOB_DESC" VARCHAR2(1024 BYTE), 
	"AUTHOR" VARCHAR2(64 BYTE), 
	"NOTE" VARCHAR2(2048 BYTE)
   ) ;

   COMMENT ON COLUMN "CTRL_JOB"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "CTRL_JOB"."STREAM_NAME" IS 'Name of the stream which job belongs to';
   COMMENT ON COLUMN "CTRL_JOB"."PRIORITY" IS 'Priority of the job, less number means higher priority';
   COMMENT ON COLUMN "CTRL_JOB"."CMD_LINE" IS 'Command line of the job';
   COMMENT ON COLUMN "CTRL_JOB"."SRC_SYS_ID" IS 'Source system code which data is processed';
   COMMENT ON COLUMN "CTRL_JOB"."PHASE" IS 'Phase name of DWH transformation';
   COMMENT ON COLUMN "CTRL_JOB"."TABLE_NAME" IS 'Main table name which data is processed';
   COMMENT ON COLUMN "CTRL_JOB"."JOB_CATEGORY" IS 'Category of the job. Used for parallelism control';
   COMMENT ON COLUMN "CTRL_JOB"."JOB_TYPE" IS 'Kind of job';
   COMMENT ON COLUMN "CTRL_JOB"."TOUGHNESS" IS 'Job toughness';
   COMMENT ON COLUMN "CTRL_JOB"."CONT_ANYWAY" IS 'If continue next job execution when job fails';
   COMMENT ON COLUMN "CTRL_JOB"."MAX_RUNS" IS 'Maximum number of job launches without manual restart';
   COMMENT ON COLUMN "CTRL_JOB"."ALWAYS_RESTART" IS 'Do restart in any case';
   COMMENT ON COLUMN "CTRL_JOB"."STATUS_BEGIN" IS 'Force pushed status when job launch';
   COMMENT ON COLUMN "CTRL_JOB"."WAITING_HR" IS 'Minimum number of hours passed from load_date for launch granting';
   COMMENT ON COLUMN "CTRL_JOB"."DEADLINE_HR" IS 'Maximal number of hours passed from load_date when job should be finished';
   COMMENT ON COLUMN "CTRL_JOB"."ENGINE_ID" IS 'Identification of engine which can process the job';
   COMMENT ON COLUMN "CTRL_JOB"."JOB_DESC" IS 'Job description';
   COMMENT ON COLUMN "CTRL_JOB"."AUTHOR" IS 'Author of the job';
   COMMENT ON COLUMN "CTRL_JOB"."NOTE" IS 'Note for job procession';
   COMMENT ON TABLE "CTRL_JOB"  IS 'Job definition';
--------------------------------------------------------
--  DDL for Table CTRL_JOB_DEPENDENCY
--------------------------------------------------------

  CREATE TABLE "CTRL_JOB_DEPENDENCY" 
   (	"JOB_NAME" VARCHAR2(128 BYTE), 
	"PARENT_JOB_NAME" VARCHAR2(128 BYTE), 
	"REL_TYPE" CHAR(1 BYTE)
   ) ;

   COMMENT ON COLUMN "CTRL_JOB_DEPENDENCY"."JOB_NAME" IS 'Child job name';
   COMMENT ON COLUMN "CTRL_JOB_DEPENDENCY"."PARENT_JOB_NAME" IS 'Parent job name';
   COMMENT ON COLUMN "CTRL_JOB_DEPENDENCY"."REL_TYPE" IS 'Relation type, NULL for real job dependency';
   COMMENT ON TABLE "CTRL_JOB_DEPENDENCY"  IS 'Dependency between jobs inside the stream';
--------------------------------------------------------
--  DDL for Table CTRL_JOB_STATUS
--------------------------------------------------------

  CREATE TABLE "CTRL_JOB_STATUS" 
   (	"STATUS" NUMBER(38,0), 
	"RUNABLE" VARCHAR2(16 BYTE), 
	"DELAY_MINUTES" NUMBER(38,0), 
	"FINISHED" NUMBER(38,0), 
	"FINISHED_SUCCESSFULLY" NUMBER(38,0), 
	"EXECUTABLE" NUMBER(38,0), 
	"SORTING_ORDER" NUMBER(38,0), 
	"DESCRIPTION" VARCHAR2(1024 BYTE)
   ) ;

   COMMENT ON COLUMN "CTRL_JOB_STATUS"."STATUS" IS 'Status of  the job';
   COMMENT ON COLUMN "CTRL_JOB_STATUS"."RUNABLE" IS 'Status category';
   COMMENT ON COLUMN "CTRL_JOB_STATUS"."DELAY_MINUTES" IS 'Number in minutes how long job has to stay in status before launching';
   COMMENT ON COLUMN "CTRL_JOB_STATUS"."FINISHED" IS 'Is the status final ?';
   COMMENT ON COLUMN "CTRL_JOB_STATUS"."FINISHED_SUCCESSFULLY" IS 'Was the job in this status finished successfully?';
   COMMENT ON COLUMN "CTRL_JOB_STATUS"."EXECUTABLE" IS 'Is status really executable';
   COMMENT ON COLUMN "CTRL_JOB_STATUS"."SORTING_ORDER" IS 'Sorting order (for stream status indication)';
   COMMENT ON COLUMN "CTRL_JOB_STATUS"."DESCRIPTION" IS 'Description of the status';
   COMMENT ON TABLE "CTRL_JOB_STATUS"  IS 'Lookup of job statuses';
--------------------------------------------------------
--  DDL for Table CTRL_JOB_TABLE_REF
--------------------------------------------------------

  CREATE TABLE "CTRL_JOB_TABLE_REF" 
   (	"JOB_NAME" VARCHAR2(128 BYTE), 
	"DATABASE_NAME" VARCHAR2(128 BYTE), 
	"TABLE_NAME" VARCHAR2(128 BYTE), 
	"LOCK_TYPE" CHAR(1 BYTE)
   ) ;

   COMMENT ON COLUMN "CTRL_JOB_TABLE_REF"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "CTRL_JOB_TABLE_REF"."DATABASE_NAME" IS 'Database name which job is working with';
   COMMENT ON COLUMN "CTRL_JOB_TABLE_REF"."TABLE_NAME" IS 'Table name which job is working with';
   COMMENT ON COLUMN "CTRL_JOB_TABLE_REF"."LOCK_TYPE" IS 'Lock type, W=write, R=read';
   COMMENT ON TABLE "CTRL_JOB_TABLE_REF"  IS 'Relation of which job is using which table';
--------------------------------------------------------
--  DDL for Table CTRL_NBD_CAL
--------------------------------------------------------

  CREATE TABLE "CTRL_NBD_CAL" 
   (	"COUNTRY_CD" VARCHAR2(4 BYTE), 
	"NBD_DATE" DATE
   ) ;

   COMMENT ON COLUMN "CTRL_NBD_CAL"."COUNTRY_CD" IS 'Country code';
   COMMENT ON COLUMN "CTRL_NBD_CAL"."NBD_DATE" IS 'National bank holiday date';
   COMMENT ON TABLE "CTRL_NBD_CAL"  IS 'National bank holiday definition';
--------------------------------------------------------
--  DDL for Table CTRL_NEXT_STATUS
--------------------------------------------------------

  CREATE TABLE "CTRL_NEXT_STATUS" 
   (	"STATUS_IN" NUMBER(38,0), 
	"STATUS_OUT" NUMBER(38,0), 
	"SIGNAL" VARCHAR2(16 BYTE), 
	"REQUEST" VARCHAR2(16 BYTE), 
	"LAUNCH" NUMBER(38,0), 
	"CONT_ANYWAY" NUMBER(38,0)
   ) ;

   COMMENT ON COLUMN "CTRL_NEXT_STATUS"."STATUS_IN" IS 'Input status';
   COMMENT ON COLUMN "CTRL_NEXT_STATUS"."STATUS_OUT" IS 'Output status';
   COMMENT ON COLUMN "CTRL_NEXT_STATUS"."SIGNAL" IS 'Signal which changing the status';
   COMMENT ON COLUMN "CTRL_NEXT_STATUS"."REQUEST" IS 'Request for status change';
   COMMENT ON COLUMN "CTRL_NEXT_STATUS"."LAUNCH" IS 'Job is launching';
   COMMENT ON COLUMN "CTRL_NEXT_STATUS"."CONT_ANYWAY" IS 'If continue next job execution when job fails';
   COMMENT ON TABLE "CTRL_NEXT_STATUS"  IS 'Job status transition table';
--------------------------------------------------------
--  DDL for Table CTRL_NOTIFICATION
--------------------------------------------------------

  CREATE TABLE "CTRL_NOTIFICATION" 
   (	"JOB_NAME" VARCHAR2(128 BYTE), 
	"NOTIFICATION_ENABLED" NUMBER(38,0), 
	"NOTIFICATION_CD" NUMBER(38,0), 
	"AVG_DURARION_TOLERANCE" NUMBER(38,0), 
	"AVG_END_TM_TOLERANCE" NUMBER(38,0), 
	"CHECKED_STATUS" NUMBER(38,0), 
	"MAX_N_RUN" NUMBER(38,0), 
	"ERROR_CD" VARCHAR2(16 BYTE), 
	"FINISHED_AFTER_INIT_TOLERANCE" NUMBER(38,0)
   ) ;

   COMMENT ON COLUMN "CTRL_NOTIFICATION"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "CTRL_NOTIFICATION"."NOTIFICATION_ENABLED" IS 'Is notification enabled?';
   COMMENT ON COLUMN "CTRL_NOTIFICATION"."NOTIFICATION_CD" IS 'The channel in which the notification will be processed';
   COMMENT ON COLUMN "CTRL_NOTIFICATION"."AVG_DURARION_TOLERANCE" IS 'Number of second passed before event Job duration overrun is generated';
   COMMENT ON COLUMN "CTRL_NOTIFICATION"."AVG_END_TM_TOLERANCE" IS 'Number of second passed before event Job end overrun is generated';
   COMMENT ON COLUMN "CTRL_NOTIFICATION"."CHECKED_STATUS" IS 'Which job status has to be notified';
   COMMENT ON COLUMN "CTRL_NOTIFICATION"."MAX_N_RUN" IS 'Number of restarts for notification';
   COMMENT ON COLUMN "CTRL_NOTIFICATION"."ERROR_CD" IS 'Error code for event sorting and recommendation generation';
   COMMENT ON COLUMN "CTRL_NOTIFICATION"."FINISHED_AFTER_INIT_TOLERANCE" IS 'Number of minutes passed after init before event job not finish on time.';
   COMMENT ON TABLE "CTRL_NOTIFICATION"  IS 'Job notification settings';
--------------------------------------------------------
--  DDL for Table CTRL_NOTIFICATION_RLTD
--------------------------------------------------------

  CREATE TABLE "CTRL_NOTIFICATION_RLTD" 
   (	"NOTIFICATION_CD" NUMBER(38,0), 
	"NOTIFICATION_TYPE_CD" NUMBER(38,0)
   ) ;

   COMMENT ON COLUMN "CTRL_NOTIFICATION_RLTD"."NOTIFICATION_CD" IS 'Notification code';
   COMMENT ON COLUMN "CTRL_NOTIFICATION_RLTD"."NOTIFICATION_TYPE_CD" IS 'Channel used for notification';
   COMMENT ON TABLE "CTRL_NOTIFICATION_RLTD"  IS 'Transition table for notification type to channel mapping';
--------------------------------------------------------
--  DDL for Table CTRL_NOTIFICATION_SEVERITY
--------------------------------------------------------

  CREATE TABLE "CTRL_NOTIFICATION_SEVERITY" 
   (	"ERROR_CD" VARCHAR2(2048 BYTE), 
	"SEVERITY_LEVEL_CD" NUMBER(38,0)
   ) ;

   COMMENT ON COLUMN "CTRL_NOTIFICATION_SEVERITY"."ERROR_CD" IS 'Error code';
   COMMENT ON COLUMN "CTRL_NOTIFICATION_SEVERITY"."SEVERITY_LEVEL_CD" IS 'Severity level code';
   COMMENT ON TABLE "CTRL_NOTIFICATION_SEVERITY"  IS 'Notification severity definition';
--------------------------------------------------------
--  DDL for Table CTRL_NOTIFICATION_TYPES
--------------------------------------------------------

  CREATE TABLE "CTRL_NOTIFICATION_TYPES" 
   (	"NOTIFICATION_TYPE_CD" NUMBER(38,0), 
	"NOTIFICATION_TYPE_DS" VARCHAR2(1024 BYTE)
   ) ;

   COMMENT ON COLUMN "CTRL_NOTIFICATION_TYPES"."NOTIFICATION_TYPE_CD" IS 'Channel which is used for notification';
   COMMENT ON COLUMN "CTRL_NOTIFICATION_TYPES"."NOTIFICATION_TYPE_DS" IS 'Description of channel';
   COMMENT ON TABLE "CTRL_NOTIFICATION_TYPES"  IS 'Notification type definition';
--------------------------------------------------------
--  DDL for Table CTRL_PARAMETERS
--------------------------------------------------------

  CREATE TABLE "CTRL_PARAMETERS" 
   (	"PARAM_NAME" VARCHAR2(128 BYTE), 
	"PARAM_CD" NUMBER(38,0), 
	"PARAM_TYPE" VARCHAR2(128 BYTE), 
	"PARAM_VAL_INT" NUMBER(38,0), 
	"PARAM_VAL_CHAR" VARCHAR2(1024 BYTE), 
	"PARAM_VAL_DATE" DATE, 
	"PARAM_VAL_TS" TIMESTAMP (8) WITH LOCAL TIME ZONE, 
	"DESCRIPTION" VARCHAR2(1024 BYTE)
   ) ;

   COMMENT ON COLUMN "CTRL_PARAMETERS"."PARAM_NAME" IS 'Parameter name';
   COMMENT ON COLUMN "CTRL_PARAMETERS"."PARAM_CD" IS 'Parameter sequence code, mostly used for engine_id';
   COMMENT ON COLUMN "CTRL_PARAMETERS"."PARAM_TYPE" IS 'Parameter type';
   COMMENT ON COLUMN "CTRL_PARAMETERS"."PARAM_VAL_INT" IS 'Parameter value - number domain';
   COMMENT ON COLUMN "CTRL_PARAMETERS"."PARAM_VAL_CHAR" IS 'Parameter value - char domain';
   COMMENT ON COLUMN "CTRL_PARAMETERS"."PARAM_VAL_DATE" IS 'Parameter value - date domain';
   COMMENT ON COLUMN "CTRL_PARAMETERS"."PARAM_VAL_TS" IS 'Parameter value - timestamp domain';
   COMMENT ON COLUMN "CTRL_PARAMETERS"."DESCRIPTION" IS 'Description of parameter meaning';
   COMMENT ON TABLE "CTRL_PARAMETERS"  IS 'Parameters settings';
--------------------------------------------------------
--  DDL for Table CTRL_SOURCE
--------------------------------------------------------

  CREATE TABLE "CTRL_SOURCE" 
   (	"SOURCE_ID" NUMBER(*,0), 
	"SOURCE_NM" VARCHAR2(128 BYTE), 
	"SOURCE_DESC" VARCHAR2(1024 BYTE), 
	"PHYSICAL_SOURCE" NUMBER(*,0), 
	"HOST" VARCHAR2(64 BYTE), 
	"SCHEMA_NAME" VARCHAR2(256 BYTE), 
	"SNIFFED_DIR" VARCHAR2(256 BYTE), 
	"VALIDATED_DIR" VARCHAR2(256 BYTE), 
	"SNIFFER_JOB_NAME" VARCHAR2(128 BYTE), 
	"DELIVERY_CHECKER_JOB_NAME" VARCHAR2(128 BYTE), 
	"NOTIFICATION_ENABLED" NUMBER(1,0)
   ) ;

   COMMENT ON COLUMN "CTRL_SOURCE"."SOURCE_ID" IS 'Source identification';
   COMMENT ON COLUMN "CTRL_SOURCE"."SOURCE_NM" IS 'Source short name';
   COMMENT ON COLUMN "CTRL_SOURCE"."SOURCE_DESC" IS 'Source description';
   COMMENT ON COLUMN "CTRL_SOURCE"."PHYSICAL_SOURCE" IS 'Source identification number';
   COMMENT ON COLUMN "CTRL_SOURCE"."HOST" IS 'Host';
   COMMENT ON COLUMN "CTRL_SOURCE"."SCHEMA_NAME" IS 'Schema name';
   COMMENT ON COLUMN "CTRL_SOURCE"."SNIFFED_DIR" IS 'Folder where extracts are stored';
   COMMENT ON COLUMN "CTRL_SOURCE"."VALIDATED_DIR" IS 'Folder where validated extracts are stored';
   COMMENT ON COLUMN "CTRL_SOURCE"."SNIFFER_JOB_NAME" IS 'Sniffer job name';
   COMMENT ON COLUMN "CTRL_SOURCE"."DELIVERY_CHECKER_JOB_NAME" IS 'Delivery checker job name';
   COMMENT ON COLUMN "CTRL_SOURCE"."NOTIFICATION_ENABLED" IS 'Is notification enabled?';
   COMMENT ON TABLE "CTRL_SOURCE"  IS 'Source definition';
--------------------------------------------------------
--  DDL for Table CTRL_SOURCE_PLAN_REF
--------------------------------------------------------

  CREATE TABLE "CTRL_SOURCE_PLAN_REF" 
   (	"SOURCE_ID" NUMBER(*,0), 
	"RUNPLAN" CHAR(9 BYTE), 
	"ALERT_ZONE_START_TM" NUMBER(*,0), 
	"ALERT_ZONE_END_TM" NUMBER(*,0), 
	"NOWAIT_ALERT_ZONE_END_TM" NUMBER(*,0), 
	"CRITICAL" NUMBER(*,0), 
	"RELATED_TO_INITIALIZATION" NUMBER(*,0), 
	"ALERT_TM_IN_MINUTES" NUMBER(*,0) DEFAULT '0'
   ) ;

   COMMENT ON COLUMN "CTRL_SOURCE_PLAN_REF"."SOURCE_ID" IS 'Source identification';
   COMMENT ON COLUMN "CTRL_SOURCE_PLAN_REF"."RUNPLAN" IS 'Running plan';
   COMMENT ON COLUMN "CTRL_SOURCE_PLAN_REF"."ALERT_ZONE_START_TM" IS 'Alert zone time for warning message creation, number of hours/minutes (ALERT_TM_IN_MINUTES) from LOAD_DATE/INITIALIZATION_END (RELATED_TO_INITIALIZATION) parameter value';
   COMMENT ON COLUMN "CTRL_SOURCE_PLAN_REF"."ALERT_ZONE_END_TM" IS 'Alert zone time for Sniffer finishing or critical message creation, number of hours/minutes (ALERT_TM_IN_MINUTES) from LOAD_DATE/INITIALIZATION_END (RELATED_TO_INITIALIZATION) parameter value';
   COMMENT ON COLUMN "CTRL_SOURCE_PLAN_REF"."NOWAIT_ALERT_ZONE_END_TM" IS 'Alert zone time for Sniffer finishing in days when delivery is not expected, number of hours/minutes (ALERT_TM_IN_MINUTES) from LOAD_DATE/INITIALIZATION_END (RELATED_TO_INITIALIZATION) parameter value';
   COMMENT ON COLUMN "CTRL_SOURCE_PLAN_REF"."CRITICAL" IS 'Critical or not critical source';
   COMMENT ON COLUMN "CTRL_SOURCE_PLAN_REF"."RELATED_TO_INITIALIZATION" IS 'Is alert zone related to initialization time or load date?';
   COMMENT ON COLUMN "CTRL_SOURCE_PLAN_REF"."ALERT_TM_IN_MINUTES" IS '0- hours, 1- minutes in *_TM columns';
   COMMENT ON TABLE "CTRL_SOURCE_PLAN_REF"  IS 'Calendar for source processing';
--------------------------------------------------------
--  DDL for Table CTRL_SRCTABLE
--------------------------------------------------------

  CREATE TABLE "CTRL_SRCTABLE" 
   (	"TABLE_NAME" VARCHAR2(128 BYTE), 
	"LOG_NAME" VARCHAR2(128 BYTE), 
	"TABLE_TYPE" CHAR(1 BYTE), 
	"COMMON_TABLE_NAME" VARCHAR2(128 BYTE), 
	"TGT_TABLE_NAME" VARCHAR2(128 BYTE), 
	"SOURCE_ID" NUMBER(*,0), 
	"JOB_NAME" VARCHAR2(128 BYTE)
   ) ;

   COMMENT ON COLUMN "CTRL_SRCTABLE"."TABLE_NAME" IS 'Mask for table processing';
   COMMENT ON COLUMN "CTRL_SRCTABLE"."LOG_NAME" IS 'Name of the log';
   COMMENT ON COLUMN "CTRL_SRCTABLE"."TABLE_TYPE" IS 'Kind of the table';
   COMMENT ON COLUMN "CTRL_SRCTABLE"."COMMON_TABLE_NAME" IS 'Table name for table type junction';
   COMMENT ON COLUMN "CTRL_SRCTABLE"."TGT_TABLE_NAME" IS 'Target table name';
   COMMENT ON COLUMN "CTRL_SRCTABLE"."SOURCE_ID" IS 'Source identification';
   COMMENT ON COLUMN "CTRL_SRCTABLE"."JOB_NAME" IS 'Job name for table processing';
   COMMENT ON TABLE "CTRL_SRCTABLE"  IS 'Lookup of source tables';
--------------------------------------------------------
--  DDL for Table CTRL_STREAM
--------------------------------------------------------

  CREATE TABLE "CTRL_STREAM" 
   (	"STREAM_NAME" VARCHAR2(128 BYTE), 
	"STREAM_DESC" VARCHAR2(2048 BYTE), 
	"NOTE" VARCHAR2(2048 BYTE)
   ) ;

   COMMENT ON COLUMN "CTRL_STREAM"."STREAM_NAME" IS 'Name of the stream';
   COMMENT ON COLUMN "CTRL_STREAM"."STREAM_DESC" IS 'Description of the stream';
   COMMENT ON COLUMN "CTRL_STREAM"."NOTE" IS 'Note for stream procession';
   COMMENT ON TABLE "CTRL_STREAM"  IS 'Stream definition';
--------------------------------------------------------
--  DDL for Table CTRL_STREAM_DEPENDENCY
--------------------------------------------------------

  CREATE TABLE "CTRL_STREAM_DEPENDENCY" 
   (	"STREAM_NAME" VARCHAR2(128 BYTE), 
	"PARENT_STREAM_NAME" VARCHAR2(128 BYTE), 
	"REL_TYPE" CHAR(1 BYTE)
   ) ;

   COMMENT ON COLUMN "CTRL_STREAM_DEPENDENCY"."STREAM_NAME" IS 'Child stream name';
   COMMENT ON COLUMN "CTRL_STREAM_DEPENDENCY"."PARENT_STREAM_NAME" IS 'Parent stream name';
   COMMENT ON COLUMN "CTRL_STREAM_DEPENDENCY"."REL_TYPE" IS 'Relation type, NULL for real stream dependency';
   COMMENT ON TABLE "CTRL_STREAM_DEPENDENCY"  IS 'Dependency between streams';
--------------------------------------------------------
--  DDL for Table CTRL_STREAM_PLAN_REF
--------------------------------------------------------

  CREATE TABLE "CTRL_STREAM_PLAN_REF" 
   (	"STREAM_NAME" VARCHAR2(128 BYTE), 
	"RUNPLAN" CHAR(9 BYTE), 
	"COUNTRY_CD" VARCHAR2(4 BYTE)
   ) ;

   COMMENT ON COLUMN "CTRL_STREAM_PLAN_REF"."STREAM_NAME" IS 'Name of the stream';
   COMMENT ON COLUMN "CTRL_STREAM_PLAN_REF"."RUNPLAN" IS 'Plan for job in stream launch [type][reg|irreg][3from][3to][shift]';
   COMMENT ON COLUMN "CTRL_STREAM_PLAN_REF"."COUNTRY_CD" IS 'Country code';
   COMMENT ON TABLE "CTRL_STREAM_PLAN_REF"  IS 'Calendars to stream assignation';
--------------------------------------------------------
--  DDL for Table CTRL_TASK_PARAMETERS
--------------------------------------------------------

  CREATE TABLE "CTRL_TASK_PARAMETERS" 
   (	"PARAM_NAME" VARCHAR2(128 BYTE), 
	"PARAM_TYPE" VARCHAR2(128 BYTE), 
	"PARAM_VAL_INT_CURR" NUMBER(38,0), 
	"PARAM_VAL_INT_MAX" NUMBER(38,0), 
	"PARAM_VAL_INT_DEFAULT" NUMBER(38,0), 
	"PARAM_DIMENSION" VARCHAR2(128 BYTE), 
	"TASK_TYPE" VARCHAR2(128 BYTE), 
	"PARENT_TASK_TYPE" VARCHAR2(128 BYTE), 
	"VALID_FROM" NUMBER(38,0), 
	"VALID_TO" NUMBER(38,0), 
	"ENGINE_ID" NUMBER(38,0), 
	"SYSTEM_NAME" VARCHAR2(128 BYTE), 
	"DESCRIPTION" VARCHAR2(1024 BYTE)
   ) ;

   COMMENT ON COLUMN "CTRL_TASK_PARAMETERS"."PARAM_NAME" IS 'Parameter name';
   COMMENT ON COLUMN "CTRL_TASK_PARAMETERS"."PARAM_TYPE" IS 'Parameter type';
   COMMENT ON COLUMN "CTRL_TASK_PARAMETERS"."PARAM_VAL_INT_CURR" IS 'Not used, moved to SESS_PARALLELISM_CONTROL';
   COMMENT ON COLUMN "CTRL_TASK_PARAMETERS"."PARAM_VAL_INT_MAX" IS 'Maximal threshold which can be reached by category or subcategory';
   COMMENT ON COLUMN "CTRL_TASK_PARAMETERS"."PARAM_VAL_INT_DEFAULT" IS 'Default maximal threshold for category or subcategory';
   COMMENT ON COLUMN "CTRL_TASK_PARAMETERS"."PARAM_DIMENSION" IS 'Used for TOUGH_SPEC_CATEGORY_CONTROL - definition of phase';
   COMMENT ON COLUMN "CTRL_TASK_PARAMETERS"."TASK_TYPE" IS 'Job category or subcategory for parallelism control ';
   COMMENT ON COLUMN "CTRL_TASK_PARAMETERS"."PARENT_TASK_TYPE" IS 'Job category for parallelism control ';
   COMMENT ON COLUMN "CTRL_TASK_PARAMETERS"."VALID_FROM" IS 'From which hour is values valid';
   COMMENT ON COLUMN "CTRL_TASK_PARAMETERS"."VALID_TO" IS 'To which hour is values valid';
   COMMENT ON COLUMN "CTRL_TASK_PARAMETERS"."ENGINE_ID" IS 'Engine identification';
   COMMENT ON COLUMN "CTRL_TASK_PARAMETERS"."SYSTEM_NAME" IS 'Name of the system / ETL server for which the parameter is valid';
   COMMENT ON COLUMN "CTRL_TASK_PARAMETERS"."DESCRIPTION" IS 'Description of parameter';
   COMMENT ON TABLE "CTRL_TASK_PARAMETERS"  IS 'Parallelism control settings table';
--------------------------------------------------------
--  DDL for Table DBG_TLOG
--------------------------------------------------------

  CREATE TABLE "DBG_TLOG" 
   (	"ID" NUMBER, 
	"LDATE" DATE DEFAULT sysdate, 
	"LHSECS" NUMBER, 
	"LLEVEL" NUMBER, 
	"LSECTION" VARCHAR2(2000 BYTE), 
	"LTEXTE" VARCHAR2(2000 BYTE), 
	"LUSER" VARCHAR2(30 BYTE)
   ) ;
--------------------------------------------------------
--  DDL for Table DBG_TLOG_ATTRS
--------------------------------------------------------

  CREATE TABLE "DBG_TLOG_ATTRS" 
   (	"ERRID" NUMBER(16,0), 
	"ATTR_TYPE" VARCHAR2(12 BYTE), 
	"ATTR_NAME" VARCHAR2(256 BYTE), 
	"FMT_TYPE" VARCHAR2(256 BYTE), 
	"CVALUE" VARCHAR2(2048 BYTE), 
	"ERR_SEQ_ID" NUMBER
   ) ;
--------------------------------------------------------
--  DDL for Table DBG_TLOGLEVEL
--------------------------------------------------------

  CREATE TABLE "DBG_TLOGLEVEL" 
   (	"LLEVEL" NUMBER(4,0), 
	"LJLEVEL" NUMBER(5,0), 
	"LSYSLOGEQUIV" NUMBER(4,0), 
	"LCODE" VARCHAR2(10 BYTE), 
	"LDESC" VARCHAR2(255 BYTE)
   ) ;
--------------------------------------------------------
--  DDL for Table GUI_ACCESS_GROUP_ROLE_REF
--------------------------------------------------------

  CREATE TABLE "GUI_ACCESS_GROUP_ROLE_REF" 
   (	"DOMAIN_GROUP" VARCHAR2(128 BYTE), 
	"ACCESS_ROLE" VARCHAR2(1024 BYTE)
   ) ;

   COMMENT ON COLUMN "GUI_ACCESS_GROUP_ROLE_REF"."DOMAIN_GROUP" IS 'Domain group name';
   COMMENT ON COLUMN "GUI_ACCESS_GROUP_ROLE_REF"."ACCESS_ROLE" IS 'Access role name';
   COMMENT ON TABLE "GUI_ACCESS_GROUP_ROLE_REF"  IS 'Domain group - access role mapping';
--------------------------------------------------------
--  DDL for Table GUI_ACCESS_ROLE_RIGHT_REF
--------------------------------------------------------

  CREATE TABLE "GUI_ACCESS_ROLE_RIGHT_REF" 
   (	"ACCESS_ROLE" VARCHAR2(128 BYTE), 
	"GUI_PAGE" VARCHAR2(128 BYTE), 
	"ACCESS_RIGHT" VARCHAR2(128 BYTE)
   ) ;

   COMMENT ON COLUMN "GUI_ACCESS_ROLE_RIGHT_REF"."ACCESS_ROLE" IS 'Access role name';
   COMMENT ON COLUMN "GUI_ACCESS_ROLE_RIGHT_REF"."GUI_PAGE" IS 'GUI page';
   COMMENT ON COLUMN "GUI_ACCESS_ROLE_RIGHT_REF"."ACCESS_RIGHT" IS 'Access right name';
   COMMENT ON TABLE "GUI_ACCESS_ROLE_RIGHT_REF"  IS 'Access role - access right mapping';
--------------------------------------------------------
--  DDL for Table GUI_ACCESS_USER_GROUP_REF
--------------------------------------------------------

  CREATE TABLE "GUI_ACCESS_USER_GROUP_REF" 
   (	"USER_NAME" VARCHAR2(128 BYTE), 
	"DOMAIN_GROUP" VARCHAR2(128 BYTE)
   ) ;

   COMMENT ON COLUMN "GUI_ACCESS_USER_GROUP_REF"."USER_NAME" IS 'User name who did the action';
   COMMENT ON COLUMN "GUI_ACCESS_USER_GROUP_REF"."DOMAIN_GROUP" IS 'Domain group name';
   COMMENT ON TABLE "GUI_ACCESS_USER_GROUP_REF"  IS 'User - domain group mapping';
--------------------------------------------------------
--  DDL for Table GUI_AUTH
--------------------------------------------------------

  CREATE TABLE "GUI_AUTH" 
   (	"USR_ID" NUMBER(*,0), 
	"USR_NAME" VARCHAR2(256 BYTE), 
	"USR_PASSWD" VARCHAR2(1024 BYTE), 
	"USR_LEVEL" NUMBER(*,0)
   ) ;

   COMMENT ON COLUMN "GUI_AUTH"."USR_ID" IS 'User ID';
   COMMENT ON COLUMN "GUI_AUTH"."USR_NAME" IS 'User name';
   COMMENT ON COLUMN "GUI_AUTH"."USR_PASSWD" IS 'User password';
   COMMENT ON COLUMN "GUI_AUTH"."USR_LEVEL" IS 'User level';
   COMMENT ON TABLE "GUI_AUTH"  IS 'User authentication table';
--------------------------------------------------------
--  DDL for Table GUI_CHANGE_CONTROL
--------------------------------------------------------

  CREATE TABLE "GUI_CHANGE_CONTROL" 
   (	"LABEL_NAME" VARCHAR2(30 BYTE), 
	"USER_NAME" VARCHAR2(128 BYTE), 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"UID_INDICATOR" CHAR(1 BYTE), 
	"CMD_TS" TIMESTAMP (6), 
	"SEQ_NUM" NUMBER, 
	"CMD" VARCHAR2(4000 BYTE)
   ) ;

   COMMENT ON COLUMN "GUI_CHANGE_CONTROL"."LABEL_NAME" IS 'Label name';
   COMMENT ON COLUMN "GUI_CHANGE_CONTROL"."USER_NAME" IS 'User name who did the action';
   COMMENT ON COLUMN "GUI_CHANGE_CONTROL"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "GUI_CHANGE_CONTROL"."UID_INDICATOR" IS 'Operatin indicator M - merge, D - delete';
   COMMENT ON COLUMN "GUI_CHANGE_CONTROL"."CMD_TS" IS 'Execution timestamp';
   COMMENT ON COLUMN "GUI_CHANGE_CONTROL"."SEQ_NUM" IS 'Sequence number';
   COMMENT ON COLUMN "GUI_CHANGE_CONTROL"."CMD" IS 'SQL command';
   COMMENT ON TABLE "GUI_CHANGE_CONTROL"  IS 'List of changes done via change management';
--------------------------------------------------------
--  DDL for Table GUI_CHANGE_MANAGEMENT
--------------------------------------------------------

  CREATE TABLE "GUI_CHANGE_MANAGEMENT" 
   (	"LABEL_NAME" VARCHAR2(30 BYTE), 
	"LABEL_STATUS" VARCHAR2(16 BYTE), 
	"USER_NAME" VARCHAR2(128 BYTE), 
	"CREATE_TS" TIMESTAMP (6), 
	"DESCRIPTION" VARCHAR2(1024 BYTE), 
	"ENV" CHAR(4 BYTE)
   ) ;

   COMMENT ON COLUMN "GUI_CHANGE_MANAGEMENT"."LABEL_NAME" IS 'Label name';
   COMMENT ON COLUMN "GUI_CHANGE_MANAGEMENT"."LABEL_STATUS" IS 'Label status - Open or Close';
   COMMENT ON COLUMN "GUI_CHANGE_MANAGEMENT"."USER_NAME" IS 'User name who created the label';
   COMMENT ON COLUMN "GUI_CHANGE_MANAGEMENT"."CREATE_TS" IS 'Timestamp when label was created';
   COMMENT ON COLUMN "GUI_CHANGE_MANAGEMENT"."DESCRIPTION" IS 'Description what is label established for';
   COMMENT ON COLUMN "GUI_CHANGE_MANAGEMENT"."ENV" IS 'Environment name where is label opened, DEVL in 99.99 percent';
   COMMENT ON TABLE "GUI_CHANGE_MANAGEMENT"  IS 'Change management';
--------------------------------------------------------
--  DDL for Table GUI_LOG_CTRL_ACTION
--------------------------------------------------------

  CREATE TABLE "GUI_LOG_CTRL_ACTION" 
   (	"USER_NAME" VARCHAR2(128 BYTE), 
	"ACTION" VARCHAR2(128 BYTE), 
	"ACTION_TS" TIMESTAMP (6), 
	"SQL_CODE" VARCHAR2(4000 BYTE), 
	"DWH_DATE" DATE
   ) ;

   COMMENT ON COLUMN "GUI_LOG_CTRL_ACTION"."USER_NAME" IS 'User name who did the action';
   COMMENT ON COLUMN "GUI_LOG_CTRL_ACTION"."ACTION" IS 'Action identification';
   COMMENT ON COLUMN "GUI_LOG_CTRL_ACTION"."ACTION_TS" IS 'Timestamp when action was done';
   COMMENT ON COLUMN "GUI_LOG_CTRL_ACTION"."SQL_CODE" IS 'SQL code of action';
   COMMENT ON COLUMN "GUI_LOG_CTRL_ACTION"."DWH_DATE" IS 'DWH date';
   COMMENT ON TABLE "GUI_LOG_CTRL_ACTION"  IS 'Log of GUI control actions';
--------------------------------------------------------
--  DDL for Table GUI_SHOW_LOGS_JOBS_URL_PATH
--------------------------------------------------------

  CREATE TABLE "GUI_SHOW_LOGS_JOBS_URL_PATH" 
   (	"JOB_NAME" VARCHAR2(128 BYTE), 
	"JOB_TYPE" VARCHAR2(32 BYTE), 
	"URL_PATH" VARCHAR2(1000 BYTE), 
	"LOG_NAME" VARCHAR2(250 BYTE), 
	"FILE_NAME" VARCHAR2(500 BYTE)
   ) ;

   COMMENT ON COLUMN "GUI_SHOW_LOGS_JOBS_URL_PATH"."JOB_NAME" IS 'name of job for which config item is valid, null means all jobs';
   COMMENT ON COLUMN "GUI_SHOW_LOGS_JOBS_URL_PATH"."JOB_TYPE" IS 'type of job for which config item is valid, null means all job types';
   COMMENT ON COLUMN "GUI_SHOW_LOGS_JOBS_URL_PATH"."URL_PATH" IS 'relative path from the root of web server';
   COMMENT ON COLUMN "GUI_SHOW_LOGS_JOBS_URL_PATH"."LOG_NAME" IS 'name of log, rows are grupped by this column';
   COMMENT ON COLUMN "GUI_SHOW_LOGS_JOBS_URL_PATH"."FILE_NAME" IS 'file name which is shown in popup window';
   COMMENT ON TABLE "GUI_SHOW_LOGS_JOBS_URL_PATH"  IS 'config used for URL generation of logs showed by GUI ';
--------------------------------------------------------
--  DDL for Table GUI_SHOW_LOGS_SYS_CONF
--------------------------------------------------------

  CREATE TABLE "GUI_SHOW_LOGS_SYS_CONF" 
   (	"ENGINE_ID" NUMBER(38,0), 
	"SYSTEM_NAME" VARCHAR2(128 BYTE), 
	"HOST_URL" VARCHAR2(1000 BYTE)
   ) ;

   COMMENT ON COLUMN "GUI_SHOW_LOGS_SYS_CONF"."ENGINE_ID" IS 'Engine id which can process the job';
   COMMENT ON COLUMN "GUI_SHOW_LOGS_SYS_CONF"."SYSTEM_NAME" IS 'System which process the job';
   COMMENT ON COLUMN "GUI_SHOW_LOGS_SYS_CONF"."HOST_URL" IS 'URL of web server which provides access to logs (root)';
   COMMENT ON TABLE "GUI_SHOW_LOGS_SYS_CONF"  IS 'Configuration table specifying web server urls root for engines and sytems';
--------------------------------------------------------
--  DDL for Table LKP_APPLICATION
--------------------------------------------------------

  CREATE TABLE "LKP_APPLICATION" 
   (	"APPLICATION_ID" NUMBER(38,0), 
	"IGNORE_STATS" NUMBER(38,0), 
	"DESCRIPTION" VARCHAR2(1024 BYTE), 
	"ENGINE_ID" NUMBER(38,0), 
	"IS_ACTIVE" NUMBER(38,0)
   ) ;

   COMMENT ON COLUMN "LKP_APPLICATION"."APPLICATION_ID" IS 'Application identification';
   COMMENT ON COLUMN "LKP_APPLICATION"."IGNORE_STATS" IS 'If ignore statistics if job was processed by this application';
   COMMENT ON COLUMN "LKP_APPLICATION"."DESCRIPTION" IS 'Description of application';
   COMMENT ON COLUMN "LKP_APPLICATION"."ENGINE_ID" IS 'Engine ID';
   COMMENT ON COLUMN "LKP_APPLICATION"."IS_ACTIVE" IS 'Activity indicator';
   COMMENT ON TABLE "LKP_APPLICATION"  IS 'Lookup of application for job processing';
--------------------------------------------------------
--  DDL for Table LKP_COUNTRY
--------------------------------------------------------

  CREATE TABLE "LKP_COUNTRY" 
   (	"COUNTRY_CD" VARCHAR2(4 BYTE), 
	"COUNTRY_NAME" VARCHAR2(128 BYTE), 
	"DESCRIPTION" VARCHAR2(1024 BYTE)
   ) ;

   COMMENT ON COLUMN "LKP_COUNTRY"."COUNTRY_CD" IS 'Country code';
   COMMENT ON COLUMN "LKP_COUNTRY"."COUNTRY_NAME" IS 'Country name';
   COMMENT ON COLUMN "LKP_COUNTRY"."DESCRIPTION" IS 'Description';
   COMMENT ON TABLE "LKP_COUNTRY"  IS 'Lookup of country';
--------------------------------------------------------
--  DDL for Table LKP_ERROR_CD
--------------------------------------------------------

  CREATE TABLE "LKP_ERROR_CD" 
   (	"ERROR_CD" VARCHAR2(16 BYTE), 
	"ERROR_CD_NAME" VARCHAR2(36 BYTE), 
	"ERROR_CD_NAME_SHORT" VARCHAR2(7 BYTE), 
	"ERROR_CD_DESC" VARCHAR2(256 BYTE), 
	"ERROR_CD_SOURCE" VARCHAR2(256 BYTE), 
	"ERROR_CD_RECOM" VARCHAR2(1024 BYTE)
   ) ;

   COMMENT ON COLUMN "LKP_ERROR_CD"."ERROR_CD" IS 'Error code';
   COMMENT ON COLUMN "LKP_ERROR_CD"."ERROR_CD_NAME" IS 'Error code name';
   COMMENT ON COLUMN "LKP_ERROR_CD"."ERROR_CD_NAME_SHORT" IS 'Error code name short';
   COMMENT ON COLUMN "LKP_ERROR_CD"."ERROR_CD_DESC" IS 'Error code description';
   COMMENT ON COLUMN "LKP_ERROR_CD"."ERROR_CD_SOURCE" IS 'Error code source';
   COMMENT ON COLUMN "LKP_ERROR_CD"."ERROR_CD_RECOM" IS 'Error code reccomendation';
   COMMENT ON TABLE "LKP_ERROR_CD"  IS 'Lookup of error code';
--------------------------------------------------------
--  DDL for Table LKP_GUI_ACCESS_CONTROL
--------------------------------------------------------

  CREATE TABLE "LKP_GUI_ACCESS_CONTROL" 
   (	"ACCESS_RIGHT" VARCHAR2(128 BYTE)
   ) ;

   COMMENT ON COLUMN "LKP_GUI_ACCESS_CONTROL"."ACCESS_RIGHT" IS 'Access right name';
   COMMENT ON TABLE "LKP_GUI_ACCESS_CONTROL"  IS 'Lookup of access right';
--------------------------------------------------------
--  DDL for Table LKP_GUI_ACCESS_MENU
--------------------------------------------------------

  CREATE TABLE "LKP_GUI_ACCESS_MENU" 
   (	"ACCESS_MENU" VARCHAR2(128 BYTE)
   ) ;

   COMMENT ON COLUMN "LKP_GUI_ACCESS_MENU"."ACCESS_MENU" IS 'Access menu item';
   COMMENT ON TABLE "LKP_GUI_ACCESS_MENU"  IS 'Lookup of access menu item';
--------------------------------------------------------
--  DDL for Table LKP_GUI_ACCESS_ROLE
--------------------------------------------------------

  CREATE TABLE "LKP_GUI_ACCESS_ROLE" 
   (	"ACCESS_ROLE" VARCHAR2(128 BYTE)
   ) ;

   COMMENT ON COLUMN "LKP_GUI_ACCESS_ROLE"."ACCESS_ROLE" IS 'Access role name';
   COMMENT ON TABLE "LKP_GUI_ACCESS_ROLE"  IS 'Lookup of access role';
--------------------------------------------------------
--  DDL for Table LKP_JOB_CATEGORY
--------------------------------------------------------

  CREATE TABLE "LKP_JOB_CATEGORY" 
   (	"JOB_CATEGORY" VARCHAR2(32 BYTE), 
	"DESCRIPTION" VARCHAR2(1024 BYTE), 
	"ABORTABLE" NUMBER
   ) ;

   COMMENT ON COLUMN "LKP_JOB_CATEGORY"."JOB_CATEGORY" IS 'Job subcategory name for parallelism control ';
   COMMENT ON COLUMN "LKP_JOB_CATEGORY"."DESCRIPTION" IS 'Description of subcategory';
   COMMENT ON COLUMN "LKP_JOB_CATEGORY"."ABORTABLE" IS 'Is abort supported for the job category?';
   COMMENT ON TABLE "LKP_JOB_CATEGORY"  IS 'Lookup of job category';
--------------------------------------------------------
--  DDL for Table LKP_JOB_TYPE
--------------------------------------------------------

  CREATE TABLE "LKP_JOB_TYPE" 
   (	"JOB_TYPE" VARCHAR2(32 BYTE), 
	"DESCRIPTION" VARCHAR2(1024 BYTE)
   ) ;

   COMMENT ON COLUMN "LKP_JOB_TYPE"."JOB_TYPE" IS 'Kind of job';
   COMMENT ON COLUMN "LKP_JOB_TYPE"."DESCRIPTION" IS 'Description of job type';
   COMMENT ON TABLE "LKP_JOB_TYPE"  IS 'Lookup of job type';
--------------------------------------------------------
--  DDL for Table LKP_PHASE
--------------------------------------------------------

  CREATE TABLE "LKP_PHASE" 
   (	"JOB_PHASE" VARCHAR2(32 BYTE), 
	"DESCRIPTION" VARCHAR2(1024 BYTE)
   ) ;

   COMMENT ON COLUMN "LKP_PHASE"."JOB_PHASE" IS 'Phase name';
   COMMENT ON COLUMN "LKP_PHASE"."DESCRIPTION" IS 'Description of phase name';
   COMMENT ON TABLE "LKP_PHASE"  IS 'Lookup of phase name';
--------------------------------------------------------
--  DDL for Table LKP_PLAN
--------------------------------------------------------

  CREATE TABLE "LKP_PLAN" 
   (	"RUNPLAN" CHAR(9 BYTE), 
	"DESCRIPTION" VARCHAR2(1024 BYTE)
   ) ;

   COMMENT ON COLUMN "LKP_PLAN"."RUNPLAN" IS 'Run plan';
   COMMENT ON COLUMN "LKP_PLAN"."DESCRIPTION" IS 'Description of runplan';
   COMMENT ON TABLE "LKP_PLAN"  IS 'Lookup of run plan';
--------------------------------------------------------
--  DDL for Table PROC_LOG
--------------------------------------------------------

  CREATE TABLE "PROC_LOG" 
   (	"PROCESS_NM" VARCHAR2(64 CHAR), 
	"VERSION_NUM" VARCHAR2(16 CHAR), 
	"PROCESS_TS" DATE, 
	"RUN_NUM" NUMBER(*,0), 
	"START_DT" DATE, 
	"END_DT" DATE, 
	"STAT_CD" NUMBER(*,0), 
	"DESCRIPTION" VARCHAR2(512 CHAR), 
	"PROCESS_STEP" VARCHAR2(512 CHAR), 
	"SEQ_NUM" NUMBER(38,0), 
	"STEP_CNT" NUMBER(*,0)
   ) ;

   COMMENT ON COLUMN "PROC_LOG"."PROCESS_NM" IS 'Proccess name';
   COMMENT ON COLUMN "PROC_LOG"."VERSION_NUM" IS 'version number of excecuted procedure';
   COMMENT ON COLUMN "PROC_LOG"."PROCESS_TS" IS 'Timestamp';
   COMMENT ON COLUMN "PROC_LOG"."RUN_NUM" IS 'Number of run';
   COMMENT ON COLUMN "PROC_LOG"."START_DT" IS 'Input parametr';
   COMMENT ON COLUMN "PROC_LOG"."END_DT" IS 'Input parametr';
   COMMENT ON COLUMN "PROC_LOG"."STAT_CD" IS 'Status code';
   COMMENT ON COLUMN "PROC_LOG"."DESCRIPTION" IS 'Description';
   COMMENT ON COLUMN "PROC_LOG"."PROCESS_STEP" IS 'Step of process';
   COMMENT ON COLUMN "PROC_LOG"."SEQ_NUM" IS 'Sequence number';
   COMMENT ON COLUMN "PROC_LOG"."STEP_CNT" IS 'Step counter';
   COMMENT ON TABLE "PROC_LOG"  IS 'Procedure execution log';
--------------------------------------------------------
--  DDL for Table SESS_JOB
--------------------------------------------------------

  CREATE TABLE "SESS_JOB" 
   (	"JOB_ID" NUMBER(38,0), 
	"STREAM_ID" NUMBER(38,0), 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"STREAM_NAME" VARCHAR2(128 BYTE), 
	"STATUS" NUMBER(38,0), 
	"LAST_UPDATE" TIMESTAMP (6), 
	"LOAD_DATE" DATE, 
	"PRIORITY" NUMBER(38,0), 
	"CMD_LINE" VARCHAR2(1024 BYTE), 
	"SRC_SYS_ID" NUMBER(38,0), 
	"PHASE" VARCHAR2(32 BYTE), 
	"TABLE_NAME" VARCHAR2(128 BYTE), 
	"JOB_CATEGORY" VARCHAR2(32 BYTE), 
	"JOB_TYPE" VARCHAR2(32 BYTE), 
	"TOUGHNESS" NUMBER(38,0), 
	"CONT_ANYWAY" NUMBER(38,0), 
	"RESTART" NUMBER(38,0), 
	"ALWAYS_RESTART" NUMBER(38,0), 
	"N_RUN" NUMBER(38,0), 
	"MAX_RUNS" NUMBER(38,0), 
	"WAITING_HR" NUMBER(38,0), 
	"DEADLINE_HR" NUMBER(38,0), 
	"APPLICATION_ID" NUMBER(38,0), 
	"ENGINE_ID" NUMBER(38,0), 
	"SYSTEM_NAME" VARCHAR2(128 BYTE), 
	"QUEUE_NUMBER" NUMBER(38,0)
   ) ;

   COMMENT ON COLUMN "SESS_JOB"."JOB_ID" IS 'Job identification';
   COMMENT ON COLUMN "SESS_JOB"."STREAM_ID" IS 'Unique sequence number generated for stream_name identification';
   COMMENT ON COLUMN "SESS_JOB"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "SESS_JOB"."STREAM_NAME" IS 'Name of the stream which job belongs to';
   COMMENT ON COLUMN "SESS_JOB"."STATUS" IS 'Current status of the job';
   COMMENT ON COLUMN "SESS_JOB"."LAST_UPDATE" IS 'Timestamp of the job status last update';
   COMMENT ON COLUMN "SESS_JOB"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "SESS_JOB"."PRIORITY" IS 'Priority of the job, less number means higher priority';
   COMMENT ON COLUMN "SESS_JOB"."CMD_LINE" IS 'Command line of the job';
   COMMENT ON COLUMN "SESS_JOB"."SRC_SYS_ID" IS 'Source system code which data is processed';
   COMMENT ON COLUMN "SESS_JOB"."PHASE" IS 'Phase name of DWH transformation';
   COMMENT ON COLUMN "SESS_JOB"."TABLE_NAME" IS 'Main table name which data is processed';
   COMMENT ON COLUMN "SESS_JOB"."JOB_CATEGORY" IS 'Category of the job. Suitable for parallelism control';
   COMMENT ON COLUMN "SESS_JOB"."JOB_TYPE" IS 'Kind of job';
   COMMENT ON COLUMN "SESS_JOB"."TOUGHNESS" IS 'Job toughness';
   COMMENT ON COLUMN "SESS_JOB"."CONT_ANYWAY" IS 'If continue next job execution when job fails';
   COMMENT ON COLUMN "SESS_JOB"."RESTART" IS 'Do a restart';
   COMMENT ON COLUMN "SESS_JOB"."ALWAYS_RESTART" IS 'Do restart in any case';
   COMMENT ON COLUMN "SESS_JOB"."N_RUN" IS 'Actual number of job launch';
   COMMENT ON COLUMN "SESS_JOB"."MAX_RUNS" IS 'Maximum number of job launches without manual restart';
   COMMENT ON COLUMN "SESS_JOB"."WAITING_HR" IS 'Minimum number of hours passed from load_date for launch granting';
   COMMENT ON COLUMN "SESS_JOB"."DEADLINE_HR" IS 'Maximal number of hours passed from load_date when job should be finished';
   COMMENT ON COLUMN "SESS_JOB"."APPLICATION_ID" IS 'Application identification which drive the job';
   COMMENT ON COLUMN "SESS_JOB"."ENGINE_ID" IS 'Engine id which can process the job';
   COMMENT ON COLUMN "SESS_JOB"."SYSTEM_NAME" IS 'System which process the job';
   COMMENT ON COLUMN "SESS_JOB"."QUEUE_NUMBER" IS 'Queue number';
   COMMENT ON TABLE "SESS_JOB"  IS 'List of the job with actual status of processing';
--------------------------------------------------------
--  DDL for Table SESS_JOB_BCKP
--------------------------------------------------------

  CREATE TABLE "SESS_JOB_BCKP" 
   (	"JOB_ID" NUMBER(38,0), 
	"STREAM_ID" NUMBER(38,0), 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"STREAM_NAME" VARCHAR2(128 BYTE), 
	"STATUS" NUMBER(38,0), 
	"LAST_UPDATE" TIMESTAMP (6), 
	"LOAD_DATE" DATE, 
	"PRIORITY" NUMBER(38,0), 
	"CMD_LINE" VARCHAR2(1024 BYTE), 
	"SRC_SYS_ID" NUMBER(38,0), 
	"PHASE" VARCHAR2(32 BYTE), 
	"TABLE_NAME" VARCHAR2(128 BYTE), 
	"JOB_CATEGORY" VARCHAR2(32 BYTE), 
	"JOB_TYPE" VARCHAR2(32 BYTE), 
	"TOUGHNESS" NUMBER(38,0), 
	"CONT_ANYWAY" NUMBER(38,0), 
	"RESTART" NUMBER(38,0), 
	"ALWAYS_RESTART" NUMBER(38,0), 
	"N_RUN" NUMBER(38,0), 
	"MAX_RUNS" NUMBER(38,0), 
	"WAITING_HR" NUMBER(38,0), 
	"DEADLINE_HR" NUMBER(38,0), 
	"APPLICATION_ID" NUMBER(38,0), 
	"ENGINE_ID" NUMBER(38,0), 
	"SYSTEM_NAME" VARCHAR2(128 BYTE), 
	"QUEUE_NUMBER" NUMBER(38,0)
   ) ;

   COMMENT ON COLUMN "SESS_JOB_BCKP"."JOB_ID" IS 'Job identification';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."STREAM_ID" IS 'Unique sequence number generated for stream_name identification';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."STREAM_NAME" IS 'Name of the stream which job belongs to';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."STATUS" IS 'Current status of the job';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."LAST_UPDATE" IS 'Timestamp of the job status last update';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."PRIORITY" IS 'Priority of the job, less number means higher priority';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."CMD_LINE" IS 'Command line of the job';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."SRC_SYS_ID" IS 'Source system code which data is processed';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."PHASE" IS 'Phase name of DWH transformation';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."TABLE_NAME" IS 'Main table name which data is processed';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."JOB_CATEGORY" IS 'Category of the job. Suitable for parallelism control';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."JOB_TYPE" IS 'Kind of job';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."TOUGHNESS" IS 'Job toughness';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."CONT_ANYWAY" IS 'If continue next job execution when job fails';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."RESTART" IS 'Do a restart';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."ALWAYS_RESTART" IS 'Do restart in any case';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."N_RUN" IS 'Actual number of job launch';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."MAX_RUNS" IS 'Maximum number of job launches without manual restart';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."WAITING_HR" IS 'Minimum number of hours passed from load_date for launch granting';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."DEADLINE_HR" IS 'Maximal number of hours passed from load_date when job should be finished';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."APPLICATION_ID" IS 'Application identification which drive the job';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."ENGINE_ID" IS 'Engine id which can process the job';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."SYSTEM_NAME" IS 'System which process the job';
   COMMENT ON COLUMN "SESS_JOB_BCKP"."QUEUE_NUMBER" IS 'Queue number';
   COMMENT ON TABLE "SESS_JOB_BCKP"  IS 'List of the job with actual status of processing';
--------------------------------------------------------
--  DDL for Table SESS_JOB_DEPENDENCY
--------------------------------------------------------

  CREATE TABLE "SESS_JOB_DEPENDENCY" 
   (	"JOB_ID" NUMBER(38,0), 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"PARENT_JOB_ID" NUMBER(38,0), 
	"PARENT_JOB_NAME" VARCHAR2(128 BYTE), 
	"REL_TYPE" CHAR(1 BYTE), 
	"ENGINE_ID" NUMBER
   ) ;

   COMMENT ON COLUMN "SESS_JOB_DEPENDENCY"."JOB_ID" IS 'Child job name identification';
   COMMENT ON COLUMN "SESS_JOB_DEPENDENCY"."JOB_NAME" IS 'Name of the child job';
   COMMENT ON COLUMN "SESS_JOB_DEPENDENCY"."PARENT_JOB_ID" IS 'Parent job name identification';
   COMMENT ON COLUMN "SESS_JOB_DEPENDENCY"."PARENT_JOB_NAME" IS 'Name of the parent job';
   COMMENT ON COLUMN "SESS_JOB_DEPENDENCY"."REL_TYPE" IS 'Relation type, NULL for real job dependency';
   COMMENT ON COLUMN "SESS_JOB_DEPENDENCY"."ENGINE_ID" IS 'Engine identification';
   COMMENT ON TABLE "SESS_JOB_DEPENDENCY"  IS 'Current state of job dependencies';
--------------------------------------------------------
--  DDL for Table SESS_JOB_DEPENDENCY_BCKP
--------------------------------------------------------

  CREATE TABLE "SESS_JOB_DEPENDENCY_BCKP" 
   (	"JOB_ID" NUMBER(38,0), 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"PARENT_JOB_ID" NUMBER(38,0), 
	"PARENT_JOB_NAME" VARCHAR2(128 BYTE), 
	"REL_TYPE" CHAR(1 BYTE), 
	"ENGINE_ID" NUMBER
   ) ;

   COMMENT ON COLUMN "SESS_JOB_DEPENDENCY_BCKP"."JOB_ID" IS 'Child job name identification';
   COMMENT ON COLUMN "SESS_JOB_DEPENDENCY_BCKP"."JOB_NAME" IS 'Name of the child job';
   COMMENT ON COLUMN "SESS_JOB_DEPENDENCY_BCKP"."PARENT_JOB_ID" IS 'Parent job name identification';
   COMMENT ON COLUMN "SESS_JOB_DEPENDENCY_BCKP"."PARENT_JOB_NAME" IS 'Name of the parent job';
   COMMENT ON COLUMN "SESS_JOB_DEPENDENCY_BCKP"."REL_TYPE" IS 'Relation type, NULL for real job dependency';
   COMMENT ON COLUMN "SESS_JOB_DEPENDENCY_BCKP"."ENGINE_ID" IS 'Engine identification';
   COMMENT ON TABLE "SESS_JOB_DEPENDENCY_BCKP"  IS 'Current state of job dependencies after initialization';
--------------------------------------------------------
--  DDL for Table SESS_JOB_STATISTICS
--------------------------------------------------------

  CREATE TABLE "SESS_JOB_STATISTICS" 
   (	"JOB_NAME" VARCHAR2(128 BYTE), 
	"LOAD_DATE" DATE, 
	"DAY_IN_WEEK" NUMBER(38,0), 
	"DAY_IN_MONTH" NUMBER(38,0), 
	"FIRST_START_TS" TIMESTAMP (6), 
	"LAST_START_TS" TIMESTAMP (6), 
	"LAST_STATUS_TS" TIMESTAMP (6), 
	"END_TS" TIMESTAMP (6), 
	"LAST_STATUS" NUMBER(38,0), 
	"N_RUN" NUMBER(38,0), 
	"AVG_DURATION" NUMBER(38,0), 
	"AVG_END_TM" NUMBER(38,0), 
	"ENGINE_ID" NUMBER(38,0), 
	"IGNORE_STAT" NUMBER(38,0)
   ) ;

   COMMENT ON COLUMN "SESS_JOB_STATISTICS"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "SESS_JOB_STATISTICS"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "SESS_JOB_STATISTICS"."DAY_IN_WEEK" IS 'Day in week, Monday=1, Sunday=7';
   COMMENT ON COLUMN "SESS_JOB_STATISTICS"."DAY_IN_MONTH" IS 'Day in month, ultimo=999';
   COMMENT ON COLUMN "SESS_JOB_STATISTICS"."FIRST_START_TS" IS 'Timestamp when job was launched the first time';
   COMMENT ON COLUMN "SESS_JOB_STATISTICS"."LAST_START_TS" IS 'Timestamp when job was launched the last time';
   COMMENT ON COLUMN "SESS_JOB_STATISTICS"."LAST_STATUS_TS" IS 'Timestamp of last status change';
   COMMENT ON COLUMN "SESS_JOB_STATISTICS"."END_TS" IS 'Timestamp when job finished';
   COMMENT ON COLUMN "SESS_JOB_STATISTICS"."LAST_STATUS" IS 'Last status of the job';
   COMMENT ON COLUMN "SESS_JOB_STATISTICS"."N_RUN" IS 'Number of job launch';
   COMMENT ON COLUMN "SESS_JOB_STATISTICS"."AVG_DURATION" IS 'Average duration';
   COMMENT ON COLUMN "SESS_JOB_STATISTICS"."AVG_END_TM" IS 'Average time when job finished';
   COMMENT ON COLUMN "SESS_JOB_STATISTICS"."ENGINE_ID" IS 'Engine identification';
   COMMENT ON COLUMN "SESS_JOB_STATISTICS"."IGNORE_STAT" IS 'If statistics is used for counting, ignore_stat=0';
   COMMENT ON TABLE "SESS_JOB_STATISTICS"  IS 'Current job statistics';
--------------------------------------------------------
--  DDL for Table SESS_JOB_TABLE_REF
--------------------------------------------------------

  CREATE TABLE "SESS_JOB_TABLE_REF" 
   (	"JOB_NAME" VARCHAR2(128 BYTE), 
	"DATABASE_NAME" VARCHAR2(128 BYTE), 
	"TABLE_NAME" VARCHAR2(128 BYTE), 
	"LOCK_TYPE" CHAR(1 BYTE)
   ) ;

   COMMENT ON COLUMN "SESS_JOB_TABLE_REF"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "SESS_JOB_TABLE_REF"."DATABASE_NAME" IS 'Database name which job is working with';
   COMMENT ON COLUMN "SESS_JOB_TABLE_REF"."TABLE_NAME" IS 'Table name';
   COMMENT ON COLUMN "SESS_JOB_TABLE_REF"."LOCK_TYPE" IS 'Lock type, W=write, R=read';
   COMMENT ON TABLE "SESS_JOB_TABLE_REF"  IS 'Relation of which job is using which table';
--------------------------------------------------------
--  DDL for Table SESS_PARALLELISM_CONTROL
--------------------------------------------------------

  CREATE TABLE "SESS_PARALLELISM_CONTROL" 
   (	"PARAM_VAL_INT_CURR" NUMBER(38,0), 
	"PARAM_VAL_INT_MAX" NUMBER(38,0), 
	"PARAM_VAL_INT_DEFAULT" NUMBER(38,0), 
	"JOB_CATEGORY" VARCHAR2(128 BYTE), 
	"PARENT_JOB_CATEGORY" VARCHAR2(128 BYTE), 
	"ENGINE_ID" NUMBER(38,0), 
	"SYSTEM_NAME" VARCHAR2(128 BYTE), 
	"OVERLOAD" NUMBER(*,0), 
	"CURR_RUNNING_JOBS" NUMBER(*,0), 
	"TOTAL_TOUGH" NUMBER(*,0), 
	"TASK_MIN_CONTROL" NUMBER(*,0)
   ) ;

   COMMENT ON COLUMN "SESS_PARALLELISM_CONTROL"."PARAM_VAL_INT_CURR" IS 'toughness sum of currently running jobs';
   COMMENT ON COLUMN "SESS_PARALLELISM_CONTROL"."PARAM_VAL_INT_MAX" IS 'Maximal threshold which can be reached by category or subcategory';
   COMMENT ON COLUMN "SESS_PARALLELISM_CONTROL"."PARAM_VAL_INT_DEFAULT" IS 'Default maximal threshold for category or subcategory';
   COMMENT ON COLUMN "SESS_PARALLELISM_CONTROL"."JOB_CATEGORY" IS 'Category of the job. Suitable for parallelism control';
   COMMENT ON COLUMN "SESS_PARALLELISM_CONTROL"."PARENT_JOB_CATEGORY" IS 'Parent job category for parallelism control ';
   COMMENT ON COLUMN "SESS_PARALLELISM_CONTROL"."ENGINE_ID" IS 'Engine identification';
   COMMENT ON COLUMN "SESS_PARALLELISM_CONTROL"."SYSTEM_NAME" IS 'System which process the job';
   COMMENT ON COLUMN "SESS_PARALLELISM_CONTROL"."OVERLOAD" IS 'If overload process was done';
   COMMENT ON COLUMN "SESS_PARALLELISM_CONTROL"."CURR_RUNNING_JOBS" IS 'Current running job counter';
   COMMENT ON COLUMN "SESS_PARALLELISM_CONTROL"."TOTAL_TOUGH" IS 'Total toughness on category';
   COMMENT ON COLUMN "SESS_PARALLELISM_CONTROL"."TASK_MIN_CONTROL" IS 'Min. num of jobs when toughness reservation is applied';
   COMMENT ON TABLE "SESS_PARALLELISM_CONTROL"  IS 'Current state of parallelism control';
--------------------------------------------------------
--  DDL for Table SESS_QUEUE
--------------------------------------------------------

  CREATE TABLE "SESS_QUEUE" 
   (	"QUEUE_NUMBER" NUMBER(38,0), 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"JOB_ID" NUMBER(38,0), 
	"AVAILABLE" NUMBER(38,0), 
	"LAST_UPDATE" TIMESTAMP (6), 
	"ENGINE_ID" NUMBER(38,0), 
	"SYSTEM_NAME" VARCHAR2(128 BYTE), 
	"RUNNING_JOB_PID" NUMBER(*,0)
   ) ;

   COMMENT ON COLUMN "SESS_QUEUE"."QUEUE_NUMBER" IS 'Queue number';
   COMMENT ON COLUMN "SESS_QUEUE"."JOB_NAME" IS 'Job name running in queue number';
   COMMENT ON COLUMN "SESS_QUEUE"."JOB_ID" IS 'Job identification running in queue number';
   COMMENT ON COLUMN "SESS_QUEUE"."AVAILABLE" IS 'Is queue number available for job launch?';
   COMMENT ON COLUMN "SESS_QUEUE"."LAST_UPDATE" IS 'Timestamp of last used';
   COMMENT ON COLUMN "SESS_QUEUE"."ENGINE_ID" IS 'Engine id for which is queue determine';
   COMMENT ON COLUMN "SESS_QUEUE"."SYSTEM_NAME" IS 'Name of the system / ETL server on which is job running';
   COMMENT ON COLUMN "SESS_QUEUE"."RUNNING_JOB_PID" IS 'PID of PDC run job process';
   COMMENT ON TABLE "SESS_QUEUE"  IS 'Queue list for job execution';
--------------------------------------------------------
--  DDL for Table SESS_SRCTABLE
--------------------------------------------------------

  CREATE TABLE "SESS_SRCTABLE" 
   (	"TABLE_NAME" VARCHAR2(128 BYTE), 
	"LOG_NAME" VARCHAR2(128 BYTE), 
	"COMMON_TABLE_NAME" VARCHAR2(128 BYTE), 
	"SCHEMA_NAME" VARCHAR2(128 BYTE), 
	"SOURCE_ID" NUMBER(*,0), 
	"JOB_ID" NUMBER(*,0), 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"EFF_LOAD_DATE" DATE, 
	"LOAD_DATE" DATE, 
	"LOAD_STATUS" VARCHAR2(16 BYTE), 
	"INSERT_TS" TIMESTAMP (6)
   ) ;

   COMMENT ON COLUMN "SESS_SRCTABLE"."TABLE_NAME" IS 'Table name';
   COMMENT ON COLUMN "SESS_SRCTABLE"."LOG_NAME" IS 'Name of the log';
   COMMENT ON COLUMN "SESS_SRCTABLE"."COMMON_TABLE_NAME" IS 'Table name for table type junction';
   COMMENT ON COLUMN "SESS_SRCTABLE"."SCHEMA_NAME" IS 'Schema name where table was found';
   COMMENT ON COLUMN "SESS_SRCTABLE"."SOURCE_ID" IS 'Source identification which table belongs to';
   COMMENT ON COLUMN "SESS_SRCTABLE"."JOB_ID" IS 'Job identification prepared for table processing';
   COMMENT ON COLUMN "SESS_SRCTABLE"."JOB_NAME" IS 'Job name of job prepared for table processing';
   COMMENT ON COLUMN "SESS_SRCTABLE"."EFF_LOAD_DATE" IS 'Date which the data is related to, taken from schema name';
   COMMENT ON COLUMN "SESS_SRCTABLE"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "SESS_SRCTABLE"."LOAD_STATUS" IS 'Status of data load from table';
   COMMENT ON COLUMN "SESS_SRCTABLE"."INSERT_TS" IS 'Timestamp when the record was created';
   COMMENT ON TABLE "SESS_SRCTABLE"  IS 'Daily list of tables for processing';
--------------------------------------------------------
--  DDL for Table SESS_STATUS
--------------------------------------------------------

  CREATE TABLE "SESS_STATUS" 
   (	"JOB_ID" NUMBER(38,0), 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"STREAM_NAME" VARCHAR2(128 BYTE), 
	"STATUS_TS" TIMESTAMP (6), 
	"LOAD_DATE" DATE, 
	"STATUS" NUMBER(38,0), 
	"N_RUN" NUMBER(38,0), 
	"SIGNAL" VARCHAR2(16 BYTE), 
	"APPLICATION_ID" NUMBER(38,0), 
	"ENGINE_ID" NUMBER(38,0), 
	"SYSTEM_NAME" VARCHAR2(128 BYTE)
   ) ;

   COMMENT ON COLUMN "SESS_STATUS"."JOB_ID" IS 'Job identification';
   COMMENT ON COLUMN "SESS_STATUS"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "SESS_STATUS"."STREAM_NAME" IS 'Name of the stream';
   COMMENT ON COLUMN "SESS_STATUS"."STATUS_TS" IS 'Timestamp of status change';
   COMMENT ON COLUMN "SESS_STATUS"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "SESS_STATUS"."STATUS" IS 'Job status';
   COMMENT ON COLUMN "SESS_STATUS"."N_RUN" IS 'Number of job launching';
   COMMENT ON COLUMN "SESS_STATUS"."SIGNAL" IS 'Signal which changed the status';
   COMMENT ON COLUMN "SESS_STATUS"."APPLICATION_ID" IS 'Application identification which drives the job';
   COMMENT ON COLUMN "SESS_STATUS"."ENGINE_ID" IS 'Engine ID';
   COMMENT ON COLUMN "SESS_STATUS"."SYSTEM_NAME" IS 'System name where status change was applied';
   COMMENT ON TABLE "SESS_STATUS"  IS 'Log table for job status trace';
--------------------------------------------------------
--  DDL for Table STAT_JOB_STATISTICS
--------------------------------------------------------

  CREATE TABLE "STAT_JOB_STATISTICS" 
   (	"JOB_NAME" VARCHAR2(128 BYTE), 
	"LOAD_DATE" DATE, 
	"DAY_IN_WEEK" NUMBER(38,0), 
	"DAY_IN_MONTH" NUMBER(38,0), 
	"FIRST_START_TS" TIMESTAMP (6), 
	"LAST_START_TS" TIMESTAMP (6), 
	"LAST_STATUS_TS" TIMESTAMP (6), 
	"END_TS" TIMESTAMP (6), 
	"LAST_STATUS" NUMBER(38,0), 
	"N_RUN" NUMBER(38,0), 
	"AVG_DURATION" NUMBER(38,0), 
	"AVG_END_TM" NUMBER(38,0), 
	"ENGINE_ID" NUMBER(38,0), 
	"IGNORE_STAT" NUMBER(38,0), 
	"DWH_DATE" DATE
   ) ;

   COMMENT ON COLUMN "STAT_JOB_STATISTICS"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "STAT_JOB_STATISTICS"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "STAT_JOB_STATISTICS"."DAY_IN_WEEK" IS 'Day in week, Monday=1, Sunday=7';
   COMMENT ON COLUMN "STAT_JOB_STATISTICS"."DAY_IN_MONTH" IS 'Day in month, ultimo=999';
   COMMENT ON COLUMN "STAT_JOB_STATISTICS"."FIRST_START_TS" IS 'Timestamp when job was launched the first time';
   COMMENT ON COLUMN "STAT_JOB_STATISTICS"."LAST_START_TS" IS 'Timestamp when job was launched the last time';
   COMMENT ON COLUMN "STAT_JOB_STATISTICS"."LAST_STATUS_TS" IS 'Timestamp of last status change';
   COMMENT ON COLUMN "STAT_JOB_STATISTICS"."END_TS" IS 'Timestamp when job finished';
   COMMENT ON COLUMN "STAT_JOB_STATISTICS"."LAST_STATUS" IS 'Last status of the job';
   COMMENT ON COLUMN "STAT_JOB_STATISTICS"."N_RUN" IS 'Number of job launch';
   COMMENT ON COLUMN "STAT_JOB_STATISTICS"."AVG_DURATION" IS 'Average duration';
   COMMENT ON COLUMN "STAT_JOB_STATISTICS"."AVG_END_TM" IS 'Average time when job finished';
   COMMENT ON COLUMN "STAT_JOB_STATISTICS"."ENGINE_ID" IS 'Engine identification';
   COMMENT ON COLUMN "STAT_JOB_STATISTICS"."IGNORE_STAT" IS 'If statistics is used for counting, ignore_stat=0';
   COMMENT ON COLUMN "STAT_JOB_STATISTICS"."DWH_DATE" IS 'DWH date';
   COMMENT ON TABLE "STAT_JOB_STATISTICS"  IS 'History of job statistics';
--------------------------------------------------------
--  DDL for Table STAT_LOG_EVENT_HIST
--------------------------------------------------------

  CREATE TABLE "STAT_LOG_EVENT_HIST" 
   (	"LOG_EVENT_ID" NUMBER(38,0), 
	"EVENT_TS" TIMESTAMP (8), 
	"NOTIFICATION_CD" NUMBER(38,0), 
	"LOAD_DATE" DATE, 
	"JOB_NAME" VARCHAR2(2048 BYTE), 
	"JOB_ID" NUMBER(38,0), 
	"SEVERITY_LEVEL_CD" NUMBER(38,0), 
	"ERROR_CD" VARCHAR2(2048 BYTE), 
	"EVENT_CD" NUMBER(38,0), 
	"EVENT_DS" VARCHAR2(2048 BYTE), 
	"START_TS" TIMESTAMP (8), 
	"END_TS" TIMESTAMP (8), 
	"TRACKING_DURATION" NUMBER, 
	"LAST_STATUS" TIMESTAMP (8), 
	"N_RUN" NUMBER(38,0), 
	"CHECKED_STATUS" NUMBER(38,0), 
	"MAX_N_RUN" NUMBER(38,0), 
	"AVG_DURARION_TOLERANCE" NUMBER(38,0), 
	"AVG_END_TM_TOLERANCE" NUMBER(38,0), 
	"ACTUAL_VALUE" NUMBER(38,0), 
	"THRESHOLD" NUMBER(38,0), 
	"OBJECT_NAME" VARCHAR2(2048 BYTE), 
	"NOTE" VARCHAR2(2048 BYTE), 
	"SENT_TS" TIMESTAMP (8), 
	"DWH_DATE" DATE, 
	"ENGINE_ID" NUMBER(38,0), 
	"RECOMMENDATION_DS" VARCHAR2(2048 BYTE), 
	"SYSTEM_NAME" VARCHAR2(128 BYTE)
   ) ;

   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."LOG_EVENT_ID" IS 'Log event id';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."EVENT_TS" IS 'Event timestamp';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."NOTIFICATION_CD" IS 'Notification code';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."JOB_ID" IS 'Job identification';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."SEVERITY_LEVEL_CD" IS 'Severity level code';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."ERROR_CD" IS 'Error code';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."EVENT_CD" IS 'Error code';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."EVENT_DS" IS 'Event description';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."TRACKING_DURATION" IS 'Job toughness';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."LAST_STATUS" IS 'Last status of the job';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."N_RUN" IS 'Actual number of job launch';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."CHECKED_STATUS" IS 'Which job status has to be notified';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."MAX_N_RUN" IS 'Number of restarts for notification';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."AVG_DURARION_TOLERANCE" IS 'Number of second passed before event Job duration overrun is generated';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."AVG_END_TM_TOLERANCE" IS 'Number of second passed before event Job end overrun is generated';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."ACTUAL_VALUE" IS 'Actual value of checked attirbute';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."THRESHOLD" IS 'min. num of jobs when toughness reservation is applied';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."OBJECT_NAME" IS 'Object name';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."NOTE" IS 'Note';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."SENT_TS" IS 'Message sending timestamp';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."DWH_DATE" IS 'DWH date';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."ENGINE_ID" IS 'Engine identification';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."RECOMMENDATION_DS" IS 'Recommendattion description';
   COMMENT ON COLUMN "STAT_LOG_EVENT_HIST"."SYSTEM_NAME" IS 'System which processed the job';
   COMMENT ON TABLE "STAT_LOG_EVENT_HIST"  IS 'Events found by Framework checker';
--------------------------------------------------------
--  DDL for Table STAT_LOG_MESSAGE_HIST
--------------------------------------------------------

  CREATE TABLE "STAT_LOG_MESSAGE_HIST" 
   (	"LOG_EVENT_ID" NUMBER(38,0), 
	"ERROR_CD" VARCHAR2(2048 BYTE), 
	"ENGINE_NAME" VARCHAR2(2048 BYTE), 
	"JOB_NAME" VARCHAR2(2048 BYTE), 
	"JOB_ID" NUMBER(38,0), 
	"SEVERITY" VARCHAR2(2048 BYTE), 
	"NOTIFICATION_TYPE_CD" NUMBER(38,0), 
	"EVENT_DS" VARCHAR2(2048 BYTE), 
	"RECOMMENDATION_DS" VARCHAR2(2048 BYTE), 
	"NOTE" VARCHAR2(2048 BYTE), 
	"ADDRESS" VARCHAR2(2048 BYTE), 
	"DETECTED_TS" TIMESTAMP (6), 
	"SENT_TS" TIMESTAMP (6), 
	"SYSTEM_NAME" VARCHAR2(128 BYTE)
   ) ;

   COMMENT ON COLUMN "STAT_LOG_MESSAGE_HIST"."LOG_EVENT_ID" IS 'Log event id';
   COMMENT ON COLUMN "STAT_LOG_MESSAGE_HIST"."ERROR_CD" IS 'Error code';
   COMMENT ON COLUMN "STAT_LOG_MESSAGE_HIST"."ENGINE_NAME" IS 'Engine name';
   COMMENT ON COLUMN "STAT_LOG_MESSAGE_HIST"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "STAT_LOG_MESSAGE_HIST"."JOB_ID" IS 'Job identification';
   COMMENT ON COLUMN "STAT_LOG_MESSAGE_HIST"."SEVERITY" IS 'Severity';
   COMMENT ON COLUMN "STAT_LOG_MESSAGE_HIST"."NOTIFICATION_TYPE_CD" IS 'Channel used for notification';
   COMMENT ON COLUMN "STAT_LOG_MESSAGE_HIST"."EVENT_DS" IS 'Event description';
   COMMENT ON COLUMN "STAT_LOG_MESSAGE_HIST"."RECOMMENDATION_DS" IS 'Recommendattion description';
   COMMENT ON COLUMN "STAT_LOG_MESSAGE_HIST"."NOTE" IS 'Note';
   COMMENT ON COLUMN "STAT_LOG_MESSAGE_HIST"."DETECTED_TS" IS 'Timetamp when issue was identified';
   COMMENT ON COLUMN "STAT_LOG_MESSAGE_HIST"."SENT_TS" IS 'Message sending timestamp';
   COMMENT ON COLUMN "STAT_LOG_MESSAGE_HIST"."SYSTEM_NAME" IS 'System which processed the job';
   COMMENT ON TABLE "STAT_LOG_MESSAGE_HIST"  IS 'History of sent messages';
--------------------------------------------------------
--  DDL for Table STAT_MAN_BATCH
--------------------------------------------------------

  CREATE TABLE "STAT_MAN_BATCH" 
   (	"MAN_BATCH_ID" NUMBER(*,0), 
	"MAN_BATCH_BUS_DATE" DATE, 
	"MAN_BATCH_CURR_DATE" TIMESTAMP (6), 
	"MAN_BATCH_DESC" VARCHAR2(2048 BYTE)
   ) ;

   COMMENT ON COLUMN "STAT_MAN_BATCH"."MAN_BATCH_ID" IS 'ID of manual batch';
   COMMENT ON COLUMN "STAT_MAN_BATCH"."MAN_BATCH_BUS_DATE" IS 'Bussiness date';
   COMMENT ON COLUMN "STAT_MAN_BATCH"."MAN_BATCH_CURR_DATE" IS 'Creation timestamp';
   COMMENT ON COLUMN "STAT_MAN_BATCH"."MAN_BATCH_DESC" IS 'Manual batch description';
--------------------------------------------------------
--  DDL for Table STAT_SCHEMA_LOAD_HIST
--------------------------------------------------------

  CREATE TABLE "STAT_SCHEMA_LOAD_HIST" 
   (	"SCHEMA_NAME" VARCHAR2(128 BYTE), 
	"LOAD_DATE" DATE
   ) ;

   COMMENT ON COLUMN "STAT_SCHEMA_LOAD_HIST"."SCHEMA_NAME" IS 'Name of the schema';
   COMMENT ON COLUMN "STAT_SCHEMA_LOAD_HIST"."LOAD_DATE" IS 'Load date';
   COMMENT ON TABLE "STAT_SCHEMA_LOAD_HIST"  IS 'Hisory of schema processing';
--------------------------------------------------------
--  DDL for Table STAT_SOURCE_LOAD_HIST
--------------------------------------------------------

  CREATE TABLE "STAT_SOURCE_LOAD_HIST" 
   (	"SOURCE_ID" NUMBER(*,0), 
	"EFF_LOAD_DATE" DATE, 
	"SCHEMA_NAME" VARCHAR2(128 BYTE), 
	"LOAD_DATE" DATE, 
	"LOAD_STATUS" VARCHAR2(16 BYTE)
   ) ;

   COMMENT ON COLUMN "STAT_SOURCE_LOAD_HIST"."SOURCE_ID" IS 'Source identification';
   COMMENT ON COLUMN "STAT_SOURCE_LOAD_HIST"."EFF_LOAD_DATE" IS 'Date which the data is related to';
   COMMENT ON COLUMN "STAT_SOURCE_LOAD_HIST"."SCHEMA_NAME" IS 'Name of the schema';
   COMMENT ON COLUMN "STAT_SOURCE_LOAD_HIST"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "STAT_SOURCE_LOAD_HIST"."LOAD_STATUS" IS 'Status of data load from source';
   COMMENT ON TABLE "STAT_SOURCE_LOAD_HIST"  IS 'History of source load';
--------------------------------------------------------
--  DDL for Table STAT_SRCTABLE
--------------------------------------------------------

  CREATE TABLE "STAT_SRCTABLE" 
   (	"COMMON_TABLE_NAME" VARCHAR2(128 BYTE), 
	"INCREMENT_DATE" DATE, 
	"SNAPSHOT_DATE" DATE
   ) ;

   COMMENT ON COLUMN "STAT_SRCTABLE"."COMMON_TABLE_NAME" IS 'Table name of full table, for C and S table junction';
   COMMENT ON COLUMN "STAT_SRCTABLE"."INCREMENT_DATE" IS 'Date of last table update by data from increment or snapshot table type';
   COMMENT ON COLUMN "STAT_SRCTABLE"."SNAPSHOT_DATE" IS 'Date of last table update by data from increment table type';
   COMMENT ON TABLE "STAT_SRCTABLE"  IS 'Memory for last processing date remember';
--------------------------------------------------------
--  DDL for Table STAT_SRCTABLE_LOAD_HIST
--------------------------------------------------------

  CREATE TABLE "STAT_SRCTABLE_LOAD_HIST" 
   (	"TABLE_NAME" VARCHAR2(128 BYTE), 
	"LOG_NAME" VARCHAR2(128 BYTE), 
	"COMMON_TABLE_NAME" VARCHAR2(128 BYTE), 
	"SCHEMA_NAME" VARCHAR2(128 BYTE), 
	"SOURCE_ID" NUMBER(*,0), 
	"JOB_ID" NUMBER(*,0), 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"EFF_LOAD_DATE" DATE, 
	"LOAD_DATE" DATE, 
	"LOAD_STATUS" VARCHAR2(16 BYTE)
   ) ;

   COMMENT ON COLUMN "STAT_SRCTABLE_LOAD_HIST"."TABLE_NAME" IS 'Table name';
   COMMENT ON COLUMN "STAT_SRCTABLE_LOAD_HIST"."LOG_NAME" IS 'Name of the log';
   COMMENT ON COLUMN "STAT_SRCTABLE_LOAD_HIST"."COMMON_TABLE_NAME" IS 'Table name for table type junction';
   COMMENT ON COLUMN "STAT_SRCTABLE_LOAD_HIST"."SCHEMA_NAME" IS 'Schema name where table was found';
   COMMENT ON COLUMN "STAT_SRCTABLE_LOAD_HIST"."SOURCE_ID" IS 'Source identification which table belongs to';
   COMMENT ON COLUMN "STAT_SRCTABLE_LOAD_HIST"."JOB_ID" IS 'Job identification prepared for table processing';
   COMMENT ON COLUMN "STAT_SRCTABLE_LOAD_HIST"."JOB_NAME" IS 'Job name of job prepared for table processing';
   COMMENT ON COLUMN "STAT_SRCTABLE_LOAD_HIST"."EFF_LOAD_DATE" IS 'Date which the data is related to, taken from schema name';
   COMMENT ON COLUMN "STAT_SRCTABLE_LOAD_HIST"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "STAT_SRCTABLE_LOAD_HIST"."LOAD_STATUS" IS 'Status of data load from table';
   COMMENT ON TABLE "STAT_SRCTABLE_LOAD_HIST"  IS 'Hisory of table processing';
--------------------------------------------------------
--  DDL for Table STAT_SRCTABLE_REVOKED_PROCESS
--------------------------------------------------------

  CREATE TABLE "STAT_SRCTABLE_REVOKED_PROCESS" 
   (	"TABLE_NAME" VARCHAR2(128 BYTE), 
	"LOG_NAME" VARCHAR2(128 BYTE), 
	"SCHEMA_NAME" VARCHAR2(128 BYTE), 
	"COMMON_TABLE_NAME" VARCHAR2(128 BYTE), 
	"TABLE_TYPE" CHAR(1 BYTE), 
	"SOURCE_NM" VARCHAR2(128 BYTE), 
	"EFF_LOAD_DATE" DATE, 
	"LOAD_DATE" DATE, 
	"INSERTED_TS" TIMESTAMP (6), 
	"OPERATED_TS" TIMESTAMP (6), 
	"REASON" VARCHAR2(128 BYTE)
   ) ;

   COMMENT ON COLUMN "STAT_SRCTABLE_REVOKED_PROCESS"."TABLE_NAME" IS 'Table name';
   COMMENT ON COLUMN "STAT_SRCTABLE_REVOKED_PROCESS"."LOG_NAME" IS 'Log name';
   COMMENT ON COLUMN "STAT_SRCTABLE_REVOKED_PROCESS"."SCHEMA_NAME" IS 'Schema name which table was supplied in';
   COMMENT ON COLUMN "STAT_SRCTABLE_REVOKED_PROCESS"."COMMON_TABLE_NAME" IS 'Table name for table type junction';
   COMMENT ON COLUMN "STAT_SRCTABLE_REVOKED_PROCESS"."TABLE_TYPE" IS 'Kind of the table';
   COMMENT ON COLUMN "STAT_SRCTABLE_REVOKED_PROCESS"."SOURCE_NM" IS 'Source short name';
   COMMENT ON COLUMN "STAT_SRCTABLE_REVOKED_PROCESS"."EFF_LOAD_DATE" IS 'Date which the data is related to, taken from schema name';
   COMMENT ON COLUMN "STAT_SRCTABLE_REVOKED_PROCESS"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "STAT_SRCTABLE_REVOKED_PROCESS"."INSERTED_TS" IS 'Timestamp when the record was created';
   COMMENT ON COLUMN "STAT_SRCTABLE_REVOKED_PROCESS"."OPERATED_TS" IS 'Timestamp whne the record was processed';
   COMMENT ON COLUMN "STAT_SRCTABLE_REVOKED_PROCESS"."REASON" IS 'Revoke reason';
   COMMENT ON TABLE "STAT_SRCTABLE_REVOKED_PROCESS"  IS 'List of tables which were revoked from processing';
--------------------------------------------------------
--  DDL for Table STAT_STATUS
--------------------------------------------------------

  CREATE TABLE "STAT_STATUS" 
   (	"JOB_ID" NUMBER(38,0), 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"STREAM_NAME" VARCHAR2(128 BYTE), 
	"STATUS_TS" TIMESTAMP (6), 
	"LOAD_DATE" DATE, 
	"STATUS" NUMBER(38,0), 
	"N_RUN" NUMBER(38,0), 
	"SIGNAL" VARCHAR2(16 BYTE), 
	"APPLICATION_ID" NUMBER(38,0), 
	"ENGINE_ID" NUMBER(38,0), 
	"SYSTEM_NAME" VARCHAR2(128 BYTE), 
	"DWH_DATE" DATE
   ) ;

   COMMENT ON COLUMN "STAT_STATUS"."JOB_ID" IS 'Job identification';
   COMMENT ON COLUMN "STAT_STATUS"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "STAT_STATUS"."STREAM_NAME" IS 'Name of the stream';
   COMMENT ON COLUMN "STAT_STATUS"."STATUS_TS" IS 'Timestamp of status change';
   COMMENT ON COLUMN "STAT_STATUS"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "STAT_STATUS"."STATUS" IS 'Job status';
   COMMENT ON COLUMN "STAT_STATUS"."N_RUN" IS 'Number of job launching';
   COMMENT ON COLUMN "STAT_STATUS"."SIGNAL" IS 'Signal which changed the status';
   COMMENT ON COLUMN "STAT_STATUS"."APPLICATION_ID" IS 'Application identification which drives the job';
   COMMENT ON COLUMN "STAT_STATUS"."ENGINE_ID" IS 'Engine ID';
   COMMENT ON COLUMN "STAT_STATUS"."SYSTEM_NAME" IS 'System name where status change was applied';
   COMMENT ON COLUMN "STAT_STATUS"."DWH_DATE" IS 'DWH date';
   COMMENT ON TABLE "STAT_STATUS"  IS 'History table for job status trace';
--------------------------------------------------------
--  DDL for Table TEMP_CRTP_DEPENDENCY_GRAPH
--------------------------------------------------------

  CREATE TABLE "TEMP_CRTP_DEPENDENCY_GRAPH" 
   (	"JOB_ID" NUMBER(*,0), 
	"PARENT_JOB_ID" NUMBER(*,0), 
	"DURATION" NUMBER(38,2), 
	"LOAD_DATE" DATE, 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"PARENT_JOB_NAME" VARCHAR2(128 BYTE), 
	"ENGINE_ID" NUMBER(38,0)
   ) ;

   COMMENT ON COLUMN "TEMP_CRTP_DEPENDENCY_GRAPH"."JOB_ID" IS 'Job identification';
   COMMENT ON COLUMN "TEMP_CRTP_DEPENDENCY_GRAPH"."PARENT_JOB_ID" IS 'Parent job name identification';
   COMMENT ON COLUMN "TEMP_CRTP_DEPENDENCY_GRAPH"."DURATION" IS 'Job duration';
   COMMENT ON COLUMN "TEMP_CRTP_DEPENDENCY_GRAPH"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "TEMP_CRTP_DEPENDENCY_GRAPH"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "TEMP_CRTP_DEPENDENCY_GRAPH"."PARENT_JOB_NAME" IS 'Parent job name';
   COMMENT ON COLUMN "TEMP_CRTP_DEPENDENCY_GRAPH"."ENGINE_ID" IS 'Engine identification';
   COMMENT ON TABLE "TEMP_CRTP_DEPENDENCY_GRAPH"  IS 'Critical path dependency graph';
--------------------------------------------------------
--  DDL for Table TEMP_CRTP_JOB_DISTANCES
--------------------------------------------------------

  CREATE TABLE "TEMP_CRTP_JOB_DISTANCES" 
   (	"ENGINE_ID" NUMBER(38,0), 
	"JOB_ID" NUMBER(*,0), 
	"DISTANCE" BINARY_DOUBLE, 
	"PREDECESSOR_JOB_ID" NUMBER(*,0), 
	"LOAD_DATE" DATE, 
	"ORDER_ON_CRITICAL_PATH" NUMBER(*,0)
   ) ;

   COMMENT ON COLUMN "TEMP_CRTP_JOB_DISTANCES"."ENGINE_ID" IS 'Engine identification';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_DISTANCES"."JOB_ID" IS 'Job identification';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_DISTANCES"."DISTANCE" IS 'Distance';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_DISTANCES"."PREDECESSOR_JOB_ID" IS 'Job id of previous job on critical path';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_DISTANCES"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_DISTANCES"."ORDER_ON_CRITICAL_PATH" IS 'Job order on critical path (-1 = not on critical path)';
   COMMENT ON TABLE "TEMP_CRTP_JOB_DISTANCES"  IS 'Temp table for critical path calculation';
--------------------------------------------------------
--  DDL for Table TEMP_CRTP_JOB_STATISTICS
--------------------------------------------------------

  CREATE TABLE "TEMP_CRTP_JOB_STATISTICS" 
   (	"JOB_NAME" VARCHAR2(128 BYTE), 
	"LOAD_DATE" DATE, 
	"DAY_IN_WEEK" NUMBER(38,0), 
	"DAY_IN_MONTH" NUMBER(38,0), 
	"FIRST_START_TS" TIMESTAMP (6), 
	"LAST_START_TS" TIMESTAMP (6), 
	"LAST_STATUS_TS" TIMESTAMP (6), 
	"END_TS" TIMESTAMP (6), 
	"LAST_STATUS" NUMBER(38,0), 
	"N_RUN" NUMBER(38,0), 
	"AVG_DURATION" NUMBER(38,0), 
	"AVG_END_TM" NUMBER(38,0), 
	"ENGINE_ID" NUMBER(38,0), 
	"IGNORE_STAT" NUMBER(38,0), 
	"DWH_DATE" DATE
   ) ;

   COMMENT ON COLUMN "TEMP_CRTP_JOB_STATISTICS"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_STATISTICS"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_STATISTICS"."DAY_IN_WEEK" IS 'Day in week, Monday=1, Sunday=7';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_STATISTICS"."DAY_IN_MONTH" IS 'Day in month, ultimo=999';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_STATISTICS"."FIRST_START_TS" IS 'Timestamp when job was launched the first time';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_STATISTICS"."LAST_START_TS" IS 'Timestamp when job was launched the last time';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_STATISTICS"."LAST_STATUS_TS" IS 'Timestamp of last status change';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_STATISTICS"."END_TS" IS 'Timestamp when job finished';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_STATISTICS"."LAST_STATUS" IS 'Last status of the job';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_STATISTICS"."N_RUN" IS 'Number of job launch';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_STATISTICS"."AVG_DURATION" IS 'Average duration';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_STATISTICS"."AVG_END_TM" IS 'Average time when job finished';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_STATISTICS"."ENGINE_ID" IS 'Engine identification';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_STATISTICS"."IGNORE_STAT" IS 'If statistics is used for counting, ignore_stat=0';
   COMMENT ON COLUMN "TEMP_CRTP_JOB_STATISTICS"."DWH_DATE" IS 'DWH date';
   COMMENT ON TABLE "TEMP_CRTP_JOB_STATISTICS"  IS 'Job statistics used for critical path calculation';
--------------------------------------------------------
--  DDL for Table TEMP_ENG_JOB_POSSIBLE
--------------------------------------------------------

  CREATE TABLE "TEMP_ENG_JOB_POSSIBLE" 
   (	"SEQ" NUMBER(38,0), 
	"JOB_ID" NUMBER(38,0), 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"PRIORITY" NUMBER(38,0), 
	"STATUS" NUMBER(38,0), 
	"N_RUN" NUMBER(38,0), 
	"JOB_TYPE" VARCHAR2(32 BYTE), 
	"TOUGHNESS" NUMBER(38,0), 
	"CMD_LINE" VARCHAR2(1024 BYTE), 
	"PARENT_JOB_CATEGORY" VARCHAR2(128 BYTE), 
	"JOB_CATEGORY" VARCHAR2(32 BYTE), 
	"ENGINE_ID" NUMBER(38,0)
   ) ;

   COMMENT ON COLUMN "TEMP_ENG_JOB_POSSIBLE"."SEQ" IS 'Sequence';
   COMMENT ON COLUMN "TEMP_ENG_JOB_POSSIBLE"."JOB_ID" IS 'Job identification';
   COMMENT ON COLUMN "TEMP_ENG_JOB_POSSIBLE"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "TEMP_ENG_JOB_POSSIBLE"."PRIORITY" IS 'Priority of the job, less number means higher priority';
   COMMENT ON COLUMN "TEMP_ENG_JOB_POSSIBLE"."STATUS" IS 'Current status of the job';
   COMMENT ON COLUMN "TEMP_ENG_JOB_POSSIBLE"."N_RUN" IS 'Actual number of job launch';
   COMMENT ON COLUMN "TEMP_ENG_JOB_POSSIBLE"."JOB_TYPE" IS 'Kind of job';
   COMMENT ON COLUMN "TEMP_ENG_JOB_POSSIBLE"."TOUGHNESS" IS 'Job toughness';
   COMMENT ON COLUMN "TEMP_ENG_JOB_POSSIBLE"."CMD_LINE" IS 'Command line of the job';
   COMMENT ON COLUMN "TEMP_ENG_JOB_POSSIBLE"."PARENT_JOB_CATEGORY" IS 'Parent job category for parallelism control ';
   COMMENT ON COLUMN "TEMP_ENG_JOB_POSSIBLE"."JOB_CATEGORY" IS 'Category of the job. Suitable for parallelism control';
   COMMENT ON COLUMN "TEMP_ENG_JOB_POSSIBLE"."ENGINE_ID" IS 'Engine id which can process the job';
   COMMENT ON TABLE "TEMP_ENG_JOB_POSSIBLE"  IS 'Temp table used by get job list process - possible jobs to run';
--------------------------------------------------------
--  DDL for Table TEMP_ENG_JOB_READY
--------------------------------------------------------

  CREATE TABLE "TEMP_ENG_JOB_READY" 
   (	"JOB_ID" NUMBER(38,0), 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"JOB_AVAILABILITY" NUMBER(38,0), 
	"JOB_TYPE" VARCHAR2(32 BYTE), 
	"JOB_CATEGORY" VARCHAR2(32 BYTE), 
	"CMD_LINE" VARCHAR2(1024 BYTE), 
	"QUEUE_NUMBER" NUMBER(38,0), 
	"LOAD_DATE" DATE, 
	"ENGINE_ID" NUMBER(38,0)
   ) ;

   COMMENT ON COLUMN "TEMP_ENG_JOB_READY"."JOB_ID" IS 'Job identification';
   COMMENT ON COLUMN "TEMP_ENG_JOB_READY"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "TEMP_ENG_JOB_READY"."JOB_AVAILABILITY" IS 'Job Availability';
   COMMENT ON COLUMN "TEMP_ENG_JOB_READY"."JOB_TYPE" IS 'Kind of job';
   COMMENT ON COLUMN "TEMP_ENG_JOB_READY"."JOB_CATEGORY" IS 'Category of the job. Suitable for parallelism control';
   COMMENT ON COLUMN "TEMP_ENG_JOB_READY"."CMD_LINE" IS 'Command line of the job';
   COMMENT ON COLUMN "TEMP_ENG_JOB_READY"."QUEUE_NUMBER" IS 'Queue number';
   COMMENT ON COLUMN "TEMP_ENG_JOB_READY"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "TEMP_ENG_JOB_READY"."ENGINE_ID" IS 'Engine id which can process the job';
   COMMENT ON TABLE "TEMP_ENG_JOB_READY"  IS 'Temp table used by get job list process - jobs to run';
--------------------------------------------------------
--  DDL for Table TEMP_ENG_JOB_RUNNING
--------------------------------------------------------

  CREATE TABLE "TEMP_ENG_JOB_RUNNING" 
   (	"JOB_ID" NUMBER(38,0), 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"JOB_TYPE" VARCHAR2(32 BYTE), 
	"TOUGHNESS" NUMBER(38,0), 
	"DATABASE_NAME" VARCHAR2(128 BYTE), 
	"TABLE_NAME" VARCHAR2(128 BYTE), 
	"LOCK_TYPE" CHAR(1 BYTE), 
	"JOB_CATEGORY" VARCHAR2(32 BYTE), 
	"IS_RUNNING" NUMBER(38,0), 
	"ENGINE_ID" NUMBER(38,0), 
	"SYSTEM_NAME" VARCHAR2(128 BYTE)
   ) ;

   COMMENT ON COLUMN "TEMP_ENG_JOB_RUNNING"."JOB_ID" IS 'Job identification';
   COMMENT ON COLUMN "TEMP_ENG_JOB_RUNNING"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "TEMP_ENG_JOB_RUNNING"."JOB_TYPE" IS 'Kind of job';
   COMMENT ON COLUMN "TEMP_ENG_JOB_RUNNING"."TOUGHNESS" IS 'Job toughness';
   COMMENT ON COLUMN "TEMP_ENG_JOB_RUNNING"."DATABASE_NAME" IS 'Database name which job is working with';
   COMMENT ON COLUMN "TEMP_ENG_JOB_RUNNING"."TABLE_NAME" IS 'Table name which job is working with';
   COMMENT ON COLUMN "TEMP_ENG_JOB_RUNNING"."LOCK_TYPE" IS 'Lock type, W=write, R=read';
   COMMENT ON COLUMN "TEMP_ENG_JOB_RUNNING"."JOB_CATEGORY" IS 'Category of the job. Suitable for parallelism control';
   COMMENT ON COLUMN "TEMP_ENG_JOB_RUNNING"."IS_RUNNING" IS 'Is job running?';
   COMMENT ON COLUMN "TEMP_ENG_JOB_RUNNING"."ENGINE_ID" IS 'Engine id which can process the job';
   COMMENT ON COLUMN "TEMP_ENG_JOB_RUNNING"."SYSTEM_NAME" IS 'System which process the job';
   COMMENT ON TABLE "TEMP_ENG_JOB_RUNNING"  IS 'Temp table used by get job list process - currently running jobs';
--------------------------------------------------------
--  DDL for Table TEMP_ENG_QUEUE
--------------------------------------------------------

  CREATE TABLE "TEMP_ENG_QUEUE" 
   (	"SEQ" NUMBER(38,0), 
	"QUEUE_NUMBER" NUMBER(38,0), 
	"ENGINE_ID" NUMBER(38,0)
   ) ;

   COMMENT ON COLUMN "TEMP_ENG_QUEUE"."SEQ" IS 'Sequence';
   COMMENT ON COLUMN "TEMP_ENG_QUEUE"."QUEUE_NUMBER" IS 'Queue number';
   COMMENT ON COLUMN "TEMP_ENG_QUEUE"."ENGINE_ID" IS 'Engine id for which is queue determine';
   COMMENT ON TABLE "TEMP_ENG_QUEUE"  IS 'Temp table used by get job list process - queue list';
--------------------------------------------------------
--  DDL for Table TEMP_GUI_SHOW_LOGS
--------------------------------------------------------

  CREATE GLOBAL TEMPORARY TABLE "TEMP_GUI_SHOW_LOGS" 
   (	"JOB_ID" NUMBER(28,0), 
	"URL_PATH" VARCHAR2(1000 BYTE), 
	"LOG_NAME" VARCHAR2(250 BYTE), 
	"FILE_NAME" VARCHAR2(500 BYTE)
   ) ON COMMIT PRESERVE ROWS ;

   COMMENT ON COLUMN "TEMP_GUI_SHOW_LOGS"."JOB_ID" IS 'Job identification';
   COMMENT ON COLUMN "TEMP_GUI_SHOW_LOGS"."URL_PATH" IS 'calculated URL with log';
   COMMENT ON COLUMN "TEMP_GUI_SHOW_LOGS"."LOG_NAME" IS 'Name of the log';
   COMMENT ON COLUMN "TEMP_GUI_SHOW_LOGS"."FILE_NAME" IS 'file name which is shown in popup window';
   COMMENT ON TABLE "TEMP_GUI_SHOW_LOGS"  IS 'Temp table used for getting URL to show log';
--------------------------------------------------------
--  DDL for Table TEMP_INIT_PLAN
--------------------------------------------------------

  CREATE TABLE "TEMP_INIT_PLAN" 
   (	"RUNPLAN" CHAR(9 BYTE), 
	"LOAD_DATE" DATE, 
	"STATUS" NUMBER(38,0), 
	"ENGINE_ID" NUMBER(38,0), 
	"COUNTRY_CD" VARCHAR2(4 BYTE)
   ) ;

   COMMENT ON COLUMN "TEMP_INIT_PLAN"."RUNPLAN" IS 'Run plan';
   COMMENT ON COLUMN "TEMP_INIT_PLAN"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "TEMP_INIT_PLAN"."STATUS" IS 'Begin status of the job';
   COMMENT ON COLUMN "TEMP_INIT_PLAN"."ENGINE_ID" IS 'Engine id which can process the job';
   COMMENT ON COLUMN "TEMP_INIT_PLAN"."COUNTRY_CD" IS 'Country code';
   COMMENT ON TABLE "TEMP_INIT_PLAN"  IS 'Status to plan assignment for load date';
--------------------------------------------------------
--  DDL for Table TEMP_PARALLELISM_CONTROL
--------------------------------------------------------

  CREATE TABLE "TEMP_PARALLELISM_CONTROL" 
   (	"PARAM_VAL_INT_CURR" NUMBER(38,0), 
	"PARAM_VAL_INT_MAX" NUMBER(38,0), 
	"PARAM_VAL_INT_DEFAULT" NUMBER(38,0), 
	"JOB_CATEGORY" VARCHAR2(128 BYTE), 
	"PARENT_JOB_CATEGORY" VARCHAR2(128 BYTE), 
	"ENGINE_ID" NUMBER(38,0), 
	"SYSTEM_NAME" VARCHAR2(128 BYTE), 
	"OVERLOAD" NUMBER(*,0), 
	"CURR_RUNNING_JOBS" NUMBER(*,0), 
	"TOTAL_TOUGH" NUMBER(*,0), 
	"TASK_MIN_CONTROL" NUMBER(*,0)
   ) ;

   COMMENT ON COLUMN "TEMP_PARALLELISM_CONTROL"."PARAM_VAL_INT_CURR" IS 'toughness sum of currently running jobs';
   COMMENT ON COLUMN "TEMP_PARALLELISM_CONTROL"."PARAM_VAL_INT_MAX" IS 'Maximal threshold which can be reached by category or subcategory';
   COMMENT ON COLUMN "TEMP_PARALLELISM_CONTROL"."PARAM_VAL_INT_DEFAULT" IS 'Default maximal threshold for category or subcategory';
   COMMENT ON COLUMN "TEMP_PARALLELISM_CONTROL"."JOB_CATEGORY" IS 'Category of the job. Suitable for parallelism control';
   COMMENT ON COLUMN "TEMP_PARALLELISM_CONTROL"."PARENT_JOB_CATEGORY" IS 'Parent job category for parallelism control ';
   COMMENT ON COLUMN "TEMP_PARALLELISM_CONTROL"."ENGINE_ID" IS 'Engine identification';
   COMMENT ON COLUMN "TEMP_PARALLELISM_CONTROL"."SYSTEM_NAME" IS 'System which process the job';
   COMMENT ON COLUMN "TEMP_PARALLELISM_CONTROL"."OVERLOAD" IS 'If overload process was done';
   COMMENT ON COLUMN "TEMP_PARALLELISM_CONTROL"."CURR_RUNNING_JOBS" IS 'Current running job counter';
   COMMENT ON COLUMN "TEMP_PARALLELISM_CONTROL"."TOTAL_TOUGH" IS 'Total toughness on category';
   COMMENT ON COLUMN "TEMP_PARALLELISM_CONTROL"."TASK_MIN_CONTROL" IS 'min. num of jobs when toughness reservation is applied';
   COMMENT ON TABLE "TEMP_PARALLELISM_CONTROL"  IS 'Temp table used by get job list process - parallelism control settings evaluation';
--------------------------------------------------------
--  DDL for Table TEMP_V_JOB_POSSIBLE
--------------------------------------------------------

  CREATE TABLE "TEMP_V_JOB_POSSIBLE" 
   (	"SEQ" NUMBER(38,0), 
	"JOB_ID" NUMBER(38,0), 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"PRIORITY" NUMBER(38,0), 
	"STATUS" NUMBER(38,0), 
	"N_RUN" NUMBER(38,0), 
	"JOB_TYPE" VARCHAR2(32 BYTE), 
	"TOUGHNESS" NUMBER(38,0), 
	"CMD_LINE" VARCHAR2(1024 BYTE), 
	"PARENT_JOB_CATEGORY" VARCHAR2(128 BYTE), 
	"JOB_CATEGORY" VARCHAR2(32 BYTE), 
	"ENGINE_ID" NUMBER(38,0)
   ) ;

   COMMENT ON COLUMN "TEMP_V_JOB_POSSIBLE"."SEQ" IS 'Sequence';
   COMMENT ON COLUMN "TEMP_V_JOB_POSSIBLE"."JOB_ID" IS 'Job identification';
   COMMENT ON COLUMN "TEMP_V_JOB_POSSIBLE"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "TEMP_V_JOB_POSSIBLE"."PRIORITY" IS 'Priority of the job, less number means higher priority';
   COMMENT ON COLUMN "TEMP_V_JOB_POSSIBLE"."STATUS" IS 'Job status';
   COMMENT ON COLUMN "TEMP_V_JOB_POSSIBLE"."N_RUN" IS 'Number of job launch';
   COMMENT ON COLUMN "TEMP_V_JOB_POSSIBLE"."JOB_TYPE" IS 'Kind of job';
   COMMENT ON COLUMN "TEMP_V_JOB_POSSIBLE"."TOUGHNESS" IS 'Job toughness';
   COMMENT ON COLUMN "TEMP_V_JOB_POSSIBLE"."CMD_LINE" IS 'Command line of the job';
   COMMENT ON COLUMN "TEMP_V_JOB_POSSIBLE"."PARENT_JOB_CATEGORY" IS 'Parent job category for parallelism control ';
   COMMENT ON COLUMN "TEMP_V_JOB_POSSIBLE"."JOB_CATEGORY" IS 'Category of the job. Suitable for parallelism control';
   COMMENT ON COLUMN "TEMP_V_JOB_POSSIBLE"."ENGINE_ID" IS 'Engine identification';
   COMMENT ON TABLE "TEMP_V_JOB_POSSIBLE"  IS 'Temp table used by SP_GET_JOB_LIST - possible jobs to run';
--------------------------------------------------------
--  DDL for Table TEMP_V_JOB_READY
--------------------------------------------------------

  CREATE TABLE "TEMP_V_JOB_READY" 
   (	"JOB_ID" NUMBER(38,0), 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"JOB_AVAILABILITY" NUMBER(38,0), 
	"JOB_TYPE" VARCHAR2(32 BYTE), 
	"JOB_CATEGORY" VARCHAR2(32 BYTE), 
	"CMD_LINE" VARCHAR2(1024 BYTE), 
	"QUEUE_NUMBER" NUMBER(38,0), 
	"LOAD_DATE" DATE, 
	"ENGINE_ID" NUMBER(38,0)
   ) ;

   COMMENT ON COLUMN "TEMP_V_JOB_READY"."JOB_ID" IS 'Job identification';
   COMMENT ON COLUMN "TEMP_V_JOB_READY"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "TEMP_V_JOB_READY"."JOB_AVAILABILITY" IS 'Job Availability';
   COMMENT ON COLUMN "TEMP_V_JOB_READY"."JOB_TYPE" IS 'Kind of job';
   COMMENT ON COLUMN "TEMP_V_JOB_READY"."JOB_CATEGORY" IS 'Category of the job. Suitable for parallelism control';
   COMMENT ON COLUMN "TEMP_V_JOB_READY"."CMD_LINE" IS 'Command line of the job';
   COMMENT ON COLUMN "TEMP_V_JOB_READY"."QUEUE_NUMBER" IS 'Queue number';
   COMMENT ON COLUMN "TEMP_V_JOB_READY"."LOAD_DATE" IS 'Load date';
   COMMENT ON COLUMN "TEMP_V_JOB_READY"."ENGINE_ID" IS 'Engine identification';
   COMMENT ON TABLE "TEMP_V_JOB_READY"  IS 'Temp table used by SP_GET_JOB_LIST - jobs to run';
--------------------------------------------------------
--  DDL for Table TEMP_V_JOB_RUNNING
--------------------------------------------------------

  CREATE TABLE "TEMP_V_JOB_RUNNING" 
   (	"JOB_ID" NUMBER(38,0), 
	"JOB_NAME" VARCHAR2(128 BYTE), 
	"JOB_TYPE" VARCHAR2(32 BYTE), 
	"TOUGHNESS" NUMBER(38,0), 
	"DATABASE_NAME" VARCHAR2(128 BYTE), 
	"TABLE_NAME" VARCHAR2(128 BYTE), 
	"LOCK_TYPE" CHAR(1 BYTE), 
	"JOB_CATEGORY" VARCHAR2(32 BYTE), 
	"IS_RUNNING" NUMBER(38,0), 
	"ENGINE_ID" NUMBER(38,0), 
	"SYSTEM_NAME" VARCHAR2(128 BYTE)
   ) ;

   COMMENT ON COLUMN "TEMP_V_JOB_RUNNING"."JOB_ID" IS 'Job identification';
   COMMENT ON COLUMN "TEMP_V_JOB_RUNNING"."JOB_NAME" IS 'Name of the job';
   COMMENT ON COLUMN "TEMP_V_JOB_RUNNING"."JOB_TYPE" IS 'Kind of job';
   COMMENT ON COLUMN "TEMP_V_JOB_RUNNING"."TOUGHNESS" IS 'Job toughness';
   COMMENT ON COLUMN "TEMP_V_JOB_RUNNING"."DATABASE_NAME" IS 'Database name which job is working with';
   COMMENT ON COLUMN "TEMP_V_JOB_RUNNING"."TABLE_NAME" IS 'Table name';
   COMMENT ON COLUMN "TEMP_V_JOB_RUNNING"."LOCK_TYPE" IS 'Lock type, W=write, R=read';
   COMMENT ON COLUMN "TEMP_V_JOB_RUNNING"."JOB_CATEGORY" IS 'Category of the job. Suitable for parallelism control';
   COMMENT ON COLUMN "TEMP_V_JOB_RUNNING"."IS_RUNNING" IS 'Is job running?';
   COMMENT ON COLUMN "TEMP_V_JOB_RUNNING"."ENGINE_ID" IS 'Engine identification';
   COMMENT ON COLUMN "TEMP_V_JOB_RUNNING"."SYSTEM_NAME" IS 'System which process the job';
   COMMENT ON TABLE "TEMP_V_JOB_RUNNING"  IS 'Temp table used by SP_GET_JOB_LIST - currently running jobs';
--------------------------------------------------------
--  DDL for Table TEMP_V_QUEUE
--------------------------------------------------------

  CREATE TABLE "TEMP_V_QUEUE" 
   (	"SEQ" NUMBER(38,0), 
	"QUEUE_NUMBER" NUMBER(38,0), 
	"ENGINE_ID" NUMBER(38,0)
   ) ;

   COMMENT ON COLUMN "TEMP_V_QUEUE"."SEQ" IS 'Sequence';
   COMMENT ON COLUMN "TEMP_V_QUEUE"."QUEUE_NUMBER" IS 'Queue number';
   COMMENT ON COLUMN "TEMP_V_QUEUE"."ENGINE_ID" IS 'Engine identification';
   COMMENT ON TABLE "TEMP_V_QUEUE"  IS 'Temp table used by SP_GET_JOB_LIST - queue list';
--------------------------------------------------------
--  DDL for View V_STAT_JOB_STATISTICS_DAY_IM
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "V_STAT_JOB_STATISTICS_DAY_IM" ("PORADI", "JOB_NAME", "LOAD_DATE", "DAY_IN_WEEK", "DAY_IN_MONTH", "FIRST_START_TS", "LAST_START_TS", "LAST_STATUS_TS", "END_TS", "LAST_STATUS", "N_RUN", "AVG_DURATION", "AVG_END_TM", "ENGINE_ID") AS 
  SELECT   PORADI
             , JOB_NAME
             , LOAD_DATE
             , DAY_IN_WEEK
             , DAY_IN_MONTH
             , FIRST_START_TS
             , LAST_START_TS
             , LAST_STATUS_TS
             , END_TS
             , LAST_STATUS
             , N_RUN
             , AVG_DURATION
             , AVG_END_TM
             , ENGINE_ID
        FROM   (SELECT   ROW_NUMBER() OVER (PARTITION BY JOB_NAME, DAY_IN_MONTH ORDER BY LOAD_DATE DESC) PORADI
                       , JOB_NAME
                       , LOAD_DATE
                       , DAY_IN_WEEK
                       , DAY_IN_MONTH
                       , FIRST_START_TS
                       , LAST_START_TS
                       , LAST_STATUS_TS
                       , END_TS
                       , LAST_STATUS
                       , N_RUN
                       , NVL(AVG_DURATION, 0) AVG_DURATION
                       , NVL(AVG_END_TM, 0) AVG_END_TM
                       , ENGINE_ID
                  FROM   STAT_JOB_STATISTICS)
       WHERE   PORADI < 15
    ORDER BY   JOB_NAME, PORADI;
--------------------------------------------------------
--  DDL for View V_STAT_JOB_STATISTICS_DAY_IW
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "V_STAT_JOB_STATISTICS_DAY_IW" ("PORADI", "JOB_NAME", "LOAD_DATE", "DAY_IN_WEEK", "DAY_IN_MONTH", "FIRST_START_TS", "LAST_START_TS", "LAST_STATUS_TS", "END_TS", "LAST_STATUS", "N_RUN", "AVG_DURATION", "AVG_END_TM", "ENGINE_ID") AS 
  SELECT   PORADI
             , JOB_NAME
             , LOAD_DATE
             , DAY_IN_WEEK
             , DAY_IN_MONTH
             , FIRST_START_TS
             , LAST_START_TS
             , LAST_STATUS_TS
             , END_TS
             , LAST_STATUS
             , N_RUN
             , AVG_DURATION
             , AVG_END_TM
             , ENGINE_ID
        FROM   (SELECT   ROW_NUMBER() OVER (PARTITION BY JOB_NAME, DAY_IN_WEEK ORDER BY LOAD_DATE DESC) PORADI
                       , JOB_NAME
                       , LOAD_DATE
                       , DAY_IN_WEEK
                       , DAY_IN_MONTH
                       , FIRST_START_TS
                       , LAST_START_TS
                       , LAST_STATUS_TS
                       , END_TS
                       , LAST_STATUS
                       , N_RUN
                       , NVL(AVG_DURATION, 0) AVG_DURATION
                       , NVL(AVG_END_TM, 0) AVG_END_TM
                       , ENGINE_ID
                  FROM   STAT_JOB_STATISTICS)
       WHERE   PORADI < 15
    ORDER BY   JOB_NAME, PORADI;
--------------------------------------------------------
--  DDL for Index CTRL_JOB_TABLE_REF_UK1
--------------------------------------------------------

  CREATE UNIQUE INDEX "CTRL_JOB_TABLE_REF_UK1" ON "CTRL_JOB_TABLE_REF" ("JOB_NAME", "DATABASE_NAME", "TABLE_NAME") 
  ;
--------------------------------------------------------
--  DDL for Index IDX_JOB_ID
--------------------------------------------------------

  CREATE UNIQUE INDEX "IDX_JOB_ID" ON "SESS_JOB" ("JOB_ID") 
  ;
--------------------------------------------------------
--  DDL for Index IDX_SESS_JOB_TASK_TYPE
--------------------------------------------------------

  CREATE INDEX "IDX_SESS_JOB_TASK_TYPE" ON "SESS_JOB" ("JOB_CATEGORY") 
  ;
--------------------------------------------------------
--  DDL for Index IDX_SJD_JOB_ID
--------------------------------------------------------

  CREATE INDEX "IDX_SJD_JOB_ID" ON "SESS_JOB_DEPENDENCY" ("JOB_ID") 
  ;
--------------------------------------------------------
--  DDL for Index JOB_NAME_UNIQUE
--------------------------------------------------------

  CREATE UNIQUE INDEX "JOB_NAME_UNIQUE" ON "CTRL_JOB" ("JOB_NAME") 
  ;
--------------------------------------------------------
--  DDL for Index LKP_COUNTRY_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "LKP_COUNTRY_PK" ON "LKP_COUNTRY" ("COUNTRY_CD") 
  ;
--------------------------------------------------------
--  DDL for Index LKP_GUI_ACCESS_CONTROL_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "LKP_GUI_ACCESS_CONTROL_PK" ON "LKP_GUI_ACCESS_CONTROL" ("ACCESS_RIGHT") 
  ;
--------------------------------------------------------
--  DDL for Index LKP_GUI_ACCESS_MENU_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "LKP_GUI_ACCESS_MENU_PK" ON "LKP_GUI_ACCESS_MENU" ("ACCESS_MENU") 
  ;
--------------------------------------------------------
--  DDL for Index LKP_GUI_ACCESS_ROLE_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "LKP_GUI_ACCESS_ROLE_PK" ON "LKP_GUI_ACCESS_ROLE" ("ACCESS_ROLE") 
  ;
--------------------------------------------------------
--  DDL for Index PK_CTRL_JOB_DEPENDENCY
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_CTRL_JOB_DEPENDENCY" ON "CTRL_JOB_DEPENDENCY" ("JOB_NAME", "PARENT_JOB_NAME") 
  ;
--------------------------------------------------------
--  DDL for Index PK_CTRL_STREAM
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_CTRL_STREAM" ON "CTRL_STREAM" ("STREAM_NAME") 
  ;
--------------------------------------------------------
--  DDL for Index PK_CTRL_STREAM_DEPENDENCY
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_CTRL_STREAM_DEPENDENCY" ON "CTRL_STREAM_DEPENDENCY" ("STREAM_NAME", "PARENT_STREAM_NAME") 
  ;
--------------------------------------------------------
--  DDL for Index SYS_C008938
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C008938" ON "CTRL_NOTIFICATION_SEVERITY" ("ERROR_CD") 
  ;
--------------------------------------------------------
--  Constraints for Table CTRL_JOB
--------------------------------------------------------

  ALTER TABLE "CTRL_JOB" ADD CONSTRAINT "JOB_NAME_UNIQUE" UNIQUE ("JOB_NAME") ENABLE;
  ALTER TABLE "CTRL_JOB" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
  ALTER TABLE "CTRL_JOB" MODIFY ("ALWAYS_RESTART" NOT NULL ENABLE);
  ALTER TABLE "CTRL_JOB" MODIFY ("MAX_RUNS" NOT NULL ENABLE);
  ALTER TABLE "CTRL_JOB" MODIFY ("CONT_ANYWAY" NOT NULL ENABLE);
  ALTER TABLE "CTRL_JOB" MODIFY ("JOB_CATEGORY" NOT NULL ENABLE);
  ALTER TABLE "CTRL_JOB" MODIFY ("STREAM_NAME" NOT NULL ENABLE);
  ALTER TABLE "CTRL_JOB" MODIFY ("JOB_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CTRL_JOB_DEPENDENCY
--------------------------------------------------------

  ALTER TABLE "CTRL_JOB_DEPENDENCY" ADD CONSTRAINT "PK_CTRL_JOB_DEPENDENCY" PRIMARY KEY ("JOB_NAME", "PARENT_JOB_NAME") ENABLE;
  ALTER TABLE "CTRL_JOB_DEPENDENCY" MODIFY ("PARENT_JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "CTRL_JOB_DEPENDENCY" MODIFY ("JOB_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CTRL_JOB_STATUS
--------------------------------------------------------

  ALTER TABLE "CTRL_JOB_STATUS" MODIFY ("SORTING_ORDER" NOT NULL ENABLE);
  ALTER TABLE "CTRL_JOB_STATUS" MODIFY ("EXECUTABLE" NOT NULL ENABLE);
  ALTER TABLE "CTRL_JOB_STATUS" MODIFY ("FINISHED_SUCCESSFULLY" NOT NULL ENABLE);
  ALTER TABLE "CTRL_JOB_STATUS" MODIFY ("FINISHED" NOT NULL ENABLE);
  ALTER TABLE "CTRL_JOB_STATUS" MODIFY ("DELAY_MINUTES" NOT NULL ENABLE);
  ALTER TABLE "CTRL_JOB_STATUS" MODIFY ("RUNABLE" NOT NULL ENABLE);
  ALTER TABLE "CTRL_JOB_STATUS" MODIFY ("STATUS" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CTRL_JOB_TABLE_REF
--------------------------------------------------------

  ALTER TABLE "CTRL_JOB_TABLE_REF" ADD CONSTRAINT "CTRL_JOB_TABLE_REF_UK1" UNIQUE ("JOB_NAME", "DATABASE_NAME", "TABLE_NAME") ENABLE;
  ALTER TABLE "CTRL_JOB_TABLE_REF" MODIFY ("LOCK_TYPE" NOT NULL ENABLE);
  ALTER TABLE "CTRL_JOB_TABLE_REF" MODIFY ("TABLE_NAME" NOT NULL ENABLE);
  ALTER TABLE "CTRL_JOB_TABLE_REF" MODIFY ("DATABASE_NAME" NOT NULL ENABLE);
  ALTER TABLE "CTRL_JOB_TABLE_REF" MODIFY ("JOB_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CTRL_NBD_CAL
--------------------------------------------------------

  ALTER TABLE "CTRL_NBD_CAL" MODIFY ("NBD_DATE" NOT NULL ENABLE);
  ALTER TABLE "CTRL_NBD_CAL" MODIFY ("COUNTRY_CD" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CTRL_NEXT_STATUS
--------------------------------------------------------

  ALTER TABLE "CTRL_NEXT_STATUS" MODIFY ("CONT_ANYWAY" NOT NULL ENABLE);
  ALTER TABLE "CTRL_NEXT_STATUS" MODIFY ("LAUNCH" NOT NULL ENABLE);
  ALTER TABLE "CTRL_NEXT_STATUS" MODIFY ("REQUEST" NOT NULL ENABLE);
  ALTER TABLE "CTRL_NEXT_STATUS" MODIFY ("SIGNAL" NOT NULL ENABLE);
  ALTER TABLE "CTRL_NEXT_STATUS" MODIFY ("STATUS_OUT" NOT NULL ENABLE);
  ALTER TABLE "CTRL_NEXT_STATUS" MODIFY ("STATUS_IN" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CTRL_NOTIFICATION
--------------------------------------------------------

  ALTER TABLE "CTRL_NOTIFICATION" MODIFY ("JOB_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CTRL_NOTIFICATION_RLTD
--------------------------------------------------------

  ALTER TABLE "CTRL_NOTIFICATION_RLTD" MODIFY ("NOTIFICATION_TYPE_CD" NOT NULL ENABLE);
  ALTER TABLE "CTRL_NOTIFICATION_RLTD" MODIFY ("NOTIFICATION_CD" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CTRL_NOTIFICATION_SEVERITY
--------------------------------------------------------

  ALTER TABLE "CTRL_NOTIFICATION_SEVERITY" ADD PRIMARY KEY ("ERROR_CD") ENABLE;
--------------------------------------------------------
--  Constraints for Table CTRL_NOTIFICATION_TYPES
--------------------------------------------------------

  ALTER TABLE "CTRL_NOTIFICATION_TYPES" MODIFY ("NOTIFICATION_TYPE_CD" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CTRL_PARAMETERS
--------------------------------------------------------

  ALTER TABLE "CTRL_PARAMETERS" MODIFY ("PARAM_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CTRL_SOURCE
--------------------------------------------------------

  ALTER TABLE "CTRL_SOURCE" MODIFY ("DELIVERY_CHECKER_JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "CTRL_SOURCE" MODIFY ("VALIDATED_DIR" NOT NULL ENABLE);
  ALTER TABLE "CTRL_SOURCE" MODIFY ("SNIFFED_DIR" NOT NULL ENABLE);
  ALTER TABLE "CTRL_SOURCE" MODIFY ("SCHEMA_NAME" NOT NULL ENABLE);
  ALTER TABLE "CTRL_SOURCE" MODIFY ("HOST" NOT NULL ENABLE);
  ALTER TABLE "CTRL_SOURCE" MODIFY ("PHYSICAL_SOURCE" NOT NULL ENABLE);
  ALTER TABLE "CTRL_SOURCE" MODIFY ("SOURCE_NM" NOT NULL ENABLE);
  ALTER TABLE "CTRL_SOURCE" MODIFY ("SOURCE_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CTRL_SOURCE_PLAN_REF
--------------------------------------------------------

  ALTER TABLE "CTRL_SOURCE_PLAN_REF" MODIFY ("RELATED_TO_INITIALIZATION" NOT NULL ENABLE);
  ALTER TABLE "CTRL_SOURCE_PLAN_REF" MODIFY ("CRITICAL" NOT NULL ENABLE);
  ALTER TABLE "CTRL_SOURCE_PLAN_REF" MODIFY ("NOWAIT_ALERT_ZONE_END_TM" NOT NULL ENABLE);
  ALTER TABLE "CTRL_SOURCE_PLAN_REF" MODIFY ("ALERT_ZONE_END_TM" NOT NULL ENABLE);
  ALTER TABLE "CTRL_SOURCE_PLAN_REF" MODIFY ("RUNPLAN" NOT NULL ENABLE);
  ALTER TABLE "CTRL_SOURCE_PLAN_REF" MODIFY ("SOURCE_ID" NOT NULL ENABLE);
  ALTER TABLE "CTRL_SOURCE_PLAN_REF" MODIFY ("ALERT_TM_IN_MINUTES" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CTRL_STREAM
--------------------------------------------------------

  ALTER TABLE "CTRL_STREAM" ADD CONSTRAINT "PK_CTRL_STREAM" UNIQUE ("STREAM_NAME") ENABLE;
  ALTER TABLE "CTRL_STREAM" MODIFY ("STREAM_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CTRL_STREAM_DEPENDENCY
--------------------------------------------------------

  ALTER TABLE "CTRL_STREAM_DEPENDENCY" ADD CONSTRAINT "PK_CTRL_STREAM_DEPENDENCY" PRIMARY KEY ("STREAM_NAME", "PARENT_STREAM_NAME") ENABLE;
  ALTER TABLE "CTRL_STREAM_DEPENDENCY" MODIFY ("PARENT_STREAM_NAME" NOT NULL ENABLE);
  ALTER TABLE "CTRL_STREAM_DEPENDENCY" MODIFY ("STREAM_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CTRL_STREAM_PLAN_REF
--------------------------------------------------------

  ALTER TABLE "CTRL_STREAM_PLAN_REF" MODIFY ("RUNPLAN" NOT NULL ENABLE);
  ALTER TABLE "CTRL_STREAM_PLAN_REF" MODIFY ("STREAM_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CTRL_TASK_PARAMETERS
--------------------------------------------------------

  ALTER TABLE "CTRL_TASK_PARAMETERS" MODIFY ("PARAM_VAL_INT_DEFAULT" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table GUI_ACCESS_GROUP_ROLE_REF
--------------------------------------------------------

  ALTER TABLE "GUI_ACCESS_GROUP_ROLE_REF" MODIFY ("ACCESS_ROLE" NOT NULL ENABLE);
  ALTER TABLE "GUI_ACCESS_GROUP_ROLE_REF" MODIFY ("DOMAIN_GROUP" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table GUI_ACCESS_ROLE_RIGHT_REF
--------------------------------------------------------

  ALTER TABLE "GUI_ACCESS_ROLE_RIGHT_REF" MODIFY ("ACCESS_RIGHT" NOT NULL ENABLE);
  ALTER TABLE "GUI_ACCESS_ROLE_RIGHT_REF" MODIFY ("GUI_PAGE" NOT NULL ENABLE);
  ALTER TABLE "GUI_ACCESS_ROLE_RIGHT_REF" MODIFY ("ACCESS_ROLE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table GUI_ACCESS_USER_GROUP_REF
--------------------------------------------------------

  ALTER TABLE "GUI_ACCESS_USER_GROUP_REF" MODIFY ("DOMAIN_GROUP" NOT NULL ENABLE);
  ALTER TABLE "GUI_ACCESS_USER_GROUP_REF" MODIFY ("USER_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table GUI_AUTH
--------------------------------------------------------

  ALTER TABLE "GUI_AUTH" MODIFY ("USR_LEVEL" NOT NULL ENABLE);
  ALTER TABLE "GUI_AUTH" MODIFY ("USR_PASSWD" NOT NULL ENABLE);
  ALTER TABLE "GUI_AUTH" MODIFY ("USR_NAME" NOT NULL ENABLE);
  ALTER TABLE "GUI_AUTH" MODIFY ("USR_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table GUI_CHANGE_CONTROL
--------------------------------------------------------

  ALTER TABLE "GUI_CHANGE_CONTROL" MODIFY ("CMD" NOT NULL ENABLE);
  ALTER TABLE "GUI_CHANGE_CONTROL" MODIFY ("SEQ_NUM" NOT NULL ENABLE);
  ALTER TABLE "GUI_CHANGE_CONTROL" MODIFY ("CMD_TS" NOT NULL ENABLE);
  ALTER TABLE "GUI_CHANGE_CONTROL" MODIFY ("USER_NAME" NOT NULL ENABLE);
  ALTER TABLE "GUI_CHANGE_CONTROL" MODIFY ("LABEL_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table GUI_CHANGE_MANAGEMENT
--------------------------------------------------------

  ALTER TABLE "GUI_CHANGE_MANAGEMENT" MODIFY ("ENV" NOT NULL ENABLE);
  ALTER TABLE "GUI_CHANGE_MANAGEMENT" MODIFY ("CREATE_TS" NOT NULL ENABLE);
  ALTER TABLE "GUI_CHANGE_MANAGEMENT" MODIFY ("USER_NAME" NOT NULL ENABLE);
  ALTER TABLE "GUI_CHANGE_MANAGEMENT" MODIFY ("LABEL_STATUS" NOT NULL ENABLE);
  ALTER TABLE "GUI_CHANGE_MANAGEMENT" MODIFY ("LABEL_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table GUI_LOG_CTRL_ACTION
--------------------------------------------------------

  ALTER TABLE "GUI_LOG_CTRL_ACTION" MODIFY ("DWH_DATE" NOT NULL ENABLE);
  ALTER TABLE "GUI_LOG_CTRL_ACTION" MODIFY ("ACTION" NOT NULL ENABLE);
  ALTER TABLE "GUI_LOG_CTRL_ACTION" MODIFY ("USER_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table GUI_SHOW_LOGS_JOBS_URL_PATH
--------------------------------------------------------

  ALTER TABLE "GUI_SHOW_LOGS_JOBS_URL_PATH" MODIFY ("FILE_NAME" NOT NULL ENABLE);
  ALTER TABLE "GUI_SHOW_LOGS_JOBS_URL_PATH" MODIFY ("LOG_NAME" NOT NULL ENABLE);
  ALTER TABLE "GUI_SHOW_LOGS_JOBS_URL_PATH" MODIFY ("URL_PATH" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table LKP_COUNTRY
--------------------------------------------------------

  ALTER TABLE "LKP_COUNTRY" ADD CONSTRAINT "LKP_COUNTRY_PK" PRIMARY KEY ("COUNTRY_CD") ENABLE;
  ALTER TABLE "LKP_COUNTRY" MODIFY ("COUNTRY_NAME" NOT NULL ENABLE);
  ALTER TABLE "LKP_COUNTRY" MODIFY ("COUNTRY_CD" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table LKP_ERROR_CD
--------------------------------------------------------

  ALTER TABLE "LKP_ERROR_CD" MODIFY ("ERROR_CD_RECOM" NOT NULL ENABLE);
  ALTER TABLE "LKP_ERROR_CD" MODIFY ("ERROR_CD_DESC" NOT NULL ENABLE);
  ALTER TABLE "LKP_ERROR_CD" MODIFY ("ERROR_CD_NAME_SHORT" NOT NULL ENABLE);
  ALTER TABLE "LKP_ERROR_CD" MODIFY ("ERROR_CD_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table LKP_GUI_ACCESS_CONTROL
--------------------------------------------------------

  ALTER TABLE "LKP_GUI_ACCESS_CONTROL" ADD CONSTRAINT "LKP_GUI_ACCESS_CONTROL_PK" PRIMARY KEY ("ACCESS_RIGHT") ENABLE;
  ALTER TABLE "LKP_GUI_ACCESS_CONTROL" MODIFY ("ACCESS_RIGHT" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table LKP_GUI_ACCESS_MENU
--------------------------------------------------------

  ALTER TABLE "LKP_GUI_ACCESS_MENU" ADD CONSTRAINT "LKP_GUI_ACCESS_MENU_PK" PRIMARY KEY ("ACCESS_MENU") ENABLE;
  ALTER TABLE "LKP_GUI_ACCESS_MENU" MODIFY ("ACCESS_MENU" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table LKP_GUI_ACCESS_ROLE
--------------------------------------------------------

  ALTER TABLE "LKP_GUI_ACCESS_ROLE" ADD CONSTRAINT "LKP_GUI_ACCESS_ROLE_PK" PRIMARY KEY ("ACCESS_ROLE") ENABLE;
  ALTER TABLE "LKP_GUI_ACCESS_ROLE" MODIFY ("ACCESS_ROLE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table LKP_JOB_CATEGORY
--------------------------------------------------------

  ALTER TABLE "LKP_JOB_CATEGORY" MODIFY ("JOB_CATEGORY" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table LKP_JOB_TYPE
--------------------------------------------------------

  ALTER TABLE "LKP_JOB_TYPE" MODIFY ("JOB_TYPE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table LKP_PHASE
--------------------------------------------------------

  ALTER TABLE "LKP_PHASE" MODIFY ("JOB_PHASE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table LKP_PLAN
--------------------------------------------------------

  ALTER TABLE "LKP_PLAN" MODIFY ("RUNPLAN" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SESS_JOB
--------------------------------------------------------

  ALTER TABLE "SESS_JOB" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB" MODIFY ("MAX_RUNS" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB" MODIFY ("N_RUN" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB" MODIFY ("ALWAYS_RESTART" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB" MODIFY ("RESTART" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB" MODIFY ("CONT_ANYWAY" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB" MODIFY ("JOB_CATEGORY" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB" MODIFY ("LOAD_DATE" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB" MODIFY ("STATUS" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB" MODIFY ("STREAM_NAME" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB" MODIFY ("JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB" MODIFY ("STREAM_ID" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB" MODIFY ("JOB_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SESS_JOB_BCKP
--------------------------------------------------------

  ALTER TABLE "SESS_JOB_BCKP" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_BCKP" MODIFY ("MAX_RUNS" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_BCKP" MODIFY ("N_RUN" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_BCKP" MODIFY ("ALWAYS_RESTART" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_BCKP" MODIFY ("RESTART" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_BCKP" MODIFY ("CONT_ANYWAY" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_BCKP" MODIFY ("JOB_CATEGORY" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_BCKP" MODIFY ("LOAD_DATE" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_BCKP" MODIFY ("STATUS" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_BCKP" MODIFY ("STREAM_NAME" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_BCKP" MODIFY ("JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_BCKP" MODIFY ("STREAM_ID" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_BCKP" MODIFY ("JOB_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SESS_JOB_DEPENDENCY
--------------------------------------------------------

  ALTER TABLE "SESS_JOB_DEPENDENCY" MODIFY ("PARENT_JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_DEPENDENCY" MODIFY ("PARENT_JOB_ID" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_DEPENDENCY" MODIFY ("JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_DEPENDENCY" MODIFY ("JOB_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SESS_JOB_DEPENDENCY_BCKP
--------------------------------------------------------

  ALTER TABLE "SESS_JOB_DEPENDENCY_BCKP" MODIFY ("PARENT_JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_DEPENDENCY_BCKP" MODIFY ("PARENT_JOB_ID" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_DEPENDENCY_BCKP" MODIFY ("JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_DEPENDENCY_BCKP" MODIFY ("JOB_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SESS_JOB_STATISTICS
--------------------------------------------------------

  ALTER TABLE "SESS_JOB_STATISTICS" MODIFY ("JOB_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SESS_JOB_TABLE_REF
--------------------------------------------------------

  ALTER TABLE "SESS_JOB_TABLE_REF" MODIFY ("LOCK_TYPE" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_TABLE_REF" MODIFY ("TABLE_NAME" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_TABLE_REF" MODIFY ("DATABASE_NAME" NOT NULL ENABLE);
  ALTER TABLE "SESS_JOB_TABLE_REF" MODIFY ("JOB_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SESS_PARALLELISM_CONTROL
--------------------------------------------------------

  ALTER TABLE "SESS_PARALLELISM_CONTROL" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
  ALTER TABLE "SESS_PARALLELISM_CONTROL" MODIFY ("PARAM_VAL_INT_DEFAULT" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SESS_QUEUE
--------------------------------------------------------

  ALTER TABLE "SESS_QUEUE" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
  ALTER TABLE "SESS_QUEUE" MODIFY ("AVAILABLE" NOT NULL ENABLE);
  ALTER TABLE "SESS_QUEUE" MODIFY ("QUEUE_NUMBER" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SESS_STATUS
--------------------------------------------------------

  ALTER TABLE "SESS_STATUS" MODIFY ("STREAM_NAME" NOT NULL ENABLE);
  ALTER TABLE "SESS_STATUS" MODIFY ("STATUS_TS" NOT NULL ENABLE);
  ALTER TABLE "SESS_STATUS" MODIFY ("STATUS" NOT NULL ENABLE);
  ALTER TABLE "SESS_STATUS" MODIFY ("SIGNAL" NOT NULL ENABLE);
  ALTER TABLE "SESS_STATUS" MODIFY ("N_RUN" NOT NULL ENABLE);
  ALTER TABLE "SESS_STATUS" MODIFY ("LOAD_DATE" NOT NULL ENABLE);
  ALTER TABLE "SESS_STATUS" MODIFY ("JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "SESS_STATUS" MODIFY ("JOB_ID" NOT NULL ENABLE);
  ALTER TABLE "SESS_STATUS" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table STAT_JOB_STATISTICS
--------------------------------------------------------

  ALTER TABLE "STAT_JOB_STATISTICS" MODIFY ("JOB_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table STAT_LOG_EVENT_HIST
--------------------------------------------------------

  ALTER TABLE "STAT_LOG_EVENT_HIST" MODIFY ("DWH_DATE" NOT NULL ENABLE);
  ALTER TABLE "STAT_LOG_EVENT_HIST" MODIFY ("JOB_ID" NOT NULL ENABLE);
  ALTER TABLE "STAT_LOG_EVENT_HIST" MODIFY ("JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "STAT_LOG_EVENT_HIST" MODIFY ("LOG_EVENT_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table STAT_LOG_MESSAGE_HIST
--------------------------------------------------------

  ALTER TABLE "STAT_LOG_MESSAGE_HIST" MODIFY ("DETECTED_TS" NOT NULL ENABLE);
  ALTER TABLE "STAT_LOG_MESSAGE_HIST" MODIFY ("EVENT_DS" NOT NULL ENABLE);
  ALTER TABLE "STAT_LOG_MESSAGE_HIST" MODIFY ("NOTIFICATION_TYPE_CD" NOT NULL ENABLE);
  ALTER TABLE "STAT_LOG_MESSAGE_HIST" MODIFY ("SEVERITY" NOT NULL ENABLE);
  ALTER TABLE "STAT_LOG_MESSAGE_HIST" MODIFY ("JOB_ID" NOT NULL ENABLE);
  ALTER TABLE "STAT_LOG_MESSAGE_HIST" MODIFY ("JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "STAT_LOG_MESSAGE_HIST" MODIFY ("ERROR_CD" NOT NULL ENABLE);
  ALTER TABLE "STAT_LOG_MESSAGE_HIST" MODIFY ("LOG_EVENT_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table STAT_SCHEMA_LOAD_HIST
--------------------------------------------------------

  ALTER TABLE "STAT_SCHEMA_LOAD_HIST" MODIFY ("LOAD_DATE" NOT NULL ENABLE);
  ALTER TABLE "STAT_SCHEMA_LOAD_HIST" MODIFY ("SCHEMA_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table STAT_SOURCE_LOAD_HIST
--------------------------------------------------------

  ALTER TABLE "STAT_SOURCE_LOAD_HIST" MODIFY ("LOAD_STATUS" NOT NULL ENABLE);
  ALTER TABLE "STAT_SOURCE_LOAD_HIST" MODIFY ("LOAD_DATE" NOT NULL ENABLE);
  ALTER TABLE "STAT_SOURCE_LOAD_HIST" MODIFY ("SCHEMA_NAME" NOT NULL ENABLE);
  ALTER TABLE "STAT_SOURCE_LOAD_HIST" MODIFY ("EFF_LOAD_DATE" NOT NULL ENABLE);
  ALTER TABLE "STAT_SOURCE_LOAD_HIST" MODIFY ("SOURCE_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table STAT_STATUS
--------------------------------------------------------

  ALTER TABLE "STAT_STATUS" MODIFY ("JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "STAT_STATUS" MODIFY ("JOB_ID" NOT NULL ENABLE);
  ALTER TABLE "STAT_STATUS" ADD CHECK ("STATUS" IS NOT NULL) ENABLE;
  ALTER TABLE "STAT_STATUS" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
  ALTER TABLE "STAT_STATUS" MODIFY ("SIGNAL" NOT NULL ENABLE);
  ALTER TABLE "STAT_STATUS" MODIFY ("N_RUN" NOT NULL ENABLE);
  ALTER TABLE "STAT_STATUS" MODIFY ("LOAD_DATE" NOT NULL ENABLE);
  ALTER TABLE "STAT_STATUS" MODIFY ("STATUS_TS" NOT NULL ENABLE);
  ALTER TABLE "STAT_STATUS" MODIFY ("STREAM_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TEMP_CRTP_DEPENDENCY_GRAPH
--------------------------------------------------------

  ALTER TABLE "TEMP_CRTP_DEPENDENCY_GRAPH" MODIFY ("DURATION" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TEMP_CRTP_JOB_STATISTICS
--------------------------------------------------------

  ALTER TABLE "TEMP_CRTP_JOB_STATISTICS" MODIFY ("JOB_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TEMP_ENG_JOB_POSSIBLE
--------------------------------------------------------

  ALTER TABLE "TEMP_ENG_JOB_POSSIBLE" MODIFY ("STATUS" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_POSSIBLE" MODIFY ("SEQ" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_POSSIBLE" MODIFY ("PRIORITY" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_POSSIBLE" MODIFY ("N_RUN" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_POSSIBLE" MODIFY ("JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_POSSIBLE" MODIFY ("JOB_ID" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_POSSIBLE" MODIFY ("JOB_CATEGORY" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_POSSIBLE" MODIFY ("PARENT_JOB_CATEGORY" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_POSSIBLE" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TEMP_ENG_JOB_READY
--------------------------------------------------------

  ALTER TABLE "TEMP_ENG_JOB_READY" MODIFY ("QUEUE_NUMBER" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_READY" MODIFY ("LOAD_DATE" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_READY" MODIFY ("JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_READY" MODIFY ("JOB_ID" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_READY" MODIFY ("JOB_CATEGORY" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_READY" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TEMP_ENG_JOB_RUNNING
--------------------------------------------------------

  ALTER TABLE "TEMP_ENG_JOB_RUNNING" MODIFY ("JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_RUNNING" MODIFY ("JOB_ID" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_RUNNING" MODIFY ("JOB_CATEGORY" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_RUNNING" MODIFY ("IS_RUNNING" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_JOB_RUNNING" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TEMP_ENG_QUEUE
--------------------------------------------------------

  ALTER TABLE "TEMP_ENG_QUEUE" MODIFY ("SEQ" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_QUEUE" MODIFY ("QUEUE_NUMBER" NOT NULL ENABLE);
  ALTER TABLE "TEMP_ENG_QUEUE" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TEMP_GUI_SHOW_LOGS
--------------------------------------------------------

  ALTER TABLE "TEMP_GUI_SHOW_LOGS" MODIFY ("URL_PATH" NOT NULL ENABLE);
  ALTER TABLE "TEMP_GUI_SHOW_LOGS" MODIFY ("JOB_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TEMP_INIT_PLAN
--------------------------------------------------------

  ALTER TABLE "TEMP_INIT_PLAN" MODIFY ("RUNPLAN" NOT NULL ENABLE);
  ALTER TABLE "TEMP_INIT_PLAN" MODIFY ("LOAD_DATE" NOT NULL ENABLE);
  ALTER TABLE "TEMP_INIT_PLAN" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TEMP_PARALLELISM_CONTROL
--------------------------------------------------------

  ALTER TABLE "TEMP_PARALLELISM_CONTROL" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TEMP_V_JOB_POSSIBLE
--------------------------------------------------------

  ALTER TABLE "TEMP_V_JOB_POSSIBLE" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_POSSIBLE" MODIFY ("JOB_CATEGORY" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_POSSIBLE" MODIFY ("PARENT_JOB_CATEGORY" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_POSSIBLE" MODIFY ("N_RUN" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_POSSIBLE" MODIFY ("STATUS" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_POSSIBLE" MODIFY ("PRIORITY" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_POSSIBLE" MODIFY ("JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_POSSIBLE" MODIFY ("JOB_ID" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_POSSIBLE" MODIFY ("SEQ" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TEMP_V_JOB_READY
--------------------------------------------------------

  ALTER TABLE "TEMP_V_JOB_READY" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_READY" MODIFY ("LOAD_DATE" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_READY" MODIFY ("QUEUE_NUMBER" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_READY" MODIFY ("JOB_CATEGORY" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_READY" MODIFY ("JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_READY" MODIFY ("JOB_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TEMP_V_JOB_RUNNING
--------------------------------------------------------

  ALTER TABLE "TEMP_V_JOB_RUNNING" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_RUNNING" MODIFY ("IS_RUNNING" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_RUNNING" MODIFY ("JOB_CATEGORY" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_RUNNING" MODIFY ("JOB_NAME" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_JOB_RUNNING" MODIFY ("JOB_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TEMP_V_QUEUE
--------------------------------------------------------

  ALTER TABLE "TEMP_V_QUEUE" MODIFY ("ENGINE_ID" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_QUEUE" MODIFY ("QUEUE_NUMBER" NOT NULL ENABLE);
  ALTER TABLE "TEMP_V_QUEUE" MODIFY ("SEQ" NOT NULL ENABLE);
