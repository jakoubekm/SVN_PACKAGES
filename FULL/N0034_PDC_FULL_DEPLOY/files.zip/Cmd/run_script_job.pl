use strict;
use warnings;

# Libs.
use XML::Simple;
use IO::Handle;
use File::Spec;
use DBI;


# Modules.


# Constants.



#---------------------------------------------------------------
# global variables
#---------------------------------------------------------------

#------------------------------------------------------------------------------
# Subroutines.
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# Get current date time.
#
# return current date time as string
#------------------------------------------------------------------------------
sub dateYYYYXMMXDDDHHYMMYSS {
	my ($sec, $min, $hour, $mday, $mon, $year) = localtime;
	my $s = sprintf("%04d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $mday, $hour, $min, $sec);
	return $s;
}

#------------------------------------------------------------------------------
# open_log
#   opens log file
#
# $_[0] - filename
# $_[0] - write header 1/0
#
# return handle
#------------------------------------------------------------------------------
sub open_log($$){
  my ($filename,$writeheader) = @_;
    
  my $myfile;  
  open($myfile, ">>$filename.log") || die "Cannot open log file '$filename' [$!]. Stopped";
  
  if($writeheader==1){
    # write log header
	 print($myfile ('#' x 80) . "\n");
	 print($myfile "Log started: " . dateYYYYXMMXDDDHHYMMYSS() . "\n");
	 print($myfile ('#' x 80) . "\n\n");
	 $myfile->autoflush(1);
	}

	
  
  return $myfile;
}

#------------------------------------------------------------------------------
# print_log
#   prints to log
#
# $_[0] - filehandle
# $_[1] - text
#
# return nothing
#------------------------------------------------------------------------------
sub print_log($$){
  my ($myfile,$text) = @_;
     
  print($myfile $text);
	
	$myfile->autoflush(1);
 
}

#------------------------------------------------------------------------------
# print_log_line
#   prints to log (adds the new line character)
#
# $_[0] - filehandle
# $_[1] - text
#
# return nothing
#------------------------------------------------------------------------------
sub print_log_line($$){
  my ($myfile,$text) = @_;
     
  print_log($myfile,"$text\n");
}

#------------------------------------------------------------------------------
# close_log
#   close_log log file
#
# $_[0] - filehandle
# $_[1] - filename
# $_[2] - close OK 0/1
#
# return nothing
#------------------------------------------------------------------------------
sub close_log($$$){
  my ($myfile,$filename,$closeOK) = @_;
    
  if($closeOK==1){
    # write log header
	 print($myfile ('#' x 80) . "\n");
	 print($myfile "Log finished: " . dateYYYYXMMXDDDHHYMMYSS . "\n");
	 print($myfile ('#' x 80) . "\n\n");

	 $myfile->autoflush(1);
	}
	
	close($myfile) || die "Cannot close log file. [$!]. Stopped";
	
	if($closeOK==1){
	  my $ts = dateYYYYXMMXDDDHHYMMYSS();                  
	  $ts =~ s/-//g; 
	  $ts =~ s/://g;
	  $ts =~ s/ //g;
    my $ren = "$filename\_$ts.log";
    rename("$filename.log",$ren);
  }      
		 
}

# can be depracated after deploy of N0015_RLS_ENG_REFRESH_INT
#------------------------------------------------------------------------------
# job_load_dttm
#	
# $_[0] - $error_message
#
# returns reference to the connection object or undef on error
#------------------------------------------------------------------------------ 
sub job_load_dttm($$$$$){
    my ($pdcserver, $pdcuser, $pdcpassword,$jobid,$jobname) = @_;
    
    my $dbh = DBI->connect( $pdcserver,
                        $pdcuser,
                        $pdcpassword
                      );
    if (!defined $dbh) { die("Database connection not made: $DBI::errstr"); }
    
    my $loaddttm="";
    my $sql = "SELECT TO_CHAR(LOAD_DATE,'yyyy-mm-dd hh24:mi:ss') FROM SESS_JOB WHERE job_id=$jobid and job_name='$jobname'"; 
    my $error_occured=1;
    if(my $sth = $dbh->prepare($sql)){  
      if($sth->execute()){                   
        if($sth->bind_columns(undef, \$loaddttm)){
          if($sth->fetch()) {
            $error_occured=0;
          } else {              
            $sth->finish();
            $dbh->disconnect;
          }
          $sth->finish();
        }
      }
    } 
    if($error_occured==1){
      $dbh->disconnect;
      die("Error retrieving data: $DBI::errstr");
    }
    
    $dbh->disconnect;
    return $loaddttm;
}


#------------------------------------------------------------------------------
# Main.
#------------------------------------------------------------------------------

# check command line parameter
if($#ARGV < 3){
  print "usage: perl run_script.pl job_name job_id LOAD_DTTM template [PARAM0] [PARAM1] [...] \n";
  die "Wrong number of input parameter!"  
}

# set global variables (paths, filenames, etc..)

if(!exists($ENV{'PMROOTDIR'})) {
  die "Env. variable PMROOTDIR is not set. Stopped";
}
my $PMRootDir = $ENV{'PMROOTDIR'};

if(!exists($ENV{'PMWORKFLOWLOGDIR'})) {
  die "Env. variable PMWORKFLOWLOGDIR is not set. Stopped";
}
my $PMWorkflowLogDir = $ENV{'PMWORKFLOWLOGDIR'};

my $config_path = File::Spec->catfile($PMRootDir,'Security','Passwords');
my $config_filename = "system_info.xml";

my $config = XMLin(File::Spec->catfile($config_path,$config_filename)); 
if(!$config) {
  die "Cannot read configuration file '$config_filename' [$!]. Stopped";
}

#This is to get correct tag from xml config file if enviroment variable ETLSERVER exists
if(!exists($ENV{'SYSTEMNAME'})) {
  die "Env. variable SYSTEMNAME is not set. Stopped";
}
my $SYSTEM = $ENV{'SYSTEMNAME'}; 

if(!exists($config->{connection}->{$SYSTEM})){
  die "Settings for $SYSTEM not found in configuration file. Stopped";
}


my $job_name = $ARGV[0];
my $job_id = $ARGV[1];
#my $loaddttm = $ARGV[2]; after deploy of N0015_RLS_ENG_REFRESH_INT
#LOAD_DTTM from engine.pl is in bad format -> PDC DB is asked for load_dttm in proper format
my $loaddttm = job_load_dttm($config->{connection}->{$SYSTEM}->{PDCserver},$config->{connection}->{$SYSTEM}->{PDCuser},$config->{connection}->{$SYSTEM}->{PDCpassword},$job_id,$job_name);

my $template_filename = $ARGV[3];

my $template_path = File::Spec->catfile($PMRootDir,'Bin','Scripts');
my $template_type = '';
if((my $pos=rindex($template_filename,'.')) >=0) { $template_type = uc(substr($template_filename,$pos+1)); }


my $param_index = 1;
my $output_filename_suffix = '';
my @other_args = ();
while ( exists($ARGV[$param_index+3]) ) {
  push(@other_args,$ARGV[$param_index+3]);
  my $suffix_cleaned = lc($ARGV[$param_index+3]);
  $suffix_cleaned =~ tr/\//_/; 
  $output_filename_suffix .= '_' . $suffix_cleaned;
  $param_index++;
}

my $ldttm = $loaddttm;
$ldttm =~ s/-//g;
$ldttm =~ s/://g;
$ldttm =~ s/ /_/g;
$output_filename_suffix .= '_@ldttm' . $ldttm . '@jname' . lc($job_name). '@jid' . lc($job_id);

my $output_path = File::Spec->catfile($PMRootDir,'Security','Comps');
my $output_filename = $template_filename . $output_filename_suffix;

# log directory
my $log_path = File::Spec->catfile($PMWorkflowLogDir,'TDLogs');
my $log_filename = $template_filename . $output_filename_suffix;;

# initialize log
my $log = open_log(File::Spec->catfile($log_path,$log_filename),1);

# read configuration file ( holds the strings to be replaced in template )
print_log_line($log,"PMRootDir is:        $PMRootDir");
print_log_line($log,"PMWorkflowLogDir is: $PMWorkflowLogDir");
print_log($log,"Job name is: $job_name");
print_log_line($log,"");
print_log($log,"Job ID is: $job_id");
print_log_line($log,"");
print_log($log,"Using LOAD_DTTM: ");
print_log_line($log,"$loaddttm");
print_log_line($log,"");
print_log_line($log,"Converting template into script using settings for $SYSTEM:");
print_log_line($log,substr(File::Spec->catfile($template_path,$template_filename),length($PMRootDir)));
print_log_line($log,"");

if(($template_type ne 'BTEQ') && ($template_type ne 'PL') && ($template_type ne 'TPT') ) {
  print_log_line($log,"Unknown type of script '$template_type'. Stopped");
  die "Unknown type of script '$template_type'. Stopped";
}


$param_index = 0;
while ( exists($other_args[$param_index]) ) {
  print_log_line($log,"Additional parameter PARAM$param_index: $other_args[$param_index]");
  $param_index++;
}

if(!exists($config->{connection}->{$SYSTEM})){
  print_log_line($log,"Settings for $SYSTEM not found in configuration file. Stopped");
  die "Settings for $SYSTEM not found in configuration file. Stopped";
}

# read template
my $res = open(TEMPLATE, "<" . File::Spec->catfile($template_path,$template_filename) );
if(!$res) {
   print_log_line($log, "Cannot open template file '$template_filename' [$!]. Stopped");
   die "Cannot open template file '$template_filename' [$!]. Stopped";
}
my $str = do{ undef $/; <TEMPLATE> };
close(TEMPLATE) || die "Cannot close template file '$template_filename' [$!]. Stopped";

# do the replace
while ( my ($key, $value) = each(%{$config->{connection}->{$SYSTEM}}) ) {
  if($template_type eq 'PL'){
       $value =~ s/\\/\\\\/ig;
       $value =~ s/\$/\\\$/ig;
  }
  $str =~ s/\Q%$key%/\E$value/ig;
}

# do the replace  of Environments
while ( my ($key, $value) = each(%ENV) ) {
  if($template_type eq 'PL'){
       $value =~ s/\\/\\\\/ig;
       $value =~ s/\$/\\\$/ig;
  }
  $str =~ s/\Q%$key%/\E$value/ig;
}

# do the replace of PARAMx (if exists)
$param_index = 0;
while ( exists($other_args[$param_index]) ) {
  $str =~ s/\Q%PARAM$param_index%/\E$other_args[$param_index]/ig;
  $param_index++;
}

# do the replace of LOAD_DTTM (if exists)
if($loaddttm ne ""){
  $str =~ s/\Q%LOAD_DTTM%/\E$loaddttm/ig;
}

# do the replace of LOAD_DTTM (if exists)
if($ldttm ne ""){
  $str =~ s/\Q%LDTTM%/\E$ldttm/ig;
}


my $current_date=dateYYYYXMMXDDDHHYMMYSS();
$current_date =~ s/[^\d]//g;
$str =~ s/\Q%CURRENT_DATE%/\E$current_date/ig;

$str =~ s/\Q%COMPS_PATH%/\E$output_path/ig;
$str =~ s/\Q%PMROOTDIR_PATH%/\E$PMRootDir/ig;
$str =~ s/\Q%PMWORKFLOWLOGDIR_PATH%/\E$PMWorkflowLogDir/ig;

$str =~ s/\Q%JOB_ID%/\E$job_id/ig;
$str =~ s/\Q%JOB_NAME%/\E$job_name/ig;

# add QueryBand to BTEQ
#my $queryband_cmd = "SET QUERY_BAND = 'OBJ=$template_filename;LOAD_DTTM=";
#if($loaddttm ne ""){
#  $queryband_cmd .= $loaddttm;
#} else {
#  $queryband_cmd .= "UNKNOWN";
#}    
#$queryband_cmd .= ";' For Session;";
#if($output_filename =~ m/.\.bteq$/i){
#  $str =~ s/\.LOGON(.*)/\.LOGON$1\n\n$queryband_cmd/ig; 
#}
 
# save the result
$res = open(RESULT, ">" . File::Spec->catfile($output_path,$output_filename) );
if(!$res){
  print_log_line($log, "Cannot create script file '$output_filename' [$!]. Stopped");
  die "Cannot create script file '$output_filename' [$!]. Stopped";
}
print RESULT $str;
close(RESULT) || die "Cannot close script file '$output_filename' [$!]. Stopped";
print_log_line($log,"Script created:");
print_log_line($log,substr(File::Spec->catfile($output_path,$output_filename),length($PMRootDir)));
print_log_line($log,"");
print_log_line($log,"Executing script:");
print_log_line($log,"");
close_log($log,File::Spec->catfile($log_path,$log_filename),0);
 
# run BTEQ 
$res = 1;
if($template_type eq 'BTEQ')
{
  $res = system('bteq -c LATIN1250_1A0 < ' . File::Spec->catfile($output_path,$output_filename) . ' >> ' . File::Spec->catfile($log_path,$log_filename) . '.log 2>&1');
}
if($template_type eq 'PL'){
  $res = system('perl '  . File::Spec->catfile($output_path,$output_filename) . ' >> ' . File::Spec->catfile($log_path,$log_filename) . '.log 2>&1');                                                                                                  
}
if($res==0){
  $log=open_log(File::Spec->catfile($log_path,$log_filename),0);
  close_log($log,File::Spec->catfile($log_path,$log_filename),1);
  exit(0);
}
exit(1);


__END__

=head1 NAME

 run_script.pl 

=head1 SYNOPSIS

 run_script 

=head1 DESCRIPTION

 Translates and runs Teradata BTEQ script and Perl. Derived from run_script.pl, use job_name,job_id and load_date as input.

=head1 VERSION

Version 1.0

=head1 REVISION HISTORY

1.0 - 2015-12-15 - Initial (Milan Budka, Teradata)

               

=head1 AUTHOR

Vladimir Duchon, Teradata
Milan Budka, Teradata

=cut

:endofperl
exit /B %RET%