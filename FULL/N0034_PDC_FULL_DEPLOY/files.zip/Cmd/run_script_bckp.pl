use strict;
use warnings;

# Libs.
use XML::Simple;
use IO::Handle;
use File::Spec;

# Modules.


# Constants.



#---------------------------------------------------------------
# global variables
#---------------------------------------------------------------

#------------------------------------------------------------------------------
# Subroutines.
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# Get current date time.
#
# return current date time as string
#------------------------------------------------------------------------------
sub dateYYYYXMMXDDDHHYMMYSS {
	my ($sec, $min, $hour, $mday, $mon, $year) = localtime;
	my $s = sprintf("%04d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $mday, $hour, $min, $sec);
	return $s;
}

#------------------------------------------------------------------------------
# open_log
#   opens log file
#
# $_[0] - filename
# $_[0] - write header 1/0
#
# return handle
#------------------------------------------------------------------------------
sub open_log($$){
  my ($filename,$writeheader) = @_;
    
  my $myfile;  
  open($myfile, ">>$filename.log") || die "Cannot open log file '$filename' [$!]. Stopped";
  
  if($writeheader==1){
    # write log header
	 print($myfile ('#' x 80) . "\n");
	 print($myfile "Log started: " . dateYYYYXMMXDDDHHYMMYSS() . "\n");
	 print($myfile ('#' x 80) . "\n\n");
	 $myfile->autoflush(1);
	}

	
  
  return $myfile;
}

#------------------------------------------------------------------------------
# print_log
#   prints to log
#
# $_[0] - filehandle
# $_[1] - text
#
# return nothing
#------------------------------------------------------------------------------
sub print_log($$){
  my ($myfile,$text) = @_;
     
  print($myfile $text);
	
	$myfile->autoflush(1);
 
}

#------------------------------------------------------------------------------
# print_log_line
#   prints to log (adds the new line character)
#
# $_[0] - filehandle
# $_[1] - text
#
# return nothing
#------------------------------------------------------------------------------
sub print_log_line($$){
  my ($myfile,$text) = @_;
     
  print_log($myfile,"$text\n");
}

#------------------------------------------------------------------------------
# close_log
#   close_log log file
#
# $_[0] - filehandle
# $_[1] - filename
# $_[2] - close OK 0/1
#
# return nothing
#------------------------------------------------------------------------------
sub close_log($$$){
  my ($myfile,$filename,$closeOK) = @_;
    
  if($closeOK==1){
    # write log header
	 print($myfile ('#' x 80) . "\n");
	 print($myfile "Log finished: " . dateYYYYXMMXDDDHHYMMYSS . "\n");
	 print($myfile ('#' x 80) . "\n\n");

	 $myfile->autoflush(1);
	}
	
	close($myfile) || die "Cannot close log file. [$!]. Stopped";
	
	if($closeOK==1){
	  my $ts = dateYYYYXMMXDDDHHYMMYSS();                  
	  $ts =~ s/-//g; 
	  $ts =~ s/://g;
	  $ts =~ s/ //g;
    my $ren = "$filename\_$ts.log";
    rename("$filename.log",$ren);
  }      
		 
}

#------------------------------------------------------------------------------
# Main.
#------------------------------------------------------------------------------

# check command line parameter
if($#ARGV < 4){
  print "usage: perl run_script.pl PMRootDir PMWorkflowLogDir template job_id workflow_id [LOAD_DTTM] [PARAM1] [PARAM2] [...] \n";
  die "Wrong number of input parameter!"  
}

# set global variables (paths, filenames, etc..)

my $PMRootDir = $ARGV[0];

my $PMWorkflowLogDir = $ARGV[1];

my $config_path = File::Spec->catfile($PMRootDir,'Security','Passwords');
my $config_filename = "system_info.xml";

my $job_id = $ARGV[3];
my $workflow_id = $ARGV[4]; 

my $loaddttm = "";
if(exists($ARGV[5])){
  $loaddttm = $ARGV[5]; 
}

my $template_path = File::Spec->catfile($PMRootDir,'Bin','Scripts');
my $template_filename = $ARGV[2];

my $param_index = 1;
my $output_filename_suffix = '';
while ( exists($ARGV[$param_index+5]) ) {
  my $suffix_cleaned = lc($ARGV[$param_index+5]);
  $suffix_cleaned =~ tr/\//_/; 
  $output_filename_suffix .= '_' . $suffix_cleaned;
  $param_index++;
}

my $ldttm = $loaddttm;
$ldttm =~ s/-//g;
$ldttm =~ s/://g;
$ldttm =~ s/ /_/g;
$output_filename_suffix .= '_@ldttm' . $ldttm . '@job' . lc($ARGV[3]) . '@wid' . lc($ARGV[4]);

my $output_path = File::Spec->catfile($PMRootDir,'Security','Comps');
my $output_filename = $ARGV[2] . $output_filename_suffix;

# BTEQ log directory
my $log_path = File::Spec->catfile($PMWorkflowLogDir,'TDLogs');
my $log_filename = $ARGV[2] . $output_filename_suffix;;

if($output_filename =~ m/.\.pl($output_filename_suffix)$/i){
  $log_path = File::Spec->catfile($PMWorkflowLogDir,'CmdLogs');
}

# initialize log
my $log = open_log(File::Spec->catfile($log_path,$log_filename),1);

#This is to get correct tag from xml config file if enviroment variable ETLSERVER exists
if(!exists($ENV{'SYSTEMNAME'})) {
  print_log_line($log,"Env. variable SYSTEMNAME is not set. Stopped");
  die "Env. variable ETLSERVER is not set. Stopped";
}
my $SYSTEM = $ENV{'SYSTEMNAME'};

# read configuration file ( holds the strings to be replaced in template )
print_log_line($log,"PMRootDir is:        $PMRootDir");
print_log_line($log,"PMWorkflowLogDir is: $PMWorkflowLogDir");
print_log_line($log,"");
print_log_line($log,"Converting template into script using settings for $SYSTEM:");
print_log_line($log,substr(File::Spec->catfile($template_path,$template_filename),length($PMRootDir)));
print_log_line($log,"");
print_log($log,"Job ID is: $job_id");
print_log_line($log,"");
print_log($log,"WID is: $workflow_id");
print_log_line($log,"");
print_log($log,"Using LOAD_DTTM: ");
if($loaddttm eq ""){
  print_log_line($log,"not present");
} else {
  print_log_line($log,"$loaddttm");
}
$param_index = 1;
while ( exists($ARGV[$param_index+5]) ) {
  print_log_line($log,"Additional parameter PARAM$param_index: $ARGV[$param_index+5]");
  $param_index++;
}
print_log_line($log,"");
my $config = XMLin(File::Spec->catfile($config_path,$config_filename)); 
if(!$config) {
  print_log_line($log,"Cannot read configuration file '$config_filename' [$!]. Stopped");
  die "Cannot read configuration file '$config_filename' [$!]. Stopped";
}

if(!exists($config->{connection}->{$SYSTEM})){
  print_log_line($log,"Settings for $SYSTEM not found in configuration file. Stopped");
  die "Settings for $SYSTEM not found in configuration file. Stopped";
}

# read template
my $res = open(TEMPLATE, "<" . File::Spec->catfile($template_path,$template_filename) );
if(!$res) {
   print_log_line($log, "Cannot open template file '$template_filename' [$!]. Stopped");
   die "Cannot open template file '$template_filename' [$!]. Stopped";
}
my $str = do{ undef $/; <TEMPLATE> };
close(TEMPLATE) || die "Cannot close template file '$template_filename' [$!]. Stopped";

# do the replace
while ( my ($key, $value) = each(%{$config->{connection}->{$SYSTEM}}) ) {
  $str =~ s/\Q%$key%/\E$value/ig;
}

# do the replace of PARAMx (if exists)
$param_index = 1;
while ( exists($ARGV[$param_index+5]) ) {
  $str =~ s/\Q%PARAM$param_index%/\E$ARGV[$param_index+5]/ig;
  $param_index++;
}

# do the replace of LOAD_DTTM (if exists)
if($loaddttm ne ""){
  $str =~ s/\Q%LOAD_DTTM%/\E$loaddttm/ig;
}

# do the replace of LOAD_DTTM (if exists)
if($ldttm ne ""){
  $str =~ s/\Q%LDTTM%/\E$ldttm/ig;
}

my $current_date=dateYYYYXMMXDDDHHYMMYSS();
$current_date =~ s/[^\d]//g;
$str =~ s/\Q%CURRENT_DATE%/\E$current_date/ig;

$str =~ s/\Q%COMPS_PATH%/\E$output_path/ig;
$str =~ s/\Q%PMROOTDIR_PATH%/\E$PMRootDir/ig;
$str =~ s/\Q%PMWORKFLOWLOGDIR_PATH%/\E$PMWorkflowLogDir/ig;

$str =~ s/\Q%JOB_ID%/\E$job_id/ig;
$str =~ s/\Q%WORKFLOW_ID%/\E$workflow_id/ig;

# add QueryBand to BTEQ
#my $queryband_cmd = "SET QUERY_BAND = 'OBJ=$template_filename;LOAD_DTTM=";
#if($loaddttm ne ""){
#  $queryband_cmd .= $loaddttm;
#} else {
#  $queryband_cmd .= "UNKNOWN";
#}    
#$queryband_cmd .= ";' For Session;";
#if($output_filename =~ m/.\.bteq$/i){
#  $str =~ s/\.LOGON(.*)/\.LOGON$1\n\n$queryband_cmd/ig; 
#}
 
# save the result
$res = open(RESULT, ">" . File::Spec->catfile($output_path,$output_filename) );
if(!$res){
  print_log_line($log, "Cannot create script file '$output_filename' [$!]. Stopped");
  die "Cannot create script file '$output_filename' [$!]. Stopped";
}
print RESULT $str;
close(RESULT) || die "Cannot close script file '$output_filename' [$!]. Stopped";
print_log_line($log,"Script created:");
print_log_line($log,substr(File::Spec->catfile($output_path,$output_filename),length($PMRootDir)));
print_log_line($log,"");
print_log_line($log,"Executing script:");
print_log_line($log,"");
close_log($log,File::Spec->catfile($log_path,$log_filename),0);
 
# run BTEQ 
$res = 1;
if($output_filename =~ m/.\.bteq($output_filename_suffix)$/i)
{
  $res = system('bteq -c LATIN1250_1A0 < ' . File::Spec->catfile($output_path,$output_filename) . ' >> ' . File::Spec->catfile($log_path,$log_filename) . '.log 2>&1');
}
if($output_filename =~ m/.\.pl($output_filename_suffix)$/i){
  $res = system($PMRootDir . '/Bin/Framework/run_perl.sh '  . File::Spec->catfile($output_path,$output_filename) . ' >> ' . File::Spec->catfile($log_path,$log_filename) . '.log 2>&1');                                                                                                  
}
if($res==0){
  $log=open_log(File::Spec->catfile($log_path,$log_filename),0);
  close_log($log,File::Spec->catfile($log_path,$log_filename),1);
  exit(0);
}
exit(1);

__END__

=head1 NAME

 run_script.pl 

=head1 SYNOPSIS

 run_script 

=head1 DESCRIPTION

 Translates and runs Teradata BTEQ script

=head1 VERSION

Version 1.8

=head1 REVISION HISTORY

1.0 - 2011-09-01 - Initial (Vladimir Duchon, Teradata)
               

=head1 AUTHOR

Vladimir Duchon, Teradata

=cut

:endofperl
exit /B %RET%