SPOOL 003_Trigger-PDC_repository.log;
--------------------------------------------------------
--  DDL for Trigger DBG_TLOG_ATTRS_PK
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "DBG_TLOG_ATTRS_PK" 
 BEFORE
 INSERT
 ON DBG_TLOG_ATTRS
 REFERENCING OLD AS OLD NEW AS NEW
 FOR EACH ROW
DECLARE
    --constants
    C_PROC_NAME      CONSTANT VARCHAR2(64) := 'TRIG_DBG_TLOG_ATTRS_PK';
    -- local variables
    V_STEP           VARCHAR2(1024);
    V_ALL_DBG_INFO   PCKG_PLOG.T_VARCHAR2;
    V_DBG_INFO_ID    INTEGER := 0;
    EXIT_CD          NUMBER;
    ERRMSG_OUT       VARCHAR2(2048);
    ERRCODE_OUT      NUMBER;
    ERRLINE_OUT      VARCHAR2(2048);
BEGIN
    V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
    V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PROC_NAME;
    ---------------
    V_STEP := 'get nextval err_seq_id';
    V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
    V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;

    SELECT   ERR_ID_SEQ.NEXTVAL INTO :NEW.ERR_SEQ_ID FROM DUAL;
EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
        EXIT_CD := -1;

        ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

        ERRCODE_OUT := SQLCODE;

        ERRLINE_OUT := 'NO DATA FOUND ' || V_STEP;

        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

        PCKG_PLOG.INFO(V_STEP);
        PCKG_PLOG.FATAL();
        PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
    WHEN OTHERS
    THEN
        EXIT_CD := -2;

        ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

        ERRCODE_OUT := SQLCODE;

        ERRLINE_OUT := 'OTHER ERROR ' || V_STEP;

        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

        PCKG_PLOG.INFO(V_STEP);
        PCKG_PLOG.FATAL();
        PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
END;
/
ALTER TRIGGER "DBG_TLOG_ATTRS_PK" ENABLE;
/
--------------------------------------------------------
--  DDL for Trigger GUI_CHANGE_CONTROL_SEQ
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "GUI_CHANGE_CONTROL_SEQ" 
 BEFORE
 INSERT
 ON GUI_CHANGE_CONTROL
 REFERENCING OLD AS OLD NEW AS NEW
 FOR EACH ROW
DECLARE

BEGIN
SELECT CHANGE_CONTROL_SEQ.NEXTVAL INTO :NEW.SEQ_NUM FROM DUAL;
END;
/
ALTER TRIGGER "GUI_CHANGE_CONTROL_SEQ" ENABLE;
/
--------------------------------------------------------
--  DDL for Trigger STAT_LOG_EVENT_HIST_PK
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "STAT_LOG_EVENT_HIST_PK" 
 BEFORE
 INSERT
 ON STAT_LOG_EVENT_HIST
 REFERENCING OLD AS OLD NEW AS NEW
 FOR EACH ROW
DECLARE
    --constants
    C_PROC_NAME      CONSTANT VARCHAR2(64) := 'TRIG_stat_log_event_hist_pk';
    -- local variables
    V_STEP           VARCHAR2(1024);
    V_ALL_DBG_INFO   PCKG_PLOG.T_VARCHAR2;
    V_DBG_INFO_ID    INTEGER := 0;
    EXIT_CD          NUMBER;
    ERRMSG_OUT       VARCHAR2(2048);
    ERRCODE_OUT      NUMBER;
    ERRLINE_OUT      VARCHAR2(2048);
BEGIN
    V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
    V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PROC_NAME;
    ---------------
    V_STEP := 'get log_event_id';
    V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
    V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;

    SELECT   STAT_LOG_EVENT_ID_SEQ.NEXTVAL INTO :NEW.LOG_EVENT_ID FROM DUAL;
EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
        EXIT_CD := -1;

        ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

        ERRCODE_OUT := SQLCODE;

        ERRLINE_OUT := 'NO DATA FOUND ' || V_STEP;

        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

        PCKG_PLOG.INFO(V_STEP);
        PCKG_PLOG.FATAL();
        PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
    WHEN OTHERS
    THEN
        EXIT_CD := -2;

        ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

        ERRCODE_OUT := SQLCODE;

        ERRLINE_OUT := 'OTHER ERROR ' || V_STEP;

        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

        PCKG_PLOG.INFO(V_STEP);
        PCKG_PLOG.FATAL();
        PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
END;
/
ALTER TRIGGER "STAT_LOG_EVENT_HIST_PK" ENABLE;
/
--------------------------------------------------------
--  DDL for Trigger STAT_MAN_BATCH_PK
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "STAT_MAN_BATCH_PK" 
 BEFORE
 INSERT
 ON STAT_MAN_BATCH
 REFERENCING OLD AS OLD NEW AS NEW
 FOR EACH ROW
DECLARE
    --constants
    C_PROC_NAME      CONSTANT VARCHAR2(64) := 'TRIG_stat_man_batch_pk';
    -- local variables
    V_STEP           VARCHAR2(1024);
    V_ALL_DBG_INFO   PCKG_PLOG.T_VARCHAR2;
    V_DBG_INFO_ID    INTEGER := 0;
    EXIT_CD          NUMBER;
    ERRMSG_OUT       VARCHAR2(2048);
    ERRCODE_OUT      NUMBER;
    ERRLINE_OUT      VARCHAR2(2048);
BEGIN
    V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
    V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PROC_NAME;
    ---------------
    V_STEP := 'get MAN_BATCH_ID and MAN_BATCH_CURR_DATE';
    V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
    V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;

    SELECT   MAN_BATCH_ID_SEQ.NEXTVAL, CURRENT_TIMESTAMP
      INTO   :NEW.MAN_BATCH_ID, :NEW.MAN_BATCH_CURR_DATE
      FROM   DUAL;
EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
        EXIT_CD := -1;

        ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

        ERRCODE_OUT := SQLCODE;

        ERRLINE_OUT := 'NO DATA FOUND ' || V_STEP;

        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

        PCKG_PLOG.INFO(V_STEP);
        PCKG_PLOG.FATAL();
        PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
    WHEN OTHERS
    THEN
        EXIT_CD := -2;

        ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

        ERRCODE_OUT := SQLCODE;

        ERRLINE_OUT := 'OTHER ERROR ' || V_STEP;

        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

        PCKG_PLOG.INFO(V_STEP);
        PCKG_PLOG.FATAL();
        PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
END;
/
ALTER TRIGGER "STAT_MAN_BATCH_PK" ENABLE;
/
--------------------------------------------------------
--  DDL for Trigger TRG_CTRL_JOB_CHECK_NOTIF
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "TRG_CTRL_JOB_CHECK_NOTIF" 
  AFTER INSERT OR DELETE ON "CTRL_JOB"
  REFERENCING FOR EACH ROW
  DECLARE
    --constants
    C_PROC_NAME      CONSTANT VARCHAR2(64) := 'TRIG_trg_ctrl_job_check_notif';
    -- local variables
    V_STEP           VARCHAR2(1024);
    V_ALL_DBG_INFO   PCKG_PLOG.T_VARCHAR2;
    V_DBG_INFO_ID    INTEGER := 0;
    EXIT_CD          NUMBER;
    ERRMSG_OUT       VARCHAR2(2048);
    ERRCODE_OUT      NUMBER;
    ERRLINE_OUT      VARCHAR2(2048);
BEGIN
    V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
    V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PROC_NAME;
    ---------------
    V_STEP := 'EXEC PCKG_FWRK.SP_SAVE_CTRL_NOTIFICATION';
    V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
    V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;
    PCKG_FWRK.SP_SAVE_CTRL_NOTIFICATION(JOB_NAME_IN   => NVL(:NEW.JOB_NAME, :OLD.JOB_NAME)
                                               , DEBUG_IN      => 0
                                               , EXIT_CD       => EXIT_CD
                                               , ERRMSG_OUT    => ERRMSG_OUT
                                               , ERRCODE_OUT   => ERRCODE_OUT
                                               , ERRLINE_OUT   => ERRLINE_OUT);
EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
        EXIT_CD := -1;

        ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

        ERRCODE_OUT := SQLCODE;

        ERRLINE_OUT := 'NO DATA FOUND ' || V_STEP;

        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

        PCKG_PLOG.INFO(V_STEP);
        PCKG_PLOG.FATAL();
        PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
    WHEN OTHERS
    THEN
        EXIT_CD := -2;

        ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

        ERRCODE_OUT := SQLCODE;

        ERRLINE_OUT := 'OTHER ERROR ' || V_STEP;

        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

        PCKG_PLOG.INFO(V_STEP);
        PCKG_PLOG.FATAL();
        PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
END;
/
ALTER TRIGGER "TRG_CTRL_JOB_CHECK_NOTIF" ENABLE;
/

