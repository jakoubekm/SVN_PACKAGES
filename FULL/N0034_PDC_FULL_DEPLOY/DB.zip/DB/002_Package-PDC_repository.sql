SPOOL 002_Package-PDC_repository.log;
  CREATE OR REPLACE PACKAGE "PCKG_CRTP" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
727 20b
UUHiF75+ne7+B4ih1p5vOdykvLUwg82NAK5qfC9AWPjV3EyD8nTnqDkv1gsPXgopMcDRXGVC
fd3dCaj5nVPPjo0OUUCR2wyKtD/kGe35pfIgXBh8/iMTYKS0chfFT9dnnuocqBeI82J/6ARm
CjZ+y5v6L2ir0wzFw7BIS5FLRhr8c6q5hl/VNrj0PDOHQCqgIRad9F1X4kw1OaYM8EE7jJ8N
ADnUm37dk6qCZ8YbkQna2LpKoqt/ilxQ/ZS5nNAo1TAjN5UIpTOrKLssxul4s1uws441rAgu
1FErWKfsAdUNfZQgp1WbpxRfh6ayXUXAmVheG6uVtGv8/MqmCSehyRMIo3Qb6YM4pnusGn1I
dQ4lwHfgBFOsN26fvOHFn/pnKgQV0a4LsjpAe4hXjuiQr0+gnb3Z/IkPw2GSEO8qp9nJkRPZ
QJecEFu6oQbUo5SID5BzCPku7lWRvC5DMRadg+v0HEPlZkyViwns/0vzB7WazX9IbU+lgcry
+Iu2zlDPIw==

/
  CREATE OR REPLACE PACKAGE "PCKG_ENGINE" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
1c41 390
FBXx/knpMsxscpOZaI63PbCOf/Iwg82TLvb9fy/NMZ3mXfEq0i/yKWtrW5OrZFxkYzsiaM4a
hL1rjua1tSbxK5/8e5+fv6KvS9TLCOxJ1/8STiElYYk73rJd6AEeg9bYAkYTiCqC04efseGz
S5FgtjgGqkateYm8T2OaWK4WoXgvnT7eVo2nfibJ1eUkw08i//rBll0z/tAPrvkIOinBToZ5
QGGjf4/cHX95bjyxcHPqDaXwfGH8BqWsEqihMAzEk6nc3Qxk/tuKXwIuGBaE/q/SpsdUU3tq
Ws4LazmkBp0eN/A+ZqKtDBrg5VVDoIFnFdZLQQgL9bv9OTt46DPzIyHdqQXLhHyV7vVfqDUh
92QDzEeWLRkWlwCwb+WFtbWw0f+riTPTz0D+qRzmrn3O9A8bJZa3uYOJwnBvPFjFsCTHsceS
dRL8FLqyxojMDIOKUu1eb8irvK18n017C+LUOoj/UOF72x7dvwOyQSPPLmNxk7ABiwRrw5E7
iRan4T2sxR9h4WEzmjq8cNQYvdVJGhtmetXMYu03UNGl7wF0U7KJFJfjUeNWGM4RvQEOYzc9
OUF35tina5SVCmP2pWt62CsugbuDs2QqNWR2bEeqDP0Hm0fe84gKJup7eS0Q8z2BJyclFWdi
bueox+fx0atNhdsplDz+rQm+fPQ99OvV0ooBtHKjaxSTvFUzv+tyKE6/k3Kcu5YoxIIfQHoI
zoSJwYuXsa4fdkkYitJS+BCK4iyY/sZBpone4tkrySZA7XFyh9h5lgPv69zyzLCGiiuls0lx
hq7wacEiPiNC56p7eEWDp50SGuA0XMzxVdMvLqoamZ08tbdryezSlN0INoVffISglEqqK8fY
1W5yiWW85mGxXhfKrToeNThTm7kouyZkAw==

/
  CREATE OR REPLACE PACKAGE "PCKG_FWRK" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
1ff6 536
C6LrMOlIpWw/3ejHX1zutcRvlJIwg82TACAFfC/Nig81NhYGpnmSN1GE1sshMqeIDBpnCdxo
AoQ3n4UJ9SmalulYwtgol4lX1OfT6TAj0CO/XaQp4bcA3PtVjpFP/M23tJrYTXGoTqiDGQtX
B/wk/xoVWWsdb5EHlcGBsZa/fQW/9fjBwdkgcx6ampwFB40QSy9uZwmeZ8JLieyKqYqBXlGy
AsVDezcuWCeXyDo1i5ysjkbukhFPT5I0hKVZjRv0votj5l+2h3bz1U6y4/aIRoUB5QrGllpo
BUyuhDDhEEFQr5GJr84RuRtujYuuFMeMzv1yBhHRgGXss2LjbG+WIXhAO/N08HBsAcPMbrMs
VMz/pxd5GjTwWL7zx3gYQ1/VRWMU8e5k2dups61a3vwm3Dj0atnY8I8pwILBRRYI+35s64iu
KnapPu2MCTseDGyuQMtnuaRdO3tvS0U/4A3BAn9VjFA1QJ4Bdkl7r55607IbieT3IH4Di+6f
yK13dzpll1nWc8hANWkyd1i+heQ8/ktr4BssvqX2V1p8DWOlXk/KTk23KaCurOsZuPT0iEPK
r4zJ+lgwMFBv85cKRjFkaacnA3F3t7jPigB+pX6VCZDsJ5rPAIyssaRi8jyO46+B6OZGJYPg
mopbeoSdNkCXXc6TxJpwWmuvRvGGhKR4zJVUCHQ2ydvEoLIkfIA8yck/DREfHFahw/SCEN2T
KY0nr6wX19ypaAhHxCIqdWnAvEI2UejFrpkqjHuEgqHU5WVGnEEmSOb/9hvxsFXD9L/IpVwq
O6vF/DuCy7by0amlengxcWQKGRjraqN/64PCZdnmrLiJnpsmaN5ryfxWmnHUMbpgaKPUBZPU
KXdV1MYz/MGmPL5740UgjBXCDQX/a/MCQnNx9uW+R3aGJIwVbINzknXdNEBzwgGAhzOtPHg7
UxddywsxzLQ13L8MK8xuZgBW30ZBPmi5xIBqGUhTzYhX+Kkg1pE56gU4De6V33cuuCap1ABu
98m9Fl6xrzL4andiaQuIPgJLRKerTRVC83U3LoEzkY9fkgDMjdFEezI+UFOVwZAty3qMQTDU
eptxK+zj0zFD9xfBRhpbdQ1o0SgBX3xgmTjYpURGSLplCTHQYXsCycbtY1+XpBQeM988oxKx
dDWpxenHqnX/YL7dFUZcN8j2EjEaN/1tMSpO2EcxQwCxWQPHw5qq/PraNICd6g5dRQ8D/GaP
/cwOoCEKjeLART/Bl4WBvpZUZiGScwSWAjF/ScjMXvnQZA9lVhMc1n/NdtZRMpi2uTmljrwj
uCjV6+l157w6KJWwMTA=

/
  CREATE OR REPLACE PACKAGE "PCKG_GUI" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
16afe 1ade
rw6hlXjx7BVaJIeni+ATUxacauMwg81MVcBd6NMisfiOXiZ7lCA9Puo8E11m4nERFHqMVO8+
qYqQ1e21unZQlspGyBExHCD44LFgLpl90NDoOsyIlXKz9HY/PobBXhDlJQ+8GorZNeTbMreJ
gB9mtcXA1IxuLIdmq0/vkrj+wbsPKKpzEM4Ncs4ehh8I78eb9qHLidtlDdzn0CVfpAkbt57s
aCplmwdS8lEMkBsH7hdQ+aXGTw/ar7WBrEzMdqygl4wLYMsHbPBCc4mLPtq3CFVCMq3T5fKO
IRvlaKIGY1q2LrPDgP5L0fEUmIMUoveBZbpsJeT1uInDoEsJtm3bf9UGF1yRZvcfcbTyicSc
7FqlrICTVRsT0w8sKuskLi619ePVl557VE/Th7No2/qM9GuqGO/HN1p66vOReMSOCVCGAmWY
L/quUfRAeP9rDLR+vayT2zBMjaHb9ApZ82S0rBvRCII8ILy94AjiXjVk3GvoQ0xk1XLz721M
M5dXUiqLNn9ehJjKjPKufGrnC/BGW3BvUHzyI6jZE680R829kJMtZvL8zBE8QSFiEZdkmZbw
lqGQvYqulbxzM6WYCVvFdLgBC9lCa4W2BUF9M9v+igxt/PX/RONvoxqFQqRDsbF9/HaJ43zV
Qwwq8GVrBz2MoB/ER/RMUSwJuPR7h4yJbS1jIl6wVOZRooM/yBMm5pPJJnyEo107Ou1X9SsF
LQ5xpKsAWtt9OtE5iKISkktClkyd6UmLsDLgfudUmwHSetDLcKEV6jg9BYeCU3CrPQinoeJR
xXsAmYNdMPWGnflhX/ni49FomKLTFQat8zgxJnLuyuES7nOy6qoDrheO9Ae6SMgHPbKbpX1I
Srvyx/Uip6PFlVwlt8ZvXuucl7UQMjqduvvRmQGfFf+ZgpIOITkuDK1TeR5B1AqnGCLjcqcS
gdiFFwldgkmbWNM6R+PPG6IiTqhPKchyfoUXZV2CH5tYnmL1PfQQEI8Gq7j/FQLvoG/U5Zhg
djjvttnjnoTG+qiLIfa1Zm5pn5okzmTDsVSY39qFv9qPF4e+w7ehYcY6/IX01Bp7ZVJre5YV
vcgBu8VjTQjYiTrgcvLwMXGNGHKn8vSiD/0+ns8KCzQlxHuE37oy7AlhdFEtHlo+OdDlakEI
TYi5p62fm5djGBaIb+XKGFx7YM8QV6qlBHIsejnS+sNlXhb6CyIhugeUzWaCkz5j9/M0gnim
MQZmUdiqVgfp9Sa+pgLRKh9PfBlXtpB8GVe2blBji+C2RXdxEeDFAW1ZBCBuvVkEYn+2nFBj
i2Y2RXdxwxWgjF2pklpGSXxk9tG0DgzXlav1Jr4EFaBcmNzB5QuVckRMwmEZJHkJTu0gfRSH
VdxaJHtFBXbzOJwFjNk4FyNP/yGkuSu/vo2MTJwLP00eRdxY6b6rwj6HAdn0tSUavRn6wTJ7
kBRvXP8pXDDeg2qaH6SIQwL2YHlY2aHvUZY9CUNUlH+BGEpR/aOQgmMeiK6RVOINt7DW30KY
xBBFcZ/9kJbfo0dRjKmzFfxU1SFH0c3mlLbRuyXT3FarT7fsgr96EF9sVxVdlrkES+03crxB
uzH8CG+hBpspiQ7mLGedIOsTvsZxuDW3jSlFoH8WsiXyRUGvcNioasjibf3uBzU0obHp8Bbb
yuUaEwGx5tPyMQFF0fZ0D9aKdSJ56QHK66Mtrk+LaRZe2ajrMt4LUKQaE/WM7COOC9iLdUh1
fYCTgJawSIFwvmI7ETxQU0Z93FPrjOSC6a0urhf//FEGnlDar0MsJmuJmMldlsx22SOz5lRL
zNW9/LwfKcld7cjPuYVjGCqtO/Dgbz8mTGBCA2rEoL9WYmui7gWko+zjm7YmY/0UnhKW8c1E
AwrAlNdHf7JTF5UmspzjD4WZ+jqtAWiXCJUmSDbSjXOE660eCCZHqmSe/ch5Ca0TBGjo6B/f
deiPKV6dOatJSJRASzWii/ztmNyQS7cCVXuKd3ox0S0aFX7DG0HZJqKQ9A9lYy5+nhsVQDcW
Yk082NEdMhXf/fjlfUZ5xfEqfKG0kVAOGVoeAteofC0+dT7p7350YCEYT0OOZiYRd5hmx54b
FafMx8ISAcvYjEvHdYd9eust2iK2vmd6YuNindHY1fHrrfY4fhg5OEwHdviRC8wxvr6PQqtD
f1izOB9BxX6KMLN319UhArIyf2RRWWAV1cJUgFy0Z7OTWRdy6afOIT3K2B4WSrXIdbp1l+iE
80Fplq0wjLB1zlKCaCRqXm+5rodyKxVhJ30CpMvIC87HSgphftBha1zk7xcrFVPC/rrUXDLU
75D7kwfJ0TzJvixBrg4qUPRiuvhPYq72qTp6t98XtRjMUVqFaAqSwU6nwkObKkpj+x9ijENC
9TB6H+6e4vUwOQ76NBX4cfUwioYmTPAQepBSf4rFK74ETsWLcXSWRO1LaiC3roMrLQpLvRK+
54Ky9jLzGvqWH6/uzfYjTJ+UtjiWJ247kDFPt0bFbcu5ipBLs+7nHxouWdCV4jXzM1F9rdr9
js1dsW199vb6DbsOM5Dmlj5CXLBC8ngrXoHXfGpHCa486NBtBZGKIIfsbOy+VustwQkjpvLp
RY55lWG9/9wFo9cefo8ruDCYh0YMibHG48bBeyNYuXj8HXSBfz/RXOhpESfFgi8lGlDrxL7y
4vIkRZlyWjOnYyyHwerPqBkpxd7ztu6cGB+czT/FFfDj3VWPHYVLYdMxM19jdO+qExIQM7zz
Yby88gFnIvf10UDE8PIjeAv2+Zwj43GfxSVut7ZrqnMQzte6DOZKPSYghS6rhdCgE3bZfQmH
2+lCPXizI30O0hXcLjDyXgNFzEZR6C5J7DwfTZMdmZazU6dwBJIKCmoEGQER0L3NZa+4RBXV
pnA1L5lbk3xHkqk8y637xNkN6BS2So+ZOFW0wqs+JXPkxGZfDNBnxKWcANd7tMfHHeEEgmgY
E9d4VfkweLnWw4nXSC3kBlvRqJorY0iLKS46NPvlwaojgw5nUwQ7bZYqss6Jozz1vmfhvVv9
BEKpL1um/JKykL+G//9Cd/BlQWAfm6hNXk7v/CK2/EVMs7+GMxFb/DmIroyZOsp3PjrzMk/7
MiVJJ8ucGd5vCMe4RXln7Yh69rwxIzefmQ1UDjuswYcQuLR89+ug13/MIc2wKnkuP8gwbRA7
ZIHobnzhQI8PL5ICcJppm+2i0q3gzTe710Bogw83rCjKHcXDffsbuaaUPgUlA9pa9XiyNqlm
L28OOMPjhUMXsmNA5kZcUnY2tqZNpkR/+6gd/f9GXxGsFRfVRkW3eAW4A5RW++e9QOlXb6z7
pnCB8Oji0ZG3Y3irI5iQhNd2fkNp7wcFMG30Cs9OwygSTs3SiwydJuZHH/yqSoqfF3SuiGSN
7y6QG0NQGWg3SSyV1CLj+YVuMnKQZLzJIBPpT0LxhYCaMNT6dxEkc12MA62wkeUTdoebO3mq
UZcrCwXe1W7KSNEuA/dodJsK/U2ntKn3fNHncKxQZ1DRVqbZ+0t0ppq1ayO1IhC1F22BEPt9
CFEklr9C3D/IOwA/Egfqc40NrR114abpL8rh3S/nRnba8XqpTomLu/t2IaqPJ68Rr6ndLk3B
0Ay7jzNd3kHAivfELoWGfZAmmKOsIfq3FF5Mm2njwL7O7cCqGJ8zOBwgw+TEKsNG5AizzoyX
am6vaRJIMufzmalUcAiT5JD6A449Y1jbjUaHuC6lsIe2iryCUD8sG5Z6SZ5eFlLAPvPy52Om
Fu5fQ0BgiLu255BS18cghzAWl7pf6gt8x0TL5MKZFHfMpzocZjuXRgqATlJyXUlx014gNmi4
Vr802uC6SIEY9DtTjgP+VlDenp9YynYbV7+9UJOsx43KpGNwaEALeC+d11g/aEmfgvjbybtw
pUcxkJZxWOr0V+KA6hBWfzwQBS25O00DZBC/REtVEx5AXqq1KBUpYe4au6n1aBq8ppfuHM3c
PSUyQ9wyc4AkWUwQRcRR+ZjK6FEiVbqzpe39Xuul3bpctQLLXl5PuYeAJyPw5KCVTCtuJe6L
pLuMSgF3PO5L4K+mKKdIEKoLO9SokD6vwpCYDOt4WP0RYEDHzVWLgzzXEZJcOgMvf7uh23B0
OQsrykdG0P0XcyJ3E07+M7RddEXGiPVtgs7LFw6y/5iKIGAXGcRk/juKscZDxsbmUbA4a15z
Zj2Bvh2M4pikSuEkpEQ/eiecTsypWxqf2qhElBcHnsId6bSvFR4OR9NEGacvRXy21JZnnJW5
lX/aS0fLegO266nA10p+HVPivxN4OWRTGUL0vxSMMMCu/vr/UNf17hIp5ojnEYIZQVagmSjN
FaKYUvN8/c2XgA79gqj+AeFI2TZVjSlqWaSaMEteiMyz+jaW7cQXNr+yIst+/Y/rEMDUHX9i
loZEFNooezD7vYdnm4fVZ/IXpRtGUIVV+5GajLMtmt7BXUr/zRy8zRzizYdBYtgLmLAPbf0R
6n3hsFF91nFfq/JauLCaM25Su4JDGRf/7Zoa/SM87bug/SiiSD5YKMxCOTmNuTPz4dbKOABf
XUaAwDzclR5lbZvQqQ6PLcsL2QS61LSbW0pi1UaG6Ek6DL91He8CBD7bWu5J8I7RpLSrhQ5M
lihsNksWOKrkUozhdNPgyC/WRiwbWk3IbSy2oeFwxPk3O1XnNkEij/oLLPypFEpzER2dO2/y
by61v17px4aT9xQgqvzncmzuvhR6nKD+vhSzDZwoKCGcsYF/EIeq+GfMPCHe9XDIlNbYBJFz
VjUrjfYrf+sdZbZltmW2Zev9fOtqxcmSSkdGR0ZHRkfSOUfSELKC+1bpN0tev9e8NhDIy+NM
URIgtlXeT33c/em/aD6evFz1we1RDhPpOL9trEgfRBmW/Ma6Px4rkM/OJT3uHc0f6dDnAGbS
4zMI43pvvv8U8jYocVEhxnkj2utbSOtqeSOYJaxQt52gaefq9fFDiPV5sdvvM2jhIqBZrK+H
JUYUgQir2NXVURpI4nQoPRQexvw8gzcWfYkRT3GZYoewTqFTdRT7XD4EKr4Vb2XXXp9AxcnH
t39CUUaQ9p44KRnUvXD7hmbVxUXumE/NiA5Op/ZX3/A8uoDepbOIJ8NAq/CogO6lsx8jd7L9
eR2AMUuzKvXDMqQCrQ96M0rpk0B4Kyy4FwS5dB2fWP5oiDzScWTIce9CRxjOWBS7QgsqGa3w
v9yGkOsO7ioESBHBcQQrakurQD0i7imxLn5pH0KflZXacTRqldpxNJnBidFwGFuTml+ipcrV
HJEQXsKpOBifLUAfwFIpC2ht9L+jBpCnMLBDW7zrwGJqoAo8BL2VWhZg5n/T5VKEjR3Yt8/I
IEePsU6lHkLO92tVQoQZN9irvZaF1HwxRZnCEjb6GRDrhz57FtpmRh89KW621MuFfIV83+RW
pk0I3N8LSaYhOBE3qb3nIsqp+9bjysU+3Fn576RHFove96qJt0MwxXauAoYmpWoubp5PwuNb
HoVeQQacmQsX1PcyyDLIMsgyKwNK1GaH2O+V+gz/9zLIMsgyyDLhVAc0L6/vKdMIfBV1IYYS
buW3hd4Pvt9JQcZqTjDas/quuBxku05H0Kvmy1UGb45orKy6aUgBAheyf+S698VwsnxGjuE+
+zb9fIWmr0Qvxd9A/LbxPRAgVecH11Tn++ZXnqbKL0iq54bEQVNlItiFWOmA+6YMh5bdhdBF
mrk4h3pVvctN37+IzH9CO2qJNmZeU2Cb5Qr+teLF2xfMCBJ1GUXmZ7GIVtO09/9Sdez0sbw1
gGcsEbCifY8QG1sge72HnCQE3DeGc+7WiurGzZcgpnjXlKlpDRztXFilUPrX+FXaB2tpHt0Z
YUMztDTh6WIJDQGzDhreNV4/Kpd3SRIe9JahYrqFUOtJ+LHw1CqYwrkT3As9QJG17PpacAfO
ajyUrLNEnkzCaWrj7m10EBQ84WNc1YKGYN4mEdgPT4ogtea4kYkPD+/tn/JFxOIM0oQcegFg
Q5KRIADMGxnFrvqCHMzilAyqoFHB6TTggfduX8otkt26BfaJwEJs0lgnRdSRIC699PFAT3Rc
8kW1klwSoTD+zA01Pcg0noy9OC1EjGUxml+UJB+gu/qMvRORIGJCr4DfBA2FkSCkN4bE0ukI
R5fBTLPn7FOEDgqi9ahFM20Ry26H5QpqILLHdUsWHIojjLQW0q/iUH0WwzCOFCKDzwMUPxkZ
kBWYwxGJlJzdIorTdfNJtKeY/o+xPyvpx8S/D1eCCHb8J4YVMbLRbgIHEWtL6mYzLxIejali
Kk3STDlCHxPaoh2PDD9FpZjIAbTYV2M6yEJMGWXgfh4SjFenEnTe93m6TdtDhjJM1x9Z190c
RaaYpMNTqZneislE1vFTKqB8xdoaWRuOIfNg6Dseg0NFEs6GcmSjxndBBHtPWZCuB1NR2AQK
Nb1kEeKdGRB/5y9jqCrd0BVKckUqQIHoH63JaETaDzg2tiH1Mp4YViaUbH1nvG0dPjh4Tvdy
ybwv2btRGLFAirmpWH+PDjMrtwJDXstOsQmV6Y3HI5R5X7ZHT36svqQhoJfZVpfzf+N1MuPe
4J3n/Ubw/d+3zhdY7r6NTy9XoDCNmNRFTw5NAYK7muWMC2QOwF9KPJ+k/90pBq1E49xGt6wF
WI5GVjzlVSj5cBU25d7/yLv3ux3zCmUyfKGdRITQDyKoJFpxKpiqIlt9vzSrINASCDNTjiBk
/QhwZGoFTtF6XbxQofE6pIm91kvVhl0Jt3apeyJ3W/0IHs8KDDw4r7+lKdu3iaifL9rRish6
86aScrX7JZIzLA==

/
  CREATE OR REPLACE PACKAGE "PCKG_INIT" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
ff0 227
/Xfre/MNkuMXVSMwIWT0HdnUvRMwg82cLgwdfy9AAP7qRoeDrFvzCA4wdS7of98u5iKi7V2P
NRjKHOS1ddFc8ybY2selUEtGVUu2QP6QQsL9Z+JnjHU5viU9V7ewtlq2s0DYc+zWKkhPNAyI
cW/EL0Mq2+s6OjHmcXH0MR6GTl5VNH4ZyZy3InyilsyN42YCP9k/ZXDXHf+z3oZLqz1v6Zhx
k78EAhVsjhOVoZ1qloZT7YOU7W1veZdNf2GiOUYGTAxg5Z+7DG//DCy5v4h050pSkPVVYD9t
tS+RUMsl1eS+lSwJS7qBM4tLtPY1S4/nBtDxEBqPjia9Zutd8ATK09kSfnnQln7gXOvy7BQw
GGWEFyZniPC24VlNFqisRhQSvZ5lPP2aPZ92XfGFZ7DHkB27fonBrAAHkw/GSOmwVG5mg6Iz
48bKb79aPKKJcAGahBsB7ygQ0iT4Wh9q+b0Sfe+8IqOrW2GX8SbiX3hGBkQxOeUdXxCzcG+C
H9RXZ9TWZWB1CO5+TVLNtB9PqjPXxoy/HxmEWg==

/

  CREATE OR REPLACE PACKAGE "PCKG_PLOG"
IS
    /**
    *  package name : pckg_PLOG
    *<br/>
    *<br/>
    *See : <a href="http://log4plsql.sourceforge.net">http://log4plsql.sourceforge.net</a>
    *<br/>
    *<br/>
    *Objectif : Generic tool of log in a Oracle database
    *same prototype and functionality that log4j.
    *<a href="http://jakarta.apache.org/log4j">http://jakarta.apache.org/log4j </a>
    *<br/><br/><br/>
    *<b> for exemple and documentation See: http://log4plsql.sourceforge.net/docs/UserGuide.html</b>
    *
    * Default table of log level
    * 1 The OFF has the highest possible rank and is intended to turn off logging. <BR/>
    * 2 The FATAL level designates very severe error events that will presumably lead the application to abort.<BR/>
    * 3 The ERROR level designates error events that might still allow the application  to continue running.<BR/>
    * 4 The WARN level designates potentially harmful situations.<BR/>
    * 5 The INFO level designates informational messages that highlight the progress of the application at coarse-grained level.<BR/>
    * 6 The DEBUG Level designates fine-grained informational events that are most useful to debug an application.<BR/>
    * 7 The ALL has the lowest possible rank and is intended to turn on all logging.<BR/>
    *
    *
    *<br/><br/><br/><br/>
    *All data is store in TLOG table<br/>
    * ID         number,<br/>
    * LDate      DATE default sysdate,<br/>
    * LHSECS     number,<br/>
    * LLEVEL     number,<br/>
    * LSECTION   varchar2(2000),<br/>
    * LTEXTE     varchar2(2000),<br/>
    * LUSER      VARCHAR2(30),<br/>
    * CONSTRAINT pk_TLOG PRIMARY KEY (id)<br/>
    *<br/><br/><br/>
    *
    *
    *@headcom
    *<br/>
    *<br/>
    *<br/>
    *History who               date     comment
    *V0     Guillaume Moulard 08-AVR-98 Creation
    *V1     Guillaume Moulard 16-AVR-02 Add DBMS_PIPE funtionnality
    *V1.1   Guillaume Moulard 16-AVR-02 Increase a date log precision for bench user hundredths of seconds of V$TIMER
    *V2.0   Guillaume Moulard 07-MAY-02 Extend call prototype for more by add a default value
    *V2.1   Guillaume Moulard 07-MAY-02 optimisation for purge process
    *V2.1.1 Guillaume Moulard 22-NOV-02 patch bug length message identify by Lu Cheng
    *V2.2   Guillaume Moulard 23-APR-03 use automuns_transaction use Dan Catalin proposition
    *V2.3   Guillaume Moulard 30-APR-03 Add is[Debug|Info|Warn|Error]Enabled requested by Dan Catalin
    *V2.3.1 jan-pieter        27-JUN-03 supp to_char(to_char line ( line 219 )
    *V3     Guillaume Moulard 05-AUG-03 *update default value of PCKG_PLOGPARAM.DEFAULT_LEVEL -> DEBUG
    *                                   *new: log in alert.log, trace file (thank to andreAs for information)
    *                                   *new: log with DBMS_OUTPUT (Wait -> SET SERVEROUTPUT ON)
    *                                   *new: log full_call_stack
    *                                   *upd: now is possible to log in table and in log4j
    *                                   *upd: ctx and init funtion parameter.
    *                                   *new: getLOG4PLSQVersion return string Version
    *                   * use dynamique *upd: create of PLOGPARAM for updatable parameter
    *                                   *new: getLevelInText return the text level for one level
    *                                   **************************************************************
    *                                   I read a very interesting article write by Steven Feuerstein
    *                                   - Handling Exceptional Behavior -
    *                                   this 2 new features is inspired direcly by this article
    *                                   **************************************************************
    *                                   * new: assert procedure
    *                                   * new: new procedure error prototype from log SQLCODE and SQLERRM
    *V3.1   Guillaume Moulard 23-DEC-03 add functions for customize the log level
    *V3.1.1 Guillaume Moulard 29-JAN-04 increase perf : propose by Detlef
    *V3.1.2 Guillaume Moulard 02-FEV-04 *new: Log4JbackgroundProcess create a thread for each database connexion
    *V3.1.2 Guillaume Moulard 02-FEV-04 *new: Log4JbackgroundProcess create a thread for each database connexion
    *V3.1.2.1 Guillaume Moulard 12-FEV-04 *BUG: bad version number, bad log with purge and isXxxxEnabled Tx to Pascal  Mwakuye
    *V3.1.2.2 Guillaume Moulard 27-FEV-04 *BUG: pbs with call stack
    *--V3.2     Greg Woolsey      29-MAR-04 add MDC (Mapped Domain Context) Feature
    *V3.1.2.3   Sharada           29-OUG-06 add log when there is a problem whith a pipe
    *<br/>
    *<br/>
    * Copyright (C) LOG4PLSQL project team. All rights reserved.<br/>
    *<br/>
    * This software is published under the terms of the The LOG4PLSQL <br/>
    * Software License, a copy of which has been included with this<br/>
    * distribution in the LICENSE.txt file.  <br/>
    * see: <http://log4plsql.sourceforge.net>  <br/><br/>
    *
    */

    -------------------------------------------------------------------
    -- Constants (no modification please)
    -------------------------------------------------------------------

    NOLEVEL              CONSTANT NUMBER := -999.99;
    DEFAULTEXTMESS       CONSTANT VARCHAR2(20) := 'GuillaumeMoulard';

    -------------------------------------------------------------------
    -- Constants (tools general parameter)
    -- you can update regard your context
    -------------------------------------------------------------------
    -- in V3 this section is now store in PCKG_PLOGPARAM. Is note necessary for
    -- the end user to update this curent package.

    -------------------------------------------------------------------
    -- Constants (tools internal parameter)
    -------------------------------------------------------------------

    -- The OFF has the highest possible rank and is intended to turn off logging.
    LOFF                 CONSTANT NUMBER := 10;
    -- The FATAL level designates very severe error events that will presumably lead the application to abort.
    LFATAL               CONSTANT NUMBER := 20;
    -- The ERROR level designates error events that might still allow the application  to continue running.
    LERROR               CONSTANT NUMBER := 30;
    -- The WARN level designates potentially harmful situations.
    LWARN                CONSTANT NUMBER := 40;
    -- The INFO level designates informational messages that highlight the progress of the application at coarse-grained level.
    LINFO                CONSTANT NUMBER := 50;
    -- The DEBUG Level designates fine-grained informational events that are most useful to debug an application.
    LDEBUG               CONSTANT NUMBER := 60;
    -- The ALL has the lowest possible rank and is intended to turn on all logging.
    LALL                 CONSTANT NUMBER := 70;

    C_PCKG_OWNER         CONSTANT VARCHAR2(64) := USER;

    -- raise constante
    ERR_CODE_DBMS_PIPE   CONSTANT NUMBER := -20503;
    MES_CODE_DBMS_PIPE   CONSTANT VARCHAR2(100) := 'error DBMS_PIPE.send_message. return code :';

    -------------------------------------------------------------------
    -- Public declaration of package
    -------------------------------------------------------------------
    TYPE LOG_CTX IS RECORD( -- Context de log
        ISDEFAULTINIT      BOOLEAN DEFAULT FALSE
      , LLEVEL             DBG_TLOG.LLEVEL%TYPE
      , LSECTION           DBG_TLOG.LSECTION%TYPE
      , LTEXTE             DBG_TLOG.LTEXTE%TYPE
      , USE_LOG4J          BOOLEAN
      , USE_OUT_TRANS      BOOLEAN
      , USE_LOGTABLE       BOOLEAN
      , USE_ALERT          BOOLEAN
      , USE_TRACE          BOOLEAN
      , USE_DBMS_OUTPUT    BOOLEAN
      , INIT_LSECTION      DBG_TLOG.LSECTION%TYPE
      , INIT_LLEVEL        DBG_TLOG.LLEVEL%TYPE
      , DBMS_PIPE_NAME     VARCHAR2(255)
      , DBMS_OUTPUT_WRAP   PLS_INTEGER
    );

    TYPE T_VARCHAR2 IS TABLE OF VARCHAR2(2048)
                           INDEX BY BINARY_INTEGER;

    -------------------------------------------------------------------
    -- Public Procedure and function
    -------------------------------------------------------------------

    /**
     For use a log debug level
    */
    PROCEDURE DEBUG(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                               );

    PROCEDURE DEBUG(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                               PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                          );

    /**
     For use a log info level
    */
    PROCEDURE INFO(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                              );

    PROCEDURE INFO(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                              PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                         );

    /**
     For use a log warning level
    */
    PROCEDURE WARN(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                              );

    PROCEDURE WARN(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                              PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                         );

    /**
     For use a log error level
     new V3 call without argument or only with one context,  SQLCODE - SQLERRM is log.
    */
    PROCEDURE ERROR(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                               );


    PROCEDURE ERROR(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                               PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                          );

    /**
     For use a log fatal level
    */
    PROCEDURE FATAL(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                               );

    PROCEDURE FATAL(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                               PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                          );

    /**
     Generique procedure (use only for define your application level DEFINE_APPLICATION_LEVEL=TRUE)
    */

    PROCEDURE LOG(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                             PLEVEL IN DBG_TLOG.LLEVEL%TYPE, -- log level
                                                                            PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT DEFAULTEXTMESS -- log text
                                                                                                                                 );

    PROCEDURE LOG(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                             PLEVEL IN DBG_TLOGLEVEL.LCODE%TYPE, -- log level
                                                                                PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT DEFAULTEXTMESS -- log text
                                                                                                                                     );

    PROCEDURE LOG(PLEVEL IN DBG_TLOG.LLEVEL%TYPE, -- log level
                                                 PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT DEFAULTEXTMESS -- log text
                                                                                                      );

    PROCEDURE LOG(PLEVEL IN DBG_TLOGLEVEL.LCODE%TYPE, -- log level
                                                     PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT DEFAULTEXTMESS -- log text
                                                                                                          );



    /**
    context initialisation
    */
    FUNCTION INIT(PSECTION IN DBG_TLOG.LSECTION%TYPE DEFAULT NULL
                , -- root of the tree section
                 PLEVEL IN DBG_TLOG.LLEVEL%TYPE DEFAULT PCKG_PLOGPARAM.DEFAULT_LEVEL
                , -- log level (Use only for debug)
                 PLOG4J IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_USE_LOG4J
                , -- if true the log is send to log4j
                 PLOGTABLE IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_LOG_TABLE
                , -- if true the log is insert into tlog
                 POUT_TRANS IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_LOG_OUT_TRANS
                , -- if true the log is in transactional log
                 PALERT IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_LOG_ALERT
                , -- if true the log is write in alert.log
                 PTRACE IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_LOG_TRACE
                , -- if true the log is write in trace file
                 PDBMS_OUTPUT IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_DBMS_OUTPUT
                , -- if true the log is send in standard output (DBMS_OUTPUT.PUT_LINE)
                 PDBMS_PIPE_NAME IN VARCHAR2 DEFAULT PCKG_PLOGPARAM.DEFAULT_DBMS_PIPE_NAME
                , --
                 PDBMS_OUTPUT_WRAP IN PLS_INTEGER DEFAULT PCKG_PLOGPARAM.DEFAULT_DBMS_OUTPUT_LINE_WRAP)
        RETURN LOG_CTX;



    /**
    <B>Sections management</B> : init a new section
    */
    PROCEDURE SETBEGINSECTION(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                         PSECTION IN DBG_TLOG.LSECTION%TYPE -- log text
                                                                                           );

    /**
    <B>Sections management</B> : get a current section
    */
    FUNCTION GETSECTION(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                  )
        RETURN DBG_TLOG.LSECTION%TYPE;

    /**
    <B>Sections management</B> : get a default section
    */
    FUNCTION GETSECTION
        RETURN DBG_TLOG.LSECTION%TYPE;

    /**
    <B>Sections management</B> : close a Section<BR/>
    without pSECTION : clean all section
    */
    PROCEDURE SETENDSECTION(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                       PSECTION IN DBG_TLOG.LSECTION%TYPE DEFAULT 'EndAllSection' -- log text
                                                                                                                 );



    /**
    <B>Levels Management</B> : increase level<BR/>
     it is possible to dynamically update with setLevell the level of log<BR/>
     call of setLevel without paramettre repositions the levels has that specifier <BR/>
     in the package<BR/>
     erreur possible : -20501, 'Set Level not in LOG predefine constantes'<BR/>
    */
    PROCEDURE SETLEVEL(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                  PLEVEL IN DBG_TLOG.LLEVEL%TYPE DEFAULT NOLEVEL -- Higher level to allot dynamically
                                                                                                );

    PROCEDURE SETLEVEL(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                  PLEVEL IN DBG_TLOGLEVEL.LCODE%TYPE -- Higher level to allot dynamically
                                                                                    );

    /**
    <B>Levels Management</B> : Get a current level
    */
    FUNCTION GETLEVEL(PCTX IN LOG_CTX -- Context
                                     )
        RETURN DBG_TLOG.LLEVEL%TYPE;

    /**
    <B>Levels Management</B> : Get a default level
    */
    FUNCTION GETLEVEL
        RETURN DBG_TLOG.LLEVEL%TYPE;


    /**
    <B>Levels Management</B> : return true if current level is Debug
    */
    FUNCTION ISDEBUGENABLED(PCTX IN LOG_CTX -- Context
                                           )
        RETURN BOOLEAN;

    /**
    <B>Levels Management</B> : return true if default level is Debug
    */
    FUNCTION ISDEBUGENABLED
        RETURN BOOLEAN;



    /**
    <B>Levels Management</B> : return true if current level is Info
    */
    FUNCTION ISINFOENABLED(PCTX IN LOG_CTX -- Context
                                          )
        RETURN BOOLEAN;

    /**
    <B>Levels Management</B> : return true if default level is Info
    */
    FUNCTION ISINFOENABLED
        RETURN BOOLEAN;



    /**
    <B>Levels Management</B> : return true if current level is Warn
    */
    FUNCTION ISWARNENABLED(PCTX IN LOG_CTX -- Context
                                          )
        RETURN BOOLEAN;

    /**
    <B>Levels Management</B> : return true if default level is Warn
    */
    FUNCTION ISWARNENABLED
        RETURN BOOLEAN;

    /**
    <B>Levels Management</B> : return true if current level is Error
    */
    FUNCTION ISERRORENABLED(PCTX IN LOG_CTX -- Context
                                           )
        RETURN BOOLEAN;

    /**
    <B>Levels Management</B> : return true if default level is Error
    */
    FUNCTION ISERRORENABLED
        RETURN BOOLEAN;

    /**
    <B>Levels Management</B> : return true if current level is Fatal
    */
    FUNCTION ISFATALENABLED(PCTX IN LOG_CTX -- Context
                                           )
        RETURN BOOLEAN;

    /**
    <B>Levels Management</B> : return true if default level is Fatal
    */
    FUNCTION ISFATALENABLED
        RETURN BOOLEAN;



    /**
    <B>Transactional management </B> : define a transaction mode<BR/>
    parameter transactional mode <BR/>
    TRUE => Log in transaction <BR/>
    FALSE => Log out off transaction <BR/>
    */
    PROCEDURE SETTRANSACTIONMODE(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                            INTRANSACTION IN BOOLEAN DEFAULT TRUE -- TRUE => Log in transaction
                                                                                                  -- FALSE => Log out off transaction
    );

    /**
    <B>Transactional management </B> : retun a transaction mode<BR/>
    TRUE => Log in transaction <BR/>
    FALSE => Log out off transaction <BR/>
    */
    FUNCTION GETTRANSACTIONMODE(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                          )
        RETURN BOOLEAN;

    /**
    <B>Transactional management </B> : retun a default transaction mode<BR/>
    TRUE => Log in transaction <BR/>
    FALSE => Log out off transaction <BR/>
    */
    FUNCTION GETTRANSACTIONMODE
        RETURN BOOLEAN;


    /**
    <B>USE_LOG4J management </B> : define a USE_LOG4J destination mode<BR/>
    TRUE => Log is send to log4j<BR/>
    FALSE => Log is not send to log4j<BR/>
    */
    PROCEDURE SETUSE_LOG4JMODE(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                          INUSE_LOG4J IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to USE_LOG4J
                                                                                              -- FALSE => Log is not send to USE_LOG4J
    );

    /**
    <B>USE_LOG4J management </B> : retun a USE_LOG4J mode<BR/>
    TRUE => Log is send to USE_LOG4J<BR/>
    FALSE => Log is not send to USE_LOG4J<BR/>
    */
    FUNCTION GETUSE_LOG4JMODE(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                        )
        RETURN BOOLEAN;

    /**
    <B>USE_LOG4J management </B> : retun a USE_LOG4J mode<BR/>
    TRUE => Log is send to USE_LOG4J<BR/>
    FALSE => Log is not send to USE_LOG4J<BR/>
    */
    FUNCTION GETUSE_LOG4JMODE
        RETURN BOOLEAN;


    /**
    <B>LOG_TABLE management </B> : define a LOG_TABLE destination mode<BR/>
    TRUE => Log is send to LOG_TABLE<BR/>
    FALSE => Log is not send to LOG_TABLE<BR/>
    */
    PROCEDURE SETLOG_TABLEMODE(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                          INLOG_TABLE IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to LOG_TABLE
                                                                                              -- FALSE => Log is not send to LOG_TABLE
    );

    /**
    <B>LOG_TABLE management </B> : retun a LOG_TABLE mode<BR/>
    TRUE => Log is send to LOG_TABLE<BR/>
    FALSE => Log is not send to LOG_TABLE<BR/>
    */
    FUNCTION GETLOG_TABLEMODE(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                        )
        RETURN BOOLEAN;

    /**
    <B>LOG_TABLE management </B> : retun a LOG_TABLE mode<BR/>
    TRUE => Log is send to LOG_TABLE<BR/>
    FALSE => Log is not send to LOG_TABLE<BR/>
    */
    FUNCTION GETLOG_TABLEMODE
        RETURN BOOLEAN;

    /**
    <B>LOG_ALERT management </B> : define a LOG_ALERT destination mode<BR/>
    TRUE => Log is send to LOG_ALERT<BR/>
    FALSE => Log is not send to LOG_ALERT<BR/>
    */
    PROCEDURE SETLOG_ALERTMODE(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                          INLOG_ALERT IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to LOG_ALERT
                                                                                              -- FALSE => Log is not send to LOG_ALERT
    );

    /**
    <B>LOG_ALERT management </B> : retun a LOG_ALERT mode<BR/>
    TRUE => Log is send to LOG_ALERT<BR/>
    FALSE => Log is not send to LOG_ALERT<BR/>
    */
    FUNCTION GETLOG_ALERTMODE(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                        )
        RETURN BOOLEAN;

    /**
    <B>LOG_ALERT management </B> : retun a LOG_ALERT mode<BR/>
    TRUE => Log is send to LOG_ALERT<BR/>
    FALSE => Log is not send to LOG_ALERT<BR/>
    */
    FUNCTION GETLOG_ALERTMODE
        RETURN BOOLEAN;


    /**
    <B>LOG_TRACE management </B> : define a LOG_TRACE destination mode<BR/>
    TRUE => Log is send to LOG_TRACE<BR/>
    FALSE => Log is not send to LOG_TRACE<BR/>
    */
    PROCEDURE SETLOG_TRACEMODE(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                          INLOG_TRACE IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to LOG_TRACE
                                                                                              -- FALSE => Log is not send to LOG_TRACE
    );

    /**
    <B>LOG_TRACE management </B> : retun a LOG_TRACE mode<BR/>
    TRUE => Log is send to LOG_TRACE<BR/>
    FALSE => Log is not send to LOG_TRACE<BR/>
    */
    FUNCTION GETLOG_TRACEMODE(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                        )
        RETURN BOOLEAN;

    /**
    <B>LOG_TRACE management </B> : retun a LOG_TRACE mode<BR/>
    TRUE => Log is send to LOG_TRACE<BR/>
    FALSE => Log is not send to LOG_TRACE<BR/>
    */
    FUNCTION GETLOG_TRACEMODE
        RETURN BOOLEAN;


    /**
    <B>DBMS_OUTPUT management </B> : define a DBMS_OUTPUT destination mode<BR/>
    TRUE => Log is send to DBMS_OUTPUT<BR/>
    FALSE => Log is not send to DBMS_OUTPUT<BR/>
    */
    PROCEDURE SETDBMS_OUTPUTMODE(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                            INDBMS_OUTPUT IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to DBMS_OUTPUT
                                                                                                  -- FALSE => Log is not send to DBMS_OUTPUT
    );

    /**
    <B>DBMS_OUTPUT management </B> : retun a DBMS_OUTPUT mode<BR/>
    TRUE => Log is send to DBMS_OUTPUT<BR/>
    FALSE => Log is not send to DBMS_OUTPUT<BR/>
    */
    FUNCTION GETDBMS_OUTPUTMODE(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                          )
        RETURN BOOLEAN;

    /**
    <B>DBMS_OUTPUT management </B> : retun a DBMS_OUTPUT mode<BR/>
    TRUE => Log is send to DBMS_OUTPUT<BR/>
    FALSE => Log is not send to DBMS_OUTPUT<BR/>
    */
    FUNCTION GETDBMS_OUTPUTMODE
        RETURN BOOLEAN;



    /**
    <B>assert</B> log a messge is pCondition is FALSE if pRaiseExceptionIfFALSE = TRUE the message is raise<BR/>
    */
    PROCEDURE ASSERT(PCONDITION IN BOOLEAN
                   , -- error condition
                    PLOGERRORMESSAGEIFFALSE IN VARCHAR2 DEFAULT 'assert condition error'
                   , -- message if pCondition is true
                    PLOGERRORCODEIFFALSE IN NUMBER DEFAULT -20000
                   , -- error code is pCondition is true range -20000 .. -20999
                    PRAISEEXCEPTIONIFFALSE IN BOOLEAN DEFAULT FALSE
                   , -- if true raise pException_in if pCondition is true
                    PLOGERRORREPLACEERROR IN BOOLEAN DEFAULT FALSE -- TRUE, the error is placed on the stack of previous errors.
                                                                  -- If FALSE (the default), the error replaces all previous errors
                                                                  -- see Oracle Documentation RAISE_APPLICATION_ERROR
                     );

    /**
    <B>assert</B> log a messge is pCondition is FALSE if pRaiseExceptionIfFALSE = TRUE the message is raise<BR/>

    */
    PROCEDURE ASSERT(PCTX IN OUT NOCOPY LOG_CTX
                   , -- Context
                    PCONDITION IN  BOOLEAN
                   , -- error condition
                    PLOGERRORMESSAGEIFFALSE IN VARCHAR2 DEFAULT 'assert condition error'
                   , -- message if pCondition is true
                    PLOGERRORCODEIFFALSE IN NUMBER DEFAULT -20000
                   , -- error code is pCondition is true range -20000 .. -20999
                    PRAISEEXCEPTIONIFFALSE IN BOOLEAN DEFAULT FALSE
                   , -- if true raise pException_in if pCondition is true
                    PLOGERRORREPLACEERROR IN BOOLEAN DEFAULT FALSE -- TRUE, the error is placed on the stack of previous errors.
                                                                  -- If FALSE (the default), the error replaces all previous errors
                                                                  -- see Oracle Documentation RAISE_APPLICATION_ERROR
                     );

    /**
    <B>full_call_stack</B> log result of dbms_utility.format_call_stack<BR/>
    some time is necessary for debug code.
    */
    PROCEDURE FULL_CALL_STACK;

    PROCEDURE FULL_CALL_STACK(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                        );

    /**
    <B>getLOG4PLSQVersion</B> return a string with a current version<BR/>
    */
    FUNCTION GETLOG4PLSQVERSION
        RETURN VARCHAR2;


    /**
    <B>getLevelInText</B> return a string with a level in send in parameter<BR/>
    */
    FUNCTION GETLEVELINTEXT(PLEVEL DBG_TLOG.LLEVEL%TYPE DEFAULT PCKG_PLOGPARAM.DEFAULT_LEVEL)
        RETURN VARCHAR2;

    /**
    <B>getTextInLevel</B> return a level with a String in send in parameter<BR/>
    */
    FUNCTION GETTEXTINLEVEL(PCODE DBG_TLOGLEVEL.LCODE%TYPE)
        RETURN DBG_TLOG.LLEVEL%TYPE;


    /**
    <B>DBMS_PIPE_NAME management </B>
    */
    FUNCTION GETDBMS_PIPE_NAME(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                         )
        RETURN VARCHAR2;

    FUNCTION GETDBMS_PIPE_NAME
        RETURN VARCHAR2;


    PROCEDURE SETDBMS_PIPE_NAME(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                           INDBMS_PIPE_NAME IN VARCHAR2);


    -------------------------------------------------------------------
    --
    -------------------------------------------------------------------
    /**
    <B>admin functionality </B> :  delete rows in table TLOG and commit
    */
    PROCEDURE PURGE;

    PROCEDURE PURGE(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                              );

    /**
    <B>admin functionality </B> :  delete rows in table TLOG with date max and commit
    */
    PROCEDURE PURGE(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                               DATEMAX IN DATE -- All record to old as deleted
                                                              );

    PROCEDURE SETPROCPARAMS(PROCEDURE_NAME_IN IN SYS.ALL_ARGUMENTS.OBJECT_NAME%TYPE, ALL_ARGUMENTS_IN IN PCKG_PLOG.T_VARCHAR2);
END PCKG_PLOG;
/

  CREATE OR REPLACE PACKAGE "PCKG_PLOGPARAM" IS
/**
*  package name : PCKG_PLOGPARAM
*<br/>
*<br/>
*See : <a href="http://log4plsql.sourceforge.net">http://log4plsql.sourceforge.net</a>
*<br/>
*<br/>
*Objectif : Store updatable paramter for pckg_plog.
*<br/><br/><br/><br/>
* This package is create befort PLOG
*<br/><br/><br/>
*
*
*@headcom
*<br/>
*<br/>
*<br/>
*History who               date     comment
*V3     Guillaume Moulard 05-AUG-03 Creation
*V3.2     Greg Woolsey      29-MAR-04 add MDC (Mapped Domain Context) Feature
*<br/>
*<br/>
* Copyright (C) LOG4PLSQL project team. All rights reserved.<br/>
*<br/>
* This software is published under the terms of the The LOG4PLSQL <br/>
* Software License, a copy of which has been included with this<br/>
* distribution in the LICENSE.txt file.  <br/>
* see: <http://log4plsql.sourceforge.net>  <br/><br/>
*
*/



-------------------------------------------------------------------
-- Constants (tools general parameter)
-- you can update regard your context
-------------------------------------------------------------------

-- LERROR default level for production system.
-- DEFAULT_LEVEL         CONSTANT DBG_TLOG.LLEVEL%type     := 30 ; -- LERROR
-- LDEBUG for developement phase
DEFAULT_LEVEL         CONSTANT DBG_TLOG.LLEVEL%type     := 70 ; -- LERROR

-- TRUE default value for Logging in table
DEFAULT_LOG_TABLE     CONSTANT BOOLEAN              := TRUE;

-- if DEFAULT_USE_LOG4J is TRUE log4j Log4JbackgroundProcess are necessary
DEFAULT_USE_LOG4J     CONSTANT BOOLEAN              := FALSE;

-- TRUE default value for Logging out off transactional limits
DEFAULT_LOG_OUT_TRANS CONSTANT BOOLEAN              := TRUE;

-- if DEFAULT_LOG_ALERTLOG is true the log is write in alert.log file
DEFAULT_LOG_ALERT     CONSTANT BOOLEAN              := FALSE;

-- if DEFAULT_LOG_TRACE is true the log is write in trace file
DEFAULT_LOG_TRACE     CONSTANT BOOLEAN              := FALSE;

-- if DEFAULT_DBMS_OUTPUT is true the log is send in standard output (DBMS_OUTPUT.PUT_LINE)
DEFAULT_DBMS_OUTPUT   CONSTANT BOOLEAN              := FALSE;


-- default level for asset
DEFAULT_ASSET_LEVEL   CONSTANT DBG_TLOG.LLEVEL%type            := DEFAULT_LEVEL ;

-- default level for call_stack_level
DEFAULT_FULL_CALL_STACK_LEVEL CONSTANT  DBG_TLOG.LLEVEL%type   := DEFAULT_LEVEL ;

-- use for build a string section
DEFAULT_Section_sep CONSTANT DBG_TLOG.LSECTION%type := '.';

-- default PIPE_NAME
DEFAULT_DBMS_PIPE_NAME CONSTANT VARCHAR2(255) := 'LOG_PIPE';

-- Formats output sent to DBMS_OUTPUT to this width.
DEFAULT_DBMS_OUTPUT_LINE_WRAP  CONSTANT NUMBER := 1024;

END pckg_PLOGPARAM;
/

  CREATE OR REPLACE PACKAGE "PCKG_PMDC"
AS
    /**
    *  package name : PMDC
    *<br/>
    *<br/>
    *See : <a href="http://log4plsql.sourceforge.net">http://log4plsql.sourceforge.net</a>
    *<br/>
    *<br/>
    *Objectif : Generic tool of log in a Oracle database
    *same prototype and functionality that log4j.
    *<a href="http://jakarta.apache.org/log4j">http://jakarta.apache.org/log4j </a>
    *<br/><br/><br/>
    *<b> for exemple and documentation See: http://log4plsql.sourceforge.net/docs/UserGuide.html</b>
    **
    *@headcom
    *<br/>
    *<br/>
    *<br/>
    *History who               date     comment
    *V1     Greg Woolsey      29-MAR-04 add MDC (Mapped Domain Context) Feature
    *<br/>
    *<br/>
    * Copyright (C) LOG4PLSQL project team. All rights reserved.<br/>
    *<br/>
    * This software is published under the terms of the The LOG4PLSQL <br/>
    * Software License, a copy of which has been included with this<br/>
    * distribution in the LICENSE.txt file.  <br/>
    * see: <http://log4plsql.sourceforge.net>  <br/><br/>
    *
    */


    -- puts a key/value pair into the current log context
    -- putting a null vlaue is the same as calling remove(pKey)
    PROCEDURE PUT(PKEY VARCHAR2, PVALUE VARCHAR2);

    -- retrieves the current value of the given log context key
    FUNCTION GET(PKEY VARCHAR2)
        RETURN VARCHAR2;

    -- removes a key from the current log context
    PROCEDURE REMOVE(PKEY VARCHAR2);

    -- returns the string of all mapped context values
    FUNCTION GETVALUESTRING
        RETURN VARCHAR2;

    -- returns the string of all mapped context keys
    FUNCTION GETKEYSTRING
        RETURN VARCHAR2;

    -- returns the key and value string separator character(s).
    FUNCTION GETSEPARATOR
        RETURN VARCHAR2;
END PCKG_PMDC;
/
  CREATE OR REPLACE PACKAGE "PCKG_SNFR" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
59f 17d
Sn69/bWz1/cSLyKc6v2o1AlHWJAwg82Jr9wdqC9AALteWSMp3ymvBIY1hjcCk9tMOWWpzJY0
tbrnkXngWTK6hjtGyDiF/sEogo8CbkZgtDCtKXYRXS5J5lsBhWjAFFY8kIwvROkw81ZPNprS
v8TaU6pGzTdoIvWy0ooU5dvnr8TWVslddZqkOCxx4PRYft82AT+XKpsHLVsChCWZRAH0Tfdt
Nx6azM8qfwxc4JxmyLf/nfts2spkqVh5UL7xD86B/22s9Z6dDG5wON9GxgCKSodzA/3ycNTz
XA8LjKdiluq+PIQC9pZuccSiK0a9XErgdQjQqwPrwT5xRcFuub23CK3M2udroFBDOvkX+8iO
drzr8ZiSpgxuPlw=

/
  CREATE OR REPLACE PACKAGE "PCKG_TOOLS" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
962 316
NQX+NbnAVbkIRN5LpLuU1I/mhTIwg2MrLm0FfC/NrZ3mVokwOL0FCSO0JdZm2UqrQhQas0jH
JWsHHKO05vi1JhQF9NPayc11Z9KBGf3XAyolic3e1/qQyfiDjAklGTtGTDtaMHWujGf9HBKe
Vglnm1myBcxOLc7kKUF6EGweJCQ/c9K1hw+qtUyq3veNHUDm+yY0Q0cgrby4y0QYQPiXTdSZ
yu7qCV0oFPBRl9S5tqHPdIAXqan2YWh0+vZKIuE0HQhVjHmUp0v1NvQ7Wol5V2LJZ5TqX7aT
SDu16GEiFJkC6a9+85h/bfcDchmEWk31sl0LA2bocjKDf1XyGcLVV15X8UwiqENJL7xNdo6y
RElDNlNt+M0npHD0CYwmoWWjg6UHNIsb4SxJzGkYdU2TqDN1OswzvHEVPK9rgd0lzkBA6oyz
huIr3c+FsdO6IE4yvC3ZkEwRzWYgIGW/YZhzGFLHvn+XMCtvEAu4xXTnQ4csOBO8CBwo7K4M
oEefsHRBd6KtD9Xv7MiUKk2PyXpOfjUNp6yz3/ahwgDG4IMiX+XJ4y7cKmuFUFogjYJf+JDC
VPXNK3wTVXZJ0wVnJA+r9BshC1n/QMArmVPATcfnx+TPBWxkTbdaHMYNHbMbF/8dBJKZY7B1
22S+rSsa1GHgpWAbOF4Nd/t2/ZNvoGSJ3hbcUkE9YfflP6Xlm+6DS0npijQmTU+zGsUcrHDa
IHYRoTd21RISTn1AltnCHSEH0u2RT88g4HqW4lvziqiwCsMEMP4sRCt6kQ==

/

  CREATE OR REPLACE PACKAGE BODY "PCKG_CRTP" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
6e68 12fa
/sfZzf5sAiOXDKljVGZC/fwCCQ0wg8129iAFV5u8e52sxN2vm3knGlWV+zuWRJH0n3eX8dxR
8Yu3j8doOy1ICRTcxBK0LKqEGInO8WLa3pBv3xhgUUCEwId2ywdZcbs72tQRBPicfbDbEtrR
NIkUJGvK2nvmFqELKPhCGMynSygCwUAcekQUqbBmUvpYx0perJqUNUaPmnzjaNLTh+ccho5p
oPikjHyfcxW/vYvjfYZvPVIhy2ZNHiSgLCIciwtKNqiHtT0+ezHogrvhCTAiesatNcyKlfps
GJv6uApBjyGQkYasUWkvkJgmv4volmGEQ5Ui31LNJSbI00Ut6gBnORWEa9DftQQEc3LVTdiU
99qvyQOHdgHb8Fo9405kDxLndSV5b9m5DmAi3FVd2OPgCV8GeuG8j78c3FovgGwvnI+rZ/hB
Q2pRCQLgXTlry8xRPmWstzklXEyqP5sGsRwgxLhqS6UHwxlgLSs3PgvT1IYiPqIBzC7D+0Kx
Be7TDCbHZt01rRgh0J7TBHdVNofOrxGg+3ouCxuHiw6tU+G9iRsT+mr2iW4t08M9uLNGwWCV
Lx8UlXAkwwZ0hlfb0RdUS9xHzU1zz2W+cdlxfc+Vk7ooziiRMRLVSx/bpMtpsOsmoucig7p/
HjL8I1L8hDgvf+6aca7TgxSVIjO4p5XeCkErlHOpJ2MH/Zj8xjp829gcZGW9UXDxroO2VbK9
3O+cNsFTa+YxWj2p+NF1qb1L0nliekrkFEBheJ8W4zRh4F6rYXpjRgJSaonIsBXfCavuLxI2
bEgY7wk09AfDEww3H8qMIUHKrElolzpXNz8GhZhWdaG2cB8XBOh9JznpsJd+xQ5xJ7TbIb18
m4k+cJvnWew8r3MzWWyMcNVsY7cwlauajBfx7NDbxoi9TVmV80f+QpdBxXcSjAACzALujvqE
wz73SelG1ggxfP/rHSrkzmYjFgB3PGXdhu6wYPcbCXx1qBzqUOTQcRray3wHCkQkjMEdvSsz
LnZEwtLtpZw6ij8qgEzSsQ93qoz5nk6ajw0FH2MVCv3PkIfnv+3iZm67g+k3woXBmyVaiItF
szhCeCwkVWToCpXXKkW+5upOrk4eCjqBfn+dhOse1dIpi+tz8ao/0G+xpl8r67XRwfZGa/iN
YJrpoAVkDG+JC03U+gBag0+8uLcMs+t7wRb2SUbcD7qVIMSNdoQXt87NH5FDKFD08TvMPR5l
NxicftChhxONdeXxTMihCoJKWYmKrC6ja1J+URpJ9IB85eebvzIQDP9LWWh3smV+kzahe1vo
PgQxoDuT1yJHF52W4qqET7DZlZSjGVk1segKOj/DAq77TPGLUwycYi24ztUvybtzaLIK8SWg
HbKC8aiAZgTGM64mTUN+syMVEa0XDkF+BDrxXHlWrJR6lbmn9g/pGU3KuDP29n0HpZIzi8kC
InIg6k6WW0gganmAv+MnW1vPygOgxHjes+/F6FPjfa6UG4PKhPnPrVsXCyrtc3n/SWggxXpR
YShoOSLeduigH8vgG6HsIamPIy2jqeS1ZJukK07QT0hIsMSqUZg9zXN+MqranQXZdWDgN+zg
KH8gvnHYK6Y4dknTCo11N+8nMwzoA4tReonoW61UcESqM3FEK6yI/fZQMQczuCwa2sJfSzwk
lb07UdqrqfLVEKXFisf22WBQhCA848A08djb0dzAOSNTUW+k2zAb2ke7s8YpnJXGKdNMYrkr
6x6IMNcK/SFM0ViVD0czFAbxiCjmX3b/GLxbPPQOsX0asVaKeuf6Reo8q0TeYMP3QwgigKm6
PWdBZqAqej3aCy4PqLfFJ1UDNgBrOHsDso5Ni5z3LT/J+JaLGKO5hw+e/dKO9WC1dbApw478
nF5NjN9QlrEFAHVYYEh1r9aLRt/Qja8oIWk973nCtjlil0HleVSYZsO+9xvfMwWYY39eSjCn
q8wxjfKgP2AnmHbgcIhtX7kNXzstwbKGVXEtiuJ3j91nZnL9/aWJCw3xZJ6ceE6BWrDWOO+1
eWw7AaWyi+uDNZhiYSohV6NJlBVQiRlAO6cifZCEdnepmg9kfWrk/Hgn4iRZ6n1z183G2iHp
A7qlo8lw/yQu6ixFEkE4AYTYTqJIStR9PT5LwpJ26cg3LAx1rOJ/5HauOg50obvwVrFidWNC
YcRtcn7R7e3smsIEXgC/4erbNPRvsZrv2p/v7Ys2+rfFC8b/2I/PO7SSdDF6oXcxNTvRqa3H
Ntzkc8DpkBxCOyWgK7SZKNWn4z5CupZad4LkyjGKYIh3FuqxstaAwUh1CzIq8ImNKS3JTNnc
fWPoMj2o2OZS2DpigUW6ZBnK8NPDIA5ZoSr0HLOsDDWA/HFuB9xMwF9F71RJARePtpUgmMBu
rsuWPIGis39mUq/fZEJ8S7A9O6z0aXjZB4ihpErmz61APVS7BAAHqiWLAE8jCqViVodKq+Ff
Bfo/1TrB1ojPQyvFkqpzQDZqvMAMbpWeEmJuXILDV9EnASPWOQQb59yGwXS2q0zcaHeQkdyk
EegSgFnPh9mYocbjy2ouxjo2gBSGpvyPI3kG68l1bUS+R3C/xzBxMcAj6LO6PZPcaIokqGKc
vQo995RvDikK+wvMR9H1smxS8QdDQQF65tukrDsgSulme1d8q3JdJlH3Q1sAc+6B9V3TeGi3
QWVV65+rvCyVhpKOsAl6Tz6Nwu/yv8azArojrwFFqIlIw+vWPxzSTt59sLzE6ys1D4pMNTrT
OW8US4epDb1ix2pSbjldflEpXTWay5IzIdJiOX8uA2GjM23ftGEnPPJygxarHtHgJhlblHtN
UPnD49GS7HIHdDxuIOD5q1nzFIUO5ot9B22XXoKFxu94KKEejDUoJHHSBIBtHM1wswuk1SdC
TeehiJgR61hmbG8xuGFNQyZmLgRFPGlTgY/QzYVy7Ask11s/PHaSzChdWlBWIbp8JLDKk43l
iQF+VkI8lrXdxKrI2aKhcrJMAxva0Hhnb03T+iuyqcnydbohykm6KbIEtO8jMPpXyGY9C6aL
TQoquoQNnt1N/JghZDRT3VR7vl78qR050hoX+0Hb9/XcBx21UR2YwYZRl2exN65+UF9hm/sT
YH0UlYtNiB9KyyaGSTMU0eHxhswnJtqrK06lsrarE7cl/EH0NmB/nJAnsH5+au0TlsEDlAls
QwXLzN86o9Rs5kcBpguIb4NSOGEeGhENQZC9M08ad5SmdGfaMa/RvWxLgr5GGT2G6sEqP2lE
yu1AAwyfUYcutRraRapHwZ27AbZpKrpk3Nk6B9tSdYGAlQS2MwAcLbtKoqF51gfbRHh/4O+h
rABgTJq7MxGj0L3GdHohUcofKuwzGKu9OggjgfvsQjqbAerZemgVDD8EobJO+RiBgGV8OEAF
SkOh8FGUt9dzb/Ycfoa8pbw7ERNBrdKN7EZi/wFagOBh5WwpwdGBBE5h5U2SXwXwUBAR1yXq
aOUnKYC5g4MrgXVyU1yyMTIFReAplXmhdCIIflzVBIB/Vg0+6WG3LW0DJYf9t2WwuA8Wly1s
9APfpKfQ8bRkOkcaBeTRoktkl5urZ+nALld/bvLmLsgJdPhDTy4E7J2C84Ik1evAQO3g471Q
G8B3Sk6H0sgTPlHEROYQoXCPVmMlYKnoX6SS2i1SzHkphakOIqNcfbSCX9uv/ZQE3imiwn4r
ZZPHt8djN87ez6gbvBwYcjhrLnKPyKk7xkCclOae2fFGETjtFjNSi6ROvzMVWlhgPO7l2S6J
WDnyV+j9cgiFvCbPYYW5KAw/2Lnh8ouox2gUvR3QoZQTaXlS1VJaWPNs48jvpN8XAX4aR4FA
UQ3202ztGITos96Q6Xe25V5JO+7zefJR2yOzJkTgBrzHZT7Js/ZBcYMI5eArYGKEDD9516Cn
btYioDiHAjtRRkfmVH/t80PNwZ5CLWxxPt2ZTaOGL4ka120UxGbZAOxyeJdqpfGLp/olZdyG
evc9XtOI8DsO1GjPmbReEOESdCmeZi5FoCm9WJvE+ox74+4clS8bmadL+wyeMF+sEWh51ak5
DDU21RcazOdbYVOfelg2JehQ+U6EefRrB/VQu0KuaQaLKPdzMci73iR3foUBqwfuUIEZ/Nru
J6uDPzOamMxZjP7Rcg8tB1fLl4HvxbFeDMwx6SCHii4gq9Mry6PHUOxkUSpghxinOKbWZU4J
o2ho0sjbiVtovBKFJzr/wqPYUdKg66N7pGe592iyDUZEeSjEZEjnTqLw3Fv5O51qnCwZ2l16
oNlCMKv+BTEDHF+3th5OHBoLE4ufikHAHJ+Fx1ANC64py5DL2AhiReWH9lx746Zo91oiE9EX
EXu6Va6cgXm4fUqHXrjEo0d9DX/YFcn8gktM55o4p1ELGRNTrdXSqLEbIiWkB9DHne6MVXnO
MP6rYVPrSzRQo52zyIfQ16LwIiGa4OcsCkZEXBtYdhk0DxdMvPBUwPqgFxYEEMBUjZsiU4b8
vmhfYyCXKsBgzLLqu6gleN7rYWpa1ALtgA++JvyRarxfKzSxV970YxA7U0BbakPhmrRltzT6
kvJgFO0MZiiEhKe0LvVA+KEDIHR2gypWSEB3zB4fHYkBGOiEvQMtVo5y0VdNiGXSGRsW/Ryh
2ufKwlcB+OfXviNd8Kss3+PH8sbM6ZxrW1xuD3yplUc93kaqadrZI1M/LMtQA7g01L7G9jV1
h6csMi+BLMx3JrgkaZcBH0Y/TSMS5WhYOnPVHQ8HUpAvXuuzSP6Uzw81irP1LRqCuajTv+Pb
pAaxB86BNfZB9eSDqwx2djj3nuY3cMiq+CRrXB97

/
  CREATE OR REPLACE PACKAGE BODY "PCKG_ENGINE" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
1f420 3940
BQrAGjCA01nWrUaNwV4TpxaN1Wswg81M3scFVyU/nUo/RJ8KYRTXFhwFE/LN1PfEBPTCjYWJ
WQmhNA/DGC5J7Ffx6sZHGic/5G3WW0isdyk24lkbG/svgIyzcw7QN+sjHnFTjzKdEB35IhHt
7QS+Gemxx7WHUqyeqSQdnZrABYSaRK+m7f1MU+59LrWBTbGyFas+evxhgEwo3SQZpfwNHoYY
RU8550isUO2rQv+N/eoQwc47DMYkKk1onw8olgYnpvmURR/itcK9SrL8YeEs+Z0kdDexIIFb
eN2/2qVYNS7+hHh2DYN+eYb7mLyqlHFfaVzoN+FqQC6gknnqfoxaSSMR7YntTYZgRTWDK+lO
t6eh+bOrqCevbewi/BI1fTA4kgKDbcEyprHlxaiw/Fi0i5jzivUsKHpCjpbOiA8b9SRGKYxd
x0nGsHIe9cxavx3Jo3fpEhCwACfaOJIB0iBFqYIE0kViSYozAFNbXUz90tYO+EXBUcw5GLn4
hHJrbYWXNiCY1jcFPJy9pFeZkmWluocf3DTiWfZ9+OIfStH4hA9cOWKrHAPJk2mI7KtNviJz
H4I9a7Y0pAJ4HbHYkXzPkG8rnIooltEAeOchAHRo9p+3hStQuzNzSDCM1R0XInY5OgM1KH8e
OiSuWErE4oPvoK6yWndzj2FAqGYcTLWomSis2NCXiNaYDR29e3fwFb+EWqvjBlvRbnVhoMjr
HvCDZPPQudII78+gdCNzbYy4ic9B4siO3KHFSI4tGIYDl64kzNlYMrc6m/YfQekYGzjVitYP
3fTlnSroFDgruU+zzSeIN8XOHpbbi1ARfDhqDwqA+utGOpB5sB/SOJhjrhRJHpPUVbcL0FY2
clqzXaCMBxGtWD/h/k4x6kt2qs/jpnpovaqdHEWExEVjuSv7/Nutk28l7+VtecRb3pT15PmU
5PDN879UvJ31EKDWJT455PUfHFeDzbweoCDLJ6XeZJ8h+31Lvlc0iMoXj0iLyvOmy0hv8Up5
kasVCB8hvZ3QLCvzdVXWWZ8jdnLGD4wBIZpyNja44aX037jPwZ4cIgBoO57Hw/6TQtAjiK5x
1dIS72jhbi4kt9DrMWY7hoL7MxZ5Jpfc4oYNhvE7wOvFbrwHeJi4ewG32f7Pza25I1VLHtJF
tWybeJo/+liaXUfu64lYrWaWkROGbEKIM4BaZuXMFFR4jAfVwR3TB9M3pJmBrkAUBD0ReSPI
WZWo6927jMYx4H83xpV9xDHGAme9R10ECR2w0CKI5nD47d9sS9ekZfNLAJQRqRB5Wjad0Ejq
TkIhTEoiciv4h5IK4uraEMs/QCeifdo7SzyfSIXlZlXXByHMByzch+A0NxC6W9ymEXrmYCQY
/n+BdyUZFEMVuY2ZDe4K+zA5o9wvPFQxphBlYqzayPWAGC1D8z4WPlYEs34QLG5tG3w3ESmV
aciKcDNTIwQLJjq4d5XiH1M/WuMYzSgUDh453bV289gN9zs1kJOgiXfk+fhTfjvLkrtxLHeS
P/35u4GypRmBJwBan4zupmISHS4ckoA7IyPPz+SKzjb5+0mwltDQ7k8nHcMgj3IDCgoXzd9T
NM9CPRCINlw0gqMyWq9J4+YyTNhaKSpnaRiiiNzjd0LB9RIEkyestxiJG20m5/xcsPVlV0E6
J3vpAtTr2rgkQXqiv6aQyFuilMOq9jZb10SaXnQir6JtPWdTa0LwjsWCZOEpckLNNkivvDh9
LXCQh52BYY+pUI7dx1Dtffh4iw1FN+brsUz3Ft/wMUynrIg2IEp3kSVahwrJf2IO7IJxZ5iL
slAjtpKAvm12nOtkJ3FamF/eTzIKPGcHZG0ESlsTdEoG9i/1G9QeK0SoI0LhaBxWMHTqsPDQ
C80VBiD2sfOnUyJRpy7/ygMBRl/TSkTfChsYeBCez6f5cDqmLqFfamrzCtXSACHjU5G2css6
6ZNECAsj05gcTWPr53LIy12LSJijZH1gZ6SeuBjFRRlMxhSyErBsIKYjSElHWE/1SOdDOkhb
61TpgngpVQm3yIzgW/frXxvjTL1zgwsCe2+6Az2OLBjrPbHQs3b0pfq9U50LlrZY+IQo8s1V
yoojOy/IMuIM+xz84MyOFYHO9mbHkf26jntfREqkva8IZvoNvyNl/NQeSuzhqs9BaD85xIY+
zgQ3BwgnI/itRQUolKXEsc4LiowXaJfrUV6AFnMYwrNnbpCTOPqxSgNryjyazXYi3IxT8Bdb
akzBCrs8QNC/ouDUdtOaEBfFG27k6aDbZEnr+sBlP8oW3UEwObPJ00j/gQ0Vdk3hxUYNYN11
pV1VhEtoNV2USwFUywNP6i4qWt2JQNiKesQWKVe8+sYHVpLtsccSVY+e+8hrmrtc/Vx6+Qri
nCLluzMa905uPc9/E+8i1vUwuB9VIl/ByN3JXth51xzvz7loamXZCAbZFmAvwY/fOCsqkn7l
ux7cCj3HzzMaBwxv0hBRFrhtPI29Lin7H0Ug5FTP3pGdFODVjsxqr8wnkNOcWgHNzr8NFj7n
iQmQHypRthxOAgw66ISQsT3W8Yl84BSubIRK134hLnAmtm94BRrmXOSBMvz8NjlV1Om4RpEF
nrJxznPupjjf/UmJfnhwapSnNzLKPvhJ4+2F50Wxu23Zo5G1eREsxV/CcAC1RlhuglyU5c+S
mNIdQFtmyaNtPcZDxMZNI59ax5HPV6t28fEHnY8+w4Sm+jiXVsO3ur4YwMGOBVFNYPBmMqkf
dT+m+hP5Df2mILQePT3XWCyLbMuB4HrgLG0S4Or1hNXF4wH2A/3Z9p7M6GzZuxiztENWcgFh
r8ohV2CXO4cbZIKIdI2hGNubtrrFhzBhDOe3NRUWeHuXsUSfvVWfya4v01WBRa9jBTlzxF8J
duouEHHCRfqMYBiY2yv6MqFzd2psCk96J6kXSc/wSElOSQZc5/tRg4NFlYYxs3/xYsa5InXY
7rm8ddhFkbsBuedSMqDM/BfswHVgJ4NmyLFmH6ZHvayj/Fece74qct5JNzln77jkbe6UXdE1
camk6kxoSOfh11lOurmmiFtcVz/N+yi6jleM3Kp9DU7eq8JNGfawgStlXIlztQO2MRLJA4Tf
80Y/YlO5a8GyuOG1L0+Uk+kjCmrFfepCNSOu6u0ivDs5MH6+5SZV2CQZyc1nm33NQgMGebQH
mPC2RzwxqrBbLbWlDqafvqCYcrm81gUQpXV6HRiZyLn189ct5k9o/JXq2PqNOXVZnAOEuI86
Psb5VimUZdwhDVwYYiZH8BPytAqvxfRqfjfFrdRi4EQo7vlEB8zbi9gas4jC3hjtv5nDfzR+
9yvVo7BN3spUmjwqMMeJyKIdyrbqkU6yLAYqkfCxDtFvoARtUyN+VeUNZdV5k0m7QcJ/Kljf
JfuNeO7ZxJzWAvVdPXxFRYbi5Zejjieldv+p/7Tj/9LiA2h5SXmt6L7NR9EqglmwPkR953AC
8sIOlB9oNhihz4gAuDJ8M0a9odbqfU+Fr575UWTTIBYZNAAysA55aJPrn5Gz+Zm5kwXNrXjn
Iv1ASKY/RLBy7g+WSjiWNlvLeQ8nUhcZ2lUvMUlMkrKlipr6rkyiNggJr8tpzJTsj1OHtIvT
c+CRx4iuwO79pcCxuTlAdfrfpA1V+4mMcWQyHdq0/4LbX9dnBQnJbqaFMfhG+b9+84x441iA
hpggewN11iGfr//kRC6HoNPvYcMEdkP69MN/7fVa/1RxtI+JAatytp4mIn1jDlNwvJFvHyG3
xn0VyWxOAWQ5xqqeWLZsxfv5g2CK9FnQnNuJEWl946HNMJe0KDjHgSrYQVOEncg9698o+YFf
5UcCnGhgJ1Zs39CzMCd2EN+uUyhl/vRkFJYOjvv8Bs5eAvsDSTtSwyxBWVa7hnCZGJ3+C21g
6Fe/ug+OwzHdYu13rAqGQDsMsl4X2M2NejT31IslnerHzTmUTvJM5sTE/cOg1TK9ANpIBFjC
IZu7a/31Fnwy91/olMpWNfVYQzoHsSgIYttY/0Bd14qMd5Sq/qdmEp2sh6K1tnR9qGyxKA72
WjZuaL3tbaSHyxrWXlqiJdHgGl2mezpXT0eLt0N4sy5myRYHUPqVwDRx9EF2RoyklwleGwSK
Ce/cv+eQNHMjeCN1WZXcG89zL3s+fxH6e/IsllvrkzKuKOgTAz2wcusRqLkO0nUARkhgV8nv
niHK0oLaHgEfjLQg8LJjIxl3RtWXR9TCaWtk/5UR2xUHGuqvkWhxR9whdyl+WEUd392xCE+0
LLJWJHKMlcExaqR1gAv/XGn4MooZUAcGGrtAhJpt7f5f5RtAFiRzRuHHCRzwD2tu1tvNV2da
domL0Pqbggvs0MyNiYMDqIqxX6dfYHSCksL0bk58XHzdj/TP+4Kxk0mFvliv02zpKr6o2I2O
auR2jGuRLBFMM4MxS5EjqxQgeagaAzVDII/vfSqwqHmod1Cu/QQG3gKk4DunJIUPEQAOy//w
QHHZLANQSBl045eWK8T6L6VDNpu+p8/8nLd7CSYylXVIwcRjYkAqMmmT9i3cT5t7NypbqlEQ
bYSjdX7JMpmH/+kinpCUgn+hr44ML5OH6Zl7lzV4yY08vLQGExcfDBKzlbMMyV1WfEnvUyiG
uvEbbTpohf3FMghqu2txdAlMeh9KidK+U6Ht4qQL7xJC774WsGF/iK11RXiFExbEDnHvQpnl
PkigDnFzJZnFebB9rPK+uFhEYvpUtIag8cbqwmrxGU4usta0MNAxhJgJoNkh1YnQG6odlx6N
cAKThPZLFdjz7ysWlkj/ngOSHi3mvJAJ2MgfGYX/8+TQdM4OblmeCK8y6rf22+Mo4i3scXOB
zo9FCj6UlZQK+kb+tCTLIUWQLrssG8QMKsqJ8qeBA5671OZr0fF2LC64xT2cMAE0CVpnculU
3VXF4dmIdXMc17ssyapZ6E+H7Ia5jkUGviylRUE+zI47HcIU8o69QTp8mHPhfM/xR/k4raid
Cwi2bM9Rr664fX+lgk0eiR+CjWOitI3k662ZVkc2KxqM4G/0n6HG89/wAkmjk8xSCBbT195m
vTZqX+/02Bdvq6DPVx9HkqFTifUZZ2T4PCq9YFjsKKUCoZlxA5JODt92dHFP9WxMYXubwRAP
PaoTw5Fq4NSUHjqCYEQtOv0YNjnLqb7VkyPR79CTQpfdbFpT87WHW6SwVJFlL7gorSaednhD
d6tgO/COUlTYkxVtbUc/e12Uq2V6qqdOB/Ok0Vbslt3ggQhvvOQhE6odm485m9Rtrpc5STlz
jsstZ//Y4DhvwGIJX1GYpfdbnqsjf/ur7FnFrqEUOczkp/oFGKEqFKsMfwVRdbDp0cVMj3E3
QPY2c3b/4kO5bDGQokz49z7+kYx23KLfQcoSA47CIgJ6f5twhPvHrhrV9LlbXNdSr9a+SZuL
d2WKt1+EGreVgpa7msksbBxVtKmcFr1bG1jVA/AOHB9HKvG03x8zj+j8laFwRe1muWjDc+YZ
+sPtFT+x9P5ZzMEeUxyQrbARTJODWowYnp0n++fZ+mTIIZyGilkuCeI4CSdL9yOpi+wbWBNJ
OOvncBn7mpVHJdiZ9Axj6xK7aDaM5jLXmLWu1rnVOsQRFLfro+KQgH4ezJFq3+BHGJsMZEl5
XXmj4kjC6uuSGxN4sZyQbLHbw9ysyoRgQhCiuw/gk06KFPpvC0XEUpxf38c/QIhvEN+fPyA6
c8p89TcXx4lrk1BtzKAK4hnpFh1JZAzODmwqHf6rpfH//9soatWex/So1BdPiUdpxYQxRcCE
OredcTDxoCcmdMl3nJkXZYxsqayI19+oionZuBv3IhjqXMl6BUV98bZgAj4RogzwZr9x3XyE
q+q043pfZt2RAoFl1rP7bNHo7GScrUd0FS58n9zpu3qZQ/uCV3T+I1fNw9WqK4qwRZXaGnCt
3HJV1qmv31uPFrvFAxKXR4Deloax+Fr/nLOQesGUADMjf13FTP6Wt8bGSUu5bMjf1jIPDrMs
XcKMSj6ckKsjc2kv1IFCMQrq+nNQOr5QKNPoEbDvkq1z+xb13cEI4c9fUT4wbnJIjJVmRe/L
Ml8fgq4gG1KDD+1RerVTa4Qz/2B7fTkWimA/FAUrZCiNINF7gNGNtOMIAiaVQK8N84Z52zD9
fxlIK/1/h+21ftswmPiKuYJfBHJw/W4/cj4/LhBmHsPXgckMdqM/rYShVf2THEzOulG1YjMs
0NGawazcTrkWrA6O+72BUw5SpfrgUvDZRgUu4OToe+cTChLameiu2iQrG++wH7DiShh1VZ+U
LfAxHUxItBzoR5A8e598AUgVl4e9jS0QPvb+CZeL6fa78WUOFyfZyDlN+bDlQgwFvVD9+1iy
tgw3qjdRv0zh4r357Yf9WIeLNt1G5Ztg7f+6zZEHVKj1MvsFswTAPjfXjqZ3PyPNa+sFexc9
NZ3hIWy9FNrQuYxCIe3waV/VjnvkHPm/eIdKr34Nz3Fir3PPMz1GjLl8RlfLdQWez4krcT+K
HsARfbYRdXyA0+F6OALIQDQPkCftCRg692HTK1sFGEgkcsgEDid80GpDpcJuEsCOrTy/hBaR
n/gZEY+SVSIZMeSCvhoU8fR6wLzycGsQB7pzCgrRY6aJRsOxN15tNSbFBFxm3CB1vVqBr9eq
6WtbSIaEwHMg/Q8JfRAbew/LIUXaTJYCoulXwx0CnvUmqXD1pRc+fZXnnz6ZQoPXge150T51
wozXbNZ82YoT6+3N/YJNJbmrmPbfA/ZQUo4vqKUVbPupI1XKiAySqEVZxWQ807N2EKb5QsHO
Wt/a1+pp/Vh9AsJNyqmV7bhznGBI06HToTQXDp9/dLeSGzLrGV4916lGYJdmWmJkmvwoSKk+
MLMOvufr5vdCjFjyOkgaVoCDKFH6aa1uxUVPoGnlvZFGdU05hy97h3U/DjMGrcz9AcPpKU2J
4RitZqtCnluMRCSGDEa5B3w/yM/Vyddu3C55UgGvoAxd+5Ifc3vfjxovJ7wMYpZdfH4J5mtU
gtoidmykXimKk20R0dChf25kyQzyvG07RO/A0a9cYBCVCl8t7l3ewjO6rKtKxHdIFcgREGW3
50pDTVkSb2JLxmDSwZEtceQXJM4Y+TMUbcOVRpxfqKldURpmFnPbxsVtj3ddQd3LwMhbvBnK
6qgWtjjJRiDxcZzQIgEJPikn8bUv3MOKSmlDIRDCH3KyINfRUUNl+oM2sZ7pbZwtsBAPp/e5
KsPOzEWlUq0Ya/ruyvdvPIwHDd5RVkyODrKvK1dDHi35R7zZSjbOg6Zri6f/v0U32fz+q86c
08eHJUjhJtYd75ePZinvmdeTAIXmx2/sA1BuVXFv7ANQblUqrqTsjOnaPt+A4AGV4cB+E4nK
fot9aXKIIzvZBoGsuQIHaifuI+nKYprtHEU1VOGikXTaj0/h7QGG3pTk0RCwD87r9qhPLcaO
k4Yq96KZyeI33qsO7Ec/IeYqLrjX4YXo4hYH2m9gHAG0CyW9WRN1RYILo4oGWoekY2z5NeYm
vTL64Pz8FdPmAY7AIF0weLuQ/ZvjafNMFFx5tywt5+4LJa3Pr/+PcFAeYXZ+kdbBoiVvKX4E
GuGu/p5ERkWrd7RhVw51eR6YB/XrjCcMzbCAg6eDrtC8Yg1PpMi6kqb26w2NrriAi7lnz548
ssYPL+UMdpz0a5H8SWesym6Kjt2cmoIaRci4dwtDc+qw8gsSecQ9x+R0FZFYRB0fDPfrjhTc
WMIc/W92xZHzLk2y7a7Hg/CtExjczgLPQ7T8hTGAgEEUF82KHLhbWauFv3KcWVnnTDEAtgW7
GHaXnOkILlr0z6jL5V4BEwoY6twaMAzgbkWQ3gl7xksAlG4LtLEyp+fjd68cGyEc3Lmj8axX
xFvgRGCxk384Vf/o2bMwks3QCHjmkVuPD+trDSRUjIb1EtHEhRBP1Xe8HA3kSOfB8W1kNPfP
haAEMUf6a/LnyKIWACCs1cEdkhdL9BSXrSzfbbm+P5s8kcXACcreGEOkyjkHWrndk+5PAIBj
6vYSUb97prNd6/XkL8cSiQCL0UVPWaGbBDRMSS2WxnqSmsWjVr/CAQGO90ryMFhKCTPonmXp
Sz5kbpugGnBMGS+DC39bUHiNLb0uDKL9aSqJ/J78OVQ5a3Vv5WlCD7GnyC+JIuY+DQSgMOi3
uRYn83fmh0eFwqH/T66f0T3rG1hlVYoaYatk/y7mBaUGZKN0PPQ9e2BUlc7ZrcKbiC65h+Ey
oqpTuT5yJZTl1KuFEWXX3tyYcPXWf9CF3v9wzClgoVNLbt8qma7E6focvgvJ44RXYRrmEEFU
SPXSJcRZtXpeF1ZipJ1RUM1e+v1xXLYBjL6I4Y5oQYNeJIk3359OMi6P8EwyZ6TjC+oAUDaL
FsBzK4/FSCicMeGJchb+vgYnOfpwedxJutUMBAzhxd7dZ5LFSQSO88sYmecB3jBzTW7mfIKH
Jnz7MgaMqqcwJ5kexIAkecs+ophTUWCeMcRgXXXIqM8wkRR14CVnAr16JVl4NplKpf4tZPWf
vMBxlEQcY8lMtGGbo049oOWBmpoxg6HJ7mghWmnseyFg1MxKwXLzqWZsGjH6iU25FNlqN9sB
oeusAUwK53rfgvfoszYCKLwdvpNoJ7YUoevrHnsQkeEOzMonXw2fSH0fO2xhbrBthMOiZuNq
FNsmDEEpMWULZqgUyrex480KLZCbpr+9qJrA7YmhdWZxKPoNWi4ErAAZZRGsnxr9Hjg0VEoG
d8+GKUwdWcx2bIpUL7u+kRNjv8z4reFafS1GBSsPjHf7JkVgoeF/5Wq8H1h0mK5DfSwxTfWO
YpLjqKFS0pi2nGvnw647QFSMuOGKuFahl9WbtQ/CkEWQ95uOR/M3tcnbaptmbFqeO4CyvadK
MK567xOIVcu/txZb3Oj+gny+rr9z4WiuL3Ru+qzDd76EL0QpUMdlOGmb3LktatRQC5TTSE+K
LqxRdEbAaNxlKN19qPJO31Xp0LPS0ewZPws7mWB5v6YpUIGjW7Yx4rIfBLnp3BkOe6PMDHZp
sGB6HlDi+Cpbf/Y6LW7P8I8knSIJCvVnusvAvKPIxVo4abEWODgOuClfxrZaM26fVRGMDbTM
bSNGkDRl79+XCLJubrx6IkCqVChXuEI6m+X4ZeflgZIxQZO49t9PgMSJUYKj0TPXTCbINzE0
aq43D68px86xbYZdZLZXPWktlDZAg217vdEWENaEOeygkEY2ibONvbNSr04zAxVxccwn74qh
7OgVBwmQf239J3ZWjp4Ca7vUb4I5AZUqwzDhBNS0fnWtTt+pouNee9Ndb16jiENTnl2qD41x
/1YmcUhlrWZqHurYa7R+fu+tNx1eKqI6o77KsqSbX5qLrqo/y1NuaCD2kxwYmrZPigcPk7se
wv7jPA3/IxIgGQW6qxvuxvW1YRMFSEgeeby8xDoPqlyqbWn/8EPOuQVPqvmTVeX4vlUNn7E/
6hm5X4bYlwXtMilhGUoZxLaQRdiWzkUZj/ZF9QvtdXESM9qM3XmB7Z9pGagjeca511OfINu+
EpYtxQuhfMYNE+8ivsf+Ekl+TGH443zmsaoHkBjpLDivRHZ1QjfW5kqPDsiWVxbuy8t3HO7N
/pzDBNfO+Tdta0CdsUK7nQD8jxEfbrdUO5J8/ZrwUER74XUtlmh9/ggdQgkH0IPNjAoK70Z6
6h4V26/NZ60a1hkFNZLkFjpbM0mATBVMvfhzhy/+bD7MCtMbt8+PmL9HGTcPuIst1fOdSnIh
nK2/t/gUlJfGETpbl2nPmOxqWwzPr9bw1chVRLiwTxteFko7i+sQmNwliURCc30N/by/TGRA
L1hHZMDXEqdAMJRpW81IsO/mkiW3F3nQ13V+4BkRiksmxePoNggsr57e/hxB6z2x0LPPIZgs
YlEFMdLL/cDASkElrTsTvuQYgNS3CJKURbzfiL1iK7+dj53Q+QSWICSa1yLwG15TnrhjNp2H
a092dcUfu4cqDbcbFgqbK1QbJgKgVjPYY/sp5KMBsQZy34N9t0YTzT9hjz0oNq0kTEYxSMOY
zP43ZccEh9zDPS6m1/bv1x7m1x7Wav3mB3gdKCB2LGGlpUjuOJkOuURnpNOAoAVD5DiJBgyZ
4Sr7OTQdiFC8cakxITVvA2fo+DdjCa5mbBqJMNOzTeUZA05wS1mZg1St/+EWb2ctKaPY8ZGz
X9eMiJ+xtEwDth3fHLp9dO1ve4xnSZqs8BGsMtGrVzt2/X2gQJLYh7DNdeWgiKDdtaUnYh2o
hQ1Q64bBteVPoQIxaGE+ot0aeb7Fyxr8U5fDcllSlg40H+qPbdUIAZQ6UWGHEsT+ktx5vJFF
c+mgXzvDuKB/4GPhyQpDvJCDmId5qouuxfhJlUAZnESJI6G21Y7IVGtUx8rUdudbu7Rfa/Dl
kHZeE86pK3cZ46fyvMrlUSsuDeHEXF6xBVcrrg0Fi8azXtrs/bhjpyO2ESFc7icT7aliOxVI
gAftvdgc9oFUCsajADP6mKV2dZ4TvwhVd1OlVPCxJzQrhg1RmJRVO9T2xPBV3wV3MF6yaQH+
EH+KwjdaJ95+NX4STN1ZiMGc4+9TnE0TyUaVMplYk4wadJN1M1E8i/W0RwbUufb9Cob/TpPq
lxNuIN3OEF48u/1lqprPz4nhdQzi8zRLN13JpeG8cOFWjmeOnme9An82lDDIQ9/yG20MbYkB
JBXsmBpIOfhN/BXT5gF78KfhOqHXAjfTdhheJIWLpUTa1n5AwN663l0poitrFV6CTP7mAMrU
sHjh9TNP75J5GEB62jo15HQUQpbfgz8jz3kmEMUpOiuDcsuvsB59r7O1PFWhm04WfK3RWvw2
pty/GOt9EIddoQX5hGoWz+E4f1JLVpVLeu24b8rk7O6A/ORKvt5kdcq0FES6uDv6uzAQGvLx
Y//t59VDG0zqyVU93a3yzcOVsz5K17W4xRRz1f+WitencF8GfVm5tHfg/gNCbkVYL9wb24Yj
/gM90rlNIxssnGa3pbf9L//yRd/MCuD6TimowClUQTr6V4zrGb3AuqCo0esc0x3eUV5SBkFW
IT1Be0ysblwwvGc9vljLm90QAIVy3w9cA95j1w5VH/3KfwE2fJ8QRo8PivaS6A9F060KypBs
1ogJ189YM7Qx3A01K/KwZGsloiXOMqTzDf4KXiryT28DdQUx9a2rrp1zf/lgtNf5k552BBPu
yK4g4z+SIupNEAAnOlUvCaJk7J3TWRwWAF3W6nXX8RDxHdOo6DVlWkF4NfHczA+AvgxYT24o
DF5BmSSrdFCBwMLSV/sAlHuLO5Zh3mui37hviTiBtikN/Plyc3CbvUMaFMH5jp5Rv7NzkatV
Kg5KgMJU1PrZwbO1K7PgQha63wXcyC1AKqWCj4KoF/WobjpgvUeIrHyhcEGKanUM3VFGuslx
jNFkZy8fUHcB3tQxs4in3S8ThVDnlzP8bgWvJUyWsZCMOs/U2RIJwnJ3OVyrJll5aY18h/EJ
2Qkn3hhWrghsxQMgPMbcEdEaXfLOV10+4QkJWfPpy/jDT+MDfP8rDMW1Yu1QW/HVjV43rU7F
WJ5WpxZHh49tjOZWOepa8d9JmPJd+zTS/hja9Jl81pWc+oy9lsixQWToPWp6nmwD9RkhWBuT
/P4E1QJdvOR2+zCH5oOu8e22Z65gQ5hDNuaCfuhIaC6Iqu+on1nxuwH+j4OKwfwYoWDpUHdt
QA31A6vJco4a3TSb/CFFMjL+kL9pEriH/lBNrt0DNAsdmhAoAGQeTI8h2R3kqCC0HiYoIjls
fqtn2X+aafvUW7/fXJthqxgzJKP3jyuGPo7qsO+FkbhmqRSakomYZLS17hVIKr5v5jOT7HK3
DJzcwDf8eCunubaz8/m1lsVmR7MwyygOblm7F3DAT9Gb4WcyRMV8WGk1Y2skIVhRgRtX8rld
XAkCBgBiXmnvRmL8IW9KI8sGU2NH0+wbl73pHc19qBWYtcQxgE1NImDrmBEj+PDtbhqbgywG
UgVA26b+Yr8vzJDifdBRN9a/ErlIAHEc/4dWjORipU8PLCZcelDNEkPPTUQmGhw5gXbXZ1rB
WZYjetRnLaqyU1LJSLYHzYwcO0P3wJ9nfp0qE3KMuvJFHGIfB9uzkN1sMGLtHKW3j+q4knb5
gQZXOh420ft33UaGRTNRSohP5LIJwl+D1AX/vYmtmi70AwCOIfpzCWe/ReOLDMAzlhfSi62p
bR2WuHPIR2I9Lex7ATQJMX/FbrfyhwmHt+qHw7T1rYuUef2UXItB6rQk/ZTXcvJkYbji9nxH
otMr9vZS81XFIeM2T5ijstdAkf3ZTG5g6CERbREfjGtqEevTyV7QnafcOt/ikSGf3CBKOZzj
eLWyUi9k/Z+Qh/6dU8Y97bh4NVfgO2T+HyuxG3MNOM+/HNTqq7WDG2DCEwVISP1gzoAMGJF4
JlUamEqjVleKkJUVERu3nofCUiEosYS/uiq2ZJUyZco7Q8xFNSAlKgCheO7pRfsoJfAS0OgC
CaHiRgUWhMyamNl90O6QhQfkMZeA0kr2ufXkCPsd1Jpv2X0er/hNqB0nf5r3l5WmQct3nxd6
/abX/b24FZIs223ru/Vl7+IQi4exBgp3GJKzwCpPUWxzV7xz4bxKtW7PLl8rCOkkQdhQvRkJ
ghtxLM0iF43YuhuZrUXAIt1ccE8NVUqCigIlRNTcUEtefcSHcs0y1tV+I+djeZ9jJgJVVWUM
5GL/xd9bp5RVYjDJx3Axafafx5Oll2CjA5iLKVGhXxzQW4zh0INV3VGAbwCDFCOOt4kC0FbP
oPPOTQCT5FPOs/q/9CxEs9P9L2/7St3AOUpPZSP1fvdmbY6TLWhm6W8+whPZ/DRvPsJa91Uq
W6yOlXuYdsWekMRIZrer++lxjyPYKhOpq/hbdQ7bInGZnC1nPZ835dfKXCHptVf3CMeMNIZm
5y4vbVSg9hMR6r31oTkKj3TVWsZshqkTnsjVqTNBTsSIlUaERuo4cbPDyDE5a3zpMQTP2rel
ExSJ/ZLDTnVa7JS+D3PP5LJrcdkInOeAMW5yHAQfMeCs+oO5La1nFNA4NzS+9haexrewI6Q5
rbMHkdn9bY7hZcnsKMxhNMYXGAL2EEpIoVpGPc15oMr7GsJwJhKH1ORMY18NTVVcmHUwcxxH
mgLDFJXHYEu2jiKh8t/yRYaEN55r65EqVyo1/0GQKX46rezGv5RwrRMQr6/G4BX7Cimkz/0u
JC7o8/3Fh+cdhf7egqR0WsYb4+W7KRznvKlv8mFpwj0FYol+a5GYvlaJfmuRmPaK4rNn+iFN
G1vxlkW7P47KMeHdW7Km64kR+3BtubmXpwjgm5h26ZJBYojHr4T7dbedR/vLbQ7qG7Q9G1AL
bWNUVpWe4m8MLVQYVXFvDC1UGFUqn7EEAh2M0uswVuHs0weZaiYnJVkqDVZsKuaWnk0pVncJ
DhtP4iZpAdGz3O6SbwqtkdjJgnDwiVBiJ4Q3341m5PXaEdfUvP9Dv1VUmHZ8asFLGGdgwxMT
oZQv76x8vqZfxWJxQEV1Q7+2MEheXa+Uq8w+p1VZnD1ZVibX5eB/tpTJZmoMBDEjjF5J5xoT
eUxm40iSHVGmRSmWWjZyemte1jeKWrSJCyyeaNZrlvQZ6BV7nh72vkWjiM9qSOOwoKg2sn5b
/azG1RhQ+CncKQAsnEt3SCZVBPbI5erFUO4VlSbL1vOOkXDw85+tJmt4lTVbjTs5YxdY36xF
JQIlAwWenubn9mrnGjcrjwOrA7ufj4Lr/Agc1WSYIJ5gtC+JSyTrKIT4KIiIXsjmaKXaMARn
LVqxpfqZJaX6sy108X0NYGnzmZIieK1GegSnkHlmyRaKAfjMwPZzKI5XQMkJkByX9k8bV20F
rz36C3tzWKCf8YRiHubxVd8uZOjYB0HV/GvqJSOowC4LvHU82Yeh9gbD4EdZYyoI1QF4usjr
TNJz/QmcKcmbxeIKhDeJaS/25oQgJ293Puhxp3dis2p7uu3djXou0KEpXTUddrFDM2JJxo+I
qROZcJ2Jqd8cKSgOz415B9yaH8/sV7xmcuSxprG587I14yCtZ9a/qfHBxBLrB+/XDMF0QvuQ
vXZD0KeRzoSFOSNE+POwkGTUTOWbLEfddrQIU0JlfRt243zktNRE+ls4nZqZSnt9R/3tn2r+
4h49tHFdsvMd5U/HgGNQIHvpymAgFFAucdwf9/IWltGZwK6BkqVZBDN9NrB9FAIaiQnyiILz
e7IWyV1pp2Yltm55u+XxEsCVXyzMVD/uGu7k2EGiaX8njtGcLEqDOD+hFpeIjYRGnjHmlWcE
nqM/nCpAhaR64Ps5ELhks6VCB+kVYo8kJ3f0h8yXo0fucbPnp+zSbrJZv7owoVKa8rxu6Fab
3HiM8Inl7iK8IptoKKhu5vkluqkheMm5FZB+clMTo16UtF1AP7ZAYqekVJ9wMftyy1909c6Q
P0VPkEjJGAv+vlXBn0+CPs8+t2aIXVKnFIiiRC2jNUaqzuS1+SybwGWO

/
  CREATE OR REPLACE PACKAGE BODY "PCKG_FWRK" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
249a0 464a
1ghak5KO1dx9JnGTDnYWLlA61GEwg80Q+MerrWGl/vbO1dJV5brddAiDtIKY2l9e6Q55t3Cl
zdRCipZM2/XT0/1xqQC3d3OGZBo/KTIUgR39SddIzXtVJfeje8F9NPX/6cT+RRL8DpyG+RLS
Dx/tsbD5+rr+gao9OYey7poC2rmtcwyxNRlEEIb+/24Z9rV5mv4bVfpjsX3alpauc6/n7rVm
5CS2wXdStVdg+KCdKbHm/5iv27uBCJqG2b2r8BKGbf4R9UL5JVJ5qFO5vr/8t7l2yHhMxL88
MgUzcCOGvO9q+ntY7nBd3QPeCWezm/EPsuSVYiOc4nifsyaCCJCzPjcifUmWfxoXckFC/1Ap
9/Pt6hKhEysgBsuWRUj+z9D5ZLXo2tL6FGmxhBkSIAZu+Iy5vu8Qg/TaIklLdnJOD/AP4A4J
t68RXVN9PQS7e4iVsB1XtsaBaWXlNJELrO+yUqORy30EPYz0B+Nc6pYwv3eA4KpfAMZoB3j6
8W5FhtmZ0psAZWSASUwe9bMQrPjuaFMPIHoVgnYu8aR55D93ogSGHqb0d9pl9cGQu4dK5PqP
dq5+XShbwda9P7TH0RvWCE2Mfgf3+ixP3Xm3JBmPN5CZlQZsgiK0ICwq2lkHubh9/g/TeyKI
gqQWhFMESq7+Gz9oWM1vv69t2e9bQ+GRzDMxizBJ8XL6tGi7KNzc0tf4IHLkP79mfh9m0LTJ
alLEIOvieOzOjAhdkXyrMBfcTy+snEocYc8pcHfhPB2u0Kql1XuppzSvDXQt+jraU0UFNk1K
+f6qvd/xOw6047WTmm1P1FeDMf9W4Ln/4JGFZGo9H1JKWWjtug4KmD0jvuZPrPAsViLXHzck
Tz3EIcZ7ZoSd5x/FbluCLbZHrVUdwHsmOsG4eryPVLI6Z9IzR/N75HivAghDTZruo06a7XWW
IjcskIFqDM4wor4w9SHSpYpJstKZJzyihyKI1hYP2Z8hjwLHkHXHL0hTvwa3MnSTayzWSHCf
pCInZmPYZ8562SVS1f7Kc7Cl8Na243AP591JMAtjs3UuXd/QDn9Fo37klcBOUrx1ZCRbgrXZ
m2rsqelyDw5LbKMg6BOYDUs9QmGYGmLBYZC525F6HCMw1XqwwZ31GyCkF3dact30sWbmQB6P
lBRHb7tHOum2LeTqUqtJEQsRH2tZOX+oYFE7555Wq/Ot7jGCAQVU3w6kBDihLXe+s8FkKYv8
Tn46vdcfE3AyJO0ZzI7T3LnBKeBCRyc4z0uV0yPswWeUcuHqevuTGZ9J7QP5dVamOWAb8rQJ
TAjtiW2F5saZRKpRfqL0MHRlcLyAY56uLTtCxN+1M+WoYyUvuXiI6yT9Zk5vM4zMnYfcF/l+
Rb38YsOdkOLoeCLUGc69DDguaA6amtokmhLQqoEbU9MtpacBq8QKjxmWZR/ry4t7siu/bdfk
G2cDOsbQCAqB0iKl+n83sPj6KLkddItOz+0xk0dasRz2Kof+LoV5f0Vukv/9wNxusjSh7+TH
BjrDOsGqxpZdgpXy9CvVPM6RLG50I0xRTnBg//DjB3sWpntr+5UXcFB0944ENgzviWz7DJSQ
3hFQJOgSapAJlWCk0lwLJcxPLG+pze5Vv1u3/vkvtX9d/jZqHO2I8o5WMt6imkwgYfk9Vnwf
xjLG4uNvJfw8bV9nzKR2OPWtdm9AGf5hHaTrQQqo61HHLIH7tAFnT1NVGR77Ion4nEha5Hqn
lNYiiiP0SGY/Z1J978WhFh/oNn13R13SjeuWy3M0+P8Hiw92I/4uU2vRMVD6MH1TVcyWBvBD
Z7BUQtEV0UQjIMD0Y1pWoYfyaDQ2zyTHpLt+eoogAVXGlg8494cQL42puwtDiCfH1MwKbysa
nMTEr1aOrvx9IVQ21VbG11DA8zGv8okWelSfPjhi4Ddvj74m27rjTmAKsNSUk+suP1R8nyOG
TsdZbKheQ0pBzh6VIl+rX7q2162rQDIb45DTW/erPgax6aeoUqg+gOOHH7fRCSi34KldMi1/
BP63J1/OMi01BLuJJ8jODebMalOsXJH5vs5f5BNUw4g9GHgESa7rbJWW49h1Iq8no37bhIax
bkHU4gmDlj93ZuXvf4MhUTUT5ppdhuu8CIxvIz9no7DNW0k+uRyCnkCR5lZVTf3XP9nohvWv
xCRpNIQFLD4ZrjW+rgCTzOpRkp5aQWFr+BmmDxL/RleH5sde7wj3ScbFzBBesXSnBKXYmLkp
bMnE7kKEKKYzuux6vZUUjTA6J1++9kZyk8DA9RD80KkI8Ws0wVsVI6XSwUy80htIavhPqEIZ
5lvOnWttaYrbCSxI3Pk+eOD62CKrtu9UH7P6J1ZKlJRzEcP1rMQQzlrDoimRX6EVgYrnGnMR
NuYXiKN8xZtNhQseXTXLBMrDbJIcFvzZHpCtbEQ/jdP4XIfO6t7zcNBvNjlTuVQsIzxXZBSs
GFu3bKOX31QYldgjQMjo2PMuOuHsDuPv4O9qDwT9bM7nqNnOFJilFFy48RKtq/NqESFWOkVr
weoIocUyXh7rulViP9K0FDqMIOiq+OrZRPm3kny/FtyhH8zIorYWWmQrFIrbjsBRBGSH2R/1
Zr2fI79OxZ7VBS1Mwm0bC0J36/QUXggy+9835XBql7gDo/8E9weZczGVU8iQ9L36FWC97A4p
4GCGolSXbHUturNMn/Mc8mvERkvQcfukRIQqRzUEw3Tt23s/dtnWvzoEMTaRdYRigw3NRMwU
TjPGSUlpVgKt8qxbXtWWdGYgqYQZUAI0Nb1CarKbOdNdsvOFHuRyHjxyHktyHhhyHpFyHiJy
HgR4mDRirfJ9u0Fks5uGxu3gubs0Ss3g0R5+/xFcqroHIXPms/NzWfhMvgBQRM/ZlTTURHOv
RHrtJEGAxJvBK/lopKXBK8tVGF/F0FxDUDuFjGbQedr1k7/s+rDaq25XSPMgSDUkSIgcaNPP
xLr+g0puxLweNIi2O5B+OV00LkzEuZUZGvjAfU239UblHEiE3/g09hGi9dVRvrrdmQVZGQ99
1HYPRVT3LJBqLm63tnOVJktY6bevhcdo9IR0e7iMCAKGny7wcbAe8ICp76xUJADEHz8imF5K
wfcZJ/5GfN8ZLuXjo636O+2GiWA75AY8ywhfQbgMsJ8mHB0N0A6XvmufLNbklY/pb/gxrbcf
rw/5xVMPP7LJ+c0nQuluqNC7kKB1FL7wEr8MpW3oeaWxCgrX0moy3Sp0PNqPJ+004+cM2Vii
yQdjdMAjf3YptJHfX5OTI1dGIglVODXt5Smvtp9QQaJ3eNFB5jgkbWr00twoG58//NYY/5Yi
GlExrxdv3teQ6ve3VKpGMibeXx44EddukTgSzbNgI33Qp3RXIEIdczilNDYkkTUskcm1jAK7
83zQE1VK4aH4lprr709uOg3YSGBCGUNTBAKtBmq+VdgBMnwYZyeVVW1CcW1CaBhCcRhCaPRC
cfRCaONCceNCaAdCcQdCaEBCcUBCaAJCcQJgeKjmgW1pisoIZtnQERCBrVNYUZXSOZmMiJbk
AuLp1itNuw+AwxvFZbyH6yGytUJFYCyscDdRjH4ovq/17XHIDb0s8xfevFg+jWcKkwjLMYov
RwcJn7F5P8Q7swEKHGKcgj2D7ROVmBPr2hOagrrd1RPr7xMjD9W7zAEcZEeGjf5NZtAYemHN
AFGLydaaEXyrWTlV7o8k0nqWP/1LGvipARnnVgjccDLVyLUxIyIwVh1lJg9KRQBmBAKLs317
OdfD7NUMIzMhKUJOGtaHlAV2Q2eXxyakk2C1fs8p5g+SZOjCQgW8QpqIn5qG+jT+jh7OIL7t
Hll8F2bl3QKGy9QQXvicTCBQTu+YLnUkhwX5z2gsbrQNLPCaZgAc5JiIrQ0RFmY8roXhxxk+
9Z88IpKGz6Vbf/BSuoldO1upxKr4TEFz3W3zk9uUQjjjJF8HkH2cm9GVyU1Or33ABjAnU70x
zmvifhtf9RvkW7uKeXd5Ga9GSEcCHx0FEisfdl6rjqORRYu0PBnAfpmcdkJIDICxD8B+nLjG
UsE0QORElgZ7veLWCrLyTD3a9ZmCaAcdObCOp0E2Jsr+iRz0y6Ba9crKzGVAHDLLl1McE0j/
imRyrs8gptVMWLrH7nt0y3p9+UcfTvC1QjpGhZD/MG9xrp0425JhGQDbe0e4yBolkxvSe3dR
sWv5zlrGdwuDODp1QCuvG1R+i9lERbIrTkN+/p+7Fmq59MLA6AB6Jbnu9z8olfeB2kKRvrfS
8QCMkTRXYSYl8dhwVgfGNcknr55twdhZ0eRe6iZmWFhRzItRlHkL+hjPCVTcoVYdqBB14sHq
FFonDTUaDq9ITA/q3Vwe9F8G1HY/5hE4fZptYFkzD1OIeNJu5usO7OiSYaTbfcoRxmhxlbGu
Q+Ptk/+LLDh0Eon0CvBbdNOVcVtUErTFqUlWBfI/AjA0/0XIDGcbPVoiNhOd4+qQVjMjHysT
q5m4uktalIfN2+yzpp9bh8UjEInN0L0vSFWitWe1knMRqp2pj38PjBbNxrn0dp0BL60JHcMb
OIZ4O0sIE/kaDMZ3bYideTVwblU76MOHNFiWn2k8tQBt2Ja0zmV5j7uDsuRVygiZ7x7ECP5i
foYHpp1o7c34wRy6ftCt56LHiiRQr7OzvJ8SQtXl10H5XpiwtXe7PqTcnfe1aDxgJYQesx2J
AR5hud3gugrlxazlLwubJIuM0GpxCwYUGOphFGzZ+bzmHTQZTimB5BKFpnjZQ+qgh1EeQwbr
htlzZY76rTVFyeQ5Y7QuxOAKDAw7oV3pL0dQgeTJvEKs9vbk5xFS/WCiB3+QsbHG0fvoP5z2
ZIVD5yOk5wtHSaKWgMrAreGkuXc5zWnMvGKUXQUjfyJOAXT55Nlu5/+fnpO5uLQVYsHoB8qm
bvVbhLBPnWdPOivjI9001nkm3JozJ9J5ZCKaMydOeWTRmjMnm3lkHJozJwh5ZMuaMyeleWT5
GTMnu3lkuRkzJ7lYtyjJrZclEngssE4ecCtyEDl5sOUZYdX8lC5wEYLmi+wSafrtZgpTlcDP
umKVxM1lz7qWr8SQGl9YwmWXq4eN9C1FQ6nllyNNRfLqzMwy6k1F8ur3gOkcbIdjhip8ao17
PFGjjbEDlIwM7Vqx2mr4L6vK+lV4x0rU6hJrfx+FrVontjg1+HGxZt9aE2fdefFtod4+GqW1
Nch31G8bBNYFBGWCvIOYuFsL4Ho5/dL/+CIxxc7raEHQXHFVm3FuMgAEqX9rAVO8dU1u6y34
hwVat5vTqpcwIQiYjP4gmHwvsWuncaUQv+MSErwmiCr+NyD0NS+dB/4zeR9ObrMmqousLpLc
xK6hWuvoElJ/X1Xa7M2heWY4UkARD14DAkUXu40HF+6BaPuWAk7wWnodixgSLVs1pDPIULh3
ejhR+rZ1xHRg71ZmNKsTVhxwWGX/llhKdWkqK7iyIUh4vZ51qb0+E1ZwsuyiFVtauSQ0UHyC
Dhyx2W2ZxnnIQARk5wD38ifuaiOKc/vaxs6rPxdfbqQqF1wTbvBxK6PDHUW44qEHPwkkDJwc
UOx1KvEc/CCvJfa2iCJeAB2Ns2hQAv57BKtJSkbPoNQD8rKEcEpviSl1NUAdSfg+H2bopNrp
YLzsjetcaN4eaD7LH3kV80jKhMisrlNL37L063puhvR1bV5dx8pi6nHiBsCUnApTdnLHuLca
ojy1nFReWHYuFCSZPznIcJX6xdwzhMDC2HFHQEIEvurc/5WzeNA4OCA9UZyVrkYIR24Ui1L1
Mj4tAC5I8c+A/pEGUziFZXLDoGLFGZuMpW8w+yaqN53OtmavOrY4WpioDLOTFOF3f91QZzj8
ch/8Efz1Spf2Xu6d9jmot1UGX/6wNsmX5vyB0DiO1W3H9jG3RO+ck1pssvmmdv3gfiSsuInY
OLTMLW4B8+p78ezIGJw2C0lhtwKvEeMzNWXPfYaNq6AusssuskqJss4MwvxQhYDcZ4UXymhJ
Pz+F+FZDypG5AxC9PBMeOv6mEL0gS1U7sydCLFZadf6xLkueUABRMj2s1yc/gSrKjaS54mTh
0pCOv1RZjLggIenE2Qpw1m/5/Egt1Fc/gnPa5LZqh7eXjtlEksLkqRN5p3gEnjmBECPaD4wK
cpoiaFwBRvLF71251kq/hlUqaB+PQNTaF8yxNaoMQ9YJ2OJ4uoAx1Vt/c7PQwyrjfnhNBHlj
P8g4omqkPmi6bEB+Y+wvHJlp2+VR5p/pAoc4P5CwWv+8Na/rMuK3XhVPckpOKG46rPC4v94o
Qu6hdQNgULyHlXf/Zo74ubCxvzX57jWhmiGSt9hpkUxWM5+UaPhFGC1iwjD0nu880NejteMC
XCMA76yRDkNJqlhjT01m8WYCxC7I99x1vEw/7RPzoZKfMr+22G+aUJRiojM6y1WHCz/Ck4cL
m6NwKYht/x6tozaas9Iei0gj7XWCLiZG5FMVfwFbomsbtDJ2mjNZIReXVuYr2e3DY/yipzEx
kT58dymE0+isNe+IObeLgfXtCGoJNIHJXo3VgF0PcvohzUeCcszWEyp4qGWU2LJ0I4fWk456
YylzSST/NisgUQ/IWEmV6/QJH9IbVF/tuGgc+dNBNdcfE3v6fL9LnZp+g+h19KARf+5pQWQp
Z48Fvc7CnbZ2m8h0vblstM0WFKfn22QUvVmgZ50ULOtHE9/pQlSnyAxs6uiOA+xNOyp+a8Uc
faJ6A0UwppknbCZfXbwyGo7FJ9ej3vB05zL+cb7mm8nhf/zQka4N3MI0OnpfIxoqug3Oc6Ph
wdcynSNtiqMuazkABTQTG0z4psM2m8l2fx5oW0WZOWDtEv3aT3hP48xCmpQtOUNyJPF4mIVh
X1stnhLIsalpd+Pdrsrq6Mt7z+zGnBvzdCsRTkJFZ6+axK89QDzvShkb9AvBHjS3Vah6oKMT
uYGBm2Rw1BAjh1n0bJg0xz6RpUshI10qz3o0CIbdg844F6azsDQtrhEdujXLdOqVGBTYPshK
6FTCWKwmkWG3FkADp6Ct9r0EU3AB1ZOHRA+w/uuFVMD+Mr5Tnm9OUI6svs6kcNXezUaQkdmL
Sp81x4AFxUtdvmNoPW9D4nB/Tnh4gXaL53DJb2BA5AN3E7bxMXPsXzq3deGDRC77zeDoqTMz
LvvNBuipM+tlRKAs2Y6mM4ImmM0V/Ej483dVn6gyHzx6gasKbA+AOl6H+RGeAfgtlJefNQLx
MLAf2bKSVw9HsU+h3T2rAoHg05DCh8OoDHC3if5NTdyfVCmRAX2RzfEywjM8MsKfY7cAQNyf
dX2RZ5HOHfYLTe22kgTz81WEqKO8AjMTfXILZz/DFuAHJmZvYPrxBnDfY+8/WvDuSw7UuFRZ
C1dovNS4hRF0WzohQGpJY3/dhojhaSjwwPhhIUBqFatqOD/wNeA+vncHaoDMLJt7NEHI4o+i
5n/twC9V9oXVRbqKoI1x+LHPTlj/SbWiHJP0rVY19DpnnuPirCk9FwY5CpEQKzwkVpM8JGhF
2KpU+pIo1R5ezLUW7c1EwYRQ9PjW0Inz1+kTFcYuS1FEjqo9GbtVEnb6HIZ2MktZpTcx9qlI
b/4RlkUWZJvx5Ia/VmFebj9KHyW40DqV+a7F7iyUiaXQGKHOgAWcpdAYDM6AJAJGtY9BqYwV
wHOz7zDhSkGJFg9uAotQHVmKM706tkocuo4kxQVPfA+iqgc8tdLl8sWOjv58TQ6LvyFd3UkK
MRlHH78TcO0HRerbFYgZ1Pjvu1bENSdYIoz5kYFrjPGBa4w7HoSAjSLSZ5IvaVHYQZGvdp3i
6j365RV/TeXcQOX8kZSUXEOc5fyRlELDXczgMmU8m+c8G2rsX7EAMkvTaRoWky0nkWyJqNWH
qn7aAsaPw6kGcm6ryDHFCm6pBnJ7gA4lRkhPgmnkNa02hrtSkPs8rQu2bPlOLr+Fv4InCntp
GG2d6JPSS2mC9xtP9m+OiTieHOix+Wwi1uQI+r3aMDM+FmeIOR/Tg+BWEK3bnsB6bVbWHmeI
yfM++elg6jd8X/KPFIc2lzftAy0TVvmlgembI66zuZ2hoa3p4VUMnOa5Bnl1zrnOYomEH/S+
uSUaRZGb8A/sfeFOHr3uXbzBX6b24Jm/dnsXObcX1XkhffYT2xsUee9MG4Ma9xuzXHfmF0r0
8SXFaDKgZLQi/7mrFbLXFyE1ChHFhvlS/EqWllDZ/n3GVKKZfhrVfdBo1JgUD2lHd7p9TM7e
s2v0taSqW7MzS1eb0UFlBUnyvBy/OOi2xCfmFGnrDqpPcYj9gRuK7ICOzNWpPspBovTPPfqq
rV1nxn2kXxZxTjUkSNjmdRrewkfGKfEKE7ZObwd6IQoyETMjxiKC9bAT1DMuHAR7ZQXZnx8c
BWZRb5lYSbrUhLbVi1J/FasqZZfYFYWuWUcGNPjiryhZblizJN3c1ve03nzh2o2VfjVml1lg
WOc+gj6UG+jhXYltDtjcO28DcWJIKqOKVk5uqxAXJaR0v0ZxXMbUlo4H/S+k6yDcfwW4z8Zr
JJK3MXGcyt4KOzDx8LpUWiwJZy5SfxTLnC0Rd7GWunbnjAeijIegLhqmH3M5GjhiRJViE7iG
TSZh4oQlxQzA0ehtLjUYoB22uFEPPVdaogUYvfh89+ML3cOCkDH6JUXsAKHV+gJ0DRtWlpEu
8BurCycnX1UiPKJ/co1XvWZj4hNNHqjqtH2Ad8BB3WvVQVgzgMnuhntOWAVfKxmkpCxNGGl6
SL70O0dm31u/qfL95XTtDimEH7k0dT9Y17PgQq6XcdgIF5asu8QKKT2bP0XKARZaYm0g0Ies
4d8fJsBPFoNSrZZELB1MFZqJDHV9HnHgABsfBPmC95u0GnU7FJVwDIXb2+sHoCpoi8+1ZQ8g
i2KOK2Y1HspoTRHqUJufkoG52TQZ98qRBU8Jubclfcv+xADlpzjsGbCiKCB2syul8V4DPn+U
0x0bOqqA0Xs7y9EfPMU06AynFuM8RGQFVmcM9ZhFSXhSKZUFKuwuH5pIEeOoJiUl5gOdIusO
xSHprycNcTrqgvnUuX70SDxPpR5Evs2YkwlaXl33unu/sa/8y52rVosTI1t14DzXFlIMGm3z
yCctYuQ8j76rhoZsSR/rUIGbtkW9PB4psKYQ1BqmVlL3AdEHJJOHI+OQjnfOFfJ/m6SX75kQ
+pKwbbF4YB4XdhaORJR/+lKjaZAsqFTP7Jbh8lhGHxqUHPRgxUAAb0HVz15qMK7v+GfWvPnm
Wr0TbhFB3f5UJ+iIYF2guAb3oWlWRfZwjGMXr9Gl+YBG1KOkV2pnuFP2V8hj0bd5PqRVOyxU
E9l854szVDL1jpyjtIETMGwOZo7m1zmZgiQBaLisU4Pd7tgMpkSIHoRfgmbFBErYsmD/R3c3
3QFetMCLUqkvFwupx4s3qXARPo6DYHVU4H86xfGns5wpsWzywxMg2mzyqY9R4XIzG54Z5Hvz
8JTGKx9Jx+za0kAoHts9wvPbZUOgl8oVhWSL/w5SFI0yKOyI3RZWbG7nkL11gycV2RlrTq5E
8veIPiN/0ksZPMqpzjBb0gYE59CzHjIUEZ729fyuahjj4Bq4Fnl8X1JZ5SLJLMOI+OB2X/xN
m3Cp7MV9lZetrKvRnK/8LaB4EnNioaeUxfoeVKHUxYHFVK4klqxNBPzPtnArXzL12AqMPZsS
S0EPrrMA7JalmcAKikklgcssCbHaz2VFGe5qKSMHKGMepCJf4r/Oj0UZ7h0eIwcoYx6kIlPi
v84vRRnuhPwjQPknDbtLCfjFDa6/HW8vNRXmpib7rVMobxNVgizqew9jTnnqwQsNIpWYa8Hd
GVHfissQWQ/zK2OPfvM4FTrn3lyI7+aNrr8PRAQrjJDN4z/JUFAch4DV1AnZPOufCV4SZ0zN
3t72KE1kAHXUMwR7BWr2eShNxABAizNnRQUdJyCVgcRbJY8c8gcSymK57tJTW3dd8iVDGPbH
0O/PEaZvJSkY9jLp0kWs7Ez7VeIOn+rsP+rCQOrCSrCxmwb+fuh89rLMMa4meODtVhcaSRq6
AMJvnide21ixSm5CqvwJBHcOkKowRDPGuNEnJsWytbKNg3w2V1pmQmpn/BZKI/NGN6/MWrjY
tVE+LkWtT4dynQc9nLBZXTLnv/NWJM+9uYQAMPNo0bucsa9mU6Ey4Fylpet8eiv/R5dYk62C
1RfJQ0fYbliNgk77jo/yHeIhj/IdGeWcgnfq9xB9Zm+lF1TlT3Lo99u1EHtqm3Okkkq5nTgq
j7kidTg3tU5lp04gnL+aCAvmGr8PqXBOb+w/zmCJ45ZOu0dEutjRevQWxpvv0zBcxJ6Aj9oH
+pNKtgCSsNBxLG71L+UBa8/dn2MwxWpp25ewPiNLpXpwJe6brfCM0v6zt29PUp2TY2hkwqiM
xUMil6fAmqQoB5aY7bHgl7vFtqrpcVwb+eb1Xmx9ZE2LwQ6r3zUkt5cA4o3bY4tbHonCbKEI
qpQu04IU19x5efIJb8VEYC+jyaTj1UiedPeg+p5uMgymS4YbQmcoBjL7qChlZAfCcMV8vyZ5
PK9UD29GZ8y3Rw5YrOWjaEeZRSBg+D/JoBfZwuZtHCr6eh4awNVGfDht2LiNjUw3vgx5gl7V
D8tvUbGgXMm8tup5Y7w2bJ2oYsKsjZn64V7B/cmkQAramV/IoPqeduLymV8aucgXVFzMutcO
4E5HhJ6BuGtrdclYJkA7P5nMDGgb1bhrdNGmQd6NhvWf02Y33AFJ+LML8Rs0zxU2ukCOqXZ4
+v9cWMVRUDgvxPqecSlFOTn3gyWv461fcmIUe5GvY9y6UsjAzpGCH7gJQnEDsWnhceVCnns1
h+ust8U73beVrt9oFSoOoD1PynnKC5RNdoFPwOo/BvYiLQI/Zs2iM7N1w4jhDJthn7SWH9LT
AH6N02o1DMMvE1ibkp5bSVL5tN3u9ba9X8K8pzXz7qla/NbL46Oxj49s3nM7n7c91TB896PI
+z5wfHNWU5R/eT/3ZlKannSw/aUDa8LtQ0B/GKZbotOaMmd3wiLQdyZuSDd3rGlytv0yL6M/
h8VzwHwwswWmhKiwx93TPgXJ5jRa/6/M2VCmdvDdYvuUAZG4wA5n19aRkTiG/vKsgtABLbT2
A/U0X0evOF26gnbMBG+TvkXcUSublDCQkg5/GL52idv0SB0Ctt6UQ805ENqH3Z5kVgShBnc3
zG2wpFZ1Bg04JzuinRdQl+cJ3o3khxYLWFoh22CQ7Bfaq69GWjPxDQ2MiQC4XjyHg8y9b1Oy
CzOKheaEd3DKy+9tHdsSUXyAn8MXPxG30Dv0pD1CQVa9UBpy2KMPcQ1ddhu38jv1pDpfbHzg
urqAEiMGp8Uek1tXZvr8xzNkSvXh8e1fiiSkzhHvwgoRyPwWKJZo8Q0+MkdJtrn7qxh76IIW
/Nh8/vUOA0D17tcqpEOT5jzsLb71qdbheIY7SaQIduf6lffIeKjarqEyvR4bXW6D73fPWFFp
J1RQx0xoVAEWyELVWP2w+MdFadMzeA/Y1j1AaJqTq+B+2UOgg84xr4XHccD2SGVge+rD1ytz
/79PNwgfk/6FMP4Un81UeHISHxQynbS/UKdVJVPyiiRgukqZ9fZUeMRW62O/ALTvWK1U8/XT
VL+CiYHCYV0X/EjqudlwusSaKhCIfO29epkMuGVpTN8/C/0O0bqnOxKFeFgOkZt+S8VVvWaY
eAkpLejhlqFKZ9WkB35/8VGLgaaseWoeo19U5+1AOlRt81trod165Y3jN90M/fnrBkMiEYKm
8SChmxxQWsZ4ow6psN5+r7ajrM45O/FAGbo02zmM5R0GyMvGKvWD4AEhj+3sOYw3iOGKd+VU
/MW4Oxhj4uAmClT8GFPlVPzFp0VR7EkcDLJEYPVfqD2DkWWXK3HyWH446cDLiIHnOuEglPQL
pqXejIrvpSmHdx1dmdinxzTdUE7Yek+06bLaSLbGTM0Xq/vyXVEcDD17mlPP5h9w6zF8W8UG
5Iy6ciEYZRTcAHWDQ3UyYlhZ0Y+ei91/qBBtqyHrFoctWYgc9fOnq4rZ8wsmWtLhFR9xU4ic
OxFZOJPMAmPUlKeIk1NVtOb4fBV0NUZWP5Ge70d2onWCRi90ypHQOFzKAvlHy3MpaFKaf8YD
k3axeyAwI7mjppTL3tR/vc7+lC0Cb8YDrRGmkx0BPCv9yXBEyNoYC9YEx0DEUD+2XzvjSl5V
+msiEoY3qYxxdo7jIaBXrLa2DyOfxBWEvt7zKbdDtALtd9R81WotmVddWAPrdFl6EYYy7q7e
XOElSq3U2c9HGMwdrIZBq8jwpUYLXEPNrnUnlHwBiDO4ttix666v4kQiqZ4LSpicMZaYkZe0
nK35qMc2NgorQ+04dn+xdpxnbXHB+jCGxetVE0ZSAZ2pRFVvrDTUOTagCMYn8wpWsC3w6v1g
NpnGS9c5/W63kvALVZyNDy1lBis/lZdkVDqU1Qbl5BiNDy1R7E8VZIXlPw4X9ysLcEODQMj0
WifI2UwraBwPQGK8IdrPk9/O8c27Mxu//YyYoE6uCBkiMG1VqbEOJjyIMg/LkCKmhD3DKNAq
g/2PgZFpj2MPiIm5l2TX8A8qooEQDxOYJWV6PS7eE20lZRTu7KDX16qI56q7ncJAmzxpbbpu
9K/SXks1bUPJ+VI/lG8H7GTMS3U/U7zLySgn1SpQIbnJ2Csa/H3+rkC2vJ/zyVo0FzaHXwqQ
VNYc5DrxMZmWas6sia79t5JZMjP25NfEBd3GT3d3msVsiKzdbRoGDEjNrD0nviM06Qtk8w+H
j1wRkYSIiFwRWNX/Njy/QFPVe1LGwcX/FOcfUlGqG7okgMjYO9h3iIwwRPwIMeZjRuj/58Z5
Q9L5tuxVO+ZltFZk1j31UpR3xFaK/R54fUhW/ZxKTBigCqetWgGoO6f0fLOVVYGB3JYfrvot
PYo3fGWJLmUGhovJwXzMMjpVniiVSgItyExupGokPWaISyi4KYd5K7EiEugAvNofPCX2nyfo
8if66w0XBQrdle7hsUDHVV//I5Z7MuOESNzWmSXAgoq7s0ge+QE+nIS3lQl7dtVbCwHXO3Zf
wiiRmUHUl2NU915DCdKK5xqbpCtdCE46y2wA76cx3NGAAOzj0XffjHG4LfU8cG2UaYBZxYiY
/10lLkEFrQPY5FRLHQytgLrBXG9kXJ+/lLuw04go+Jlz45daekLizXOMqira8ilUHa7lDXSv
aiPnzc3Qrn3CIymcisIPRni+mlXP5ysROvdAfmQsgLD+bmvrE2ld7XYuq+3qGYfj6NgboSo/
lVGCLlTZfMzf75h7QOq3RxWRyKLw4CoEku89YOveyuwtZdxOhfxnZZ40cHH+wPXcWoFbq04J
d5GdXvRFPZOHkENj9EV0eQAkTRSPGCfF5fqAKl1XCRjxpGNZViNw5oAMer5UoCfujKowQiIG
T5W+BmDYqc7kZ/FRvnwqx1l1k0rfvbMVgJO9szzT9WAIMQmf357/PAkDzJFAQ0O1vvVo/t8M
rDgtYy+PQB3QaBDyIb1TOBgPcGpM07GTqIJs1h8E+DLoM/UqhXWi4+1FkLlV3Orr/bUnQEpq
7rYwq0kOim3cb0tCR0UMoeXGRSfRKay3vttBW2UsvMcKh7v+/v9y/hmGD+0Z2PYQZHrD4WJx
mM4tPGSIUZosxlEM6Bw+ys8blCMVG6mV6jJnu1q+4ZMSk7tTmO2yK0dlUAwXMBcVwYFFIVtK
OPIDTYI/zz3ktl9p2jD0njAk7byZUMY9mxvSCAn1QhQuUELB0tFJy6tuT9pz+/ozHLujUfls
2Dcpb08ditkG/PHhgbMtBMXdgchnTSp7bEi68Fode6lS8ff85or7V3GDhnAotcGa+PjlQV+S
vSUrY0wrwMBDWn9N9yhyrnRdeRSG8jE7487BUv4WMtrwKwrnppxeqEa9M/UjuUpNA5uxwyfN
700NmCmCZd7c6m3XQRoQkTyQkY4UqTWkntA+mi11Ow2DjmcOxe3ly3vXp79uPJEbT09c1uXD
rPLsTVnBjWomUewYJ/K4V/tbO6Oi/nZyjMzKaz8ublzwIX86SJldGL7qFTBsX5kVMGYQZJ3n
hy9nhYdbHg21ATr7v8gCJ3Q2nZvB9BNakOQfpXbbDtVrxNMjCoaYe7zVa8RR7Bgn8vTC8QE1
XINlwCkANFj8EoYMxMHOEBdXMIT/3WBi/0/zTLRfBiZrWcw7q8qaoTo08adRDrCFtJWgQwEA
pMOHfR1OqX8Jvj6yVLK8e6htQ+PX+URkuGbSd4+ZjsKiGDD3w7e12cpL9tOpqMpbBIhHUkn5
qtTvSdHGEtGfKU2rB78aAc7ehkHadXBzfk2SnyYtHnSYIbqCQfjn/h7LW7Vr5ZDlf97zXFun
ykmURHUgXwqybihgnMABNkIGccea/bLc3HacUEHCQqD43JqL2u2x1m2ZAV7phtnzbHlyx5KL
1FMp2WvHudq7Wt6RPwEJw4Z3GtIzrdfM0Q0jb7b6Yx7uC3wVnzTpw/4/lvF2xwLvJ3t9xDau
NdLg9dG8MJQ9djVMKH/V4qYIJ5Y+X9ff3BzlqF6eH3Beb2JhQaKcAOfALY+hpN7+wBSErsWI
2WR1RgZRb2B5BO4nyp/7B//6NgpxGolc26Wz1Ub63QW2F9zTiM0+wD4aL6toRlE79G+BNPji
988Rtz/emzH1rPXOfRltxhd4BF9gdfdQqI6/fn1+WNWCR3NYznuyh4DxPDcwOIU6602GW4yv
faAZ5YBktLjf5NoyxpwffUMSvg41Tj1GOh8cklxx7RuTLOIQTYvFThOksOaATaWAtVevU7sJ
4i8gBDGkKn+PQyzQloUIjPKOxzLEnm8THiB9ZEP8Hs8IvWIfa7j6N5oM4xpe2Ul8vRdayQDs
Rk3nXtMmdLcALspehqzDBIyJpSmx2Sl01+gTFH/LklNxMT/PODfzQ/pux3sbvgF9NSQVcSoi
zYRRyeyX7oLzJrP2fk0ImQfZd9OvbquKmMilWkCjcs0u5ytAmdzAd/JXR0teGIqXAcN3wMqi
dUiGLd6Mgj/q9d3Nkuqvc7a8XNAiY9EvYCPjA7/koDEDWkRugbE6zXl8hK+aEz3SJwMZLuTB
cNKQGUse8vaUbR3uxcj6bWI55X5XvZtuT7ZtAJUdfIC3bP+JRnpjOPekey2yQutl4WOt/I5U
hw+WtWbBYEaitVQHK+pcKa4ELXfwHn1O0iJnLKxw948nCy0aPFU6dDiRkESxTvhwlEfsqloI
r6r5iHJ3SVsOqqUGAldZMF9lVITQzAT053aVw39E3+PIgnuQbvOgb+rlvX6XZKEsSNMS0yLf
E32uVp6KuwrAIB3zsVBBKWXJ+qTdPPWWDbfo2rQJRnnWqJrK7D5BCeo2+T7ugG/hFMqpwMUY
BJt9fykUv8xyfML4+pa6Wzu4t1wwNbbqvWrlWekheQ7odA3KK7ZnIFPAS2jQBEbb4L9RUcob
94aPcKZbYljfZssaBNO/fEtivXYPOYPTdho1vQFPgme3XE2gR04vtX9dsTlqZjH623HQCZxg
RyO2cU14us3oIW8PR7rsxHRjY2A2L+H3nGMiNjz22Pga3sw6lsOB7gyiBfC2k79lgb15Vo/c
xfhp6a3XMOA9BxuFXigdM+4DuwiQayKhZSIqMRb4TQNbQKb1ENsUrAjIcE8ZXcLadFXQBtJn
aK3HpLt+eooXzkEI2epUdF632lMkC2yw9PgWBC1ZxsoHNoDNnQDWMHEcG5y03n4wGxF3zB/c
H50U2CHFjpsbcl1CsHmjUwKgOW47h+z15KP5VOn/dugP0qOV4WMhe37EIToaUbCJwwe7WBpP
w/WNwM2lTIaxLo0819GrXHIJ1tjcNQt3A4HJQm082Zg9XA49haUKe38PWWTqr/UzYpTjrb4W
E+grIa8gP+9EINHx7abMaKxFXJH5nAUUK6o6lH6GHwXljnJaHjQEn4DxYQ4leO8ytoISJWNE
lzzwh7HH5nL1zhB13ihg9wia2hnQiqMYlJJD/hDFcQoZ94HoK1yVmGXB07nWJxuzyz6L87w+
e22zznkfgvMw0WnWkfJpHTDJf8CvYmd2CjVgOdQvu15dwJC3q5FwhThxBJgQxmzoHkZlkkqx
C8hMYaZG7MBfKaIuK+Dt8jXJU4PO31QvujVo6isZwoOJwAMKFxi3sgMnxb6u1IZrB+m/IyVP
v0ntgiRRk5OzGDNXhq8s/hgf4JasmolOEDeeIttmPQuQRctB58yUWMxcbmeyxDF/18o4nTrU
0H1Z+9ME7EP88o+9AWXw+1RFC8pqwalwo0V/7PKG1vyHEhHIL5a5ZQxSRxvupmkHqMaV0zu5
b8Sx6wKzm20PoZnMgOuVdGyHiSRppP7QA951Fqz62Df//4OAqm4o+aU0RaAEMYjmCJI2M2Zf
JwM2/cssdUWoirv8SOluSO4lENTmHEyFzikjf7XOf1TpluLi4qcKiCkNk1Eo6yrqBlGpW9Gc
HdyAPnaG8aXR0xAlmUPx3n/APHw3jip9EVlk3TymbRLsWEZ1vjpY033FHiEqyAekEps47BEP
fgnPh8npWUVajgUczIyaECz/7aiTVVDH+W0T1w9p+OdzrD/qb5PkKkQjQBeNROXzcI7j4LLC
6LTaIvJjG3mHtcLajs6cS3WSgR1yMRYvUYlDR4JaYT3XIqxCLTHIyhHuOE4S6ABpqAc3BcFo
427vAVXwcWqJArXojYBYUJ2gEGcxFlFfTDWT9BQFHAFsdqn1Id+ZBjmJZviHdgpEJ60mZN+X
KOG2gcM0Ok4C8qdhLQCV4PLsqYiZ9ApDXEuHwbJvMOcdjmRQKQbm4FlwrIiVVFcBbuwi3KnM
VYzOpne2Zh3m+0QkVdnlDbaJpcD/PnQTbYvD2QE1j7uWaaHI8DYQNzPwY4PiwR6yr2MTOiPX
25nYLFaPGlo0oX78DCKjlKQOAzqTAnVUcGnMeuHIPprDONuX44eLzrZjsVUiktt7mxTwe6hS
Gyysdw7c4e94Tv1Ri+xmLoMJGqERIoZLB7RQ9X0aXyr6tt4VYFi4HeFSG5d8tlA5Y7Rv2RbT
RUlAvTWkjVJsZ8OhrahsGDDxYUxg5ld1XTeEoVe6swg3g1fbK9k7xvC3OF0SbI8lmQ5fL1GN
mVWJ8TJhX3V1ZRXgm6LUiSx2XiPPWfqoZQHp+nwN51yzf4umWI5nmdtAfi1/rWoLwGCFXXTx
+ohJt4LDGxegWf+pWG5/gq1qycBg/110QfqIJLeCRuiJFuxuNyFDxiWJH9y3qFGLkzPjqz3y
XV9N+izDXhbi6FQRLrl9qwIwlbX4ciSo0LJJ0AMjKWXA2HEQy+K8UUQ8ZgYOE4HEgRtTQhoW
7KJwWdF5f4jn8SF4CWyHkV4Y6tHbbYmNMPdRjmRx4x+vjTA9MjBCawNd1ZHA5azCW2kBPhaq
dOmsrJtbzEMbj7a2yunJ4Wu00SdND8Chvchm1fvTTtNUw5unZR/bsIllQvtqdtvYrXD/dhza
r/Wt5W4sWk/Sam4I7+rsbhipQdH7szQc2llnwCd2dXqDKNwcbzG4xQZN4wvV2/NcjwLr4kYP
YmMQjor9wzDyRx/gGXUWzdx1MOhAX/SRV4SIT6JgtwA5dewBGXV+vQvAkRjMY7829Rwif+8O
GabegKYQYOEmCbrdWRvCvV/JvfI4wkrLEp4h8Q//5PCsnUikaFsKOov9RdSqcbHaQ3JeHj9t
A2Hj9lS2z1OX6eL6HCr/J/2/5VJK5XUE0IjlindBf/oEjdZc08ky4ysHEdG9twBDQGryudha
6GaI9vH04rAtKQQC671kNX1E+aq1WwXlCXM=

/
  CREATE OR REPLACE PACKAGE BODY "PCKG_GUI" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
94633 9a69
NeK9Y+OgPGJsbqASdJdXWMqaD80wg83tOMeG36fR5D9Mc565O+zxIQpXn0mCu2gIV1ygogX8
6BYCGmgIc1HAJUGhcp+DJrn/iske+c6ZqTa9qaa9yMhiBa6xfmET4cs1psGmwULLy9/u5C4w
iETBHpUupZ3fTnicmNnNm6rwFX6OyCQT9QDQbwUhnsKyczi/7V8ZueJRuPNjmFxTWRvMwL66
0Z/ZFMq177WcgJzMl/yfc1hEBV9aPvY5rzJ1/2QV0o0BQ+n1vO3YJ5yW+R6TuH6TtWb/v5NB
YO4nnEYKTYkhcutTz88U5JIH5Mm2rec/7SIgWmxySs5OIpsRlJB6kmhchxxBxvdhAoGW4mV4
6jg8L8YcMzqDQlo59ZAZfbx1tYtmeJI4WLuLbVUjE7eq67UbHjojx7YUBT2+gV/wJfWNTN8C
V/9MZsm8h6Jq/baWtxEw9vEe4MV0H/WhBV76/JY+KAN4lUYsgxvgr+KcbREt2p2IVtWHB21V
rFm8r/F9/gGY4KBb/6wJWkUu8WwtlaIkwq/X1QGHRtl10m6u99tR0Ujk38BYVgPVD9ca9nGr
TBrMnw0MEF8hLIYCxjn/sQgjE+zpLljYASv0dt61w52bnUe/9e0XktW89bzcwnpZm/L5XXKa
3B3Cd0qyE6wIJsWbe/IDQ3ve80KbweZd+rMtae1IXYFKEz4mhOWSZPnSwSkmw0XC6W9j1dc8
2SKnnk/rMtw7OMVxu9DS8Z1zbcN62YwuC3fZBre3huqa8mNqVxli/ynRfeBMjckTUy40vHqX
v+Tp4GyHNyEKP+m+qlGEuFaUGdNiyu/EBaIpevKb4NJ94DS9XiXErYi07zPqm+J1hdcxUVlD
S59xNC6adkyK0e/CzpcNG4alksKnqvP/TjKXD4JBRIYPICRV+cL4sc0HVfjQD9Trjx6PXVSa
Yc+kgN51R4wADTvxZN4rsw5O40ffhCy3sfoo+e9Xf7IGosX6Iay7xx7FBitgHJY4EuY/WuKG
oXNGIZATl3BzyXqNJ1yY90WrqqJvCoFKLiTu7V6+Iw2yJgpOgAOPCrYJVArzNCGqfJlKQ1FZ
/XVcV8u85ZyaLWkR89eGfDu/N5taUCSTjoDHe1I6v0dOLlcfGzmUoSMXLVejO0pIhU+P/Pw9
xKpMYrXsAYYm4Jz6VqP22KkJ/GZMZOy3f3Agp2287Rgl4Bk88OBgbc8yc6/XlahZbzXMI7zn
/9tIlHsHKs5Rn43/rLYpxOTF8qtRnL1S2ZsGhFgIG+iRFXavX36TK+8KAeUhzvVtgsJVsC0f
XVhMQsKaLR/cPOwhmmKb90PfnzhMp1roezjqMPMBTvW+a9+VO15NHFRhSZJBn9nDXuxZgXmJ
951ZRjI/dxtZhzS6bcl4WGCydztpdru+qXBRYJ8/cfYtHuJBT1yrwu8AqomiJF0aE7AYnm/a
QT0nWE/ycvqi7/w+qzNCd26k2+YUkQeAsjVTmFQgt+nEy9UM2+pJsNdmJaP3eXIDepCRmsbS
OlZXqLW3v/1APax3DrV3p7acAlLCy30fNoqZrFKlqrUgMe3s/6y9rL2svSPntttf2ey0yCHH
xMVkHJrlS+jrsB6O30TfRN9D93meWJHmPgYSIY/xAWDfgr7k17L271M/ZE0exi1PLSVGl8SM
ueu+j+vMgHJdvlI4MyIFvjEX2urP32bPWOK3lER/4dVZZAiAOmC9QbUeWKX7pdJw0zjTT/Gw
FyHASUeFXMgNSdrq+gW3JgoF2vz03CaJON6a5Qd8UnxSfFKuPNsmfTQca+pf7nj1xsSet3kE
W8E4Ip0l77X4r/5smSes/lXK+dF1nc53pPh3TP2Lu5GTmEdjs5EjZRPtWRcsTil+5lXXTQo+
Mt+w7VknJAOD3qP4deqAtvb2yTt0Y7vmn8mxr9Kj7A94tn5lanuHr0diVKWZO58VrBcErJ5F
ytaErVt1AHUAde2wfjNZcUC3RBIyVG9HQZqpc6xzrHMj5TMMiy7ymi6gLvyvbwCDMjjzMVMx
29lC87RTcSHvqxdRrq2y+Z9gatHNzSYEDNndelj5fyAr/SRaf5fk0HascofKhUiElLxjTeHw
mJaEwrprRn6Y7FBQ22lKLGP7GGKpN6s9INCrRsnbyn4ORCSKix6RvC7rFjgXAWVnRFTHS4tw
1whElPXIXKpRp6B6II5p+AtLTSre6Wi7z9Pkf3U5ThSx61xAC1kjBuXI3MllPm+RZIEAgSPt
flhU5GfuSuUZ35mLZLJvkZDIeHaNY/8Rvpss77fXY+mFv1DWiXdwnE8hPLb2op+hv2LzxrL8
mXfqpeS0cyRe1pN26NJ5lo3v7HLdcW8PId9vSSW2RVk2mpCznevNfDrqOR6eHp4ektM7HrVy
YYzScb7+1031VHMmMSuMRDtKN+zxY1DmaGa12p9LSy1LLZZo1PkCzXC+VaXtB1yCMHqVTIpG
p/NWHvqOPNM80zybbKPZtS47Q0OfiIlYRqzDtkWjk/ICCyUT8kyHZpgO+biR6dUmlgRqdq92
r3YAW8f1wHHMmiG190LZb8nM86JjdRqPICE5qSZCfMvEOiOUi9k6V+PgCWt0DywDyUaTpdYZ
qaGIczSj0WwOa4Jcy99xS7hLuHLZFS3kcHo9F7g/Cw0xZU+Qw/FAIyrqMW5X4wV1zu0Vunv/
rhWRr5GvkQAutwGgk1YtlZJVmCidW7U0tQgDJ8Ih9AttkdB7amCGlNnxm9LI99/MtE04JRur
+pfEPLrbvZkh17EeV9pFyqQhmpCAOgUW8hsxHoxXR5tVn152NF33GDrAlPONo3nor+oYtIoy
nxTJaHT5VJf+kCL1e3PcY3q04jMatNkcTi5+MczwIgkFeUbvnKHTY3Tw2Ax/d1JY9zvHYJ0w
GtZ2QqzOj18ynrWwkyN4Gt5tASUqF5ioAFfzBDo+Jsx62FTKPfn17xPyAt58IOILRXr6IVx0
LZ5FY0dNpJAFOdhYVIItySLXefkKJI3dJ/f7ENhWZJJH4WESqkR5O7fYu2xfnT+VVPw2BXYO
NZzuJyh9F5RgQbKQjFjHgsDLG/+V3TETeFuGixGDcbK6bZPHgic8GzsFDjIEjP9Pxg2jA+S4
MRvslpan6FpnLGSKS8lhYVksoyDn2MbJNhPzfmBBisk2kp4QArwcoLz8+VVow8QU7d59UoDx
EyImqH4J5tIuyYJQXVdY/R9eC3nJii5fO0It32LcyZXXGgTX9G0+LSHvTBsaXDoH5LR5ZVZH
6QcmS4K25fRQbAcpd9Lq0Iwpn6EPDsFQx32+TcH1+nhxoYX35nMC1NKWbRYonFJAmfANrFJr
f9EhSB/HZx+rH6crL7dgH1FKErwsMiwfGoOayJe103K/Tnns92LW5IA6n2pcXyXBEWRQbpa0
io4g4ndUdodVcFJ3g1GT84cZS1ZFI2jPEfxcb6I7SRO9JkHgSXfsjX/ImKHfvUXJGCMsoE0Q
wWJLFVlLRVthmulL7BNwUr4mndkuuo3BZHo8rCtH60MnJVYhbE97QdwFjqGWYBazZtbVjZNg
k1HpQFeG18BGCTmTwsL8bKEBdMDFPT1tjyTqDfAfUIdgQr5h46+jHrIIVvYeEi3cgDnhRXb6
Y68AWEQVadBHvJRzketyTjIEtnIb7Et0nz2zlz6QEDVzIAX8HvUcKgJarmLpTGT0b03xGgdK
T6ILqgb9gWoYsKdRMF9ePmo79tm4Fmtlc7DNgEsUSVyGMZ1WCkHGHjoTRUg6rtmX+uxTBfMp
2KOppYUJWrz/9CwrKxe1BIgG7xuBd6oQd3/4bAAwEHcmngkdHqkqbRVcdIx1MuhuJIbFHMjO
8UySJWJcJY5cYQKrMrw1JcpDRG+DAVWWAoeII7AuKXuaaflc8wB+IUJN4ITok+mYElGFDBrS
Z22Ln/JWXOrzMeVQkGVEeStdn/y+hzO9Q60BoSONIBaqLdIybrEftaBPVSAwFt/BzpUkSBeS
rRGKb4Pl5CaEJylKhGEnkcT3RpGd89vZePefJH0WEyCl9awC1w8oJvXZF/GjSFsSWkP9Z7eR
ONZ9FpDNffXgOityzIft+ne9jcQO8X3Z9e1VNsF4Bhmug0Mp/sce9TV2fC3swJTsprjI194N
/okgGXc5xSEWKEvncPPdZhHiLemlpkf7R/tH+6xbDsFQTpwfelBdR9ItHYrOOATGEB1bkoCy
dJ6ItK40qbFw+2T34RlqNnqV54psZ92E9anQUKYoUvuHrOF08/tZxywqFKkFSgdKWy+ddvv7
W/0vqeOmojbKZo8x6TbjGhZzSADve7brN18jJRqC9EV8pxbRd8q8Bs72i2We/ieONFgt6Mgp
Y2PwG6cBbxHzM2RqCCFNLA08w1g2K+rPtJMTA/1cLuscCuVcCJnYnvjq9kIGF0Oz8vl67jG3
ob9VB8tOLjc6jO3kzEz5KWIsiTwvq5lxtmdJqdyP7N0qr3bddqn24bE2AAdBu/D2Ble4eLPD
Nm4GyPwiQrCmB8NSWjJPz3evXgkB2NpUPksJcGPd8jeN4dVEK57YdzjCCeFVqG4dlEqKiG3q
x4qYglLAN9LhKUQlmX0fUJbIh8rtcMtwy2cjN9KsQYRyc7eHAm3JrxKNTTGmi/bK/ipuc4Pv
tUNP+05yN80HRE761s3QvU6VAkILas8IOPkELdbB2zDxYkvgcJV6LeBlC0TyvYnTFmxp8g6J
y+MJ4Jw46jkzVldYrBzhADYj51fzuGZQhA4HcMtwy2coNxysQYRy/mcojUrqeDXDG/4sFSiy
jAc5A4T47wc0x4QZJmvtfIQc9GvtCOZBEagP2MhJCYX9SfW0iS+dyTZfLwSofOZwRt3nN/Ph
79JoiKhDyPOaNqlv4WI2o+fOL6WoUOYOAnDLcMtnmTdvrEGEcnPr5mNyAa+e6e4GyZxk3vA1
gAdAToQ/WlEAgun4a20zaojN0Feb1xzNnOab+u9CbLfPZfI/3mOw3WK9p5k2tucbL1nKdWd8
N3Dhr9LYvRvvHhR2NXvfbwagd53WnOGWRIeeppSmxaUJj2Nwy3DL3Qw3nKxBhHL+2Qy9DnnV
rZWQcrxuw6rFJ2+OS+cHG0wny4/iM4STQgHlNNPDGUI+rvV3h1QWKF23KP/6HT1dAjhlLwxx
wSz0XAZkqhFlJpJ+fKGuN6Hx6lsCoew0e/kzll58rnBBQYhOw3IjCcSSxu/xXkORtHgQPWAs
k2VpCHtxiqMMfiVDe0yLeNThTj3ggFzXaEf1vO8ZgLq/oHzp00gZg0/NNKfdlnUPoBmHh2yR
+oKqinv6vzjATt8hnRvwdcQn5ABfoXn8SKAf9rAfgbGkvUQZQNnPoUeDXCdWwsrLKILxYgEV
1xuH8UFjuarZpp98JggeOswwvNwxWrnwPW2afhSM6Q8FYB6hAXJU79dO52gFDO4Z0iXFCnI5
TJiXqU0d4Fvby6Kk43t1HXUdLzLK/A7BUMdkoqT+L9nFeVakcwwpaY2wqDlPqE5S49hpG299
raJA0LcR+CIYYbADERJ7X2HG6xEZ0IzNOnrssR3eP64aQgDxizpZ7PTafqNmchRRpAcwlAKZ
4DQr7mVSDvuBLFAuWysuPpOwy5Jk7TDWux7R0bPPzZX9iocSCDljsG8fl5zoh7n9gCLcgMaU
lWpXGWL/KWW4LeIYIIsg0b/9wtQcQ9qHXNjb1WkWDLRCwkSiyk6RFa7iM7GCQ6+qNknony4a
8X4rmw0ejs8GTo+2KKkdjo7ww9G1QxPhjqHd3xhkuLqjvTTgZFage0cwCi6VwR58G9HcIfph
CqEJAbFBJa1vd7VhO7zcwcxe49J3CXeB7EcyXPHSUAi3nx6VZrzMJNgwJz7ligzRajv22evq
5gGSrgXQcJwGK/AXtcLYIxxkwSD8RUMkYtVJ9ga/gBoDJ/sV7wyoOntJy5OTkHOMzC1dHhtm
LBlrskhoYSXdeziM6Tjgyp5xWoUIVFVz+lBrj0atjUySJWJcJY5cYQKrMrw1JcpDRG+DAVWW
AoeII7AuKXuaaflc8wB+ITr6hUBZAxif/jZeCQ1boyHEXuAmRRiFKwK5iT4RA2bEXnKBwq4W
vT4MJQrPJMIZQVMgovODdtd5mzphxvUSTjr4XTP9z4J4JjXqKaGAtYlAgzxgA6hhjT51+XAb
dfyTyOKauZ4Hz2WyPLHbxHV+FSEPCTDfV533CuJeBlglsH5dPD5tcT4cCcO/qxr0LgrNsBSQ
0O3oo9BYPN9VSrArgQlvlsqQ0yS3YdCk4F1PluuBn4QSurTU7HjYPbQ24PMTUwc523xlZZjc
hxlpeGSwTxek7e4GVrqtR+b4rv7k6OUF/rVmItz4qrYszAIRTffxwsUy85TCZNFq1D/g5K1t
wBjXLQ7+fgnM043qzzOQ4xnX4YP8fO1o4lEUcpfhm8RZ/vM6yOKGznpuncxF5rYvs21JDWby
7duiZ/pBjPFMyGvQLKH62Aa9VoHBPYwp0Ewa+6Bbg4auEsOnGYUfMmWB9ZYAdbAs/yUS7rH+
2eK7ArqamQO8eIdVggq86txV74y5t67+hegSQyWYWPXJPkHR0P/sKG9VSulbYsujdqDO72wB
lFq7LCcw/geMQvHQo3039Glk5SpJ3BAivfkEWR1MgdzlLdMUONvLqKOy9NPJVWdPLHbUM9lF
zo8LeoIq+feBQYr/9V1W2GfuBdWetHsoNec/BIF2RDvLO6f6ouy6XoB5Fhe3HqUpvEdadLev
5DVTFwhgDO6ZRxXw2NGw71CZDh9nlqmHpu2mbB3tpiP7gx0jr9sfpVVR163dVfqoS5nguB/O
vaW2j0lBpCSvfteMpbYn7zmkMwWQqRpLbD5TLiCfsleyuKuPITRSq3GzTbEVtS3E9U9tAaeW
tmy0EHdS1GYDIl0Ub+gUNb/ukZC7OsmgUa1dTNSK9JtbORc7xkU2fLwcmIJSFPMuy1MfuJaP
h93taWXd7akSawCpEvAw1CYdg/ieEZZQhw7tZxIsps0QMucRuwo4EbvVDu1nEjcz4c1Eg5mg
v9ARlo+H3e2pEvv+4bkC8fu5RGiZzfto9qYhblESnfsZmTQfMJalGVvdEp2tNjT+Ezgwu3jd
EgWlh6a8ps/7ziL23cRFsb5FZry0nWGPnWz5J9uH87uepo4ZbKZppg5pZaYOpmdrAFBB+aZ9
eJAI4nr0sUvb+h33cu4OQxzzDLW4Y6rYwCRnY66JwKovY5bPJf1XKZlY0lsMYXDxjfkkq8qT
DQ5bq5M9RI70foWpb/tiIo1+hekZd4gMzRPRiE18maPCZm0xcUzCBW9C9ALEVFxS2aB2EfEs
xCv8T/G0bIG4co5q7Qm9KFMvCVrwup0Kf37s0UGrIIP9QbIfFn9xuA7bZ/Q304T6qdMdbEAz
etqJVALcg6gGm8W8N/PC1h2RF2OG27NKHOFAB8a5KnufLK8t+OPwVeoR2JqFtBA51JJtbYEE
bx6WxTwXaX5b+XGrH3LnoO82TN8V+0Y8EIR4y0xZAMmGjG5+AUq0D/oh4ANktpxIDWWQfA2v
8fUGPTn2s71x/c01SUA7XhJMgunty6N3o6+b2+kaF2fi1X4ZKHhbuMuP5L3hwc0YJ/mra4kc
RsEY2QYS2aqKtrDB87zv6z+gSvh5PiVYBjgbNcZiAfFMRS5NBVf57ELQXbPF5DciR+EzugxV
V0ebVZ8D504zYeyzuYjrqAlNQYKRifFkagghTSwyd5TGvuViIqBNrhftw7E0Mgr8LaGjXOC1
/E33VcgxoPEkXjDfq2B+9feIyzZAKt6z0E3n9LVU1dh6T97GyD9YOQibLhoNjCvTHo866Fev
w6PZBraiSQohWDzC2/rlt0kEYtVYPaLDAlKCJ2zpKzVciZF3Lpvbre8E6u8twyjrPlRsS/Jw
jd3FN1ys8Tdc4Qo2zfsKGgLm/TQlXI7xpGzHV31KxxW1wj2vavI4mJlVF/tiD49VmDIVr/b2
5LriqlKzhGf7yqJtkKJ1zD7RjzpnYZeZhO4HbqUVDFRp07ytNv2rNViMOTk12hNE02sIE0Th
VR1GufCEHRgcNunHhcwksl+IORUYHOxETnxtGM2e/a/hna1FcMCL6rPk17nNUY5XJh4u9LEj
R58hkZzIX9YWGwnU2+XwWPt4ozzT2Qm05cp3sNWPu9XHNEo+G6GOF7wuXsJfUAGo/VszofV3
JFH+0ZYfRF1QY2cyiiGZeeLZWdayk0GbkI4ELos6Rc9eDeNf7KgxDVBbpASc7kJQNcX55zj6
5O1Efmyfkoj4kbD7RVMRLKgpv3T3nKhmLCN75mXzMAym0qZ9+1DW8ftQHQ5bzUL7qUEGWTJw
QjHk5d2bzg+DSzRFX2yJYJcor5vbkt2bqUMxcEIKuFj1hjCBWUgGMIEgJ8VUpkJysoW2izUM
Fmscl4wghp1xB38psG5g6DmaDfsoOU7emVdTqbIJTF5waXPeZhrvZESyDtwlLx3Ld7IloQrW
pOFdA9lPG/8LmWqTZ7ib/Bj7uCymHYU5frJKmUsqcPbdPA6R3TypOzUSQYhh1HNPBsdfUIMu
K+b2Qw+jaw3lX2zC6ZcorDxGkqk8pjsxZ/bPSqPd9j1+PN32PSCuqFnifnEQwGnHUGT386kj
1NJj8Iy70piMPNDkQJa3qYFA3SOB5B5fcobWKl6OoDkA/wHd1hYszPInYoZTvgKe2ISn5d+e
OAyCDVzrtRE0vGJLod6ec1JkO8cndEyALtlubC+OgB+t2hC6a16XyjnAD38t5VDhUCY1GgNS
Jpqg7uuPbkH6AOq80llz9Zhwl5saSAj6ZWbZSlI8EBI8cWnpkjWHu7UjG01NwokDmuUsllHP
PwE8yzlE8jN51NeJfXtWhoUWhigClv1ksf3zCzRNR0z7XN8q6XMUOq+qWgVH1KJIz6CboibR
ynT5kmzFJLpt+9QeR2gXBoVFdWQHKocuascJ/JLgWLOEl20IWpnrksRW8P7digAXA0knQtXz
YwUM4chbg/tnHKl6pkIWiKZCpptQQcEohZz43ZvH0vNkBdesR1h7W8GpX4XWwqgoLpGKSRI7
sEcNP8I8kpdU2plG5AGgv/g96MTE0k0u5PwWTWW3eytKak4Wb05/2uH5SIWqSV1kxW2pOpyb
4voVDXFJG0JJqtFdkHakHs7hpI+7rNKYhOQbfiRVG47ZaTVzexKazJPmNU7ZsAnFo+6S3yZz
ev7s412OoTnXMc/0CzQKm4TyzeUlYPz84/+gzkHFFw6SiMy8LrZYT9gkhq5DFiU2GGX3zApY
UFeEwIZmQxeBWe/j3m7ML3NclKJP9Kx1myq+WAkvcw3xZ7VSLy3rPa4KFu1fMHHoULlgnpd5
YVnR+rUPfmpTOFR1ZcWtHNnSqT2dsJv5x5SLTgpNlTfVwErx3omZ+mkxEZD3JgP0akIh92D3
ySFo1Agw1MrU3vc69ddwj0V6EA6Ow1XZNJh52UZWFb5oW/COnMAKCotZgC6eShuEGmarmpWC
KvKaAf6BO5pWud0MmAx77Kxa+gGiC6PHwrVPhYY1/qTA4LjCLsW/7+9SNb3Bd/acR7Y+k7pi
JriCVVdi2HIQDN8kfrGgVP9qz5BvXFopCCdWjWbL20rNdBRY+z4XQc1DNrDrBSGQQtBKxoa5
Y43oMc3yjwqJScDekuDf3D1noYMJyp3f7O60YKOYv/0y7Mn4P6M7/m39q7rSriaQtpP96Vw4
I4WBSJsEhnsSGvcjUAhYQZcjQu0KM+FxKvSH/MLnmUEYkaLO6/fUPr1dURVReGV7LDIp/CmF
iuDnAjrr9zGNL/JOsO9OvBOcp0Hc9y8fMLIWRGmeDo4OkQ6OZz5nEkF/Yw5mT7B2wz0PA85W
5wIAVRh9+GCimsSouYYboqrEyrkeOaKlgGLAX8SknpePOudAVQEHFfgfy3ikJ+yaELNrZwtL
+NL8BoNtsgVteA6VuQYlREDNlf3+b2EfIHErTW+7e/cGMKtjsaGOXTCv7Teuuxndc0xdsZ7K
xOglf0sRJ9zQOntf9N1axySDscsfGvr+eaFGSeJo4RXnRvPn7y9gFogvYMpfUEGcP0OnlBVU
C/eRmpofh4rQYsvhbwDdWSJ8Gyimtx/1JkotxZLClnSD51LiNr6EoIJlhqce9ViaFnkG0DtD
R+ptpM2o6cuqfrV5KW5ETra2qBCjgbT52U2qo+kL/hVwFxWVfWq47lj1oZJpdL8rTBPiWPLL
51cy+WGc6qGJARgO/L5zNlRJOtFZSBlAm8G9cjsBXMxywIwaTRf9rThZGezNJRbZaiGc7Gy1
XQ4jVvLsr1IYuT0kVAwS/dFObC0p6iYUCj9+Yt7zApnJDo7MFcf2k4FDm6D41czA5FPNFENJ
Pomho0T1urKG352jsHGNHqiR0DtjhQeCxT5ccFPwX2sXIX4E+we3iBpzzcZlz26XuKY0kK9I
6/df1FK9c+ChHj3Eg8R23HzR92JbtuWNLbM53lIa084dLSMNyt/lDPZmO/8sWk9pZNb8SYUM
qPis/PfS+377d3b28zxnPCOSli1RS30+lI0y0DziLCYdVDuf8PuJp9oi4+RrxUCNs//WJ2OG
ZnfrfIH8PE2WlriKhM623o4CXC6I6QFMCx2TJLYChQcwX9Wrjd0shScbO+A1HmZgAoXQPdIL
PZtjFkDCP5TszCSOlecep5s1lyXpAnfQFF7KVlTC5zL6xVfl/DEmR9KJ1Y2Dy0It4LnvqlH/
lu5d9973Bk4MAMDD0VmrsrY8G99mik87sI3smSVerSaiq1VOdQkBi3I2E7tDqfHAwxrNynKF
oD0STIgjodOqEZboo56if+Rr7QQ4oci82COKpTh+3si8GCItH8pW81GJki3tFt4mLwL0JFP0
C4OMGFEopCJLo3sau4aupDkPVDUaCGRPBZkKK9PM06oRlmCTzKI4m67Lt15xk5GVCqpLH0nY
fFFLki3tFlJj8wG9cs0CPdVKFuUj/N8u/bAWOoQH91Yryt42Me8S8yjP37cTOszEZGKTxwqb
aN+6lItvtOJsjY0N9ucqsCts9rfeXHEhGDyUfmi6MfwxMnB5FdiXx4QBXFTfoqcDY98qK5Qn
x+BccUsEK0PVA3AAad+wnkTtxMUnqrRYCuiNzXAG+LtkifzcE8Vj4uvc8nlhBYuheQ2B6KEm
fVOuCSfaIF8hgTu/hCfZkJ9n/FqtuUKJ/Nz9pGNI0BAuC0DaSJGJkkoSH2NhHkjpJrlhhLNH
Hx559IO7M5jzY8mARTYqe0o40JwFQ7MdQ8wOssKFDg4xuc5ZT8pXj/KLNpWdnwC4h2Q5+HJY
peNCpFlIvHn9fnhuzbJQpjZhsktV22F4Z5liVNDWgTxTCwSOaRUjdH4zg81kPBWIYbvEmq/E
eBWmRrTfapWCfUjj4WtTIRVKWfaky7LO4ACrYdFZB/InOP32O6D+X4MTa/vPfgVwHnkNeN3n
lDHfatfQHnxeI8j6P69L/igF/VECsH4TOLsyYXjmKH4xYRWvWHkgQMvTA3lGDQdoeUsjG4fC
gUXaoKIC7tgNapfQqsA+TycUNRVEJ5adMzHpKDTSsOm7VDMy9nJcwGz2xmkyTpGwLvWvFAfy
uNAnFweY0WrCw7IZYHKssPcE2WorzvPfndDCMRB9pLmMihEs3rWS59o8xjGkIhU/pbMzP9Cg
6xKJkFWGfl0cC8Ez5xINW5pPqLOGtgzSVyOnWy3QUi/9Wy1SL/1bLWuRV+Pw1rRQHHbbSHZj
e81Hm86OcnC77wOMsaBKh8d7I659fT4ThocJrQap7WYaAL/vKe7GDGgWLD318oNUE+gVeu8L
C+oLoqSErIAUMKKsgJa9HAWU1+Qq5iZzSW1+wboXVV192Nb6bjJQSgPcSrg8YH3XezHEWERc
3x6PDclMUgkDSKcnPDU+19jOT1hEk4IekSvJVSGF2G0DdTIvdAMr391miCa5Dtjs9InF0C++
CtdnxVSI6+IWFCJKFGmtT+7Id6Au5TDxZ7GXJUqt+rau332Rnjzbo0gyaYSUhXluDRQ6XUDF
3MJFeWUKJjAbVhdivpEeVh9aFJn54eREzpmlH2llpR+Plg4AWhS6N0afscPzLBeCj+XlOPVA
//OavVjSdhR0mNInqtKFIlTxEMhs+AZZ5AlJ+JFp5PM+HDqOqqAYrp+V8ZGtX5nCTQJOMIAr
1iKzsy9wEV9PnpdDJl7RLtPpP+E/i6bOWHNM3QH39AxHsT1Aa5xbbyh9PNH7p1zACeTNmNR3
xNihrmDR3tPL16TJPPY7vvZ9kmBoqRZYmlPyhkxa5NMGEYpdjnaxp6Kp7nLfa/Swalef2OqB
8ejMOJ8wELEZ3l5ovVsWLFe9Ds9nOmllZzqpm2sAUBzB2u593z2Lh1OErNIQpptn4PhlFnNa
iejZPQ8rAB/pI1EHDmv+Vq3KR8uxYt4tQ9Q7DGq7ccJAhKQ3UNbWZ7rRlN7O/O3iBPfk0twR
1gZXo1SiCu8duT6h+l3RtlbfXNS64hA+TiuGmclc1YPx1tlPfktve5UfxJFb7OyxVyzPG315
WP/gFYfNRs33u/YXT7vUelU76wkpG9bNHpgDHU46Qou0KHtM/PxtM/WfM+XDY/QFu7TXHMlf
yTVLtbyAJasoofamjmqZW2l0DgRnf4l0Z3+p4BFymYWTCx2ODPMGhMwGOC8t/AeYPBzj0buW
PAUSDsT+FrvtRjASX7sZurjESSKvH1iP9KGlYO92I5duqFJoJ4N2sufjykg2Up0OykhsIqPO
SRXET0LO38IGdwHIlIAZ8no32FfgGrXId1cBGj8ylhuZpb/Y6+fNxJ3usGOZkmBj1e7kFfBP
sd9CrDTpCAqo5FyEFYp8e4V3gl7rde/pKH2rcDgO9mexZ/pnsaniNzNnEkDofe5xLoBZtftp
Ktb6b4+5PMN1x1/kWYHCI/I+wZO1cHPu95KHHdITX/tRTv7TkJb4hhDmTkS/NKToL1GJAnvX
OrtJdg+z5w8tzirJYyFo0Z4PzlmQ/HiOOr02mh5bECj3/vAmxUBVeItRHjsZAIbNEjQtrYpB
Zs2Qaooue2VW1Blg6W6MHhLSPIr7YJFvir5kzeD8/eUYuJIVMOFBAruZMG+lVo+TFoiPk90D
UEGcUh3YeRYQiGIN9GqRcCWN7pPqepEJ/vG+AZ2+d/7xWRCWMXf+p9xVxyKB7RvD/nXGxhdm
LNBYzzTomy1H5f90/4ywK7DwBKe6kPRnrDLbi+/fmhr7Wkv5JWbS64G6UUQ4YHphxJFWk1HS
9RNpXvr5Ig8gt27Ys8cq3Jhft5RZReDev9s2eO/YbVNUbHlCgDm4rY8NfqQGTPtN4WlEDp5n
lPI5Z5SpxaBbCOI5F53v2r0xwuvt/Khn5YRljabMRFGeooHd81yvGXpIQLfC8x3CbrjzhZ/h
ooE3ZhX3uTZw/K+sJo4AV7CW1d8tMgUXNTRBnbPBtWkDso4NoIXejQlnR2CzQStnOdxjOeEi
RM+ezo6lPo9eFoiPXt2wUBzdsKtyGcUX3fv7TYePrsqH7TUevFLdUfZlZ9wd2M3vGps8QIVX
oOQ2LjQorZ4zp4zdipX43MzKPssma8Xxa6M7SRpKX8LSchdpKbL3PvzIu34573jHZcBLq+8S
hnBYVziRINJgp595kRdFyPA3FmMrbCwqlNblLWG7A0FiRZzykkj4YJihsDTi+D/ps1m03+n2
3EUiaN8I1rK4EnCtypLcQDE/W6phsfuV8PBTLfN1Iqa2cJLd0muR3dI3KYQSDgBhrRs2WZ1s
G5InPR2Vu0Ro/pX87YBJ+J5aM5TWioKKMDAaLbuPBjiKl2fmAQQHZYnf3m2yvKMA3FelPeWu
NqU9/PVGFoeiCCKYFofbwSKazmirnv0N8WGVsjCMYZDcE8itiIZ6g0NYOkg0fkHRAbRnTBfx
9l4auDiqiMcDnrelZVHaFUpwOAiYFn3c+H5obz5xv5QVRvs+4Qk2Guda8/I5WvPIZqBbOBWs
+GQodMkFxoez3QCEqfjGc8uyM6R27toh2L8wViAMS+UB15v/uMZFrCx3lmA8srYDbZwBLHdv
FB5s3Dzz4cDGquyPrsxlob8emZL3CNGHyb5x8TnNpG8Jwzq5VpnuFM4LyiM7AXd5hgpgn9xO
Te7VsSNn71RsY7i++LqfxROQ+ZBwjVn3ZIoFoNdB9e4EK5f8VA0dgXw8HqaEfn7WC9cWvivv
xx5TcUJZ3sMxSnlRV/HIVZEhCVJvX7WtQUpW8BlNCz6C+SKa6IobsM++GOOgPcmRF8XwldTb
K2IURyH/ZkfigFhMcjgziUs2piIwrqbOpqX7j9bx+48d3VvNQot/1n5tI4P0pc3/eBDQ5P4k
/CR9450HjHMiStISV5e7Q+eqql2uLNcr36lA9Ai9wrqiQlNfgoBaZP2zx6lOWoI0HBIgosYp
Is7SlW7xZPyJxnra7mGpkDay4SpWAfnu+U5VmC1dSyXvzRWdFpHHjo5E1vjQlZ4xpUaTLY/G
mm1P/Ur1eGix1bwWeuxkb2842kM3HsohAopGgIunWKyf5sJ7z53vPGobcFvLAJ8MuH3uUGpr
B/GvaweEKM1CvcsAUtyju4T6UVYLweHj3agm5EBjCP1uFSCqxJwwnb7b+DtsEr4t24Z5bBKY
Jtte/2APOqsAQyfSp7CzuJvI9s+LOoprQ+6Es4/1RnGBnphlbuCJJO343/HgwGXvpEMazICK
ZJHiLToxQuItPaX1HMchtJz/Tko5giVCpbMR1XtyZ/zYrOJYUYtbYhiaEBglgQQBnceJV1qt
inuJnD9KCZBOya3mJhcQG140P+w//sB/JeKTgWyzYmyD8az/iRLoupd1UTzJlVKFVpqUfWG+
R3txiqMMfiVDe0yLeNThTj3ggIGFaEf1vNlIwmG5cIQX5A0As949T89mYW9lef8YHzvEnOq9
kwvXLJjcm0x1aDSy12ShPm5Pi9SaanV3/59MlfFMRS5fneIVLH27i6e8spw68bTYCndUkfMC
mcn7updGEy5ZtuzCFnpOpis+soFsBrFOjKXPkML3IZqF/8R47NavlU+xHmE0bQgT8JH3ffaB
Y/o5LlghiS3K8CFy79zH4yzZ4n8lAUhWtVB26A1r8Q3sBCYUFMnF45wgZs1l4Khk/zmDjjzs
+l7V9PxAofF/KWMr07vmtyE410vIhdjW3I7Ezm9l29JNLjUl/Ibb6ZMDreB0gk6OhUDipq6F
bq4rVT5uDHKswgFVAr6PucqGk2dH45BpyWSfbTSYkYlW2JezlF9+PFYJCwXGIrEsrh8Qbd+O
dBqtZ6O4H9c41/H+F1YrYPz9qurTafiSzE9EPDaoBG1xxIF92Ow92wxz+Rb0P4WhH+VU9dYt
gdRa3k2wIoW+sri51r+sramtqa1p1zeUv+io+hyE680EZX2t0nYj0fy+I9EP2+u6jL9CNaK7
Is19VeF6hpD6gA3bd1YxgqsdcWu6Y03y8aW3DVfLxybCzsf2NXbLXkQIwTysxXzyjcNzcGIY
1unlFPnkKIHXZyiflR8gopoEwbZxzWMB6uW4i55ZmTJ/R41AS2lMzI0nTMokvSfMrnmbcXVD
FVkAtsF+AM1aQjg5SiH3agK5nOoH3t0hnsFG07krO/vjmWBQlAas8x9fU3AWiAas8x90zUIz
Uq/PF/aimU0TLEhOCr3ePGUmaJ/aSY2KqmoVKfFM47M/yqw3pd1pEXDKVnwE0xY1iOD+X2Iw
Z8aJrm7BuJqgaUpDa9qPUN2Xv43o4ZoW3xLDtycgE2OYV0VK4EzoADNzkuQj9aATHD6N1HIt
pxsaKcgl5nfDNGP5Ed6CdxQj6XKWgp9rCjY8n7OrO+RDMHMbzuVUqkL43BN4qG0Ak99jbPrs
tjd7Sru1CPkLuP4p63NJxqfjrApxTKXuLTWsKCgsHCJ6iXQies8wEXKCM+6+nFw/45tPQNpy
4B0RpTAsBp0sKSggvLv4AcCdiniwIaNVPzSNlg/X7OKC7P/5erNAKoHGC5uQ0mIBCV3geAl5
7Va2/JiQOYpSjlCJXp0cTcleq7GA6AVGYIUMqADkQBkGTtCXZpf7l5smz99cMHLDefHAFuoY
y7NB/EdRMOrz18DrXc45YwkhcozpQjCEI16VZXhyxzw2oIu66AJY6qJtIHM//XmMTGvj1/wl
UOv01f6AAK6H+gteLZsrxxgsFSaZH81/Dcd4F4XMMX1qvEiv9ZdNFTf1JJ7G0Ir/KFhyyg0c
D8B6wNv3TcmRRp5/PYSDGFegD/KoMrd7+ZIduor2k8xzNSbidUrF4oZ7cdQB+NA9fTGZVfWO
nV74O5vYcFui1W4HCqVWBCy1uwjDvw/mPfN5sIPbh8oPtFY4KqykO5QkVeiv4DpK3/Zg/zLS
fmBpQSOLjFEqK/bRhsTZ/Sun0TqBjCV/5S4/ELtAaHKrs/AE2Pc8o+NMFUrTYaRjO++wk4P6
C8eIn7ig7eN2tWMoZm/aA9sVPdHrz3sFa8hzscy+su8P+qzWMex2/yn/EVF56jITOZrVL64V
z1g2CHqL5J7omyg+D3QsssV3K6gZCEp5SkJso2OKAoOftzjzOWN2pfy9kEQGfEflGTyBJzH0
5h+nm10/dilq4gq+6iF1viuXM+B3/JjnTGpP8KPPp2fYUBx64lfFNNy6fL78E8NczgPMxIQJ
Pe5y6Ow+Fhy+hRgd+/WgG4uE+GCu1O6fH3s+o9CKxH0Dc0x8kfENkLQgQgcyUoa+x+2lQwHT
1DyVmNC3/cuniewOnRlNo3BFB7RIcTtbA3sF819A0OzXaZNfKDEWib5E1KQ7ksfGuzuwknlv
XR+gSqC6kCODoV4MfKYVdu6u2S2L8ugn0E1vcURFGdQgnoKd9nEuHML/c5MwgH+DPXsxcTF+
lmMV4VPBRGlj/w31nTvxvim3lZ6P5SBv9sifD/4IM8b4rg9IquS4H+RO+capc9VT+LuYTz/4
wP65TTPztErYatkpEWeaWINiMVIbutga/4JV5ugKG1T09XeO1ViHIaHKg2MEb0ZLqSyi55nm
VC8V4WzapS+n357rXkb8i+sAVb/NGZ1en1SVKngsuz/kc4SlCDNqVbVoEHT5wTOqIhn508/L
uZpzI7Vk/rtItTr5sP5dmg9IneQzOrmcjMo+nvmHIp4RQwn28hhSMObQzcGYrq+YmJ2dtTD+
Sn6OqkX4gdn4+NCCm5eYDwGU6VcvVvNW97C4DsVpavVuB29X0LFOeJh9BxEZ2sadqxPgkCXP
VEiqLK0Z7RQw/vdVVWZnhWw8sGLCUYinUHRBf8atUHohAeNtzIeCTelfptMM8dCnz8lew7Is
KU7ddof3YDrfLs4YuvULgRkgh6Qs2X9/0SxVdATA0B8lqnXRNtnF4Qo8BQg4RPDjXrlkCXv0
QP0P67FkCnxJTPWhTkkFd2GLyNNslxjfr46jCVLxoFjF98qRZM2RMz5jDzL/WLRee8gLQswb
ozt7cKvkzZhwR2Aio1/X/e9CVQmGIqvm+tvFtSIr4rZ3p+3nnC3OIwsO5+v3BrY+y/IX5liZ
6ealQy/fwuKBQHQ+zDQui+qy9Em58Z7JDqgmfXMtmDQhkj/9Ab4UuON6RB9Dm4OE9kW8OkAE
lY3A7jb2bC17AIMWlR89yv7qAECM+7FvUUr4dKLHWMrxq9ASdPQYpig5NyrnpWkvVNamKDk3
KudLyzYrk7cbgEXji1J1/CZom5umb3fEPSAmp3k2ZLjZ3QaFZuA1VODbAcnE49+R0KRsThNV
OuTXQBgDzWQzFB5KONCSJH6Vo3cMzB6NnoSDFw0/ORArw4ZPe4FTSw91ObU/6JO2un3AgyTb
u1F4NgXUBvcknCkjmD65PDvazqDMbs0V0l21RFjtm/lYiX4T/wgjedzEMUMVspN0ogfio+pG
QCytROR9LjAPRS6Bkjmrkz0VM8Q75TikcAlcEoMnoelfT/91i2RdnMtROzhf11g2FMU11Kv8
QoVykBPzW25XI71JSlZydjHaNKSAShz+27MLj1tFhmDRsPCSLN/CJPZ3wU3MT7dg1NZgK+ez
CiSNXmw6e3Ysfa12OJrvTJ8BND5aAmnJFabXo+/eyyg4UgLq26Loo/VjPFvNb8L6eD2jpeqH
Nf8DBeNEDGpsk6MF2F8uU20bAHKFlFAtNserLHMOykrz3a2ftwYoNAi9aAQ1E6dt4nHu7CJw
8EkO1ChaAyyp1HhXhoh1CLKXV+Fl8HOdq7wnM2U9uYp4t3ODLyTrSynJ4BUEnMXBhESfr3JA
DossJGi10k+1NLVSVpQ9RNVbr1R5o3/QKXkfPdJ7+OLrh0WiZQO3fs/Tg/phAuZ1fUBsoBIH
A/sBltXBmFXVdomML4cuPww6PJcVlccBS6cgCgDkRHHa2A/d1bQ0cMVyuLERMB4Wv5x9MgdN
9ZwRxxMWm6d5fGYVQ5vn8wUeEy/zh5hT4+cH8ajLTvPvFY2mpU8gJFskGVUQdEgkz0WYEP4S
3WHZ0pEZmwyl+cel+YzTj0zDjAiav4ALohJb4zNAjULssxlHxHltM4cCKRN81WeaGQgZhNHP
dEBgEPj0+DOOOs1JMwXrc9C8V7qqiTtXBd1orL7Ncmj8EWsuWS4LPQ2sKbGzJAaAA0I9dad7
Ucbob1dDwds+v7eVRJjsVrcMEuK0cL3+2x/2VwWbGElbGd+l5mg80O18U4ELlhTipbSZ9wWg
eYd1CiI38Y/MLEpv/QBv8zNy+CyqvnPST8RPtT/4+WpV2hIiR4NXitarCn6skKXlU42ll+a0
vWQYumUgaIe0CUg0NKSQFFSUmB9XwebheL1I02gUU6G4t6Yhry6sE0bxNxOiYcWlnI+WOPQc
T52OOAmZqwNoFijKZVsJWGr6WQ/16Hjm6x9jKdB3esOjA24Qyt81frmNtHqfFN8p0mjeybCU
nd7idOxOAbNukexZV1UACiiJ3Eytcotx4R69PLbYSVRy7tjB+NC7JLV0GbY0STCupUGPAK8S
rP42L54ZtjRJiXR+HTCupUGPADj0Qcu7k0ipzVhyftpPKOAkAHwOP1RpT1lN6t93Se/8nJQA
MMmJ/9xLjHCA/pdKRRz4GrfxNDyNHz1cHe8Y1k9IFE3g8zVGrOdE855md/3zkjrETz/hiJ5l
jpEWhWnIa8qENUDhpESInmWO8jme4ZEWhWnIa0uirl90Y8je/ajs07F7WU4/VhEP/Memmq11
XXb/fsvoggC4dVtgcacD535stJc/fmy07dYX/nv67f+YfJRIZCGrRdjisrPkjhoDpRAsTxRi
lBnYQi2+lSUk5fTGKvKI3Scj9JdNiT5J00+ym2QGtGUduBtZaQGaXqUEFc/DF7Yx2UulrFaW
rShmYjHUCFqYw1xh1o5RqqieaJKklB3GI2V8ip7jG5u+z375w4Yhuel4MV7czaDrsNoGEhCS
UdqpF4uQ1AHqsWCsX+bHdPVzAOIwSoPIgqm6ipEthNki2CO4aNRpvh2x3I8N1anN5+CY4TH/
cGF+sdI8Udn1SkFrLcgbJ4HqPd/jXtJdPvxC97rOTlWcCSn+sIoyLIN9+L31zyh7SF/F4TdE
opk2b+dWL1RpZS9UyktncK/Tr9Mp59gl6SlwO+O0hxpcrv/lJAEqiS2rWVSyQwpA61wHxiv3
MR3CnpGUheUfEo7N6cJc7/02vpkA32bGYU1S1eCKKGLLhsTuLtTEtkpWwdZPoglrBpo/vh4i
GKCqibRBvRUIRHYPqdrn0h99llAPFohQDw6dZ6o49HD0aLOaeUNiJ6+aecAcZMEguJH7gG85
qd1DVuGedI5TLJ52NhK+P+WtljvT2CrVqO2DbWqgMRS4r5DZ+mAZrKAnbwbIKzvaGMROE/cr
O9oztN6WyWeMLNCXzs2G0Cy5qpKum3gUXoRlKhP+yljs8LgUXvYQ+/EmN/A2er3f034UtFoW
iLRaS/dw7zj0cPRAS/dsZ6NsJiAv8bHZfXk3Gi8q4xU9SPN5FR2+w+V+87u3gDR1/Gb/v/L2
hbVGSNrTPwF2bQMwy4Ftwv2OzJYmoFHcxRAZrif/fDBM9h4PkqEZcQKThBYStLX4waiI0jIj
jB4d+ROY9Whci2hlwmKDYFjKVvDRdfMJitBsY0iVYwVQKSP9TQvGhjpIvC6CwkEMqnSaqFbK
seU6ULbr5jqD4R4xKwKFPFRN4gZRlS3I0ezTbQbC8H1Whz4/UFUq12cdxlTWh+45g+PWhGuQ
VS9LN6ZUJOQKa+H1LGIAf0eq0ewkdUTGTF5PwzFI38x7a5RO9b7sIZkuoZ1fsDujax/viRH3
r1yVVoxWOMioHtCHGMPUyrAJVu3n+cdcuj2Cb9X1ds+UcWBC3q/G5iaBQDAnDZM0VAqZWZQv
9+0iZgVMwqqUxqjnglLTX3TVxouBzAErA0IMPgYQ/QLIORrMNOvi0ubnAuDb+kB78ot4GmH3
n9/GXCEU8d+rlaXOGEXH/6vyC039JUydYapyRrzr0nwotBbJ1M+k1BqqjPQrPNjjxFjc1jA6
GyXFQRQQkNHjO3qdazwrJ9ZX+vxi+1gRPXp7RIsoL6Z1JHyqcPlpwoTG5DdehBIOAHNSJwDk
wIO9VF4slx2jAI7lQURlyAaHqnxg7a6pIyh90hwOKQDuJYc1KQBmJRmPEapUoHjKg++eVUQ1
nG9DCKXBlxqBRE8M+9Nf691CN3odQj+ThQPh/J61NovkZXzB/C/JdVxqmvDfv4mDGtkyRUcg
oxhH6m2kkJx5u/LBmIobgkEqFofp+NhD/iNUo570+G1K4ItVgAiT9iWwOMBO3362d58k3JPb
iV1ZgmZW8dzfEtfgIGoBvBSjEo1hjqOi7qyIbTwJRYTsReL8DhQVeT8N3CypAxaxPw9GRADp
g/orEV5DMZuO5kMuYuXMDY8WJ9oljmdYvY11fCpgyWwhMXNnoaa7+2z78uGJNol0iTYWvRFy
DOgUxaL/24B8m6m5CL8pm5vFchsa8Nka5k6QypeTZ2xIFQxK39o8HGAUzvv3AKiFP48LD7RS
mbhxX3sFifis8Nr7CzL/k2uV1zkM3QwqeZjKK1IYe2tjPFcm7+aefvUv36OyeoGf2Z0T1BOO
8/lCxdwX2n1KAc/TbPEGGsa6ZSIyrBDTj8RUyTplqKpDu8pVbkw7mko+uR//wSEAb16mO4OZ
455zhAGlex5XxcW54xxE3rA6KaxUIbtTWbEFLjobm0rZ/7/YtiXI72sCGniWY1uMN2KOo8Z+
3DGiJUXNQ03tARqobYHFFOv0XGYuBYfyrvWBCrjDQa8H7vLPK98n51TcABkGFsQURP16ZHwT
QTF+03zyIpfYrHDiOddnKgN2qWAwUqar+yHhEUbx+xE2UOfNQkJnjBhddWlgTP9ePtfe0OQE
4OHDGENTsR+2UTMnqfGGyHNkgNIDB6b8e2wGmW2QMpidcKYRJlgVhuuEZ5kMJgLRXQFFc8++
Uaih1UAR88ZflRPDKGw6IGSfiuLma5Xr1KaN+Qn/YZCzRiqSBnmSi33gv6F7QDKeAyHM3G93
+jCUGwV8GZAHOuQY9bpTcIHU25j4gTPrzZaYqlU/tO2Yc8B4K43jOT1ib4AKPbOyOoJB7GZt
2Lqb7vkzpKqNHtljUm1qThbiF1963djWYVLkMKbinhnRtuAPTmZiJJCdYE7awILESpX6X3a+
gwsens+5GAMaqWyFDxpEyXdFP1/S1O3NmRo9ammdJxkprxQ3EJep55/spoQzW0A0uMo2l0Qv
Gp0ZNMOmNqNOrK8o8IC0I/z4gZJ6BUxG2Vejijyhz4IhDCmlFGOHm225eO19h8JtuWy+fRnA
bSPcYkWxR1Ectm2SR9X8fztNsdhRQN16yT5vzNx+6Ys6IcRDUkg9KzJo6yYfaFLqsO5nMIxb
Ra6/W578x9v58sk4hvGhzd67K149Qs4FcPB7rjf9dNzBUriM6Sl6iOID/UXJGJ+oEX+ZVRfZ
TCic/tpMSi+XOKiJlnNoU3vB18BGCXKSdEUw4e1TDgsagH66/+2b4aQXs/Afl5ds0yPTE0zz
myrHTsKSMJ/dP4I8X2pWliCCft6Mz/PYzsdCycQcIUFaIREkoIc9jkncXMQeVpjDE9wPJuje
Xis94E6M5eB6EA+NckiF2PdOGjkVA/d/IaCB1Bm5hfIKExLZypfiBRKNylruOQur6Ex+yYkS
uzDjY1dEk1CRAfuAozEl3khsxtiEGJPtNCLGFdfxzmizocXXUWMUUsseGr3Us+bgKoRczGig
k4XIMgmUFFiTE91cv+WEFDG04nWKcZ6gNxHpwqsyILVtTNJKMKhVAr6PSPJ5YCDsYbaX0+qK
b0K/+haTVI2MI6GfbFVE3ov09b4tOJQe0LAKE+n9UbspwQrSUi7LnrmzhRSiM/VfleOQIWLR
AvRV1AgcP4q8nfU8EFsp2GiWX4NFkGtxGoDQ8X0HbvVrnmjfTVkgifAbaQ0oR37WZfjKF3DL
cMtwy8PHcOll3uYnLITrzX0Ufa3SdiPR/L7sz2eV0Jj0f5+zD6AE5hiy79s5tzj47xU0t3AZ
vUvtyA8c9GTt94dB55YPkZxJUdn9+jK0Nurex2dIN2jhvkTAmV1vhWLIusrEQRy+lXhlcMTd
SDdV4UdEdZmKb7RidR11HUu6cMQOwVDHtYorKccygroF2x3EQ4ZRrnF39G17UszBGa1khBft
xRI2GZk0HzCWpYeP7d0SN/7hu4HbMGSdEFsGmdsf45bKcGfdZ883zqytqa2mCEQGmSPLAJpJ
CFzuxtQFHIvqXZqi9L9+ezOw7UBphx0p0ZZZByynaplq7vRVypLMsuIjKQLrXHQr22D+Y3Sb
WR7KIW76dKSmueE/mB2a6B6kV4s4NpNXxVGPtUNe9Hwv4jSNg3I15/N/VrjKgr3x6QjirIqR
e6wkPD30i0KgFrMECACUo+tNw8gk23H3rvq6fWvCRoOyzLwut8IK8rJNmO6uQ1YO5zE4f7KU
kdqaNPEkuBTzbB7JLPCrhUElOMOLTftYPZbsXoVHpnV/FuLFkxkurejv3PVfD3gJoqFHmn6i
X0Xdfg07rYihcDIIMUmbF4KOcqWQgUluVKoVof5J4zsXni50cszZ7WAl9hoMSn1PA7vO7N/T
OycQjcw6B4n9gh4rBN8mSzAgzFxTilQuxMK8d9JdGm5M8L5cWQTX9T6YVClw3pd9F0BCJ1+w
I2uG4j3jfga6UGhgMS043Q3vIqf4ur6L9IHEuVUVp4QEYPl+GjFxNuA1c29pMYSlwkU7DkXM
TRibF+9OPw7F2U+kUGNsU/qUWAaV5VM0GrKhlS7iacJb6mVoXXvDqri31aDBf5aC9/eO/REg
7SnwirKmM0DuIyJwAJZNQShpcijosTkpMVxJgjfX0TqrTMQTk3NEe9le9Sx//wdvH/as5wev
RkhpOA9TS5aRBLTdQHu0ln2p+RgfJ2n7W4UIaY+Es0TRZtg2TJAJzu+IE8RZK4+MNmcnIy4s
kbSe6UVq99zIXVQBEJZ0hnOQwlEhe4VEcqCvKpiYcohD9WDa/al5IH3rsuHNqeYktdJOVZhy
D7mqpL9Vlbo9vZJwUVVTjKk+o0pUmRsxKJKKHTczRuYMyJ9+U+60yx8y1ID4jxoApSUiU96W
5KDZVHWyAnsA0Nc5awWlWC7W/8h6W/1wwqagx/1MujMasiQOn4NTDB9rVkyXZjjv4X6X+aQX
1KRHLtnLi+CQOSl/MvIbPBNYHBONPBAME+aX+y4II1VfaLMgLoUilgCnJISM4jza/Ya56HLL
xtnRgJ3rKQMgiJHEaHnqD/hDjTFDplFIig34SkG6qT+nO5wyHvbuI6O+vKfi/jzdMhKPoOm4
BRt0aWa/TClAnJIp8UR+gan4Avk7ioxxyy/l7ZuT7wpKlynjYYPFZNX5Jwpo4nV+sSuAxFXu
cn1ADvpsJLdNX7MRJKZYp1Cb+Dmy90P4RC7h2f79IdtcH949014IppGUrBZnHdY5YC9ErBYO
AK7K46xIVXvWFvHN5YW0LzvfasIdOWq2NjmHwDY5HAPbRCK2lUQcx5VEh+uVREPzcpGhyabW
cYU/6HKzxZoH5dsp9ANcctJ+PV4A/T1CGhF3vY0qMkghdSsDDuscM47z1pci+TPZJLuq5JvZ
ZHOu0yl8fGHGJVTR+5Ez8rDuVsv/BnDQSgNXV20dBL3yOQS9fNOgwa1qWlEdPyfwG3lR9UQh
vRElZyHecg7TkGOmjabFpG9NNsP6iFySgbnrlqmNQVfY0oXrEMRT405J38EPpI8alpLzgiyp
xaZcpuWmw/tN5vqmTeFpAjOmaVyvSe8O8m7nwoQM0e9FmP/0wPrB7EZ2eKd1bn2uUHMDxzJD
o3HBkrphEw9WwTi83Pie86RuIoGUrozU76Sm7u7Iwn1B0ul+7a+FvMqRqqUIVuNqThY812E5
fmimrJjMj0AnoZO/jqU8q74yRnkudXkmGkK9X4vZXKIiF5W5TF3cn4FpRrYmsNH1/VhwiPMJ
zfTZTtVsp/kEaRe2iyFr5NtPwxtnYMkJ/9Fk54pIWYwdO7RyoxoAbX8Kr6uc8nnq6qNYgJwY
Tj0VBvlvY0A6q7a+wYCQcyWfw0WB8jVqwlDA25glshMDHl4qMoTH8vS/ayH+A+5lbVkjMlNJ
Zk9lX9Zzf8p2YkYLUBW8/xbNvp92F8/HtbqlTs2duayW/q/BmCi/JBC9Imj5MP6ozjD42Uyl
hlWauyRVRCRzz/gILL9P1rUjte4dQm9o+ZIeB/6/uxGQliSaRG1OjFKYhiMlRDpobSAQtb5+
l1WYjMr4wP72kJGG+6STFiltAqk0yiaWdukCkqY1zWR4lpQAAjw0kV2g+7R1aetEMSzCfFtR
OcxTFWPQcvwlgN/oEKgRH1lS0qYtTZfD6S/FrGkoIeeNR3cW0BqiGpVussKxGIsIaZiKgfcO
O9sujTLE7zDi8P6eR/vHy+ScBI4rcgMi52R2kEmqySDSxBg3/ZbU0ears6pjLzimQ+7VW9h/
cYZ/BQY+b5w5+0rGsNwuJ6IzgS4cTb1zHlh/abb9tCQuDhswS79IZy71OLVGqeylhCqms+l1
NDDAOCVe24JmVDZwVwaI83LnbIR67waIawByq41epnQMWkrkEnDxr2sXFQB25/6fq2iazLgg
wd0AHOEsnjGUZYUU6H8gIqI65qb+HfsJPaZ05wSlJq+p9RnxMqjyi3gbV0tEmXfpBKdbgJQN
SVyBYQ7BYr2BLHh6wnNWZHPeh4KSfXSWg+4HG6l8fOZGFVDATWmVvZjanfsUo1yIsVvjE07d
M+2DOuD4kusITSzxKaZcRTj33HCM/ex9OR/hKDYc53ovMMqlZxaIpWePN1AcjzerIYy2thRI
3K58S3ieVzb5/Ur4QqbkQO8QIsq8+cavKN8v0M8vj3jdIAdCneM5EO+aBas36rLGWE0Kct8z
4vjYCIZbGZSEK4BVvYTDQGj0mkAw2tsF+w/WTuHPss6rpSoWiKUqj/ZQQR/QZPMfrzlU/QTe
eBZHSBFfkE+m2q6zMj/mHs+VPbLZalQC67K2wE039UOgW19bBLs+rzBV8/UjVmTvn9xNGrOS
+8zHrmyH3Ci9y5mn66wj11et/ZFyfCsBQtfIqNGyUt7d14+JpngdSDlsHUg5aHSDHc1S3dd+
1iWfQjC8DIxtNx8EKLy8tMZDlfni0TMwUi2d9m0Qh6N60kq233CR1E8HkyFpWf80aDhlNGv1
+Kkp8rIdw1tNuaE1MgLg8VgF7zP/prH3m/E9yo3D1eDik/2eCS7Cq5aIY5l0V0wAI3t1//yR
TV5ua6bSJoR++CJtJnA/JiHafpoW12Zup0TFvcPT0SxpoQ7xaWUO8WdsawBQHJ1NkfQCdcj6
HgHSn4Crp7O1UPIC6yovbtI3riOsFlh1bVScXS5XzFaLFhdw1pjPRBkKqSi9VilJpzx39GNy
Ehh5cKmNj5KcQVF46neMwxrCBx1FqVf8s0N77bMyHbU7BzAPpQ0PNgXV482IxtF6uJ+MCsrw
VATwlFLUrHlQj9wWVHze/rV1qjrSqOQp2fj40HuieEG7iwUh79n1Alb8vIbK4rgiji/H7ai6
oEWG0asfnh+p0enz0HvRVxvZBcyzakyd/btDY+lXWRfRLTAS6QADyfTTN2PrQHQuLSdvIHTm
JqV7TMizV504T1yajO3jwr5QeKyHyIcKe6GCTmhQpzdwmUtvfpE3Dab2N/GvujY84c03MzBq
o3TOoXho5tYfhQ8rk5+NQ6m6psSmSPtoBnTEWiuRlrht/QbxEL5z05q1CzL+Ok49+HIP2Hwf
85/3vMHSpu+7w+vvlXIQ+JwpNXAqi4vxmsQTLoncTbtPsNk9oj5/kESGLY4O7qz+aXRsReiA
mZyZgqtq3/YalYvTNDXNbIMZ9/fJGtnk1HFmk8HZmaum1A52J5sFo8PPPVFEAvLvq8yEYTkC
22FRXT1547Tg92CTDIHpiR/ztzsOBHlk6Gf0MMzpC8ixGDTFNF+f6tlW6nyWqIpLQSGBj8hY
8UaR4jYImy53bvbJzth+o6qldGsMpVymsPvcHW45bB1uOVeyg07kjyGVtopA6xEpfXv6+7D7
3B1uOVd5pm7UbhD8LyzLUW9zHrmGnKjIo4EuZz1BPuWfeWfP0uPq/bSUZGoCIocnKOdV0Ruq
9AWvxNzdS87OOKYczImg7R36YGOB/npsuvhsMRLIAPK0HDxvB5OHHHBIiHwj4IPkTuTF7J30
b5DgfbMey8zuMrN9iTdr9gZURvp6J5ZyIwsBXCNBIGowxopIDLtMY8yfDUq6OVIQ+ewW6cbb
9oDqA9FiKRiU2Mjr4GD7eERInrCOUz64XhaIyCyP6N0uawDQbROeZ30+gBTShd5XT+vDDKK+
ZmiLpXQgxy/UxJpMdKMaWXgQHEOfXA3zcmKaBWobodWd5kFlJ6RrzBtQzHhlW0CaPiyhP6dP
hRkXjHop3yVuLULEJTb+RUiiTbO8klyCn1ZStodgDRuWlmSb4eMOnfTN4CQtigsd0Q+4c+/t
8n34V217e5F3xZcNDCFPVm6Kd59eA57GfkYGr5ML0hMZOHgv6yFiEuSZcCyKJvv4pjP7ih1s
HYodtFuDTkc4LPpyZd0ABddmW2gdU7BMpr/ikj1vpMLWU0VekNLdBxymLOVtGAOhKXYNTXsy
hxb8GrvaCWnOF7rEvWbZgNACAFa2wmBd9bzi1y9H2+ExWEqiVVHOnjrZorlX+rgqilDSw/bM
qd2mN68zb+d0LwQWiC8EynxQHBGuKDZggX+uYvsE7BqkeGe5KTaDaxmmrS8OiMslevMOQMVb
3exJmTymMvMhhLz8s992AsZRWV1wjr4pe42wH04In1slSXXyDGvpF3vSNrS9S7Z+WTeQpto3
8a/4HZ/hzTczih3aa0ia3h43Y87X6FpQ6/17iKbsdNYMz6Zsh8rTLI/jLFTbifQHdGU6r9MY
fWDKVrfNpSYBqq5Us9xxyzzVO9fgWEPZRuQNWl+vRSLnAw6KPaQuwDjyr8zwjTrx0cx0820M
RUsYarNGjL2AtvI5gLZKG6DBQwHGjxPUSB+3F7Ck5lAoC8FbXk5BMEIPGjRJYBn9pKq44klP
wKUiLGr4GgC7Bs88Mo+qFbVGtb21tvlJiXT5SeSuESigxoqqmxCG3pxb7GTEnOqhiQH7z2nO
Dihd1iu3uaF7a+ktxakjSf8xl/fuRSGZSijvaUIOTpdHK3+0p7nVmBIWKAN42it4l/qXGTSd
DnRn0dtebTLfyQOMvPrjWQpu2PgLV924qe6mavtAHXRs1h10WwSDHc1/2t2NbVInaq+b14tQ
+HEHmov8Q9Hq0B+fkjTi64YBkIdk/HpaSqeuoaWg0K/rmxm/QyceI7jq7uIVTAKYnr+U8jm/
lLnFoFuD6/+xm+0LErR82Y9Oc9+Dy+erHAboy/Vp7VPoP24JlrlNSYDSDnFQIxivOs8RwQNR
jXkAciNLj8cVwUZyvU+2IkmJdCJJz9wRKKDGXcc8mNSfILdECPMu45ePJC8aylosMdpcsBTP
d1sIzGrva3KQ4KltI6Xc7pAV2gK/nruO8jm7jhk+oFuDC5vcPWK8AtCjdsrvGSl8KDJNqvyv
2oGLE5JOWe06YxztJWpOoQo+59DSa5PrUR7BmUmdoM1UxZ1vgC/tR4XDbOsy/calke76FbcC
SZmub/I5rm9BVqBbg+sG+itKNylW/Px6R8HqmKV7cdSYscExpiyfyB3adxKQRB9S0Xu5YxSv
Tx+TFJ+BTdZwqxQ78mO/WJvBEF2zxXtC0r4KNHp60O95mR4PcQHCoiXlVzNLcrEroTIhD0eq
x/ceHSalNl7OrxbP+4459eCUG9riHuJ4yrqarH5Euk0bxp4DLw6ZCAyJoFRc3FZrrcKdTK09
l0Nqsdrwc8jeXUBzafZtYOYwQmrcffxSCw4m6jEdDUHY0gkA6R497I0n2VUU1VPiWFFvW2Ly
fkKtDbb/d1TyeZYmIlp3JjIG92YF1xvySY6y+utDJyVWIZBEhgj1g9+9geBG02JlzkYh2RYM
BJGFt16W6cULyF4uXO3n+cfZnOPHPOQq5ibyKyiRfBLXiTi+dQidJXL2ADU1mZBymn5aRLZv
WqKUsVFeRx7OtPXXKj4rLAbK2qNILy5DHuJwlk3JHzr5FBQAL9vZePefQKOhXQ9ktklZ5vaT
9RVYkY23s6NvLEi3ejh7VPqRTmlJX65p1T4N5n2iofzg4awCP8SvqVIfrc9I3RWpAvuZhPqm
mR1vQDN6D1RURId7fDgG63TmRiwIq5vtcK8/93CdV0uqjrQfOTQsNgR415iGvKJPKOHOYs3y
qrSc56a5Ek1TlqkPBbiEyp1nP5DID4+83RA3+OH+Al6yaB9Tlol0U5a4DxEooMbT/mJSH2L8
/UOYPdfR8AZ8D4eAMRqlkVf5J/Dm16whkkF+V05MV0+cDXn7hqh1u7hXUB0EV3aeoKbh/edB
hi3MAQ7GFWjRTHGjGgT5I5yQ8KDRIDAajn5SUo3HSoE+xuY2pE4jPC5sdV2VLFntymrxHOvR
JXTcNIcgGrxsIsxemUlkya/EXiZxC6RjqmH9wuttVqYY4GZdVS8CqZHnhEzXa9J1JMnryS2y
CwXHtAVGilMm6aCuSRtZh813zc5e/4r0YFvJlTdM4Ke/EBTEKXJmgy/2HGxO/TvFMfm+WbEF
LvtvBP0ADZQuYHrX1sTZ5OX88mXkPXCDGKjUxWtzhaPpWVXXekqFJaAUtrzTJ+vd00QenvFW
nv9q2NYL4AXcy7COaUfOKGzT1F8Vdd7QpldXbajvJ0kUGANNeb0ame2OzFZ7sG9A7v0EOTF8
dFDgtAcHAygJmON+tAccMzXkeFVapgRAsRB8h/6HmhRkRmdrN+aEjDeM+wJAM2cS5IxQnoq0
iEJugCTS3M6aJLkwb3dTxPbX+/vZHKyTENvCI+cBgdP6g+ZmU5VkuajAjf/ZLTO4EszgPw2H
/wLn2fKPCgsbyOiltswGFFU7luOHRwMOiAMWb3ECJIpagsEFiRLtWOIOUH8yTAkgLRr45hDO
Q8TGtfhyg9T30wyrI45XPPbUasVMCM0P6MAGoSqSYe3PgvkN7c+C/2Htz4LyYbq8dsoFCO0T
Ebx0C0OyYkOIp45iXVoXxzqBG/JqcbJRbxG34EiC2AtfWbI8IVm2JGztMGXfIL07f+vcNMPQ
jTzPMYU5CNMiZf9fVvdfW3i8JpBi0bXIzWeBfl0RzZN5OjGFIwiUq91P8GhvmlHCpX5doJub
kj0D9wVRulzBcmBI1UhcTyTrcESpzo8lNDbjINhUb4vS4f4duVsqW8D7aCiDHc1ChX1eGJD1
pqoFkQTSeFa9earOILj5o5Y6WXMagoHx16CuFB7W5kLP6PtHHXVbfLtErELvScjivVCh85FM
pW6lhzzQ2y+kjTPjWhn3h2IlDQfH5TG2YUb0xTWnMcCTx+fN79kqtkmGwIY9QgH4bkb314tK
YplxdpQ8fXolRJL/ZdLzBcg82dE6xjD8PNGnphpX+IevBztJj/43Ziexm2eOkdAWI6IfEGbw
EMyAqV+lT7jddi8syiIWiMoiZ89QQcGeCFKdUdpF0JDLI1bIKGdV+alFEEZoLfrhbstXpLhF
H+PrLbuTG9luHcnSu4okkSGctUlRtlhibBzKyrLndyjhJaln7ajKsud3H+ElqWftqMqy53ep
qWAqz5dyK+uzNDATvK1FcDhG8qcZ+lQLwL9tbVcscqxS9xX+7D5/EGmyCIn/mg2vcOqwxgIz
w0tjm/kbXdXtglfrnYy9Nh89tOWAiYde6a9XJlxN4hIfZTB74cbA0iaUGH6i9AqNv5Ft4Qrq
Bescw/hk0tz1HektD4RbJxK42DOrtzvrEhLItKs2n/tCpGdxH8g8OUZEnpkfHxZWaVQOS2ll
DktnOGsAlqhQ8c0FmMxUwsQSX4I8Vz5zIbjqZQCpReEyRPyS4cyxRIgHeif6IQSRZD0UPzKp
muYTULNiTk+bJ4RRodcsqP9pEj7/0lJ/KidcmPMqLbWy7Q8/TbzElUdY4BEbZO8y8F8TKgt8
D3zPPGsv15MxKvjL1dNTrSwS1PseiwpDz4RLu4LnM4Hd2Ha/LRbuybaW+ovWLl2VP+eJsFEg
y1+Z0DTqBJRjeM36jhYpbcMJK4y4qUUp/5EMJ45I4DTLH9ibt3B6zZ8XK4NJ9XWHHbJVNqMD
cllKmn6frKH2/10B1OhHMhoPJ9tPruyCgWzNQ5ciXCOJMox39AGaoQCxfVZW71Rg2wFGZu+n
2VrfnRhvBXUWhRtMD5Yfs+C/P4a8GMqb+6DTZiwvOqmFWxaIZiwvOqbNQtT3KB89PHIE/siw
XbXXmo/SMU4AEMmeP7h0NxYXl1QUk5ScIefS9dEFPU6935lKlXmU8Ei01G0UmjsVePM6rhUZ
6rst7AE78kglEV6NOMRz1JkeUW0WE7ofyaiIkhUp3ybZ0bZ7L5zeiZOUSZfVbx4UKfjMgYTn
ErZ5DzleL223u/ER+MmQR4xdyT89TAd9numT9WTzHs8yUSujydiditXX+kYKTa2Y8sffgLfT
URpeom6B7FCkqwNed3B1i1FiFmoGFshvLGziOmTET0iqMXMeM2q5Vc2cmC2elC4T1uYXzYHc
/6Uac4rWDK5cAq4vhMhdt4/QryER3KD3Iaf2avV2KhXV/MT1RpM0h8Q1AX6KEcaniE+LZIIQ
OBjvnkJrWr6bLO8HeMLEbLMoQoFFol5PNOVvrpqNpapaTU83S5wXw7b1UVHVRk1SLqk8b8/q
ZAjDrGC6p1h0XyqkN7hY6dSU2xvrmCZSF7z9wRkhAejZNkOgrWoNPCatlfBHpixCTksK1uXN
tzLRgZkTdqOYMX0GMzgRKXBV8pqMByZif/3L8Pp2iGoDMP80x/DgXOqjzs3/u2hFXlaMurKS
M3p5Sg0GpHcfqrFObSm5u6m8tLmCWfglYShSPRMjuugPEbofMQHxot6xUbEN24OWZKT2dWof
H5ixix/9oWs1swB64kMglQLfOwUam2lToAiNZnfD1hSKCv0jFH53E/ZjzkAcTgjmg46rlJ5G
lFBnLyvW59XrPDF6LpQsO5CMqyAkGfnO7tHOwCzPks0LpdnNxppIJDYkGT86KcGPhnOq16ws
uz9Fc81OTKU6+ZyYj0/+JD/LSCT3qhBCte4dOwgIc8aqdkQ6sJrW/g+sKNvEcyGZP3O4v/g6
uRFoSutP9crSi0CklO8jOY8c3XNqJYcj6rOjlNAFXH+SsVWwmp3kWSHFMLVY2PQDj/74mqxP
SCQ5T7mqknIIzoYw5ClBTVWauyShklBrEcakGJ9evF2xrr+dCVVA5TU9y+Y99Q43DeINXtmG
lE9dJBA6vm46xA8Zmqp0GV7pU7XGsJhyT9CszvkzTEvKCqO4tQhqu8PVJJoQU/gp2VWY4j3N
lInL8v56iUrm/dBjn8QsmkS7uSK10ilzZOl/EcohpZXeDoktuzUhfLft7QlDrCyq+NNoc/5V
rp1SAeQwtQLOrMRPDtBQxsHl0BvKGZhgCUfpJdHMbFsn6oZs8bhNH3ceyncMkVFFd/wTvCeB
/v4smqr5vhKVktRcsOwgqeA1LRzpLbj/RCc2KhWtH27HNzN23a2cm3DmwaEfIww5Zc8cSECu
/agyaXFHW1JLFByHSdkJ4QHQESb1+qwW+WfH8ntMtEhSq8b5dsuQxm+wuDPA+ejA6IU0R8DN
raceTJTqGauwhwdPA/l35023NaCeypWr04uhHASu1vVPCX+QrpM07cVlMePGeKsDO4oIbnm3
jPoc0J/IZm2Vsycy9YT5X7DvanHESPoH+AW/5Fzilk+fLBDMKO16zyj0ecMhNHr1oPQpiX5H
tskU8cMAeGOW2CRsw8F5c173IsTM2PjY94sBB43CXM2m3/OX2xbwy01OWyyXNe9ulhU6Zv5O
6VJvoZTXLfkJUSxV2iksE1nmgcMlG+heM6HX7B3APSpqUMGDaubvzT5enHSfXAdXQ56CwTbZ
csQxZjSI9tUpwqpESDHN2Ovw8w++x0ZfKsYdtn2tNOUultlIx9cMi26q2K5BLRw625JdsgP6
KBv7FuVryNhfwsQr5eXByn0shIfAQ7ijBb0kTBhLb/oy/83inIk+xCnuG+zjuodxMjpTWN0m
3kjiXnsC2ZkvkucrvGTla0jhbYRi2yEQqqKxelFo5I9fyZhNmFnMv59OWq3tk34+YLLBkWJI
Ko1PgcF41rgazflp0uod1yvHGirB7vc9CK4pdtwNjwhiwhh+MA+GzlW31/MtTMGj0Oox4iDw
ySIl5W+U46n+6Ts0USXevkuI07ECO4J4gm+gB3FQMw6XxjP46+IKC0+YmyOFMkiqElagAVNh
X+zKFFgbQi1o1YvAJXL1wuhWlrcyq38sAMdZW3F5jmgJhptSv/YbctDYBfz3JpjwfYErtsaN
kejJJkhHCW2yyFIrxJ0wkqDE4TPrzEELJdvzydZX289nSSi+9HB2xAWZTBsHixCHeMp5miqk
ajn4tC18yhgnnoBRfZoxqqc4NOQks9uu5TIQF/7ZYeIsBxm9sYGEd3jBRT/SI7BMsSjYlSWS
RkfiQgb0A7k4VtlN/qKf3k8eGr/ek15icaM8hAJuq7FpZbDUrdUaCwWOjTJ+Ewoj2t/cf6ZK
8IYNTKsHKjMIzDebo3SMPrmqhED7HC9wuKR9SDbuH7N6y+tN80/6YC2vPdkUv/QT32bsfpPm
DWaM+lwls6yiyGq3qzvlUYx+BQGQU2n7vJjTBGEd7u/VRYy2OWZPGVgSO3NOY9F9MzvZ0MSB
Z34kh4qpp9luw40RHtUNNOV21L0rxUZ27yVHWsPfMfU03bTuDTBsbysfkc0bAs9KpWL88K1T
8lsIBYVZQEeRhVk5XBC5W96NtIntdq6dc6UpuTNVu69Vqp215EOC2aIrbAfjIvmGc8aYcL4E
5Q+zsK6iuZNnGc/iQtWJdPIzV/JAhA1p703zyz0GaWKgwS/LPQkJl/UaMyOI7QFShJiB4Ail
gCf+P30zZugHTCVNNpwMf3SF0RwsvZ3CAwdhCd56wsXxetoGcpACs5t7ONK+t0t6etDveQX8
D242SOIV2KhtAPX5hUJaQCCQGX0iibXJYo5J5QHgbQJ952Ulfaw+rcx5g/riwW7pZTjOaxf6
JV8qtPZ6sG6AYSuuycUPqFVPSfGK5rqRQfzj64TwA5WrHt0K/djWo7qg4RXZ/UBn6tDVNOiH
Y04nAJPEYyMYwAoq1WynmKErAUyC6Y2yoyErvrRpv7g0bv236saa+QEnUvMGhhwQbB6RNZ95
UfUcCAt9kvpcQPzCSktFNnw0vNgPuPP/TjKXmu8sQD+1CNkwq89McZmM3nG8G7qxfFiA+Cdx
geEumMsGhSAkwsnK6uvQ5fNiKxLfWztSZlxh/WUMG1Y+NUVxLuwCfa1CQ+edJ03S4EbTYmVT
s2XZFgwEkYU5WZbpxQvIXliC7ef5x9mc45/X5CrmJvKnixs7JayzgbldV87Fyidc4sZml74Z
L51hh8HRPPyLDlETA7GAlb1XXmbjwqbNGqdmFXcRPj3ztdeXFCEd75kKOuw6wl3zABBnHMn7
+DtjSHbJOuLjZt55Cvl6Esypy3Q+w66yZQT6sah/8IGMSkUGuCsNlQdvgSldp/zs/uVcAN8f
CvKKD6Qqwv1lEyubF55yikXsVKPC+9exbV/RuD5Y8Laz4ravk6KfeZlm2pI4A4ydlBvAkedc
TUnegP/WBq4Six1CmSVYtQ53LPhW5wl8NmJa6BaQFiE04+Qqkxuc1C+g4qfqwcwp2Zzbr0EX
GkzUYEsrF41F8W/1xZb2KjvDkPnRJ1y1dq0668Oj9+xsD2SGX1b4kX2/wcz53xjx9Hp5yfsk
3ImW6vM6FT3J8nSreV9XEKwkObftfsDo67urQRC64r3HyFZz/IPl2TzI5ZSz5d4vlpqig5U8
8mYs6ZBXOAANp5XXbdwrvuKj2dMukNxBS8KT+thHdcVfZA0rCZEd4hjxKz9OqEMyRcr4gU4T
I2saXNsQK82et2y+o1LzCB24iPMk+ErO+7W9bB3WHfm25EmgwfM6rvS4fAhP28E+c6fA/p3j
BrwhfXDfd1tDKdB2ToX3OoyXz2XJKkglyuMS5/RqThY8+ksaVdh1YdynLnhPRMI7iUIub2/8
av2RQY6tAMZJgMZ7UdzGPFN8KrlW8EdQ47I4MN6gFjem+xMmN+ECtPKMzxMbwOAGYHteQL76
JpNcp2nlx2l6hQ1A38hP40niQ+S4FXeIKX919MoYOHyec7jlWJcS5Jl6I36cj7NqjAeAKGzW
gCjQHINOzwAjkMfrzbQfMUpbQoFqcZKv+TRJFxmcSbv68P6LanLhbG8FDZJpsRAky8+tIO7t
KP4ZE8xFB4rt1WsjFSTa5J8JJV2gma9JJZmP4mpMxofnuXtoMhaIdstTHlAcEdCqv+31AaMQ
Mos4ZPHZXCIpu362D0gunwhcAcRFE3zZkrx4bnImu+Z+5iyW9cqij0TKpR0oMPtbVg77INhF
kICHcv/fqs9TgkjN9NpF7mAsbmMzftqZOrT+Qhgi6mMOiJgqWZfgJ4ewlRLzfalABeQYtHV3
Bt/hnuRjecEhifGgNyBiY9SzMo4Kk8OAxXxqZLN8MTeDBvB7R+wI/tTtH/DL1X796zfZ9e1V
iiV94AljcUnU9u2eof20IF6GSaVA5dTA5cxf1HMjXNPgC9Zg8F57ViAKUCEG5dkgPJpTKxAE
PnIFaPGtBFo5YfRnZamRpvqp8fv6pvH7zUJBWmDN4cBkGpmFcDhbassddPshepBspZ+J3Zqh
4SBbvcuIEX1mtfvfivN+yDEySqsEtDJK81r54BMWmf4NVYikr3Pbg8v+trlJaK4WiGiuU09Q
QZyGP6fDI7pgIK6Re1retQj8YkLsKWkBKMEgxYKVCmQxWotWEIY+zwlbT6CAkmm599MStxyh
jk1nqWFDQl0cIAxKxuJW9GCunKAmKlwG94+ut4vqHLgMnleHahtEdnoXfgyPrWrHQMF0bNbB
dHKIg05Hx9362zukxwwLG0nWTlOyhkhb6Rqc4TwI4EnnNdF7u46bOMeF9YoPq/RWW9O7Gege
Rkd1CfP8sh44MP6ysZAQGRTOC8o5CQNpivyGgLKc7aFpbWj1843cNKKvq4VBFLs9K4AJy69I
Je4B2w3SYHmKQr8FXziP3lNHUdQOuah7Esf4Ok6qVaojH+TSTs3Gqmjt2qwK0BCOcRBTkmll
V9X4uIE9KtfYoRiXFgAb1UfOzbD40LXnuSQ0mT9i6qCqLE+jPgwT4n4kmhCeGVVzc3PGmL+v
Vaq19f4enP7+LBevwZa/nZflHVcdb+Fv4K43ppUZvxrQ+xbTQ9dkUZVKMKDSdPlL2zOEToPv
jnOoFZmj5nQGeP0jlIodWwQhsGsyNGcxj4DQb1cUbg6COWcs08jimvEZtfwU5wMOijxVZpeL
7y42pnm5kuQqJqfe1iWZk6+a/6yhPkxFyVMvUWhEVCtinqdo+XWHyvIb850gyFU9NUd9V3Ul
HMMZTPP54E4STDozNrm9QMYo0CwcJHo/FoiFEDBqUBwR0PRoIEUfsHk3CPVOhU3i0kBZazd4
7bKd/NeZnbn3cP76SxIatO0Z/p9UuS16qO6ru+sq4lef7FfcgUaZxDItsgtjPN9ra9M4dh5j
c/dcwz8Tw2Se0PyzDVK81md18zUW1L4MO7IDOo4ZlmFvpT/ucxX4AvGv+AL+mc1C3hlkigD1
I7wp3zHbOCUFzaSPu8vH9RAwU4dxuiwiOywXM480tMDArwIQLx+fLUebAeb5qxyNpJruTPL5
AcwZ9Q5Fb+eslB54cVlTdbh/a5G4f+7g5hKHGm2TSOd5cwxhc0a3vUnHINwbEzilISzb6253
HBuTN9Sv6pUJjhyzf1qcfvh7Ak69wbbV2m6uV09pZVdPuCJrAFAcnf+wMBkMT7wK50T/6xZx
98nC2vIHlf7Ly7vpM9hb8IqQs4z0w1KSAXvVsMvHDPihj7wMcvzmGhEk+1IwHJWNb55lVgAy
H08AS9dgPMPZYUaRN9BukdEc7ZheLHXxSvfuKHJt+JoTzTAyVg2sR3fyg51zugiWZjt13WUJ
zHKXwqoay2yn9/Up92mKKDrXG+Aez3NZIypPY8neAffyCUSmPAlG+oNmTdFc+tOGXMu985Pp
KQHbgjspIuj3mRATYrcMl5V41tSTxcerW/mSTQQFgiKLXkITU57HIzBjgh6r1ztgAo0LgEAU
ZqpYgLcnehfbQzHUCDDUFQWwgqNxBBQtYHNUJhojrEK/+JfZFY2l/rEGRm69YursKnnSuhAP
MFWHoaebjVVzcAhVBkC+oEwaaj5dt3Fg0l8j3GEetkJxMKOSo1X64uhofF+iCnb/Jrdik0QJ
wt9vCe6xHsfpJy2T00VnxZ0BBROVwByLHqBNopfQ6gsmjjEIu7TAYqGyWq1toQ//x3vZEwPs
v7kwermHTXW2ryejjWxl+leUHVzwiRrffnuf5eOEBRhF7boXK3v433c9EniMa7zpJI3le/d3
JiWrNT6+09xoumRPsOLtzgTv/hbvKgCNlIEjgHFvRf3RNKcJzNV4yRqBYhSYFU9KIdGiyh+U
b2r3sy5NDOqugMmAZxZHT0pHExBrIap7ZbsXQt4pKdKO/kKmUvs+pgmmGqaJdBqmWvsRcoKu
qTE2ji6g3ayKthDC4YTn+2jovihoqi8nmpyWpeeg+K8xgU7kvhWKRzGwtFhQyzOBjtrvT4kg
A4zCNh2QW6bStWD5pY1Y5E5kFxmlOp1BiFA6ZrnRo4qe1ZVmCMJfPwXMRLKJ08XaG884iSDr
GooCCQ38luRerd36se7OS93+kiCR0YBCFBTzXPv6xb0m4+VPnkXbi4jMbe+C8faZGZ+r4Vt+
xF6n/dIF7cMp9+6VtOnjHFccv8vxZfLctOwdX342Z66QvCUcMgMPXZhnrQWBGZ4Dx7r+BagA
xj2dpAjHaESgHaxK2cK9ljZw5yB0qaimhKZAaWWmQKZ0awByH3x37+8bNLhYkeNmYI5/4TcA
hrcj7eYEfFEST5/1ZC5G/Fh2mf1G9VLA0EdDgYodqfNHbXCH2XCHUj8zvZOB89Ix5QQo/QD2
ww0HmYBihDDwfzSVytpNG+Yj8yVtyIfK0qkkqVAdawfx+ws25ihGHINOfeftHP1+Lir60RhK
P+OLBW4C+8vt1HJqAD8/0ZvvCdEGcfVT8kLmWypLZxcIZsWvAeul5vk0ncOjzEmNIrtJjbJL
YQ2BlnMUIOIV2KiJAIq1c07IdJLsU9DsIo+dvgz+n76MsQWkEIe7ff4/gF48Ccnfb8wc0YZH
uvwJup6iF1N758iHFFrv+yeUBFa/qXW6x+oFcmfwJslhJJehmEq0D608lgbSqxNsHciyE2M8
SOFjIwoaCsbwSuiHAb93I8KT9/w+n+k7k1jwYH2+cHr11455hFDgqxo33tOjGwkMi5Psolok
j5HKSCUo3/PB75bXLEfhWCTrWQAJAZgxoilGK0frQyclViFjTVX1g9+ygeBG02Jlzokh2RYM
oIUvwW2TSmmXygxB/COhCYjWbicGHumlTwqD/FbJ3x5XzsVTX5slItDNTvPqMeMDsVkB0oii
yeQXtivXnvWPMdhZRDGrDBSOT8kEpbFH9mbQK+4o0jhvS5pfKoZ82b/p//Gn3yUddpJP3p23
ZoEO1xi2pOsOP3ejXm5XXEwIOBd5exBj7OguLlxt19Dlnvjq9jqKQEfsjeRCFYJzPb43uKPo
r8GbJGSxeVLOlzVRcPl76x8bCvUq3K+IYrFlEewkiZHsUKOs78dvblmA6BWN3t++jqAvJIjp
Qu9RCrd/QshWt9kIfs81p3MRfyuHaW7r5xqtcko9oG4/DpblLqmXNfC2ZSvryoe89KA5g+Yc
6jiQfK/huvIGt1xJJqBqp/GiY7OhttgtAtvybMPMaKejhcjwqcVawh7fMXdVJpn30JG6tDAQ
k8pEorK3PU0SCod+Qr/bF33RR0TBk7+TZU7NRtMNLk5VZrvRiGyZCsB3L1Rp446CTQl9Bap6
TNxigy8QriQPDUkyokCPl19fNxHxuuBWYHQD3irVfpLfSv6lC/6TTZP+87CTvjWIDTLakD3a
JYyAodKE3CC8aWnEOQAp8D+zpVYQcOD9ibRb+uHHpsemxw7sHdVRWmrnAEDoBbM1UMd9rdJx
d8cqMu2sgeznOyWw8HUFM27jVktv/2K2pfCoxt/YWm3cFebsdVpsghSNdAdWolcDWSngkXjC
FhlcMFFHgqXGRXufJgtBXrx1ZToD5is9W6ZmUkQWFlYjoaRYKNPIK49wlbsBduRTwzeBlemk
swzzdaOezUkJCSto6zPDIfUuODtiStP1dqJLAEBncr1oEDRzCGpVwZokqr74Y4aFpmLiu62n
YPixBa7EnYr5Mvg4/vmGH4OU9e8wcWi1sB4mf5C3255HxN6rbHR02dQLPJMNTU8/vHPbnh8w
vn6KGHD8SoXe+FPeHk3enHXeB+PenDDeraMjI3vmQNM2nKj5iAhy46pA8aj5iAhyUEEXdrVW
OjGkFrPgWPsb4Vn1qXzMrYI3tvtJI0pXs/oDFfQZ7bU06g59NmfzqWam6bQCHRbhaTZsHWk2
DueDHc0IHY6NQd86q5L9v3aFJLWdtVtmV98J

/
  CREATE OR REPLACE PACKAGE BODY "PCKG_INIT" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
25b45 3c7c
mwwSP2Cpf+sLqNLIw3VYmzipfawwg80A9seG3/H+k53hElzq8cKrZAD6Q0iCUuURGGEq6Fqy
oddfu5kMLa3aRTAaPtn/G+r4hiimD6bjSWxYwlvlw9O3puchRf3wP/92/pe+pd2TV7w5tSLH
ZNEloXyh+e3B2wCmqgMW9e0IeptnemogpZ0bSiQ6LCCPRB+33QxJC84v3aqsOtJHbd202r+L
P+FKCOfxmuffABMPju375OoGTDCzrrB7TO3QuGW5BPmqV65nL0XuikV1N2DBFuzUHz78oYGq
u6K5Y7btPKuvssaHx+fWPs7nIxWtdAgElSIOD66SCqONtYboEU4l3Vgjd7BVfOO2SVrlKLI/
5DjnylD412K5nd5KHhBZ1dha7XB0LFMZVlhG+7AI+I7igtsOURvMfoH9YTgGEFlNQD0UrkoP
tXwUBcb0ePbhK2gZKJBSe5/TI2Z9+zGXstP/n1LoHjYIW+OKFXK1WhBoWNfk9B7KFjUj93SZ
wYYau4svkvoy/FP6Xe2A3xQH0nN39NGLXpZaBifhdUYXPzBSiRpDkatV1Bfjff+EDn1gWQp9
NVm8QW/mQQvCgfXTGqFXnVN0NFeLYdpOyh4vXyi6syj5ntwZ5yt8DqOLEYpz91V6IpEOKPmB
lqJEEd51no9Pc4yb3qH9IDOCmfF4uSm2bE4UYcSRGK0Ok+A13aFvnWLqtaadlrkcgkv5Nifl
zkVTD8/6HML4+UGLBVsRb51d+PGu9HULijpBbREgi6L/jmZr0LA9jEtiGj5YMEIcAl7baPGF
rgjnhwbpKrs2LNHthQpgxn2mF8Pwd7CIYR0xoxnT4bdVWRxUCIdpDNktO0C7rjrZFFnzUrLj
XHTaN8Q2SQTJMjDj+383Bx/SNMRgyyNTeX9GRGXQs7903vkpHZiQoIPL/3C6u/rOTH8lSmGG
2cAN5MJTHSgexqrPhwETslPXImLqMWJU4pu+bNzP6VlLXqupwfyp4RKjhYOEb/lHiGiMDv+6
6vu7nriwFOcSemdJsYIo+s3WIvlZnj6VmOeMHo6edaGOknPMCAZ5MDwwb3J6xDEdwOa5yWu2
7UWpokEeztHPvT6C3Bu5tiCh0NNYUF9KRoKMIFqmbvnhNnBEkupj5FsHxU8Esl4PE5c4GEnJ
jMj+sM+J/PQpZ9sq5QRNz+B701JPxWDFT3S9o+xu6mfOmULrWdEAq4n3gvTt1DKwYMr1/lhu
mWkr47bK2ZXrBUpQn4q+vLZCd/IK2XdH0F68aa6ZitLg+oY3RXNDmk6o1j4xEHRY88nn9MeL
Ei97wd3ufsf65JDvd2+Cqtve5QPB2CNIqe939x341oLW/0Nf/0rFnsn/WKgdAqsiZAGlWDYt
H2ytsUjmsH9qnja5BaKyAswZdJDbF9yKKaDXJDuzUChV1c/n0onIG5/9Ms29awxiGBnA/nkK
ACC5Rfg8TaoADW/atQBOOZscvMhErbO9PcKv8KPr077jOn6L6R0HtF2o8eUvv1GwQwcfEL11
yI5LuoNopyIN3omKacClkpJxEcIjR0v75xV2Z8HuegQKv54gIdThnwsCTKN81p9Za7LHfMnT
OUdRYuswnost7xvg1Fm0h0Est87Sg6ZPoDrwwE07znK8zlA/OrPizgn2+RQGXub5AtteFYcO
tMSC/ic8hq7MITX5AexJUiKQftlexgG/MR1FmrW7krGyzvWd+QlkI4rXym403e3UpqYobQ+7
wkjigawQOMlTt2Ls2N8xADn6wIFL6FKmNKwDX3owsMYJIjmjeKbuQaoRGB3SJLaBbDLD4qIK
O98LTUA9SM0UTlSMa7vboXtPf5d+OPZKBrp3n28uFefCafDoufVuURPC/xVmMJztSoHd2phG
4AJg2hDeUbQDCVIaMXGov8PrERHZFMqZ1hQyrB4oSv8UZihmookRoPXPV+Bu/L/nJREcEaAT
eyzMDJANELgb+hRTWpbv8NQLcogLYm0r9mtAh009PogFS8aUMMdhyNQZmIzd+HU0v+RBbtVN
E+YxX8qfftShoTO0sSnUIMfAz3TOIKy+u5mHCM1MXU2sSnOKi06rRjUPpbyVcRRkkkhXkOat
WdINIkSEaj6Qin2+EeS7v56e9GwYB4MulEioL3TnorHaqgShXBAXnhn4HUfo7jlEqseShKWC
ehPVWy804QKmSpEg91ZmfULzAk6IV5josSpGIRRQ6Pyhllp2YcJtjUzYiuABnJwWmNLDdy69
1cj9MxJ5zjeNXvKlkz5jYOC842azbHkKsE1ceBMH+H4IAR3IfuZtG3pSDoQQSpT72Odw6abV
4YqHNk2JmWYiO0u4KSlJM1L8aruXEYh4yMy4Isc+VYss88zVP9Wws57PZZfYq/R9UnfSzx9k
VNypU7IuWWcDkDH/FbllJRWyXTYCExaFWuq0ytdRz0IdfQQ4STWP6chhkeJSoEcvmWCs0zmM
y3psEcyFm/fyFOK9058nY8PbhlpZlQBr8rAaW1grB5aq150Z0RxlS/rfE47ycClknRBEZN3X
BrmLCEgIS3FkyLvAzWKZtd3AgwrF/JmbS76x9xN+0fQhMzNfpYwu/MfT5rav5aCOmPqK4x5x
Cu56mfgz7LSA4Cc38hS3rekP2++VToKKLm0z2njw76dc/8cwo3oKG+MNAQAjhh7EEU1e915I
Sl5LOxXreIDug58/8kF8stsa1ARKBCJXVujj1Ia/f6+VZE8f/c6l9p8D5KA0qLj32wltqnrk
jC99idt/YpEG2nmC/+4ysQiR/ER/kSqwEYYxTpO2KK11hR8yl8lmbtgtUsZfZMCr+KdYQXR5
WrW1VcqmAsbJ2mR3rakFivZhRdcreKoVzeKBsofyuogEPYTNA7Nj4ebHzNvyBBAYfjgHJoc4
i7AK3t6wWmuBHdxdNazeTjVRCjq/73Kx670ETOlVDKrPFIfZTUjKvOnXUcr3SswqL9Covvbl
YugakdAk1Af3/QLItuxxL1AGlQafDVagYo1HEPIp8RJxKRz+d8RBUdE9W969tcNqfm2T0YNg
TpYrmJZU4D9tMRiUr+8qnSmjG9I7ZaiggrgiCRzmYfdLZklmYAnW9Lk3Q56yzo6K8jl0pGHp
TuzgN+8VB61Pv/DvG5/hcCdTzPnyPIAnIRac9rb2arb/mAJ4WbmJHGxzkDuE7n+Cig39ZJHX
l14XmDGNwxUkmQwl2Mi2lYiJ9WyvVIq8rsgqAy/3QFnf63muUZVVpDg3egeA9s+TBGbNMdLX
noVAgJ496bVZMVU+Ea6wnD97Q24prRyu05jG31vDocc5ScPp6M3QFgiyIIBbjiJA5VCFrLCu
VfYSBJN5LgeDq/7NzhEFTkR8n0wJnJ7GHx3c4t2zzAZLYYfTEbQn2itb0GFp5U1Jrq5x2Pqs
t+ifJnWgy9TFPa7Fy1xaanEbXEvp2bBWT3t0IpS7da6z50qTXGg+CqyZfu44wMh0VuIEdSYg
+DNZLk0fTeaMYkkDbopstMbDX8kX0jsLqF6tr6i0JUgwMKKkgHotgZ6tlYjPmuMAudDzJuQo
Vv3CfoXCqCL9CZMtY8Dp2htLYh4Gx9ysMs2jbxjClh6a81uSRT+FKyjZlaS0kb9Pq/40H5xp
B2uf51aXmj10GLkGucsdCD8Qt1UiGRdc+YNoDyiqG9AD/DnD19IN8PQx0g2rHQC10g12ipAm
LW/Po+KnE3JX0HnG4krKl9/QvyhZQHPh8lWRsZzN0y9J1mzHh4zAFp2mO5BUVrvCBfOF+VTg
swh9fU21QIjqqkPN6p3VirZO/1fAUhTqnW3kwIoUo8LG3zRLRIb2xkOjwqBqwQ9D6Pd+2cA7
PHEMB8w9yqo45Ca8Gu+Wa/iKyRCqCpdlPkU7LF2UkKqB5NzuHGaNwsTXOahA9bY0Bx3rn6l+
RAA1sk383hAE5IkHpj2uYGP99Hg57lxPXTxd3mn+1Szwq35tKbqkvTKam7PnNHs4/wL8cRS3
tnj/ApBOGOC5EotaKlP+tWvAqjO1Y8B4WHr+Mq2+UdVRlBu+UlU5u/hnznsz09saUtvqek06
KkVYC346AtjBp5jUXAIIGDnSo0AuIk9eyxP5pLA/Fyi9fyfTGv78Ehs9NG75aTSXFDmzeucb
r0Sb6k5J66ElFwyZfoTQiyE+jAzRpoMOkxKrVZqxNqBFciib3p9PD45Q4tFzJ1CltiV/DNmU
gZuZeCEg/Wu7T625lAyWNulPId70yikwP29Js8o/wYzB77isJU3u0xpl4UDXs0/Axc1bqNEf
W6WrNgYHAKsPBrMwy8RVu30R21225vKol5sNaxOxkLOyQXrdH8MMKqcnM9wqfaYnb7PRpyVW
YyJOkHBtZvw7l7DEVm68LvrSYhhju1NZI0OveNDghdPRNDYBvOYFyBWAgVyJ1wJcupqGk/XD
9YhDqr6lWdxpe4noG6fXk1wEfgj+uJPvtJ2xJThpjNPzm9Oighrwcvx6uN1WCI73R7qeQXgb
6fwyl3eMZNKyJ//9w5B4ZNogh0K8kxK8qW4wXZ1eajwOlCGwFzdL7XwECKnxH8A2l/IIefaV
BcWlYZ7kbWThD6eQo5pVb4P8cZOQMOuIi+oHhnbWsMMIszMq6P/uNauQyr2i9W6SOFe2iNAn
RLV5YTe17UKm/tAKZL9tXIJ1Gnt4LcIPdCVIdPIq+EA7jLebBJH981naIICkyOEW7miRQoXX
Bu5S1ie3LBWbkwCoiy2hBJIIs63osPX8FLkBvXX7NQOMq4fvnsVq67ZBo/d7vBHZOYswP+/+
1QWGXc51ZGIJjMnwIHq+jNUwtosbI0jW4Usj+YAWiKBprJTSUK5dTPVQWRbR/jdE6UjMziTW
nhIjUTVaGvEhCWIBoqgJrq0BRePvFX/b+ePthENbG715GwOnrQpaLaetx9luPc26BsKj8goF
xMMLJos+Mvg6ldwaPdB6jqHCAuCdO0id7SOqDLK1n/L5VR46iDK1SKDXOmGbjv/Y1mli4jQU
zaD9FGjthlkFvQYoLz1st8737OE5pfUcC3P3z31oYW+wY7CJ5d5dbMjCzLP3WB8uFS0aKUf0
C4GD1DiXXUdv1jfFQlFxKwCR936mkPq3PsUeZWOXaAuxS449eWv+4i0LThYVJ3WFTu6q1PG7
Wxlb0WZdhKOM3U4qnn44lHDIwjfcBxfVdWkInY0mqZA6PG8dRJFhDe8W31Gv60HXYLiTm+K/
1qSqBVUwIDSycL77EGZNgEulayotDZp0keAKrtg53QrqrpmRNVfv4qi3PTbXHFOdlrmcpBuK
V8G9mbAOS9vSFvhcyN0I/3N8XznWNeGVfB90aQ+Oe0+6n5LroarOnqWa8MaG+bjOVfooJHYo
tejomcUipwKrbuNd7y+iHXqauzZPOv1BNiZvgCsaHMbNB+iJz3D6yFY+f07fyhtA7HEm79wu
DC7l7+o+9H4KTW059dZFTbFq4u8+VXIx1yCPye1FTAbmLmTn1LiDZxPL3l/sxj7Qnfyiozkx
JK9VI1ITBqxcuCAcIhdwHa4cS7SpZP4xu9mBhjnY6jEDGAN3i240Ba7E5AOfKPWPoy0njYsE
JLfkPpoLQGPKPB1NK5EO80IUeOqdge5Z8GHN+2Lv1E86mX2/x6JeBdTqru7tfm7aJE/FeOaU
FFxz3M5kV8uy29CMHRqzAmjdBF38BLmV49PrmYqIcqSdqKQ2vXzw57A6d5L+ivk/QhM3lm0k
wMA/rfvuGPijYzEjh/6gwIOYvE+Nhrkehzw2xI8iK9+K+RgOZw5xpDAwtLfbZl04SZ32dgZD
9mgN7AJQZSSWFTtJvPZLse+7bTBCZx/IIFWgTv3nbaEa6e5puFveqbeFUrevtL7/s2tFeOrJ
ORbiCL0wVzaa+/WYefKIqjs5vHTBzJj3qolK2pA2TiXHMX5dnay1jvG9g6Rj0mqEk7m5nsiO
KnvdmZv8CNlkuP+4fwqBhI22PmQwgRczUIEAnkJIy8qjdPfO/J6JknoxlC9Cw2dHvfDTxlxc
Q0meTzj+YsZVgnSPTYDpmY5ZlCy9eoRO5duSOuZOyArOTZv+juze4e4Zc6LvykZpwU14/99a
fQ8/4bhBFlh9m7WbJ4N4bZTOKh3EHlywo64wZDrppwJ0xFHN618oOYNX9y2Imo5CR0CK6XZC
2BKAggU5Sesd7i3cNQRlFEbK/tAKlP8OoEU7M3C3xM6bU0IWBdJPFghGgwOQH+TIa5QRDJVb
S6lRxZhZxAx9WJMtqy1vSdxXF6RdBz0sbuBxG5Lg9AZ11XnEaBv1UmEToLUu5kIOMsRaHLv+
R7/oUPhtO9E7Vo3JeJCQOHVQWpid6XU2oZTlvDBzbNkCxpUQYG1saezPrRi8VxLdHk1j+bQC
woNo/mYhaPj6tP2wF6RsMnevKm/GyBrjTpqc2X3+gy0mGxLTNUBPxz+3f6mQe/s09GMXV6xL
C4ZM/YVvcec9obSIWgJ87oeSucJEb+RuZA+7p3hUBgycWjk2+T1f9dyKBE1HfuxnAuHChhu3
/hxiLMQMPoMUODdLTlml2AJ2wmxv5UaEPkveT7TcmzB4dsdtRx+6eWo2/YW0a785Tjm0Ricc
NkjY+0J4/ouHnDo5V/x2eQDc7awr0odVzao5JOTEVnANPF4h1QePcr8sfWLskyjnAjWy540m
/cB8rxLSf47/3Si16SoRkUhwlMt+lwschXu8oaXBV9213CrmXuMElAN7ae9wCcAnNm7+/9uA
OiUNjKWo65blNX6kk3JgsZg32M/0GuS3NW23eVsvNlXrN/574BCVpb5aaAKm3UlO5FAmLwL/
xgXcduX/dM88bNzP6XYwcoHSjzsBmMeioybm3fNCA1fYNKg0iMsnr2pTVByKF4cISvFrS/2b
33Ow/8Z5RR+zWMmEcOfUToJODYZBi1WPfqjoZpEg65a9uqcUIR7fM+B47I98hYveajAhhUsu
WwNZS4WmC3QthCi2IZ9MFwc9mK0l0YDDeY6w928MjS08C0wQ35LZ/gCq02qZCQQUzH3+snIg
RNnNisWW+3bBZvRp8QlzwFJkVUIPY01qg6Pl8fIfsO1RwAv4oPUjDBsexIY91qo/hxnPycMx
HoB+e82OacBX9Cf+falZfZYloDGWeBYdTEGOebh6Nh4SuE89rtxAWyznxYlvPdFSBfz655qt
N0a9o4m9erpo5DPOjWEp7s8yA4UScj0TvxS//KMVziP1LX1/acaClygqvsxI1RM7h348S7A4
swthA8QCTMLN3MouAzEiFC1VRLPRuKBdlkCjQ2G/x7eB649hiTeKxyVmw+Ptv1qEOs8tqHgY
UKq1jbJC8WdhNqmouFjVHcjs6Ms8KZ3tlPwagmQ/E+rPlqEoBgeB6laGQgqqVpibnHnQ0MZ7
+02l1A+rS+4CGxlvkUIzyUXRFjAC0Z9WlR8xldoh+E7FB8t31O+JK4iuTD1ZxkhcsujraY1H
kwXfY1jyIzYggrd87BSxmyu59W5RVsAYOoBIqw/G8kvX0ZBUf47iINj7ZaAd0XFd6QRMCrrl
jhUWvk7kBmWl4JXRymKj/DaxLHaV6u9d79Nsm2BKKMY3gALcBam9dkMhNaIo/T6npa8326tx
GpzMrmt5n9RXNw7la4U1at1xo6QbrfBmf0MWpSIbyIaBXfXlSPKcwa9C+hHLY+vwmotdzgTS
Rugr+f3prPV6TRF3P59OQrIVDpYwloqAgn28kSVR82nxMjCR40UzPuOr3LuRgHLphqogvIf6
1S2A8ehrDi8QOTaDHpCOGkd3w0OrTRYSl9oA8nDQvipog48g3Kq0jsBESlCRgcXgk4Raadrx
1cDEz9VcVCYV8pQr5bRtw7NezBxsYMpAd/aECiusEfIvQVP6eD4kpQJbvK3EkCrEV6n2utG3
8EJOuE9ivHxb9Qc5uhJ0BQu0HGqWOgTi4hlmueeWwWXFPZjtu+5dAk+N9xxIyoxFzwYJrNkk
ZlEq5CvcyZTSkY4rKtPznATPEfTA5hV5EZum7M1fsGbv/Whn3H9T9KxU9dD1wuSCtcNbZ4x0
gRTnNFrM16PsS0RzaWwexFmkHlRMxkVarwklh4zODeif102rn2w9ypCi9PjTDdsTHGSi57Dn
AY1BQLiTjEZ2m5Wwge1n0aNkufl6djXjdU7dFKPUVwRJv0NiXwwbT6gjiBBim8+2xkiBUl2H
kobvCF2AMh1/1ZDpNWakjCfKHIRhfKTpZnBXW/Rhubr61IVC55WALxbbLvN4qDgCOqx29Sr9
Z6TXjo3sNCg3h4VzTRA+iwrWWLR+GJJhvgtDXFidyQoFfjJOSWfYi8ouY6f0etobZsxXfVIv
sgmaRFU4aua+dqC2XaHiPlfK4yVRmRzMgDCvZaK+73fBqvmVffhgdvYkWYYOisqnAVSnLYCn
r7AxXvL2NAusVafXpb52r8kax0iv0QZlfl2TkqAIxJ0zN0/crPs9AbTrLbcK7Y/EpakXNJpJ
+wSlersJU4/54x6JnEpycxokdiKNJCxlFVnTRbgAzIdTTboPejde4sCwQOoQ6BkAk3BTfeoi
q1w+Xm3TQoTolpO/U326Iqs36kmEe26wxWjyewbA4NR5OAacXHUEuxKAQzTZj1TktQEIk0W0
eBOl3F/s9Wta/PBu5FAxV/Q1KSQowV9tGtKUgbzwhbNuFAGR+kyq/Vb2rlH4+Oypw/46NSL6
uU5t4SU9bA+y0z/mZcmhviL7PgnL5pF3UiVOuNGMhhbSc4LG7eAmsBu76kkul2bnekFPNe4g
L51Os07zVzX/q1MjoF9uOMfSsG7J+DXjJ5napmQ10yORcvqcn9xBann+2ntJfzpGyAnn+5iy
VTS5X0ilXfvcmPYm1AnXGSY5pIAI2E04L0JaYlzYjJJagSJKcX5HLMixrRQ5i94zZ/cVoonz
QNL+FpEqzq5cZvmwXjLG8WD7Z9LTRkhXmDl7oflgFL1e7dngM6tz1SdI/joY/76acpZV3NfE
IwYP8JAyphv5a7US6yFXtk3MGKQ1blc1CRAQpYYovnsCVR75/UFzq05JNkoJRG2/pbIFZggi
G5XWm9pEjJGOYDavf7JE7MoYV/GgimwJZT3HFEgA9e7CVSdjNCTCE8YHVhfuL+QR4o0MFcw6
oGiJACnUokJwn8708fGhAp4y7c+o80UNCAuNc4K/eGJoXghf8ic+et/TBwxnTIjphSl0UPDv
dCWD1fY2ur73eDse9sY3gm2WauSuKy2T/cuPFe5NgG77ts83CDlzscbGxmRKro8kWoYwsqpk
6OvqUyPEocKtcw/ZILe0XM0BLd1BZ4T9Rr0VgVf0ve24tdC8GRXyct7AIKUPbpbylJUVeWci
wzow17/S6NN/CQV55SvvlDeN2w3UKuFndv/vse9xa0VsVtw/4sDmrEdxOuEYcUJlmAHpUSNK
+o0oMwJI69ToJ9I1XBzoSp8ewDureSqy6DlvkxYBkE+wo9wpG8uKkboN+M+ze5pVIfREyeqN
6n6qHEcLro76A9e6KRzwzmVTJ1lj1cLCNSwXmEZk6U8RwyR9JpMwrjXIhaIrSKFzjtCJ0LdO
QTQLdln/cu1NZTHvXFdloyitOWL2csKrW/Zyg5dBAY2Pp1PYe3LFr2I9VOVC8mwwPtqeDY++
rojMoSMMMs4zIwhMFoW/6D6ajZfPD0VOkBHG/VfdXrcDHK0NGust3O3scKOTP89JWnKQ9LtS
F94yu3K6/tzoPw9oVe4YEP4eE4ozCCIdFMv1CWTQbqbXDPsGtMX+6qx5iyS0sM8lXnz6whAI
GrCLB0JO/KGu1giUAJdJALIc6vU+T+f16IK5HCtjQtrCem7qpXOZulyhdUNBQbXgQoDXP5Zl
2Yce5wNCwAguM1VoCEn6MpMeoIZfvn5VpVGpOcWmCKVUtGHTIPJIWQeTK30V3n1oAMdkyco/
Ejz1Q3KukQ0oJAnwqCT5NHMvF8UJRQixVbf6ilpepHH9sHAsEJCCPddT8uvnUwhWeyVHdOtf
sDjfLP81mpGwSkMBqr68Kk/Vp2Bmu3aWZ6oEjv5tK3bXHXqGXnTEBmSozk2evqmF26K0z3cC
h0H0j1+e9zpNxAEBsYO3HTI7+Qbb4EcXgiiHNDhPCZQA29RaqsBDN/mqWhU5s8TSI3iMNzAM
wwXX1TwJwo2BABYgVLhtkH+JnszlsIQGxeBKFRRaCi8HZ6uRCXxZGvoqOFqCJ55p4X8h39v2
dcb7lbkE/eDzh0LM/CyMJI9jBIcbZjAcAvOSE3pjtJ1e/iXHZHCxsXNrG6FmX/M42Uv0cdaX
S1EHR8iP78op1ml1TlifPdvH0mIQIksJxDbDsbB4xbX5FwDG0rGKLNlc0SN+Qa848FjiGTfw
A5gO6D4QEMNQ93y/steSKSFle2DBZiB0rUl+jkZNFpeDGtkurX5P7O+VyWjEZNBf4fQTpiUJ
/OdrAc46nvVkuq/ibHYu3GX9axE9wTxR9u+OeUZR8Gnk1O+OO9pAAIg7ODFFC1S/dAwqpFML
IVbN5p1fxSzFb9G/BoktY4DUPLkEmAiVtPTv1OsSOIpHKIzuo2uGcTiPhy39W5nFAYKqGF+2
QC39OXLzjHHzK2oUUjJnjYcz1ix/2wic/ySi6oDBKQJbUuxKav3SKfKbvtPTKcgtjYJzEFKc
In6S9cXEazJEKXeUGsu+o+Lj7R0x/G96Vp2REweVnGRCj5QDVXJJWP3i+Fa9pH/yxDxWlv+J
NtnHcOwVkkKEVMzhn7rI0w1tKsq6QOfCFzWcKVqZScw7uHjNcMT3N3ktVpLh9DUxCbGtNbDI
dFDlbPEo377ndg8xWZ3kW1ChEKN3yy9vtAmNgeMqlyMvFwq4L+kRceQrBhesD5k32EzFDLDg
otjYBKhW0mdvLuMxUb0WvSagde8BYQA9eIMrHCtHm3sIwH7jMM5wOZhwvAasLLqbBjm02IhH
5WLYiEc536MuRT29oy5FPRq65UIi7PWjJNHDjIBBHs7RvA1ZBpEGg6XUHb0gborcLeKwcSBw
4Q++GVBA2Y3Bsmyf1elhWVjNOaG2R417TG56LTTgXHsTkuD5LIVj7OzIx7JJiT+lNApF9ry7
HTBwdiit8LA4yHHC8J0X/XJmZK2CkKHeiP2HNMLtPEbZkPrnMvtJY+reaSePEMRY1H3evZvw
WK1TIMKYiov7fFTEVFU85d2wTCL6Xaur2jK5WiOouknIGgf2jembQkm8VqWGnwhJVOLdJAOK
xHo2rDlHrjobp/z9n/2riKba9HXKQp/eJVkVUNCZExsjLEGG/vCUfOVsU1CsqgynX6cY5eYq
/YbhHqXH13KJVaL+/e7/z5MAz0CakviatdxE/+yh27qsU1I8c0ZJokvgT+W2YkxHOGKEqmqB
4Ub9OpMo7tvMWeVKUGXnzSH6LVpVlCfgeesoIG7Mxk6hNvTTnIEr/Zd1lHsFM3fC/y3UOwhv
D4L8sAtqC0ehu5YJMAr1Fs2wSIA0wiaofHTWjFJk+ukvFbrfrOOIShBTkeDH2YK8qbgBeHZS
epf2Sq/HzGSzh5urC79OEPSsgCHRDKsJdQV+6tGwFVDJt3ay0Ju1TWAvncYW3wYS7ZwX9Yq+
KVicZ7Q2HSMGlVZA3fQ+d4IES/r/WH/H2F37Dm9r7CDQQpiFhU1ofnc9avsIRbF84KqAeOgT
61OT7pHtE5Xi56ksAiyXhCDnFf6l6PDyHBu2cUj5ikVK7ZVrUxbx/SLYAPrUh4qnSOHOKHSX
Fi9smhu5U8pIZRY9gejGmU7v1vxsvx3m38kC5qyA2x2DHHs2ej2UqwIf6JMACuvZZgxCvFa8
MhP1ugRvYoyPoN/JywySJkHOGULmFw/Ihq7wlF7BhspK9gksGK4E7bIKaukLahj81NqwvhC4
ZnvaVFv0p49wanmG7+teifRTYq85ByUcjPLO+W9/zmi8QdTHsQIFuCL+c/aRwRvM6PIeGS8F
qxKZvUVwXQEFXjMWBUQYa5HVjhh/W5QRZmvyYcJTtCrRFQMdH5apxG0lXq4fmf34nghL8S5G
dVRVVJH+PtREabVvDT2k8nyypMEkLrEkEMYkTMQkVf3sp9lP/wE12VVyhTGu/uGmnc+y/gyZ
MC6oT2lD9DNeYfQYkLdInPXQ2/3vaLIIb03u0URh4RXvrbV+ZU6HDL3I4AWwioA6e4iH3tDL
pPQC6393+P4UW+x0ZfB3H8A7pXBSTqVTUx2/HpXNfE8NVADP5+zuYRg4tpBLLXu0J6xPjBu0
or3YdIcvJ6xPMAjwZzkj4MUBS6PYUMybJz71Ko3EIxijLmPY5vsKjH6N2fKj8sOyAj54dKyz
odLO95nCsnazz14Z5qBCjBtkkFu30C/YQpR/z6SRoFhqOB43Tc0gAMvwHDsHPndt5LmsjlTx
HxFa0zhAJSut1KUFuAFbYNlUaPgqpePd6/vBcC4002UdSd6KIQkEJ4MBIZ3dDqaSqUGB1Ljk
062FKBa54Dq5Fp1pBrKrkzgdl8F0+Gnjs2nxtzue2w6NGeANDBxV2250rT2u+7HlFX3aiJMq
H64m7/7D12DbxUDFYRtne/YHDNpvB08kyx4ymqTAqrSrvggBhsNC4+XMEucnjyqjXsAXN31I
Vyjxr79qccLZVWwIGK3mQXFIlJ47pUQjT1Xms/G8zq/Qsi0kylNySDz+xBO5Xbq6oHI507S0
3/0FyQsFVlIxtN/9Bckmi0LMsogFPOdcBgLETEdJfhRu19OA0MARkwafyElKAx6Yljz+kYhD
VzX2vjHiSFDnqoYB8ZkGKC/XQpr4Uk2cp0otvFwUDF4kiP/EwVmfB46DM3ls8QsKkD0Wg1Lw
A9zmZOjcfAcse8fT/mVVk3ZvGQQnkK25KQQx2mUKmQjWOMUHrBS0V+b4XQh86X0sXg5tqirv
BdKgpCoZegHRFjUYsN9UgyPC5SMkw8c7JyTk0E40AVTsc3XmPlFZjjrfem345ZsA4d10Eoua
FYH3QW8zBl/wknx/yeB9BETC0uHljxdhev0R/TPYuOcjIxyt/7nCwjkXzAHYo4G0EzX0d5lo
HjTIKwcyV0T4FUe4SboUm/CvyjBEhZe4pKcvXSP6Dj78bOQUaOYNgyeAcEpfGCgn6E7Y5KPA
YYzro9rOxzaWHrd87BSxqy5VKVfpsVmQAunIxnHGI4+V9D4qg0OB1So1bTN0QUsZ6QRM9t+A
WAD13S/m1Io2sSx2kDfvKLrjKqN7InZ/3IHafenj4B58JybWFyx2MEwo0SXZWowItMfUVM0O
PYMW8NjcZjFud+u0Er+O3fj5Erwg2jUp/OjRjbpv2ZImoAQbZP2dskzbiYHR4VF6YRhWDUms
SnOKi06r44JyYXVtXVwsiMdrcWaSo0+sqHy6GCnHsyW8minxbHjTjeofbGcohUeFoxcHn+2j
ZXNkOLkPQV15b69cEulpHqvmo6jr1wQMHFqhEUPL1b9UvmqXpHLpuX0mFqfTIezpjyreaJcE
bM686b2Eh/2pjMq0KyRpClnfKP4xBtk5yr6sb9UwgEIHI44SzwWGBRyaM8482rwKDO3j/kXl
CSpVKUSPnAGOGP2FfWVPmImrTtDjES+djV6HRGeI7VzwosOnlunculOyLklnA5BYNqaY2U05
eMjrnkhRDi9MMd1cp8vhRmb738FesRTnNOP/AOvOs4DPVgS9njZfQM3DjG5eQfRj6CrDuuLw
QcvQhBWi5YXKDUniYAgUslK9aMkPAz15YUU6gh9u5ZF8AmwX/IeC0+v7iGtTFbaCJEyt5ZB1
ok/53N7KKvnKsz3kmPfBHpDOYAfxEinQYwGz5TngSHttrKJ7YD1n1PfGgMKU/E0h+2pU5xQ1
hm37SRd/Lt/WcGZI0HWyvSFH31182L42/BHopSHu0BHvRnbxg2PgJXsEbXPhaZphH0Xkq8YX
CUTHDc+XmyZqj14ISjqO8I91XJWQwsVT3W9m/zVlS1PgcOh7cs1Yq++fqEGVU0tU3Mmtkwdu
WcDZsQs4RV/JF9LwzfpDFVDUw7FRXtQlmrfCSZIc44B3vr0GmZO+eHfBsztHj/hgilKqX01L
EbrfkTHIAYRAfuNyW9w+C49KWN1h2G1yrb08DfaTFpe82KrGAr6xKDH8OL5THROKuV6GQf4G
dk+IJwfdBhQRqKZD0bm5fG65sXgxzYYQK63XxvdtXDGQiXwXSTWAcuGOJgruSunU2YsktGTP
ZrleW/qnEBhJ8dGRVH4ZYyNmzelGr2/tl0klSKKP9rM7zxWRID6xmx9ldIyIzbtZ4GTzdeXq
DxEb23al3r6jSCIXxHNKl7g9fwTMYUI0EnAGPJfSV1XnBPHt+1kwEKQ9rAbPqvtlyJanvzHN
55GqVi02n/X1d5rH9Z2JyLo4nCt13520UddNkevqtF/yO2XFLTbFYC5lmUf+IBShcKvSB1ni
twSOPf1p05mqZZAUEOmjBO8jIbChiEzA+1A514Prffm8Gw49ED/IrgP45FGpnzIp6tZAT8hK
k6PiTbGLhAOAjNeKkU5rk+Utw06iOlBXOuIw+lC4tjAIwOR3kEkFizX2T+F5E4oXukkiBd/B
Mfvo2gMm/37lA0kuMmGck7RZF3Ko61guSDPP8RP0wN7esCqC2/CkXZSCoXY9+xGtsDO3dZ/L
82/fTJwusQHrMnnu6pGGSNkCMVMFl9nZ1FXhE+L2DyYhSgJqg19M8MHfC5zXtAHpKNUjVLNq
GByu1SN6/l9Mci5HS6GYWjWvG83CSVMAr829SK6lhC6DAV6fMYlM9bYTwgprPzDePpgOacOY
zhrsswWkWtxA9mZvFYU338VMnZzw8iCeE1uOjdG9bL+MfErwMAGCU5AJaMUJC6UNRJePSD+c
/NYhA9o9UG/E5zecsJpwA6oWDdTfbFFDNd9sUS70EV5moyIBOoku9E3gXN9sBtx17C70Ea0x
xFIeAz7zefKi2UBW/ZKntMgu9BFeZiI18ttoJPvQidrf9R2ydhZtG/UUblTZz/Th1VPenuki
+HzX5YUsY+lR6bNni74f6e+k9XvUOcDIQoh54NQz9IjwAyHAnwZsGvagKZF5e5MT3DzotxA5
5Ca8B4RgRLkDE4FzO8VNo/WoJIW6V7WfOpAVwaPFWiAeP2JA9bY0Bx3rn6l+RAATJbTJDgM+
8HnyCxMltOghYT7w9vwNPvDNsxG3A4OJ1KcnVj16zPILe+p/lhN/SSl/m4eDe2R/6tkRde51
ZDIhLipWw6LsFwBv9knEbnc4AeZv7kYu9H5eZgWJhdoM9OTkjcTyJEAzOn86hMQscvxYv8Rz
wwYZSDLXKyZ+u6YrJn6Nlysmfo2XKyZ+jZczEaD8fwrDYcMLJouhHl04gY8THCdpQk5qbPkF
tR1D7I2g

/

  CREATE OR REPLACE PACKAGE BODY "PCKG_PLOGPARAM" IS

END pckg_PLOGPARAM;
/

  CREATE OR REPLACE PACKAGE BODY "PCKG_PLOG"
IS
    -------------------------------------------------------------------
    --
    --  Nom package        : pckg_PLOG
    --
    --  Objectif           : plog code
    --
    --  Version            : 3.0
    -------------------------------------------------------------------
    -- see package spec for history
    -------------------------------------------------------------------


    -------------------------------------------------------------------
    -- Variable global priv? au package
    -------------------------------------------------------------------
    /*
     * Copyright (C) LOG4PLSQL project team. All rights reserved.
     *
     * This software is published under the terms of the The LOG4PLSQL
     * Software License, a copy of which has been included with this
     * distribution in the LICENSE.txt file.
     * see: <http://log4plsql.sourceforge.net>  */

    -------------------------------------------------------------------

    LOG4PLSQL_VERSION   VARCHAR2(200) := '3.1.2.3';


    -------------------------------------------------------------------
    -- Code priv? au package
    -------------------------------------------------------------------
    -------------------------------------------------------------------

    --------------------------------------------------------------------
    FUNCTION GETNEXTID(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                 )
        RETURN DBG_TLOG.ID%TYPE
    IS
        TEMP   NUMBER;
    BEGIN
        SELECT   SLOG.NEXTVAL INTO TEMP FROM DUAL;

        RETURN TEMP;
    END GETNEXTID;


    ----------------------------------------------------------------------
    --function instrLast(ch1 varchar2, ch2 varchar2) return number
    --is
    --ret number := 0;
    --begin
    --    FOR i IN REVERSE 0..length(Ch1) LOOP
    --        if instr(substr(ch1,i),ch2) > 0 then
    --           return i;
    --        end if;
    --    end loop;
    --    return ret;
    --end;

    --------------------------------------------------------------------
    FUNCTION CALLEURNAME
        RETURN VARCHAR2
    IS
        ENDOFLINE    CONSTANT CHAR(1) := CHR(10);
        ENDOFFIELD   CONSTANT CHAR(1) := CHR(32);
        NBRLINE      NUMBER;
        PTFINLIGNE   NUMBER;
        PTDEBLIGNE   NUMBER;
        PTDEBCODE    NUMBER;
        PT1          NUMBER;
        CPT          NUMBER;
        ALLLINES     VARCHAR2(4000);
        RESULTAT     VARCHAR2(4000);
        LINE         VARCHAR2(4000);
        USERCODE     VARCHAR2(4000);
        MYNAME       VARCHAR2(2000) := '.PCKG_PLOG';
    BEGIN
        ALLLINES := DBMS_UTILITY.FORMAT_CALL_STACK;
        CPT := 2;
        PTFINLIGNE := LENGTH(ALLLINES);
        PTDEBLIGNE := PTFINLIGNE;

        WHILE PTFINLIGNE > 0
          AND PTDEBLIGNE > 83
        LOOP
            PTDEBLIGNE :=
                INSTR(ALLLINES
                    , ENDOFLINE
                    , -1
                    , CPT)
                + 1;
            CPT := CPT + 1;
            -- traite ligne
            LINE := SUBSTR(ALLLINES, PTDEBLIGNE, PTFINLIGNE - PTDEBLIGNE);
            PTDEBCODE :=
                INSTR(LINE
                    , ENDOFFIELD
                    , -1
                    , 1);
            USERCODE := SUBSTR(LINE, PTDEBCODE + 1);

            IF INSTR(USERCODE, MYNAME) = 0
            THEN
                IF CPT > 3
                THEN
                    RESULTAT := RESULTAT || '.';
                END IF;

                RESULTAT := RESULTAT || USERCODE;
            END IF;

            PTFINLIGNE := PTDEBLIGNE - 1;
        END LOOP;

        RETURN RESULTAT;
    END CALLEURNAME;


    --------------------------------------------------------------------
    FUNCTION GETDEFAULTCONTEXT
        -- Cette fonction est priv?, Elle retourne le contexte par default
        -- quand il n'est pas pr?ciss?
        RETURN LOG_CTX
    IS
        NEWCTX     LOG_CTX;
        LSECTION   DBG_TLOG.LSECTION%TYPE;
    BEGIN
        LSECTION := CALLEURNAME;
        NEWCTX := INIT(PSECTION => LSECTION);
        RETURN NEWCTX;
    END GETDEFAULTCONTEXT;



    --------------------------------------------------------------------
    PROCEDURE CHECKANDINITCTX(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                        )
    IS
        LSECTION   DBG_TLOG.LSECTION%TYPE;
    BEGIN
        IF PCTX.ISDEFAULTINIT = FALSE
        THEN
            LSECTION := CALLEURNAME;
            PCTX := INIT(PSECTION => LSECTION);
        END IF;
    END;



    --------------------------------------------------------------------
    PROCEDURE ADDROW(PID IN DBG_TLOG.ID%TYPE
                   , PLDATE IN DBG_TLOG.LDATE%TYPE
                   , PLHSECS IN DBG_TLOG.LHSECS%TYPE
                   , PLLEVEL IN DBG_TLOG.LLEVEL%TYPE
                   , PLSECTION IN DBG_TLOG.LSECTION%TYPE
                   , PLUSER IN DBG_TLOG.LUSER%TYPE
                   , PLTEXTE IN DBG_TLOG.LTEXTE%TYPE)
    IS
        G_LAST_ERRID   NUMBER(12, 0);
    BEGIN
        INSERT INTO DBG_TLOG(ID
                           , LDATE
                           , LHSECS
                           , LLEVEL
                           , LSECTION
                           , LUSER
                           , LTEXTE)
          VALUES   (PID
                  , PLDATE
                  , PLHSECS
                  , PLLEVEL
                  , PLSECTION
                  , PLUSER
                  , PLTEXTE);

        COMMIT;
    END;

    --------------------------------------------------------------------
    PROCEDURE ADDROWAUTONOMOUS(PID IN DBG_TLOG.ID%TYPE
                             , PLDATE IN DBG_TLOG.LDATE%TYPE
                             , PLHSECS IN DBG_TLOG.LHSECS%TYPE
                             , PLLEVEL IN DBG_TLOG.LLEVEL%TYPE
                             , PLSECTION IN DBG_TLOG.LSECTION%TYPE
                             , PLUSER IN DBG_TLOG.LUSER%TYPE
                             , PLTEXTE IN DBG_TLOG.LTEXTE%TYPE)
    IS
        PRAGMA AUTONOMOUS_TRANSACTION;
    BEGIN
        ADDROW(PID         => PID
             , PLDATE      => PLDATE
             , PLHSECS     => PLHSECS
             , PLLEVEL     => PLLEVEL
             , PLSECTION   => PLSECTION
             , PLUSER      => PLUSER
             , PLTEXTE     => PLTEXTE);
        COMMIT;
    EXCEPTION
        WHEN OTHERS
        THEN
            PCKG_PLOG.ERROR;
            ROLLBACK;
            RAISE;
    END;

    --------------------------------------------------------------------
    PROCEDURE LOG -- procedure priv? pour int?grer les donn?es dans la table
                  -- RAISE : -20503 'error DBMS_PIPE.send_message.
    (PCTX IN OUT NOCOPY LOG_CTX
   , -- Context
    PID IN         DBG_TLOG.ID%TYPE
   , PLDATE IN     DBG_TLOG.LDATE%TYPE
   , PLHSECS IN    DBG_TLOG.LHSECS%TYPE
   , PLLEVEL IN    DBG_TLOG.LLEVEL%TYPE
   , PLSECTION IN  DBG_TLOG.LSECTION%TYPE
   , PLUSER IN     DBG_TLOG.LUSER%TYPE
   , PLTEXTE IN    DBG_TLOG.LTEXTE%TYPE)
    IS
        RET       NUMBER;
        LLTEXTE   DBG_TLOG.LTEXTE%TYPE;
        PT        NUMBER;
    BEGIN
        IF PCTX.ISDEFAULTINIT = FALSE
        THEN
            PCKG_PLOG.ERROR('please is necessary to use pckg_plog.init for yours contexte.');
        END IF;

        IF PLTEXTE IS NULL
        THEN
            LLTEXTE := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
        ELSE
            BEGIN
                LLTEXTE := PLTEXTE;
            EXCEPTION
                WHEN VALUE_ERROR
                THEN
                    ASSERT(PCTX, LENGTH(PLTEXTE) <= 2000, 'Log Message id:' || PID || ' too long. ');
                    LLTEXTE := SUBSTR(PLTEXTE, 0, 2000);
                WHEN OTHERS
                THEN
                    PCKG_PLOG.FATAL();
            END;
        END IF;

        IF PCTX.USE_LOGTABLE = TRUE
        THEN
            IF PCTX.USE_OUT_TRANS = FALSE
            THEN
                ADDROW(PID         => PID
                     , PLDATE      => PLDATE
                     , PLHSECS     => PLHSECS
                     , PLLEVEL     => PLLEVEL
                     , PLSECTION   => PLSECTION
                     , PLUSER      => PLUSER
                     , PLTEXTE     => LLTEXTE);
            ELSE
                ADDROWAUTONOMOUS(PID         => PID
                               , PLDATE      => PLDATE
                               , PLHSECS     => PLHSECS
                               , PLLEVEL     => PLLEVEL
                               , PLSECTION   => PLSECTION
                               , PLUSER      => PLUSER
                               , PLTEXTE     => LLTEXTE);
            END IF;
        END IF;

        IF PCTX.USE_LOG4J = TRUE
        THEN
            DBMS_PIPE.PACK_MESSAGE(PID); -- SEQUENTIAL ID
            DBMS_PIPE.PACK_MESSAGE(PLDATE); -- TIMESTAMP OF LOG STATEMENT
            DBMS_PIPE.PACK_MESSAGE(MOD(PLHSECS, 100)); -- HUNDREDTHS OF SECONDS FOR TIMESTAMP
            DBMS_PIPE.PACK_MESSAGE(PLLEVEL); -- LOG LEVEL
            DBMS_PIPE.PACK_MESSAGE(PLSECTION); -- LOG SECTION - ANALOGUE TO LOG4J Logger NAME
            DBMS_PIPE.PACK_MESSAGE(LLTEXTE); -- LOG MESSAGE
            DBMS_PIPE.PACK_MESSAGE(PLUSER); -- CALLING USER
            DBMS_PIPE.PACK_MESSAGE('SAVE_IN_LOG'); -- MESSAGE TYPE?
            --DBMS_PIPE.pack_message(PMDC.getKeyString);      -- MAPPED DOMAIN CONTEXT KEYS FOR LOG4J
            --DBMS_PIPE.pack_message(PMDC.getValueString);    -- MAPPED DOMAIN CONTEXT VALUES FOR LOG4J
            --DBMS_PIPE.pack_message(PMDC.getSeparator);      -- MAPPED DOMAIN CONTEXT SEPARATOR FOR LOG4J

            --   ret := DBMS_PIPE.send_message(pCTX.DBMS_PIPE_NAME);
            --   IF RET <> 0 then
            --        raise_application_error(ERR_CODE_DBMS_PIPE, MES_CODE_DBMS_PIPE || RET);
            --   END IF;

            RET := DBMS_PIPE.SEND_MESSAGE(PCTX.DBMS_PIPE_NAME, 30, 1000000000);

            IF RET = 1
            THEN
                RET := DBMS_PIPE.SEND_MESSAGE(PCTX.DBMS_PIPE_NAME, 30, 1000000000);

                IF RET = 1
                THEN
                    DBMS_PIPE.PURGE(PCTX.DBMS_PIPE_NAME);
                ELSIF RET <> 0
                THEN
                    RAISE_APPLICATION_ERROR(ERR_CODE_DBMS_PIPE, MES_CODE_DBMS_PIPE || RET);
                END IF;
            END IF;
        END IF;

        IF PCTX.USE_ALERT = TRUE
        THEN
            SYS.DBMS_SYSTEM.KSDWRT(
                2
              ,    'PCKG_PLOG:'
                || TO_CHAR(PLDATE, 'YYYY-MM-DD HH24:MI:SS')
                || ':'
                || LTRIM(TO_CHAR(MOD(PLHSECS, 100), '09'))
                || ' user: '
                || PLUSER
                || ' level: '
                || GETLEVELINTEXT(PLLEVEL)
                || ' logid: '
                || PID
                || ' '
                || PLSECTION);
            SYS.DBMS_SYSTEM.KSDWRT(2, SUBSTR(LLTEXTE, 0, 1000));

            IF (LENGTH(LLTEXTE) >= 1000)
            THEN
                SYS.DBMS_SYSTEM.KSDWRT(2, SUBSTR(LLTEXTE, 1000));
            END IF;
        END IF;

        IF PCTX.USE_TRACE = TRUE
        THEN
            SYS.DBMS_SYSTEM.KSDWRT(
                1
              ,    'PCKG_PLOG:'
                || TO_CHAR(PLDATE, 'YYYY-MM-DD HH24:MI:SS')
                || ':'
                || LTRIM(TO_CHAR(MOD(PLHSECS, 100), '09'))
                || ' user: '
                || PLUSER
                || ' level: '
                || GETLEVELINTEXT(PLLEVEL)
                || ' logid: '
                || PID
                || ' '
                || PLSECTION);
            SYS.DBMS_SYSTEM.KSDWRT(1, SUBSTR(LLTEXTE, 0, 1000));

            IF (LENGTH(LLTEXTE) >= 1000)
            THEN
                SYS.DBMS_SYSTEM.KSDWRT(1, SUBSTR(LLTEXTE, 1000));
            END IF;
        END IF;

        IF PCTX.USE_DBMS_OUTPUT = TRUE
        THEN
            DECLARE
                PT         NUMBER;
                HDR        VARCHAR2(4000);
                HDR_LEN    PLS_INTEGER;
                LINE_LEN   PLS_INTEGER;
                WRAP       NUMBER := PCTX.DBMS_OUTPUT_WRAP; --length to wrap long text.
            BEGIN
                HDR := TO_CHAR(PLDATE, 'HH24:MI:SS') || ':' || LTRIM(TO_CHAR(MOD(PLHSECS, 100), '09')) || '-' || GETLEVELINTEXT(PLLEVEL) || '-' || PLSECTION || '  ';
                HDR_LEN := LENGTH(HDR);
                LINE_LEN := WRAP - HDR_LEN;
                SYS.DBMS_OUTPUT.PUT(HDR);
                PT := 1;

                WHILE PT <= LENGTH(LLTEXTE)
                LOOP
                    IF PT = 1
                    THEN
                        SYS.DBMS_OUTPUT.PUT_LINE(SUBSTR(LLTEXTE, PT, LINE_LEN));
                    ELSE
                        SYS.DBMS_OUTPUT.PUT_LINE(LPAD(' ', HDR_LEN) || SUBSTR(LLTEXTE, PT, LINE_LEN));
                    END IF;

                    PT := PT + LINE_LEN;
                END LOOP;
            END;
        END IF;
    END LOG;



    -------------------------------------------------------------------
    -------------------------------------------------------------------
    -- Code public du package
    -------------------------------------------------------------------
    -------------------------------------------------------------------


    --------------------------------------------------------------------
    FUNCTION INIT -- initialisation du contexte
                 (PSECTION IN DBG_TLOG.LSECTION%TYPE DEFAULT NULL
                , -- log section
                 PLEVEL IN DBG_TLOG.LLEVEL%TYPE DEFAULT PCKG_PLOGPARAM.DEFAULT_LEVEL
                , -- log level (Use only for debug)
                 PLOG4J IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_USE_LOG4J
                , -- if true the log is send to log4j
                 PLOGTABLE IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_LOG_TABLE
                , -- if true the log is insert into tlog
                 POUT_TRANS IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_LOG_OUT_TRANS
                , -- if true the log is in transactional log
                 PALERT IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_LOG_ALERT
                , -- if true the log is write in alert.log
                 PTRACE IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_LOG_TRACE
                , -- if true the log is write in trace file
                 PDBMS_OUTPUT IN BOOLEAN DEFAULT PCKG_PLOGPARAM.DEFAULT_DBMS_OUTPUT
                , -- if true the log is send in standard output (DBMS_OUTPUT.PUT_LINE)
                 PDBMS_PIPE_NAME IN VARCHAR2 DEFAULT PCKG_PLOGPARAM.DEFAULT_DBMS_PIPE_NAME
                , -- name of pipe to log to for Log4J output
                 PDBMS_OUTPUT_WRAP IN PLS_INTEGER DEFAULT PCKG_PLOGPARAM.DEFAULT_DBMS_OUTPUT_LINE_WRAP -- length to wrap output to when using DBMS_OUTPUT
                                                                                                      )
        RETURN LOG_CTX
    IS
        PCTX   LOG_CTX;
    BEGIN
        PCTX.ISDEFAULTINIT := TRUE;
        PCTX.LSECTION := NVL(PSECTION, CALLEURNAME);
        PCTX.INIT_LSECTION := PSECTION;
        PCTX.LLEVEL := PLEVEL;
        PCTX.INIT_LLEVEL := PLEVEL;
        PCTX.USE_LOG4J := PLOG4J;
        PCTX.USE_OUT_TRANS := POUT_TRANS;
        PCTX.USE_LOGTABLE := PLOGTABLE;
        PCTX.USE_ALERT := PALERT;
        PCTX.USE_TRACE := PTRACE;
        PCTX.USE_DBMS_OUTPUT := PDBMS_OUTPUT;
        PCTX.DBMS_PIPE_NAME := PDBMS_PIPE_NAME;
        PCTX.DBMS_OUTPUT_WRAP := PDBMS_OUTPUT_WRAP;

        RETURN PCTX;
    END INIT;

    --------------------------------------------------------------------
    PROCEDURE SETBEGINSECTION -- initialisation d'un debut de niveaux hierarchique de log
                             (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                         PSECTION IN DBG_TLOG.LSECTION%TYPE -- Texte du log
                                                                                           )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        PCTX.LSECTION := PCTX.LSECTION || PCKG_PLOGPARAM.DEFAULT_SECTION_SEP || PSECTION;
    END SETBEGINSECTION;

    --------------------------------------------------------------------
    FUNCTION GETSECTION -- renvoie la section en cours
                       (PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                  )
        RETURN DBG_TLOG.LSECTION%TYPE
    IS
    BEGIN
        RETURN PCTX.LSECTION;
    END GETSECTION;


    --------------------------------------------------------------------
    FUNCTION GETSECTION
        -- renvoie la section en cours
        RETURN DBG_TLOG.LSECTION%TYPE
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETSECTION(PCTX => GENERIQUECTX);
    END GETSECTION;


    --------------------------------------------------------------------
    PROCEDURE SETENDSECTION -- fin d'un niveau hierarchique de log et dee  tout c'est sup?rieur
                            -- par default [/]
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                PSECTION IN DBG_TLOG.LSECTION%TYPE DEFAULT 'EndAllSection' -- Texte du log
                                                                                          )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);

        IF PSECTION = 'EndAllSection'
        THEN
            PCTX.LSECTION := NVL(PCTX.INIT_LSECTION, CALLEURNAME);
            RETURN;
        END IF;

        PCTX.LSECTION := SUBSTR(PCTX.LSECTION, 1, INSTR(UPPER(PCTX.LSECTION), UPPER(PSECTION), -1) - 2);
    END SETENDSECTION;



    -------------------------------------------------------------------
    PROCEDURE SETTRANSACTIONMODE -- utlisation des log dans ou en dehors des transactions
                                 -- TRUE => Les log sont dans la transaction
                                 -- FALSE => les log sont en dehors de la transaction
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                INTRANSACTION IN BOOLEAN DEFAULT TRUE -- TRUE => Les log sont dans la transaction,
                                                                      -- FALSE => les log sont en dehors de la transaction
    )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        PCTX.USE_OUT_TRANS := INTRANSACTION;
    END SETTRANSACTIONMODE;


    -------------------------------------------------------------------
    FUNCTION GETTRANSACTIONMODE -- TRUE => Les log sont dans la transaction
                                -- FALSE => les log sont en dehors de la transaction
    (PCTX IN OUT NOCOPY LOG_CTX -- Context
                               )
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN PCTX.USE_OUT_TRANS;
    END GETTRANSACTIONMODE;

    -------------------------------------------------------------------
    FUNCTION GETTRANSACTIONMODE
        RETURN BOOLEAN
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETTRANSACTIONMODE(PCTX => GENERIQUECTX);
    END GETTRANSACTIONMODE;


    -------------------------------------------------------------------
    PROCEDURE SETUSE_LOG4JMODE --TRUE => Log is send to USE_LOG4J
                               --FALSE => Log is not send to USE_LOG4J
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                INUSE_LOG4J IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to USE_LOG4J,
                                                                    -- FALSE => Log is not send to USE_LOG4J
    )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        PCTX.USE_LOG4J := INUSE_LOG4J;
    END SETUSE_LOG4JMODE;


    -------------------------------------------------------------------
    FUNCTION GETUSE_LOG4JMODE --TRUE => Log is send to USE_LOG4J
                              --FALSE => Log is not send to USE_LOG4J
    (PCTX IN OUT NOCOPY LOG_CTX -- Context
                               )
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN PCTX.USE_LOG4J;
    END GETUSE_LOG4JMODE;

    -------------------------------------------------------------------
    FUNCTION GETUSE_LOG4JMODE
        RETURN BOOLEAN
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETTRANSACTIONMODE(PCTX => GENERIQUECTX);
    END GETUSE_LOG4JMODE;


    -------------------------------------------------------------------
    PROCEDURE SETLOG_TABLEMODE --TRUE => Log is send to LOG_TABLEMODE
                               --FALSE => Log is not send to LOG_TABLEMODE
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                INLOG_TABLE IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to LOG_TABLEMODE,
                                                                    -- FALSE => Log is not send to LOG_TABLEMODE
    )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        PCTX.USE_LOGTABLE := INLOG_TABLE;
    END SETLOG_TABLEMODE;


    -------------------------------------------------------------------
    FUNCTION GETLOG_TABLEMODE --TRUE => Log is send to LOG_TABLEMODE
                              --FALSE => Log is not send to LOG_TABLEMODE
    (PCTX IN OUT NOCOPY LOG_CTX -- Context
                               )
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN PCTX.USE_LOGTABLE;
    END GETLOG_TABLEMODE;

    -------------------------------------------------------------------
    FUNCTION GETLOG_TABLEMODE
        RETURN BOOLEAN
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETTRANSACTIONMODE(PCTX => GENERIQUECTX);
    END GETLOG_TABLEMODE;



    -------------------------------------------------------------------
    PROCEDURE SETLOG_ALERTMODE --TRUE => Log is send to LOG_ALERT
                               --FALSE => Log is not send to LOG_ALERT
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                INLOG_ALERT IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to LOG_ALERT,
                                                                    -- FALSE => Log is not send to LOG_ALERT
    )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        PCTX.USE_ALERT := INLOG_ALERT;
    END SETLOG_ALERTMODE;


    -------------------------------------------------------------------
    FUNCTION GETLOG_ALERTMODE --TRUE => Log is send to LOG_ALERT
                              --FALSE => Log is not send to LOG_ALERT
    (PCTX IN OUT NOCOPY LOG_CTX -- Context
                               )
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN PCTX.USE_ALERT;
    END GETLOG_ALERTMODE;

    -------------------------------------------------------------------
    FUNCTION GETLOG_ALERTMODE
        RETURN BOOLEAN
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETTRANSACTIONMODE(PCTX => GENERIQUECTX);
    END GETLOG_ALERTMODE;



    -------------------------------------------------------------------
    PROCEDURE SETLOG_TRACEMODE --TRUE => Log is send to LOG_TRACE
                               --FALSE => Log is not send to LOG_TRACE
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                INLOG_TRACE IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to LOG_TRACE,
                                                                    -- FALSE => Log is not send to LOG_TRACE
    )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        PCTX.USE_TRACE := INLOG_TRACE;
    END SETLOG_TRACEMODE;


    -------------------------------------------------------------------
    FUNCTION GETLOG_TRACEMODE --TRUE => Log is send to LOG_TRACE
                              --FALSE => Log is not send to LOG_TRACE
    (PCTX IN OUT NOCOPY LOG_CTX -- Context
                               )
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN PCTX.USE_TRACE;
    END GETLOG_TRACEMODE;

    -------------------------------------------------------------------
    FUNCTION GETLOG_TRACEMODE
        RETURN BOOLEAN
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETTRANSACTIONMODE(PCTX => GENERIQUECTX);
    END GETLOG_TRACEMODE;


    -------------------------------------------------------------------
    PROCEDURE SETDBMS_OUTPUTMODE --TRUE => Log is send to DBMS_OUTPUT
                                 --FALSE => Log is not send to DBMS_OUTPUT
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                INDBMS_OUTPUT IN BOOLEAN DEFAULT TRUE -- TRUE => Log is send to DBMS_OUTPUT,
                                                                      -- FALSE => Log is not send to DBMS_OUTPUT
    )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        PCTX.USE_DBMS_OUTPUT := INDBMS_OUTPUT;
    END SETDBMS_OUTPUTMODE;


    -------------------------------------------------------------------
    FUNCTION GETDBMS_OUTPUTMODE --TRUE => Log is send to DBMS_OUTPUT
                                --FALSE => Log is not send to DBMS_OUTPUT
    (PCTX IN OUT NOCOPY LOG_CTX -- Context
                               )
        RETURN BOOLEAN
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        RETURN PCTX.USE_DBMS_OUTPUT;
    END GETDBMS_OUTPUTMODE;

    -------------------------------------------------------------------
    FUNCTION GETDBMS_OUTPUTMODE
        RETURN BOOLEAN
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETTRANSACTIONMODE(PCTX => GENERIQUECTX);
    END GETDBMS_OUTPUTMODE;



    -------------------------------------------------------------------
    PROCEDURE SETLEVEL -- il est possible de modifier avec setLevell  dynamiquement le niveau de log
                       -- l'appel de setLevel sans paramettre re-poossitionne le niveaux a celuis specifier
                       -- dans le package.
                       -- erreur possible : -20501, 'Set Level not in LOG predefine constantes'
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                PLEVEL IN DBG_TLOG.LLEVEL%TYPE DEFAULT NOLEVEL -- Level sup?rieur attribuer dynamiquement
                                                                              )
    IS
        NBRL   NUMBER;
    BEGIN
        CHECKANDINITCTX(PCTX);

        IF PLEVEL = NOLEVEL
        THEN
            PCTX.LLEVEL := PCTX.INIT_LLEVEL;
        END IF;

        SELECT   COUNT( * )
          INTO   NBRL
          FROM   DBG_TLOGLEVEL
         WHERE   DBG_TLOGLEVEL.LLEVEL = PLEVEL;

        IF NBRL > 0
        THEN
            PCTX.LLEVEL := PLEVEL;
        ELSE
            RAISE_APPLICATION_ERROR(-20501, 'SetLevel (' || PLEVEL || ') not in TLOGLEVEL table');
        END IF;
    EXCEPTION
        WHEN OTHERS
        THEN
            PCKG_PLOG.ERROR;
    END SETLEVEL;

    PROCEDURE SETLEVEL -- il est possible de modifier avec setLevell  dynamiquement le niveau de log
                       -- l'appel de setLevel sans paramettre re-poossitionne le niveaux a celuis specifier
                       -- dans le package.
                       -- erreur possible : -20501, 'Set Level not in LOG predefine constantes'
    (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                PLEVEL IN DBG_TLOGLEVEL.LCODE%TYPE -- Level sup?rieur attribuer dynamiquement
                                                                  )
    IS
        NBRL   NUMBER;
    BEGIN
        SETLEVEL(PCTX, GETTEXTINLEVEL(PLEVEL));
    END SETLEVEL;


    -------------------------------------------------------------------
    FUNCTION GETLEVEL -- Retourne le level courant
                     (PCTX IN LOG_CTX -- Context
                                     )
        RETURN DBG_TLOG.LLEVEL%TYPE
    IS
    BEGIN
        RETURN PCTX.LLEVEL;
    END GETLEVEL;

    FUNCTION GETLEVEL
        RETURN DBG_TLOG.LLEVEL%TYPE
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETLEVEL(PCTX => GENERIQUECTX);
    END GETLEVEL;


    -------------------------------------------------------------------------
    FUNCTION ISLEVELENABLED -- fonction outil appeler par les is[Debug|Info|Warn|Error]Enabled
                           (PCTX IN LOG_CTX, -- Context
                                            PLEVEL IN DBG_TLOG.LLEVEL%TYPE -- Level a tester
                                                                          )
        RETURN BOOLEAN
    IS
    BEGIN
        IF GETLEVEL(PCTX) >= PLEVEL
        THEN
            RETURN TRUE;
        ELSE
            RETURN FALSE;
        END IF;
    END ISLEVELENABLED;

    FUNCTION ISLEVELENABLED(PLEVEL IN DBG_TLOG.LLEVEL%TYPE -- Level a tester
                                                          )
        RETURN BOOLEAN
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN ISLEVELENABLED(PCTX => GENERIQUECTX, PLEVEL => PLEVEL);
    END ISLEVELENABLED;

    -------------------------------------------------------------------
    FUNCTION ISFATALENABLED
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(GETTEXTINLEVEL('FATAL'));
    END;

    FUNCTION ISERRORENABLED
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(GETTEXTINLEVEL('ERROR'));
    END;

    FUNCTION ISWARNENABLED
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(GETTEXTINLEVEL('WARN'));
    END;

    FUNCTION ISINFOENABLED
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(GETTEXTINLEVEL('INFO'));
    END;

    FUNCTION ISDEBUGENABLED
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(GETTEXTINLEVEL('DEBUG'));
    END;

    FUNCTION ISFATALENABLED(PCTX IN LOG_CTX)
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(PCTX, GETTEXTINLEVEL('FATAL'));
    END;

    FUNCTION ISERRORENABLED(PCTX IN LOG_CTX)
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(PCTX, GETTEXTINLEVEL('ERROR'));
    END;

    FUNCTION ISWARNENABLED(PCTX IN LOG_CTX)
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(PCTX, GETTEXTINLEVEL('WARN'));
    END;

    FUNCTION ISINFOENABLED(PCTX IN LOG_CTX)
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(PCTX, GETTEXTINLEVEL('INFO'));
    END;

    FUNCTION ISDEBUGENABLED(PCTX IN LOG_CTX)
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN ISLEVELENABLED(PCTX, GETTEXTINLEVEL('DEBUG'));
    END;



    --------------------------------------------------------------------
    PROCEDURE PURGE
    --  Purge de la log
    IS
        TEMPLOGCTX   PCKG_PLOG.LOG_CTX;
    BEGIN
        PURGE(TEMPLOGCTX);
    END PURGE;

    --------------------------------------------------------------------
    PROCEDURE PURGE --  Purge de la log
                   (PCTX IN OUT NOCOPY LOG_CTX -- Context
                                              )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);

        EXECUTE IMMEDIATE ('truncate table dbg_tlog');

        PURGE(PCTX, SYSDATE + 1);
    END PURGE;


    --------------------------------------------------------------------
    PROCEDURE PURGE --  Purge de la log avec date max
                   (PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                               DATEMAX IN DATE -- Tout les enregistrements supperieur a
                                                               -- la date sont purg?
    )
    IS
        TEMPLOGCTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.INIT(PSECTION => 'pckg_plog.purge', PLEVEL => PCKG_PLOG.LINFO);
    BEGIN
        CHECKANDINITCTX(PCTX);

        DELETE FROM   DBG_TLOG
              WHERE   LDATE < DATEMAX;

        INFO(TEMPLOGCTX, 'Purge by user:' || USER);
    END PURGE;



    --------------------------------------------------------------------
    PROCEDURE LOG(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                             PLEVEL IN DBG_TLOG.LLEVEL%TYPE, -- log level
                                                                            PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT DEFAULTEXTMESS -- log text
                                                                                                                                 )
    IS
        LID         DBG_TLOG.ID%TYPE;
        LLSECTION   DBG_TLOG.LSECTION%TYPE := GETSECTION(PCTX);
        LLHSECS     DBG_TLOG.LHSECS%TYPE;
        M           VARCHAR2(100);
    BEGIN
        CHECKANDINITCTX(PCTX);

        IF PLEVEL > GETLEVEL(PCTX)
        THEN
            RETURN;
        END IF;

        LID := GETNEXTID(PCTX);

        LOG(PCTX        => PCTX
          , PID         => LID
          , PLDATE      => SYSDATE
          , PLHSECS     => DBMS_UTILITY.GET_TIME
          , PLLEVEL     => PLEVEL
          , PLSECTION   => LLSECTION
          , PLUSER      => USER
          , PLTEXTE     => PTEXTE);
    END LOG;

    PROCEDURE LOG(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                             PLEVEL IN DBG_TLOGLEVEL.LCODE%TYPE, -- log level
                                                                                PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT DEFAULTEXTMESS -- log text
                                                                                                                                     )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL(PLEVEL), PCTX => PCTX, PTEXTE => PTEXTE);
    END LOG;


    PROCEDURE LOG(PLEVEL IN DBG_TLOG.LLEVEL%TYPE, -- log level
                                                 PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT DEFAULTEXTMESS -- log text
                                                                                                      )
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        LOG(PLEVEL => PLEVEL, PCTX => GENERIQUECTX, PTEXTE => PTEXTE);
    END LOG;

    PROCEDURE LOG(PLEVEL IN DBG_TLOGLEVEL.LCODE%TYPE, -- log level
                                                     PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT DEFAULTEXTMESS -- log text
                                                                                                          )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL(PLEVEL), PTEXTE => PTEXTE);
    END LOG;

    --------------------------------------------------------------------
    PROCEDURE DEBUG(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                               PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                          )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('DEBUG'), PCTX => PCTX, PTEXTE => PTEXTE);
    END DEBUG;

    PROCEDURE DEBUG(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                               )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('DEBUG'), PTEXTE => PTEXTE);
    END DEBUG;

    --------------------------------------------------------------------
    PROCEDURE INFO(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                              PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                         )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('INFO'), PCTX => PCTX, PTEXTE => PTEXTE);
    END INFO;

    PROCEDURE INFO(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                              )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('INFO'), PTEXTE => PTEXTE);
    END INFO;

    --------------------------------------------------------------------
    PROCEDURE WARN(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                              PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                         )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('WARN'), PCTX => PCTX, PTEXTE => PTEXTE);
    END WARN;

    PROCEDURE WARN(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                              )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('WARN'), PTEXTE => PTEXTE);
    END WARN;

    --------------------------------------------------------------------
    PROCEDURE ERROR(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                               PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                          )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('ERROR'), PCTX => PCTX, PTEXTE => PTEXTE);
    END ERROR;

    PROCEDURE ERROR(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                               )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('ERROR'), PTEXTE => PTEXTE);
    END ERROR;

    --------------------------------------------------------------------
    PROCEDURE FATAL(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                               PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                                                          )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('FATAL'), PCTX => PCTX, PTEXTE => PTEXTE);
    END FATAL;

    PROCEDURE FATAL(PTEXTE IN DBG_TLOG.LTEXTE%TYPE DEFAULT NULL -- log text
                                                               )
    IS
    BEGIN
        LOG(PLEVEL => GETTEXTINLEVEL('FATAL'), PTEXTE => PTEXTE);
    END FATAL;

    --------------------------------------------------------------------
    PROCEDURE ASSERT(PCTX IN OUT NOCOPY LOG_CTX
                   , -- Context
                    PCONDITION IN  BOOLEAN
                   , -- error condition
                    PLOGERRORMESSAGEIFFALSE IN VARCHAR2 DEFAULT 'assert condition error'
                   , -- message if pCondition is true
                    PLOGERRORCODEIFFALSE IN NUMBER DEFAULT -20000
                   , -- error code is pCondition is true range -20000 .. -20999
                    PRAISEEXCEPTIONIFFALSE IN BOOLEAN DEFAULT FALSE
                   , -- if true raise pException_in if pCondition is true
                    PLOGERRORREPLACEERROR IN BOOLEAN DEFAULT FALSE -- TRUE, the error is placed on the stack of previous errors.
                                                                  -- If FALSE (the default), the error replaces all previous errors
                                                                  -- see Oracle Documentation RAISE_APPLICATION_ERROR

                     )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);

        IF NOT ISLEVELENABLED(PCTX, PCKG_PLOGPARAM.DEFAULT_ASSET_LEVEL)
        THEN
            RETURN;
        END IF;

        IF NOT PCONDITION
        THEN
            LOG(PLEVEL => PCKG_PLOGPARAM.DEFAULT_ASSET_LEVEL, PCTX => PCTX, PTEXTE => 'AAS' || PLOGERRORCODEIFFALSE || ': ' || PLOGERRORMESSAGEIFFALSE);

            IF PRAISEEXCEPTIONIFFALSE
            THEN
                RAISE_APPLICATION_ERROR(PLOGERRORCODEIFFALSE, PLOGERRORMESSAGEIFFALSE, PLOGERRORREPLACEERROR);
            END IF;
        END IF;
    END ASSERT;


    PROCEDURE ASSERT(PCONDITION IN BOOLEAN
                   , -- error condition
                    PLOGERRORMESSAGEIFFALSE IN VARCHAR2 DEFAULT 'assert condition error'
                   , -- message if pCondition is true
                    PLOGERRORCODEIFFALSE IN NUMBER DEFAULT -20000
                   , -- error code is pCondition is true range -20000 .. -20999
                    PRAISEEXCEPTIONIFFALSE IN BOOLEAN DEFAULT FALSE
                   , -- if true raise pException_in if pCondition is true
                    PLOGERRORREPLACEERROR IN BOOLEAN DEFAULT FALSE -- TRUE, the error is placed on the stack of previous errors.
                                                                  -- If FALSE (the default), the error replaces all previous errors
                                                                  -- see Oracle Documentation RAISE_APPLICATION_ERROR
                     )
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        ASSERT(PCTX                      => GENERIQUECTX
             , PCONDITION                => PCONDITION
             , PLOGERRORCODEIFFALSE      => PLOGERRORCODEIFFALSE
             , PLOGERRORMESSAGEIFFALSE   => PLOGERRORMESSAGEIFFALSE
             , PRAISEEXCEPTIONIFFALSE    => PRAISEEXCEPTIONIFFALSE
             , PLOGERRORREPLACEERROR     => PLOGERRORREPLACEERROR);
    END ASSERT;

    --------------------------------------------------------------------
    PROCEDURE FULL_CALL_STACK
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        FULL_CALL_STACK(PCTX => GENERIQUECTX);
    END FULL_CALL_STACK;


    PROCEDURE FULL_CALL_STACK(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                        )
    IS
    BEGIN
        CHECKANDINITCTX(PCTX);
        LOG(PLEVEL => PCKG_PLOGPARAM.DEFAULT_FULL_CALL_STACK_LEVEL, PCTX => PCTX, PTEXTE => DBMS_UTILITY.FORMAT_CALL_STACK);
    END FULL_CALL_STACK;

    --------------------------------------------------------------------
    FUNCTION GETLOG4PLSQVERSION
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN LOG4PLSQL_VERSION;
    END GETLOG4PLSQVERSION;

    --------------------------------------------------------------------
    FUNCTION GETLEVELINTEXT(PLEVEL DBG_TLOG.LLEVEL%TYPE DEFAULT PCKG_PLOGPARAM.DEFAULT_LEVEL)
        RETURN VARCHAR2
    IS
        RET   VARCHAR2(1000);
    BEGIN
        SELECT   LCODE
          INTO   RET
          FROM   DBG_TLOGLEVEL
         WHERE   LLEVEL = PLEVEL;

        RETURN RET;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 'UNDEFINED';
    END GETLEVELINTEXT;

    --------------------------------------------------------------------
    FUNCTION GETTEXTINLEVEL(PCODE DBG_TLOGLEVEL.LCODE%TYPE)
        RETURN DBG_TLOG.LLEVEL%TYPE
    IS
        RET   DBG_TLOG.LLEVEL%TYPE;
    BEGIN
        SELECT   LLEVEL
          INTO   RET
          FROM   DBG_TLOGLEVEL
         WHERE   LCODE = PCODE;

        RETURN RET;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN PCKG_PLOGPARAM.DEFAULT_LEVEL;
    END GETTEXTINLEVEL;



    FUNCTION GETDBMS_PIPE_NAME(PCTX IN OUT NOCOPY LOG_CTX -- Context
                                                         )
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN PCTX.DBMS_PIPE_NAME;
    END GETDBMS_PIPE_NAME;

    FUNCTION GETDBMS_PIPE_NAME
        RETURN VARCHAR2
    IS
        GENERIQUECTX   PCKG_PLOG.LOG_CTX := PCKG_PLOG.GETDEFAULTCONTEXT;
    BEGIN
        RETURN GETDBMS_PIPE_NAME(PCTX => GENERIQUECTX);
    END GETDBMS_PIPE_NAME;


    PROCEDURE SETDBMS_PIPE_NAME(PCTX IN OUT NOCOPY LOG_CTX, -- Context
                                                           INDBMS_PIPE_NAME IN VARCHAR2)
    IS
    BEGIN
        PCTX.DBMS_PIPE_NAME := INDBMS_PIPE_NAME;
    END SETDBMS_PIPE_NAME;

    PROCEDURE SETPROCPARAMS(PROCEDURE_NAME_IN IN SYS.ALL_ARGUMENTS.OBJECT_NAME%TYPE, ALL_ARGUMENTS_IN IN PCKG_PLOG.T_VARCHAR2)
    IS
        IERROR    PLS_INTEGER := 1;
        PLHSECS   DBG_TLOG.LHSECS%TYPE;

        CURSOR C1
        IS
              SELECT   A.ARGUMENT_NAME, A.DATA_TYPE
                FROM   SYS.ALL_ARGUMENTS A
               WHERE   UPPER(A.OBJECT_NAME) = UPPER(PROCEDURE_NAME_IN)
                   AND A.OWNER = C_PCKG_OWNER
                   AND A.DATA_TYPE != 'PL/SQL TABLE'
            ORDER BY   A.POSITION;
    BEGIN
        SELECT   MAX(DBG_TLOG.LHSECS) INTO PLHSECS FROM DBG_TLOG;

        FOR R1 IN ALL_ARGUMENTS_IN.FIRST .. ALL_ARGUMENTS_IN.LAST
        LOOP
            EXIT WHEN IERROR > ALL_ARGUMENTS_IN.COUNT;

            INSERT INTO DBG_TLOG_ATTRS(ERRID
                                              , ATTR_TYPE
                                              , ATTR_NAME
                                              , FMT_TYPE
                                              , CVALUE)
              VALUES   (PLHSECS
                      , 'Arg'
                      , 'ARGUMENT' --R1.ARGUMENT_NAME
                      , PROCEDURE_NAME_IN
                      , ALL_ARGUMENTS_IN(IERROR));

            IERROR := IERROR + 1;
        END LOOP;

        COMMIT;
    END SETPROCPARAMS;
--------------------------------------------------------------------
--------------------------------------------------------------------
END PCKG_PLOG;
/

  CREATE OR REPLACE PACKAGE BODY "PCKG_PMDC"
AS
    -------------------------------------------------------------------
    --
    --  Nom package        : PMDC
    --
    --  Objectif           : MDC Features
    --
    --  Version            : 1.0
    -------------------------------------------------------------------
    -- see package spec for history
    -------------------------------------------------------------------


    -------------------------------------------------------------------
    -- Variable global priv? au package
    -------------------------------------------------------------------
    /*
     * Copyright (C) LOG4PLSQL project team. All rights reserved.
     *
     * This software is published under the terms of the The LOG4PLSQL
     * Software License, a copy of which has been included with this
     * distribution in the LICENSE.txt file.
     * see: <http://log4plsql.sourceforge.net>  */

    -------------------------------------------------------------------





    GSEPARATOR   CONSTANT VARCHAR2(1) := CHR(29);
    GSEPLENGTH   PLS_INTEGER := LENGTH(GSEPARATOR);

    GKEYS        VARCHAR2(4096) := GSEPARATOR;
    GVALUES      VARCHAR2(4096) := GSEPARATOR;

    --
    FUNCTION GETPOS(PKEY VARCHAR2)
        RETURN PLS_INTEGER
    IS
        CNT   PLS_INTEGER := 0;
        POS   PLS_INTEGER := 0;
        SEP   PLS_INTEGER := 1;
    BEGIN
        IF GKEYS = GSEPARATOR
        THEN
            RETURN 0;
        END IF;

        POS := INSTR(GKEYS, PKEY || GSEPARATOR);

        IF POS = 0
        THEN
            RETURN 0;
        END IF;

        --
        WHILE SEP > 0
          AND SEP <= POS
        LOOP
            CNT := CNT + 1;
            SEP := INSTR(GKEYS, GSEPARATOR, SEP + GSEPLENGTH);
        END LOOP;

        RETURN CNT;
    END GETPOS;

    --
    PROCEDURE PUT(PKEY VARCHAR2, PVALUE VARCHAR2)
    IS
        IDX        PLS_INTEGER := 0;
        POSSTART   PLS_INTEGER := 0;
    BEGIN
        IDX := GETPOS(PKEY);

        IF IDX = 0
        THEN -- new key, add to end
            GKEYS := GKEYS || PKEY || GSEPARATOR;
            GVALUES := GVALUES || PVALUE || GSEPARATOR;
        ELSE -- replace value for existing key
            POSSTART :=
                INSTR(GVALUES
                    , GSEPARATOR
                    , 1
                    , IDX);
            GVALUES :=
                   SUBSTR(GVALUES, 1, POSSTART + (GSEPLENGTH - 1))
                || PVALUE
                || SUBSTR(GVALUES, INSTR(GVALUES
                                       , GSEPARATOR
                                       , POSSTART + GSEPLENGTH
                                       , 1));
        END IF;
    END PUT;

    --
    FUNCTION GET(PKEY VARCHAR2)
        RETURN VARCHAR2
    IS
        IDX      PLS_INTEGER := 0;
        LSTART   PLS_INTEGER := 0;
        LEND     PLS_INTEGER := 0;
    BEGIN
        IDX := GETPOS(PKEY);

        IF IDX = 0
        THEN
            RETURN '';
        END IF;

        --
        LSTART :=
            INSTR(GVALUES
                , GSEPARATOR
                , 1
                , IDX);
        LEND :=
            INSTR(GVALUES
                , GSEPARATOR
                , LSTART + GSEPLENGTH
                , 1);
        RETURN SUBSTR(GVALUES, LSTART + GSEPLENGTH, LEND - LSTART - GSEPLENGTH);
    END GET;

    --
    PROCEDURE REMOVE(PKEY VARCHAR2)
    IS
        IDX      PLS_INTEGER := 0;
        LSTART   PLS_INTEGER := 0;
        LEND     PLS_INTEGER := 0;
    BEGIN
        IDX := GETPOS(PKEY);

        IF IDX = 0
        THEN
            RETURN;
        END IF; -- key doesn't exist, nothing to do.

        --
        LSTART :=
            INSTR(GVALUES
                , GSEPARATOR
                , 1
                , IDX);
        LEND :=
            INSTR(GVALUES
                , GSEPARATOR
                , LSTART + GSEPLENGTH
                , 1);
        GVALUES := SUBSTR(GVALUES, 1, LSTART) || SUBSTR(GVALUES, LEND + GSEPLENGTH);
        --
        LSTART :=
            INSTR(GKEYS
                , GSEPARATOR
                , 1
                , IDX);
        LEND :=
            INSTR(GKEYS
                , GSEPARATOR
                , LSTART + GSEPLENGTH
                , 1);
        GKEYS := SUBSTR(GKEYS, 1, LSTART) || SUBSTR(GKEYS, LEND + GSEPLENGTH);
    END REMOVE;

    --
    FUNCTION GETKEYSTRING
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN GKEYS;
    END GETKEYSTRING;

    --
    FUNCTION GETVALUESTRING
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN GVALUES;
    END GETVALUESTRING;

    --
    FUNCTION GETSEPARATOR
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN GSEPARATOR;
    END GETSEPARATOR;
--
END PCKG_PMDC;
/

  CREATE OR REPLACE PACKAGE BODY "PCKG_SNFR" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
5d28 ed4
81NPiTzps3DsojIJREt2L5wTW14wg8129iAFYJsiTupWnnaibF9w+Kzh8OWmjr7xEU5rhvHe
aJZGcotjOc/AytWVDX3QnTFD9r++DAniEMurnjVm94IDA06D7kd8ugW+S7EEYu/+0xDEMtE8
iL3qCL9AgHQdrxf9gMuf6wTvwgHEZQXGUvFzdgK0FMyr2leZ1keZ8+Q6cMb/1EpyBMnGxubR
h+ge05mvD72Hhs5V4ZDSjAbQh/Gt0c/QJTYC97Z5lsx1OQx2KGdKhqnYghg+jyjBdhZX920F
FEpwr/7m2ME4lxGp4cV2jIZeasMPbl/lVpnNpsTqv1HIFJ91d/ZYmp2QZsj4GjtV+jQudqpH
BiFH05bdDjRH/uGWN23LGRuHjv+NuEtqVqMpOB6WLGXxjztgSCpqsEkXILDHy/ozc0dMCQuj
6dPTA8E7LDsXoSvzj8zVoEfHQ4HytxrCrVj9dsuK9h4FaxiA8prkNXD/9O3bx34P+0ziykhj
0z9AhHgMrNx9fJL6OeppqD4OPtgf4kRRI4M/kZhY9kme/VHqQlBl56DpTRSK4Jr4qQt6dHvU
Itg5E+GUAt2dzRIkBXfPd49XcV5yq4WeY1TjX6DdJkOssDa6NVjedoZ8+uGWWWz6512cBLRQ
dYi0tzDuKns9kwM+Z28/GLUTD6qtXRGs+c7WknsNuIsepcdlCuIr83D5enHDsxO/zmYWH7lm
QiFDEpAsUMEKcz2qm4S8qnV6tgu2oh/PD1qwVJDHh6wQilAOuhPYqBF8081YmL4Y7/zf3NP4
Q3OLi679fMFAEQQORAYoYKgjEV03ublkSFDXlBYzJ7/Wm1WwBUxBVRk0S25uzX72xp+mr+sX
s93A/xcNtyZG6saybU5g1h+MuGfA4encx49COOdr/noGNE1AItCnha0gpAPMtEVdyIi97T2e
xo4mpfFEj//lD9Y8C+HdvUq94wtQwo1Q3aS0wMU3lCza9YF9bJ23oxq2hHythGgpzDwfEP+/
fZLZ+e4/tWUbPEJ9+zMT6zVJTJnCIiC6v9KA9Db84MbERAisqet1on9RWyQAREYScVEbrWlY
xVSDblD1fqwm34TDimJrxdVyH8JXNb3tAqP4P4FzvRUiDmFs4bVZ9y6Dv/lWH3ukdzQRjcMt
Gh1QxyveXihrPeWe1ulS0V2RWU9/hz6pbU0ZXd+Z1/pplTe0AufCNNiTOYJm3AvDVmxn4Rme
dMX/xbdRKObyTpuMTaSfFOq8VRDl962qP18PJPeqeBktxcKlFBjPZbotZ6dEnwZ+/FmDXdCy
3BQD03CeFSR5XugrJqCZMlqzWFB71EvRocj6O2hhzESzKXEDeixGiV32mIupDXdF4bHMEyXT
wkUrzAhE+FuVxUj1QPyMdT05bUoqFCs+nHcSFAM2bV3Doguds/Yrbp3NubPBmAqkkv5zQQF5
iNmDdR+pirTvyiBytrGQRK+K0yIRA60S+NGlGfNlWLwanGEmuCgHfjiQRmz7hLQsZ9jQ8t5Z
QGCPT5tqNzlXWuozOrmpP761wpysaC1REqyP1Nhau+w742MhCmWuEcCKRgSXgLFaz3EqRf9h
GzgqIbCr1fDnreiFAEwBUU4rhZPznJrA3rxm5B6fcXplGy2ymi6xvFa0eApbipIp/e3zeCKQ
vOYXIKhDUFL+RaiYN+uS50XWEaeu+dYmq6tMGI02hCZZeA1z+/mfGuOT0QpwmEpUAuP3YBwn
OsuogwwgqX6tI65Wk1x0xUQpot7niu3xnFYf2JmjYPakcHr6WooUMyXGRE790BRA/0kHARPf
2jzlm2isH22g+zLM6OOHyQpugYbmX1X1pLyHW6KR82c59p4XKSkv2EHSLp61KC+5ZMfS2T0d
g1UsUJ3AMMDt+rtIqtf+OrKSYiRLGKG9Mvip4v7EBwUeCto2wU49TLwkDpq7v61q1794OteR
GS38CEml60HbntftOjV55Wgg3M1xqh24aii8MXEtUJFEs/R+Z2KzRC41MKBFJrOPXJzYewM+
OuzyUzIkHbihRRShfqcU5dpvGpNemZAVT1E/ILhb3lV0Bq7XpxB6OqgPSItYXvRg+XKdaWNL
F4cmwy0OhwLJlctZoW2D7Ynk33xHL1nNeay2ozHJMVt/Hv8U2eB1OjTB9ppvUQVLhjKrZ4nv
bKlTviaPgA0PPUzFvAZgDMohl4Mxntw26iBNNE5Bl6iTpXIJyF1PIu3ilFFdkKbcqmE3jkhX
ve+DSy3zhlgoIoM9YCT42fgxnlYVtST4WH3y8zCy/qklKYQXls2EX5MjtpuQs9ZgKCM+KGXl
x+UA2H/BYDWD79qg7lygFXG3P/5o2PxflO9XhBfq5f8xs04i3gS0Xayn8rQDUE+M+9M/dgJS
/H306EpBz4rjA1BSuU1Y2tNguvw7AOFsxzVhEBZ60QCKTZWy7Bo4UL35ddLZrgREg9/wOmsJ
sFovK95V5tRc0YHXcgZNg7Upp92vN+cbGuKu7Ud2Z6mGKtHy3uF451k+bIdTYOhrTUiXCNzH
NLQ2Kh+RdgxCQabygQMCqXbxR24W51F8Hg7Z1H9usst+Q3PxSrxYfqgJR00Wu8xoPKYMx9pZ
ECzuPeU+nuURhccAlWGB57d5XyaxvrfhXyvfXlEG5PF8I4datBQ3NuurpuUXqcXt2sAQw4IT
jCwcBsnHojXr3nZRt5g/WP8t79d0UFKGgNYEfUGE/AYLznrxSBvefXEJcmB1B1418cdjYVrv
/ejVkGsflMf5IqnHJt6yAOnxk91mG+4tq9PrPKugj7fK3wqpTOntRUtS3knJtgTYxchUO3U4
Ugiv5WIlxW4Z5VTCNiRhGiACKKMNsPoBn6XNjrZFDz9Vk9eOWD607L1fKv/g92Vmk/DOjwqF
ymzREJZYFIKkE1n/o4iwum8uj1Lyf7XMAy6BTbLGL43lYh1u0WEdwwyrdzn4rACPUtOMA7+k
NyyTz1b8dRvFsmugJ2xGykKmiss6hQY4Eu6eO1zI7HDQq+sdhZLatRT8OxFrQ7uPYOk6zDFO
9HnQLtBSDT2fXDxQQbUborIw1MZckVG+6iuHcPqakSelYtqEFni4Pk1I8g1Ko8+0xcZq/yrz
EfmBhakzmxIUykPrxpmsHfFWnAqCemRZU8Y8ycjrxlyEvgaQuR+4Un1xp3tdjhYA8Ym3yxWM
1OZiwsExuk64sjiFDIslA/60Hv3VTQtkuwESEFJd+AwFvlCuh19i3bNz1DnU76OpHXH2inRK
Sip7p+WChYFei0yQNcDueQMhkXjnr7nO8rVteLFBRQ0bCjCKZHND+PYL6x4eIx4yhZhjDQfL
Qq/DsVsKeyikYlFRPD53bSFkt00FplVV7Lwr1Mi88LyNN0Y5/1GY8N9f0P+8SmgLUN8giWN8
lLE7/gPQHq+lilCLNnYN6Lkw/MLI4Q5yWUWKqdW9PDxn45++HFx0318cTmkEvSl/8Rw9KlEG
J+4kvE/YfnLG7MQazjYJ+AZkj7vD95KmfNKUcDcVsYEcuFWFPpdLGJyn08O/pNyu3FaOtFax
ym382R6qoJoyxdmlcSkSqG2nKPXTC64hzw5unn1YAFAGX2pbze4d7K9IxjHWUjOP9pAAyITc
mTJ2os4rOfPOLp/QZiHTBFdfZ8nQBIB1pH/IfP0h8WfJ1gfTFO3SX2y4ox6kWS+gg4Ls3Slx
WqbstSysmGWACwcy2KLQpDwIeZctjXuSMc7fQ7SCpAB9/SlYl/BlPGAW+RLwnXMoxf1NBQ==


/
  CREATE OR REPLACE PACKAGE BODY "PCKG_TOOLS" wrapped 
a000000
b2
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
9d98 1103
4Ydk8mPboX4v1o8EEPuH3SPh06cwg81MHiBo39OdZDGdrBa4yIni/p+QcRzBx6Y720zVs9XT
AcZPRnH2aGMRCXHNcboOquQIbPSOoTtdsYNiHzk01bIHXXpXnYjMCblbu+RiNh5WeluaXa+Y
efDCVtGdWOlDdI9y6PIdjgE+tHdsdPwqohcv6NEY01QgGFYmjI6PnVCAuMt9zIm9xnqXRs+e
4+VmRN6N2Dg10JschRfJzqDBE5Y1kB+TabA/4QWEk6NmJOmPd5astp1X9Q96/t0kSjfvsjGt
Cb6QPGysrS8kYrc9m6W+vxTIklJxBx5iQWgbjAdNoJtXBdFpVSG2/SHbMo7ChMwYj29vkX7Z
Si8/42mkRgbKdcg28VFal3mQXFqkwe6bOtWuZrLCLxigYikDhFh8SgkAONBJQZ4rbF54OuiI
qEmvRcE2YNOXRB5j71K1IlsMrsZtt1i9rnNT8ejKn0VABRYqfR0KZyKlYlRYic3yiUegj2Qf
mhDtRabLznO/4Inbjk3MBk//Ua2Ddfyz2CDARsadluKOs3uAvyFwZ0UQatTZ1HwOD2imDE+Z
pKrvK+7osC1dM8fmhMtwuwzAnAoZMittPQa4vnF7x49G7mahb8HOhjBBByg0lbW/8tYDg7BW
q4Q88lG6i9T/TX+S7QqcMHdV3sQUT/erGQMhzvzCup3srQhpi0VIcqPLjuqb3V6l/JVOQyVq
x7hDvCiS7AjOgzkkNnxJNcTNCIo2BlChEggeLitjOBKe7l6CfzCls6TYRvNtUjmukwCxRATP
Rdg8bMVomxBZSnKvnrUtEbQgd0CrJfwQWT/lonl1qOWhgqyZz2dJqPZaJ3iVymCIRE/5s6T+
JZ6budonRqr+ACqriilNHWc0PrOMv5EOMXANxuII9b3z9Jy+D86hKfFkfNieWoZJ+4nGINvj
e1uRdz8tO9N1UfG2hcfzRVH5tzjqPpcTrf/uGXYHSkF2154e3zx5uWh5yodBYzYYcuZa58Qv
LaYrY7MHq41WuBnyi8TaCP3y+JId/Y348P/kG4sQ7wO8kK2afV+uaqH/0kdCHCuURBDQ3xMn
G7hkUMJ5hxUEOaKFSGSjUQIl2T3htTuHncOvIZZjoibB+502qGYrifSeZnXzRo0sClOgjEUB
V96zGrJtby7cgLdvWaNkLXAJAgEjovquwsqh+jFDNjlgjlShFtQ3lxML8lIRb16524kovWUz
2MllZu9DmNQEtdQMI8TnZCXFSmLdwmsVQBgmpva0x1bbwj9OF9ZUZvKzhNjTpwFz37qGWM4W
xcyOidE6MXRRvYvHX+MGxaGVC/jiHt7USGu0hZsZ+J5vwQuirEIt7ZQlM20XZEVzHyjzBSq2
FHowPrmbBwwZDiqRFaK43KNaHZwfnJyBKCRzCrw0kjCBKZv867+cGmLOQyQfJA9p0V1dnNBP
lt0thmlKUWovQc7HGtVZh48xqbU/7c46eKUp2T2uUfX+XmNGLHBpqOdRFDc4ouK6eKyM6WCh
tUX8Ubglpx95jsTMaKcfYjMNh07KS2Q5pPyoS6pFY+rYczJHW8hj0zONi8o/i2cRRv9lLfPz
G6FaW6vHymW8eBmPewBsVHegE3obmx6p/HAKIV/jDhuyLd6CEInwh5LXdtiogKHfg1FVtKRd
Xp/x0KEkdVVfaFkiUoQ6Dd+NroNUIsDHOtuyi4zC8fS++tHuJiJNyF6G7wWj+BrxW4LVnDDZ
HLCk8mq6Zs2t/mlgAV0+XAOlaeVRTWycd9/HMFEVXqQx1lvO7lKu7sboPm3F+hNMzj6J17Nn
xpLDfRyh5qH0lSptS7iY/Rdv7HnMIvHAabzi8UBBxk6u1OrwYEbnzk01zOWtfXhqTa2w2E1b
EzCXaneuufG50jGu0zvHEVkKfQ9F4zFPp+MtjPCrAIzTF3Janm4iYFdF6a6E5YuekIjVUs7J
ye2HIZ8+O3Wr2TzwkAUzg3BodfKhBNSIV5M4pZKBAWnCC6L8aH+5HJ+cKdGCFmUG37X4zoax
mdZOaJp0Acu2dt66Z+RkohiA15StMGaRr+xK3/5cl8KcwHmjSOvAEj6xkvCBExOnA1QNNQ+v
gxr7r0yxPjhV2EAq7eMyc8U8KtlUseULVU3IKr7xbLIXfqgeYeVUaJ9+iNmnLX6I2act7M+a
gDctCSriaZR0XOX5FALFPmukDjSaJXLcPQcdlW4tDW5QPMC5wqfvkzyJ4IW8J6ifutDXfX5g
F8SBVGQth8e3e+dy6oECLyfItGdoi23C0EyhvIa/QgV+s8861Xtyu80rFZ/YzBHEZNBovBmF
X+Rl9qVSeuKsTNs8uq8iQVQ3Q726rf8a7FkbvQ8xe5YmrJspWrhH1eOEw0LLmer81pfUHcbk
cZq/AKSieeNW5g0tPNSjbWli5g2HTmcvJx/sQMrFHi16+p5dni2qeyuUBFXFfkS2s/Z4X72x
8eiHWUUZPRrenLfUh67sIzXeipRj80vqL2G9pv7XBvsL7hEdIxx8wg55rFCs9RGvtEcQtWNw
AIpv6FCY/9gOuIIpSGk/LnDclRarz3EVBV7XvHdmx1DwVL5u3tFr9uwFw5Ws0ZlFfuXgXpQe
KihWXPdRidH29GHeQJgbxCWn4k/BUo7OfuumsgV0MdMx2KChbVDgqMJFsXuYtC1ioNBWoG3m
hlTAaVjQJl1IfOMAPWgQoXVFRZjuNKZORD1ppyc6kJ8U2nzU/hiAHso7tO2Vwt/FBU1+LdiV
wjz2HOenjWq3y9s5TeMeZQoYpjxJk/Rx+ZA4VO6KUQA1f/Dh3ukJFX2HOH6qb2+XSkbColQG
ArKQ0yy2z80+tRw4CqZxHcPJw8+CefejrWqv5crPl+DoPlpePDtJ4ImDPyAmxOkrQ3AQ0cui
W0wxUpmTeaUNr7HmK5mTO7F654WDB8BAgPULorqNKkRsQBfHavUMFGaUC4RTCAoEN2McvOBg
mfdO7eBULQttD4AG6swRskYlJwh/N1TWbIqMOf3O7Ux0ZxhSr7qhJYMAxSWA9KybvMVYkPLn
Xs2L9oTv8+oLjN2KPYOWucKTInzsbyvTpJFv+L6yfWgDDzHun9J6qxdoGrbu+i0lrWrxcQ6D
gPWtGS3euyKa8gGxPR47CsNY8Mwqco0QkdkWkGpBnFDbtY+nY5rYfk3SdAwEpNhFz7MX3wPU
pk7MnEtKrUIobgWfR0pY6rrrezH1bzSUEoIQRQKOKIxNCcC3rYehpOQq8AkI+tHNzZKR3X73
jwziCJuj7426un5YzNUSPDl7kGH/3MGWYi3kU5/Q9auDlYEowIwcXAEH9IoGI8Zt1bZTTKNj
11PDG8QDS8DWHIcz28tJVuW3Qpnavs6zGSOrjdLeJq1vWVosgiWndMB6PWYIs03EQjpjETpc
8cgY2hImdfzUO0Mhlut+I7t7geycdYKHHSB8D8sneZFVUj2hbb2iLJ/mtTT/34GIRrtxmwDg
CENgZK3ror2SZ3Ylvc18YiG/43opll/y/X7voW9FRH/qIrQd7kNjW84ggSO+9Yv//posz/nP
pf35VxnE1SD5CVRPjPBKeMvVw4lAPw/l+JpPeu5RQlHfrxeVv/lhZuh7LyFnLBbwee9XJi3r
wS1PYSCTAdRq0DOa8upjTVewvy/ncoP2GA/b0Eg6KjKwMvexQivCSS86gzCWAmf3zwDweufh
jeRY93p0aj5duP5wTWVyaw/Sflz+Z6CnicWdY6QULsKOkKCg1hrxjAShiITeS2oaLQ9Rp891
w+yc9MOGtKsJJ8HsfLSAo3XeGKD7A2tugZwPkPCf6ml7SeAfzDSMN0D2hGpqTLL0VfwTImqq
1i70sh4TvLQ9jqurvMlqzQ3DWf141NUWCKzJ7msgP8uku+cEBd/fa3l2kLJhefAPBVehOf0T
7C2cwx798v84dbm4uq+6RjNdFjgFfJtguKuObsV4pIyHcSU0UWdfwU3+Ngxhiwz2lzlTitzE
QbXIuo+ldckQNuXvh14G5mzUA12WcsMHuzgsYM6/xcyBepdetNLk1Lc1wmH5aFYAkQo/u+B+
ccuZylKSaBv63RQ5sxa1yMDjoNJ7nHrfrQVV3H1+BkbhYu0ey/yKpmSvjz4wocALKOROMAeo
ERIEiqZOM90THqWkZWy4eopTED94PY52ZrtMR2m5IqSj28rE6UjPX0kc+3NijBHulzz/KaWR
0GW4TyNFE40+QLNV7FnVRCl72B2dqr3wjR20ekWvMsRmDB25/vLJorQlX/5TLoSYL1AsQ0CG
2HiXx9u/Pkuw99xJ6At5q66ToL737OR216WIened5CwEaJ92

/
