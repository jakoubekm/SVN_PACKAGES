
  CREATE OR REPLACE PACKAGE BODY "PDC"."PCKG_TOOLS"
IS
    FUNCTION F_SEC_BETWEEN(TIME_FROM_IN IN DATE, TIME_TO_IN IN DATE)
        RETURN NUMBER
    IS
        /******************************************************************************
        Object type: UDF
        Name:  F_SEC_BETWEEN
        IN parameters:
                       TIME_FROM_IN
                       TIME_TO_IN IN DATE
        OUT parameters:
                       RETURN NUMBER
        Calling: N/A
        -------------------------------------------------------------------------------
        Version:        1.0
        -------------------------------------------------------------------------------
        Project: PDC
        Author:  Teradata - Marcel Samek
        Date:  2010-02-20
        -------------------------------------------------------------------------------
        Description: UDF returns number of seconds between two timestamps
                     or number of seconds between input timestamp and 1.1.2000
        -------------------------------------------------------------------------------
        Modified:
        Version:
        Date:
        Modification:
        *******************************************************************************/
        --constants
        C_PROC_NAME        CONSTANT VARCHAR2(64) := 'F_SEC_BETWEEN';
        -- local variables
        V_STEP             VARCHAR2(1024);
        V_ALL_DBG_INFO     PCKG_PLOG.T_VARCHAR2;
        V_DBG_INFO_ID      INTEGER := 0;
        EXIT_CD            NUMBER;
        ERRMSG_OUT         VARCHAR2(2048);
        ERRCODE_OUT        VARCHAR2(32);
        ERRLINE_OUT        VARCHAR2(2048);
        V_DATE_FROM_DATE   NUMBER;
        V_DATE_TO_DATE     NUMBER;
        V_DATE_FROM_SEC    NUMBER(5, 0);
        V_DATE_TO_SEC      NUMBER(5, 0);
        V_VALUE_OUT        NUMBER;
    BEGIN
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PCKG_NAME || '.' || C_PROC_NAME;

        V_STEP := 'get V_DATE_FROM_DATE';
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;
        V_DATE_FROM_DATE := TO_NUMBER(TO_CHAR(NVL(TIME_FROM_IN, TO_TIMESTAMP(TO_DATE('1.1.2000', 'DD.MM.YYYY'))), 'J'));

        V_STEP := 'get V_DATE_TO_DATE';
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;
        V_DATE_TO_DATE := TO_NUMBER(TO_CHAR(TIME_TO_IN, 'J'));

        V_STEP := 'get V_DATE_FROM_SEC';
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;
        V_DATE_FROM_SEC := TO_NUMBER(TO_CHAR(NVL(TIME_FROM_IN, TO_TIMESTAMP(TO_DATE('1.1.2000', 'DD.MM.YYYY'))), 'SSSSS'));

        V_STEP := 'get V_DATE_TO_SEC';
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;
        V_DATE_TO_SEC := TO_NUMBER(TO_CHAR(TIME_TO_IN, 'SSSSS'));

        RETURN (((V_DATE_TO_DATE - V_DATE_FROM_DATE) * 86400) + (V_DATE_TO_SEC - V_DATE_FROM_SEC));
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN -1;

            EXIT_CD := -1;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'NO DATA FOUND ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
        WHEN OTHERS
        THEN
            RETURN -1;

            EXIT_CD := -2;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'OTHER ERROR ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
    END F_SEC_BETWEEN;

    FUNCTION F_GET_DATE_UNIX_TS(TIME_IN DATE)
        RETURN NUMBER
    IS
        /******************************************************************************
        Object type: UDF
        Name:  F_GET_DATE_UNIX_TS
        IN parameters:
                       TIME_IN
        OUT parameters:
                       RETURN NUMBER
        Calling: N/A
        -------------------------------------------------------------------------------
        Version:        1.0
        -------------------------------------------------------------------------------
        Project: PDC
        Author:  Teradata - Marcel Samek
        Date:  2010-02-20
        -------------------------------------------------------------------------------
        Description: Function converts input date value to the timestamp
                     in UNIX format with seconds
        -------------------------------------------------------------------------------
        Modified:
        Version:
        Date:
        Modification:
        *******************************************************************************/
        --constants
        C_PROC_NAME      CONSTANT VARCHAR2(64) := 'F_GET_DATE_UNIX_TS';
        -- local variables
        V_STEP           VARCHAR2(1024);
        V_ALL_DBG_INFO   PCKG_PLOG.T_VARCHAR2;
        V_DBG_INFO_ID    INTEGER := 0;
        EXIT_CD          NUMBER;
        ERRMSG_OUT       VARCHAR2(2048);
        ERRCODE_OUT      NUMBER;
        ERRLINE_OUT      VARCHAR2(2048);
        V_RET_TIME       NUMBER;
    BEGIN
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PCKG_NAME || '.' || C_PROC_NAME;

        V_STEP := 'get V_RET_TIME';
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;

        SELECT   (F_SEC_BETWEEN(TO_TIMESTAMP(TO_DATE('01.01.1970', 'DD.MM.YYYY')), TIME_IN)) AS DT INTO V_RET_TIME FROM DUAL;

        RETURN V_RET_TIME;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN -1;
            EXIT_CD := -1;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'NO DATA FOUND ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
        WHEN OTHERS
        THEN
            RETURN -1;
            EXIT_CD := -2;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'OTHER ERROR ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
    END F_GET_DATE_UNIX_TS;

    FUNCTION F_GET_UNIX_TS_DATE(DATE_IN IN NUMBER)
        RETURN DATE
    IS
        /******************************************************************************
        Object type: UDF
        Name:  F_GET_UNIX_TS_DATE
        IN parameters:
                       IN_DATE
        OUT parameters:
                       RETURN DATE
        Calling: N/A
        -------------------------------------------------------------------------------
        Version:        1.0
        -------------------------------------------------------------------------------
        Project: PDC
        Author:  Teradata - Marcel Samek
        Date:  2010-02-20
        -------------------------------------------------------------------------------
        Description: Function converts input UNIX timestamp format to Gregorian datetime
        -------------------------------------------------------------------------------
        Modified:
        Version:
        Date:
        Modification:
        *******************************************************************************/
        --constants
        C_PROC_NAME      CONSTANT VARCHAR2(64) := 'F_GET_UNIX_TS_DATE';
        -- local variables
        V_STEP           VARCHAR2(1024);
        V_ALL_DBG_INFO   PCKG_PLOG.T_VARCHAR2;
        V_DBG_INFO_ID    INTEGER := 0;
        EXIT_CD          NUMBER;
        ERRMSG_OUT       VARCHAR2(2048);
        ERRCODE_OUT      NUMBER;
        ERRLINE_OUT      VARCHAR2(2048);
    BEGIN
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PCKG_NAME || '.' || C_PROC_NAME;
        RETURN TO_TIMESTAMP(TO_DATE('01.01.1970', 'DD.MM.YYYY')) + (DATE_IN / 86400);
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
            EXIT_CD := -1;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'NO DATA FOUND ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
        WHEN OTHERS
        THEN
            RETURN NULL;
            EXIT_CD := -2;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'OTHER ERROR ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
    END F_GET_UNIX_TS_DATE;

    FUNCTION F_GET_SESS_JOB_STATISTICS(JOB_NAME_IN VARCHAR2, COLUMN_IN VARCHAR2)
        RETURN NUMBER
    IS
        /******************************************************************************
        Object type: UDF
        Name:  F_GET_SESS_JOB_STATISTICS
        IN parameters:
                       JOB_NAME_IN
                       COLUMN_IN
        OUT parameters:
                       RETURN NUMBER
        Calling: N/A
        -------------------------------------------------------------------------------
        Version:        1.0
        -------------------------------------------------------------------------------
        Project: PDC
        Author:  Teradata - Marcel Samek
        Date:  2010-02-20
        -------------------------------------------------------------------------------
        Description: UDF returns tatistical data from SESSION_JOB_STATISTICS table.
        -------------------------------------------------------------------------------
        Modified:
        Version:
        Date:
        Modification:
        *******************************************************************************/
        --constants
        C_PROC_NAME      CONSTANT VARCHAR2(64) := 'F_GET_SESS_JOB_STATISTICS';
        -- local variables
        V_STEP           VARCHAR2(1024);
        V_ALL_DBG_INFO   PCKG_PLOG.T_VARCHAR2;
        V_DBG_INFO_ID    INTEGER := 0;
        EXIT_CD          NUMBER;
        ERRMSG_OUT       VARCHAR2(2048);
        ERRCODE_OUT      NUMBER;
        ERRLINE_OUT      VARCHAR2(2048);
        V_QUERY          VARCHAR2(1024);
        V_OUT_VALUE      NUMBER(38, 0);
    BEGIN
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PCKG_NAME || '.' || C_PROC_NAME;
        V_QUERY := 'SELECT sjs.' || COLUMN_IN || '
          FROM  sess_job_statistics sjs where sjs.job_name =''' || JOB_NAME_IN || '''';
        V_STEP := 'exec query into V_OUT_VALUE';
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;

        EXECUTE IMMEDIATE V_QUERY INTO   V_OUT_VALUE;

        RETURN V_OUT_VALUE;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN -1;
            EXIT_CD := -1;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'NO DATA FOUND ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
        WHEN OTHERS
        THEN
            RETURN -1;
            EXIT_CD := -2;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'OTHER ERROR ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
    END F_GET_SESS_JOB_STATISTICS;

    FUNCTION F_GET_AVG_TS(TABLE_NAME_ONE_IN VARCHAR2
                        , TABLE_NAME_TWO_IN VARCHAR2 := NULL
                        , COLUMN_ONE_IN VARCHAR2
                        , COLUMN_TWO_IN VARCHAR2 := NULL
                        , COMPARE_IN PLS_INTEGER := 0
                        , CONDITION_ONE_IN VARCHAR2
                        , CONDITION_TWO_IN VARCHAR2 := NULL
                        , FUNCTION_IN VARCHAR2 := 'AVG')
        RETURN TIMESTAMP
    IS
        /******************************************************************************
        Object type: UDF
        Name:  F_GET_AVG_TS
        IN parameters:
                        TABLE_NAME_ONE_IN
                        TABLE_NAME_TWO_IN
                        COLUMN_ONE_IN
                        COLUMN_TWO_IN
                        COMPARE_IN
                        CONDITION_ONE_IN
                        CONDITION_TWO_IN
                        FUNCTION_IN
        OUT parameters:
                       RETURN TIMESTAMP
        Calling: N/A
        -------------------------------------------------------------------------------
        Version:        1.0
        -------------------------------------------------------------------------------
        Project: PDC
        Author:  Teradata - Marcel Samek
        Date:  2010-03-01
        -------------------------------------------------------------------------------
        Description: UDF returns :
        A) average value of timestamp for exactly one column in one table
        B) higher average value of timestamps compared between two different
           tables and columns
        -------------------------------------------------------------------------------
        Modified:
        Version:
        Date:
        Modification:
        *******************************************************************************/
        --constants
        C_PROC_NAME            CONSTANT VARCHAR2(64) := 'F_GET_AVG_TS';
        -- local variables
        V_STEP                 VARCHAR2(1024);
        V_ALL_DBG_INFO         PCKG_PLOG.T_VARCHAR2;
        V_DBG_INFO_ID          INTEGER := 0;
        EXIT_CD                NUMBER;
        ERRMSG_OUT             VARCHAR2(2048);
        ERRCODE_OUT            NUMBER;
        ERRLINE_OUT            VARCHAR2(2048);
        V_QUERY                VARCHAR2(1024);
        V_TABLE_NAME_TWO_IN    VARCHAR2(1024) := NVL(TABLE_NAME_TWO_IN, TABLE_NAME_ONE_IN);
        V_COLUMN_TWO_IN        VARCHAR2(1024) := NVL(COLUMN_TWO_IN, COLUMN_ONE_IN);
        V_OUT_VALUE            VARCHAR2(1024) := NULL;
        V_CURR_CONDITION_ONE   VARCHAR2(1024) := ' where ' || CONDITION_ONE_IN;
        V_CURR_CONDITION_TWO   VARCHAR2(1024) := ' where ' || CONDITION_TWO_IN;
        V_COMP_VALUE_ONE       INTEGER;
        V_COMP_VALUE_TWO       INTEGER;
    BEGIN
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PCKG_NAME || '.' || C_PROC_NAME;
        V_QUERY := 'SELECT ' || FUNCTION_IN || '(PCKG_TOOLS.F_GET_DATE_UNIX_TS(AT.' || COLUMN_ONE_IN || ')) FROM   ' || TABLE_NAME_ONE_IN || ' AT ' || V_CURR_CONDITION_ONE;

        V_STEP := 'exec query into V_COMP_VALUE_ONE';
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;

        EXECUTE IMMEDIATE V_QUERY INTO   V_COMP_VALUE_ONE;

        V_STEP := 'set V_OUT_VALUE';
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;
        V_OUT_VALUE := PCKG_TOOLS.F_GET_UNIX_TS_DATE(V_COMP_VALUE_ONE);

        IF CONDITION_TWO_IN IS NOT NULL
       AND V_TABLE_NAME_TWO_IN IS NOT NULL
        THEN
            V_QUERY :=
                'SELECT ' || FUNCTION_IN || '(PCKG_TOOLS.F_GET_DATE_UNIX_TS(ATB.' || V_COLUMN_TWO_IN || ')) FROM   ' || V_TABLE_NAME_TWO_IN || ' ATB ' || V_CURR_CONDITION_TWO;

            V_STEP := 'exec query into V_COMP_VALUE_TWO when CONDITION_TWO_IN IS NOT NULL AND V_TABLE_NAME_TWO_IN IS NOT NULL';
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;

            EXECUTE IMMEDIATE V_QUERY INTO   V_COMP_VALUE_TWO;

            V_STEP := 'set value V_OUT_VALUE';
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;
            V_OUT_VALUE := PCKG_TOOLS.F_GET_UNIX_TS_DATE(GREATEST(V_COMP_VALUE_ONE, V_COMP_VALUE_TWO));
        END IF;

        RETURN V_OUT_VALUE;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN null;
            EXIT_CD := -1;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'NO DATA FOUND ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
        WHEN OTHERS
        THEN
            RETURN null;
            EXIT_CD := -2;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'OTHER ERROR ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
    END F_GET_AVG_TS;

    FUNCTION F_GET_FNC_COL(TABLE_NAME_ONE_IN VARCHAR2
                         , TABLE_NAME_TWO_IN VARCHAR2 := NULL
                         , COLUMN_ONE_IN VARCHAR2
                         , COLUMN_TWO_IN VARCHAR2 := NULL
                         , COMPARE_IN PLS_INTEGER := 0
                         , CONDITION_ONE_IN VARCHAR2
                         , CONDITION_TWO_IN VARCHAR2 := NULL
                         , FUNCTION_IN VARCHAR2 := 'AVG')
        RETURN VARCHAR2
    IS
        /******************************************************************************
        Object type: UDF
        Name:  F_GET_FNC_COL
        IN parameters:
                       TABLE_NAME_ONE_IN
                       TABLE_NAME_TWO_IN
                       COLUMN_ONE_IN
                       COLUMN_TWO_IN
                       COMPARE_IN
                       CONDITION_ONE_IN
                       CONDITION_TWO_IN
                       FUNCTION_IN
        OUT parameters:
                       param_out
        Calling: N/A
        -------------------------------------------------------------------------------
        Version:        1.0
        -------------------------------------------------------------------------------
        Project: PDC
        Author:  Teradata - Marcel Samek
        Date:  YYYY-MM-DD
        -------------------------------------------------------------------------------
        Description: UDF returns agregated value from any column of any table
        -------------------------------------------------------------------------------
        Modified:
        Version:
        Date:
        Modification:
        *******************************************************************************/
        --constants
        C_PROC_NAME            CONSTANT VARCHAR2(64) := 'F_GET_FNC_COL';
        -- local variables
        V_STEP                 VARCHAR2(1024);
        V_ALL_DBG_INFO         PCKG_PLOG.T_VARCHAR2;
        V_DBG_INFO_ID          INTEGER := 0;
        EXIT_CD                NUMBER;
        ERRMSG_OUT             VARCHAR2(2048);
        ERRCODE_OUT            NUMBER;
        ERRLINE_OUT            VARCHAR2(2048);
        V_QUERY                VARCHAR2(1024);
        V_TABLE_NAME_TWO_IN    VARCHAR2(1024) := NVL(TABLE_NAME_TWO_IN, TABLE_NAME_ONE_IN);
        V_COLUMN_TWO_IN        VARCHAR2(1024) := NVL(COLUMN_TWO_IN, COLUMN_ONE_IN);
        V_OUT_VALUE            VARCHAR2(1024) := NULL;
        V_CURR_CONDITION_ONE   VARCHAR2(1024) := ' where ' || CONDITION_ONE_IN;
        V_CURR_CONDITION_TWO   VARCHAR2(1024) := ' where ' || CONDITION_TWO_IN;
        V_COMP_VALUE_ONE       INTEGER;
        V_COMP_VALUE_TWO       INTEGER;
    BEGIN
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PCKG_NAME || '.' || C_PROC_NAME;
        V_QUERY := 'SELECT ' || FUNCTION_IN || '(ATC.' || COLUMN_ONE_IN || ') FROM   ' || TABLE_NAME_ONE_IN || ' ATC ' || V_CURR_CONDITION_ONE;
        V_STEP := 'exec query into V_COMP_VALUE_ONE';
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;

        EXECUTE IMMEDIATE V_QUERY INTO   V_COMP_VALUE_ONE;

        V_OUT_VALUE := V_COMP_VALUE_ONE;

        IF CONDITION_TWO_IN IS NOT NULL
       AND V_TABLE_NAME_TWO_IN IS NOT NULL
        THEN
            V_QUERY := 'SELECT ' || FUNCTION_IN || '(ATD.' || V_COLUMN_TWO_IN || ') FROM   ' || V_TABLE_NAME_TWO_IN || ' ATD ' || V_CURR_CONDITION_TWO;

            V_STEP := 'exec query into V_COMP_VALUE_TWO when CONDITION_TWO_IN IS NOT NULL AND V_TABLE_NAME_TWO_IN IS NOT NULL';
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;

            EXECUTE IMMEDIATE V_QUERY INTO   V_COMP_VALUE_TWO;

            V_OUT_VALUE := GREATEST(V_COMP_VALUE_ONE, V_COMP_VALUE_TWO);
        END IF;

        RETURN V_OUT_VALUE;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN -1;
            EXIT_CD := -1;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'NO DATA FOUND ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
        WHEN OTHERS
        THEN
            RETURN -1;
            EXIT_CD := -2;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'OTHER ERROR ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
    END F_GET_FNC_COL;

    FUNCTION F_GET_ERROR_CD(ERROR_CD_NAME_IN VARCHAR2)
        RETURN LKP_ERROR_CD.ERROR_CD%TYPE
    IS
        /******************************************************************************
        Object type: UDF
        Name:  F_GET_ERROR_CD_ID
        IN parameters:
                       ERROR_CD_NAME_IN
        OUT parameters:
                       RETURN LKP_ERROR_CD.ERROR_CD_ID%TYPE
        Calling: N/A
        -------------------------------------------------------------------------------
        Version:        1.0
        -------------------------------------------------------------------------------
        Project: PDC
        Author:  Teradata - Marcel Samek
        Date:  2010-03-01
        -------------------------------------------------------------------------------
        Description: UDF returns Error Code ID from Error Code Name
        -------------------------------------------------------------------------------
        Modified:
        Version:
        Date:
        Modification:
        *******************************************************************************/
        --constants
        C_PROC_NAME      CONSTANT VARCHAR2(64) := 'F_GET_ERROR_CD_ID';
        -- local variables
        V_STEP           VARCHAR2(1024);
        V_ALL_DBG_INFO   PCKG_PLOG.T_VARCHAR2;
        V_DBG_INFO_ID    INTEGER := 0;
        EXIT_CD          NUMBER;
        ERRMSG_OUT       VARCHAR2(2048);
        ERRCODE_OUT      NUMBER;
        ERRLINE_OUT      VARCHAR2(2048);
        V_ERROR_CD    LKP_ERROR_CD.ERROR_CD%TYPE;
    BEGIN
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PCKG_NAME || '.' || C_PROC_NAME;

        V_STEP := 'set V_ERROR_CD_ID';
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;

        SELECT   LKPE.ERROR_CD
          INTO   V_ERROR_CD
          FROM   LKP_ERROR_CD LKPE
         WHERE   UPPER(LKPE.ERROR_CD_NAME) = UPPER(ERROR_CD_NAME_IN);

        RETURN V_ERROR_CD;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN -1;
            EXIT_CD := -1;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'NO DATA FOUND ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
        WHEN OTHERS
        THEN
            RETURN -1;
            EXIT_CD := -2;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'OTHER ERROR ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
    END F_GET_ERROR_CD;

    FUNCTION F_GET_ERROR_CD_NAME_SHORT(ERROR_CD_ID_IN VARCHAR2)
        RETURN LKP_ERROR_CD.ERROR_CD_NAME_SHORT%TYPE
    IS
        /******************************************************************************
        Object type: UDF
        Name:  F_GET_ERROR_CD_NAME_SHORT
        IN parameters:
                       ERROR_CD_ID_IN
        OUT parameters:
                       RETURN LKP_ERROR_CD.ERROR_CD_NAME_SHORT%TYPE
        Calling: N/A
        -------------------------------------------------------------------------------
        Version:        1.0
        -------------------------------------------------------------------------------
        Project: PDC
        Author:  Teradata - Marcel Samek
        Date:  2010-03-01
        -------------------------------------------------------------------------------
        Description: UDF returns Error Code Short Name from Error Code ID
        -------------------------------------------------------------------------------
        Modified:
        Version:
        Date:
        Modification:
        *******************************************************************************/
        --constants
        C_PROC_NAME             CONSTANT VARCHAR2(64) := 'F_GET_ERROR_CD_NAME_SHORT';
        -- local variables
        V_STEP                  VARCHAR2(1024);
        V_ALL_DBG_INFO          PCKG_PLOG.T_VARCHAR2;
        V_DBG_INFO_ID           INTEGER := 0;
        EXIT_CD                 NUMBER;
        ERRMSG_OUT              VARCHAR2(2048);
        ERRCODE_OUT             NUMBER;
        ERRLINE_OUT             VARCHAR2(2048);
        V_ERROR_CD_NAME_SHORT   LKP_ERROR_CD.ERROR_CD_NAME_SHORT%TYPE;
    BEGIN
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PCKG_NAME || '.' || C_PROC_NAME;

        IF ERROR_CD_ID_IN IS NOT NULL
        THEN
            V_STEP := 'set V_ERROR_CD_NAME_SHORT when ERROR_CD_ID_IN IS NOT NULL';
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;

            SELECT   LKPE.ERROR_CD_NAME_SHORT
              INTO   V_ERROR_CD_NAME_SHORT
              FROM   LKP_ERROR_CD LKPE
             WHERE   UPPER(LKPE.ERROR_CD_NAME) = UPPER(ERROR_CD_ID_IN);
        ELSE
            V_STEP := 'set V_ERROR_CD_NAME_SHORT when ERROR_CD_ID_IN IS NULL';
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;
            V_ERROR_CD_NAME_SHORT := NULL;
        END IF;

        RETURN V_ERROR_CD_NAME_SHORT;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN -1;
            EXIT_CD := -1;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'NO DATA FOUND ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
        WHEN OTHERS
        THEN
            RETURN -1;
            EXIT_CD := -2;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'OTHER ERROR ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
    END F_GET_ERROR_CD_NAME_SHORT;

    FUNCTION F_GET_IGNORE_STATS(APPLICATION_ID_IN NUMBER := 1)
        RETURN LKP_APPLICATION.IGNORE_STATS%TYPE
    IS
        /******************************************************************************
        Object type: UDF
        Name:  F_GET_IGNORE_STATS
        IN parameters:
                       APPLICATION_ID_IN
        OUT parameters:
                       RETURN LKP_APPLICATION.IGNORE_STATS%TYPE
        Calling: N/A
        -------------------------------------------------------------------------------
        Version:        1.0
        -------------------------------------------------------------------------------
        Project: PDC
        Author:  Teradata - Marcel Samek
        Date:  2010-03-01
        -------------------------------------------------------------------------------
        Description: UDF returns Ignore stats flag for application ID
        -------------------------------------------------------------------------------
        Modified:
        Version:
        Date:
        Modification:
        *******************************************************************************/
        --constants
        C_PROC_NAME      CONSTANT VARCHAR2(64) := 'F_GET_IGNORE_STATS';
        -- local variables
        V_STEP           VARCHAR2(1024);
        V_ALL_DBG_INFO   PCKG_PLOG.T_VARCHAR2;
        V_DBG_INFO_ID    INTEGER := 0;
        EXIT_CD          NUMBER;
        ERRMSG_OUT       VARCHAR2(2048);
        ERRCODE_OUT      NUMBER;
        ERRLINE_OUT      VARCHAR2(2048);
        V_IGNORE_STATS   LKP_APPLICATION.IGNORE_STATS%TYPE;
    BEGIN
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PCKG_NAME || '.' || C_PROC_NAME;

        V_STEP := 'set V_IGNORE_STATS';
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;

        SELECT   LKPA.IGNORE_STATS
          INTO   V_IGNORE_STATS
          FROM   LKP_APPLICATION LKPA
         WHERE   LKPA.APPLICATION_ID = APPLICATION_ID_IN;

        RETURN V_IGNORE_STATS;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN -1;
            EXIT_CD := -1;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'NO DATA FOUND ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
        WHEN OTHERS
        THEN
            RETURN -1;
            EXIT_CD := -2;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'OTHER ERROR ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
    END F_GET_IGNORE_STATS;

    FUNCTION F_GET_CTRL_SOURCE_HOST(SOURCE_ID_IN CTRL_SOURCE.SOURCE_ID%TYPE)
        RETURN CTRL_SOURCE.HOST%TYPE
    IS
        /******************************************************************************
        Object type: UDF
        Name:  F_GET_CTRL_SOURCE_HOST
        IN parameters:
                       source_id_in
        OUT parameters:
                       RETURN ctrl_source.host%type
        Calling: N/A
        -------------------------------------------------------------------------------
        Version:        1.0
        -------------------------------------------------------------------------------
        Project: PDC
        Author:  Teradata - Marcel Samek
        Date:  2010-04-09
        -------------------------------------------------------------------------------
        Description: UDF returns host(schema) name for source ID
        -------------------------------------------------------------------------------
        Modified:
        Version:
        Date:
        Modification:
        *******************************************************************************/
        --constants
        C_PROC_NAME      CONSTANT VARCHAR2(64) := 'F_GET_CTRL_SOURCE_HOST';
        -- local variables
        V_STEP           VARCHAR2(1024);
        V_ALL_DBG_INFO   PCKG_PLOG.T_VARCHAR2;
        V_DBG_INFO_ID    INTEGER := 0;
        EXIT_CD          NUMBER;
        ERRMSG_OUT       VARCHAR2(2048);
        ERRCODE_OUT      NUMBER;
        ERRLINE_OUT      VARCHAR2(2048);
        V_HOST           CTRL_SOURCE.HOST%TYPE;
    BEGIN
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PCKG_NAME || '.' || C_PROC_NAME;

        V_STEP := 'set V_HOST';
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;

          SELECT   CTSO.HOST
            INTO   V_HOST
            FROM   CTRL_SOURCE CTSO
           WHERE   CTSO.SOURCE_ID = SOURCE_ID
        GROUP BY   CTSO.HOST;

        RETURN V_HOST;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN -1;
            EXIT_CD := -1;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'NO DATA FOUND ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
        WHEN OTHERS
        THEN
            RETURN -1;
            EXIT_CD := -2;

            ERRMSG_OUT := SUBSTR(SQLERRM, 1, 1024);

            ERRCODE_OUT := SQLCODE;

            ERRLINE_OUT := 'OTHER ERROR ' || V_STEP;

            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := EXIT_CD;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRMSG_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRCODE_OUT;
            V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
            V_ALL_DBG_INFO(V_DBG_INFO_ID) := ERRLINE_OUT;

            PCKG_PLOG.INFO(V_STEP);
            PCKG_PLOG.FATAL();
            PCKG_PLOG.SETPROCPARAMS(PROCEDURE_NAME_IN => C_PROC_NAME, ALL_ARGUMENTS_IN => V_ALL_DBG_INFO);
    END F_GET_CTRL_SOURCE_HOST;

    FUNCTION F_GET_STATUS_BEGIN(JOB_NAME_IN VARCHAR2, ENGINE_ID_IN NUMBER DEFAULT 0)
        RETURN CTRL_JOB.STATUS_BEGIN%TYPE
    IS
        /******************************************************************************
        Object type: UDF
        Name:  F_GET_STATUS_BEGIN
        IN parameters:
                       job_name_in
        OUT parameters:
                       RETURN ctrl_job.status_begin%TYPE
        Calling: N/A
        -------------------------------------------------------------------------------
        Version:        1.0
        -------------------------------------------------------------------------------
        Project: PDC
        Author:  Teradata - Marcel Samek
        Date:  2010-04-26
        -------------------------------------------------------------------------------
        Description: UDF returns
        -------------------------------------------------------------------------------
        Modified:
        Version:
        Date:
        Modification:
        *******************************************************************************/
        --constants
        C_PROC_NAME      CONSTANT VARCHAR2(64) := 'F_GET_STATUS_BEGIN';
        -- local variables
        V_STEP           VARCHAR2(1024);
        V_ALL_DBG_INFO   PCKG_PLOG.T_VARCHAR2;
        V_DBG_INFO_ID    INTEGER := 0;
        EXIT_CD          NUMBER;
        ERRMSG_OUT       VARCHAR2(2048);
        ERRCODE_OUT      NUMBER;
        ERRLINE_OUT      VARCHAR2(2048);
        V_STATUS_BEGIN   CTRL_JOB.STATUS_BEGIN%TYPE;
    BEGIN
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PCKG_NAME || '.' || C_PROC_NAME;

        V_STEP := 'set V_STATUS_BEGIN';
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;

        SELECT   CASE
                     WHEN CJ.STATUS_BEGIN IS NOT NULL
                     THEN
                         CJ.STATUS_BEGIN
                 END
          INTO   V_STATUS_BEGIN
          FROM   CTRL_JOB CJ
         WHERE   CJ.JOB_NAME = JOB_NAME_IN;

        RETURN V_STATUS_BEGIN;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            V_STATUS_BEGIN := 0;
            RETURN V_STATUS_BEGIN;
        WHEN OTHERS
        THEN
            V_STATUS_BEGIN := 0;
            RETURN V_STATUS_BEGIN;
    END F_GET_STATUS_BEGIN;

    FUNCTION F_GET_START_AT(JOB_ID_IN VARCHAR2)
        RETURN DATE
    IS
        /******************************************************************************
        Object type: UDF
        Name:  F_GET_STATUS_BEGIN
        IN parameters:
                       job_name_in
        OUT parameters:
                       RETURN ctrl_job.status_begin%TYPE
        Calling: N/A
        -------------------------------------------------------------------------------
        Version:        1.0
        -------------------------------------------------------------------------------
        Project: PDC
        Author:  Teradata - Marcel Samek
        Date:  2010-04-26
        -------------------------------------------------------------------------------
        Description: UDF returns
        -------------------------------------------------------------------------------
        Modified:
        Version:
        Date:
        Modification:
        *******************************************************************************/
        --constants
        C_PROC_NAME      CONSTANT VARCHAR2(64) := 'F_GET_STATUS_BEGIN';
        -- local variables
        V_STEP           VARCHAR2(1024);
        V_ALL_DBG_INFO   PCKG_PLOG.T_VARCHAR2;
        V_DBG_INFO_ID    INTEGER := 0;
        EXIT_CD          NUMBER;
        ERRMSG_OUT       VARCHAR2(2048);
        ERRCODE_OUT      NUMBER;
        ERRLINE_OUT      VARCHAR2(2048);
        V_START_AT       TIMESTAMP;
    BEGIN
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PCKG_NAME || '.' || C_PROC_NAME;

        V_STEP := 'set V_START_AT';
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;

        SELECT   MAX(SSA.STATUS_TS)
          INTO   V_START_AT
          FROM   SESS_STATUS SSA
         WHERE   SSA.STATUS IN (SELECT   STATUS
                                  FROM   CTRL_JOB_STATUS CJSA
                                 WHERE   CJSA.RUNABLE = 'RUNNING')
             AND SSA.JOB_ID = JOB_ID_IN;

        RETURN V_START_AT;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            V_START_AT := NULL;
            RETURN V_START_AT;
        WHEN OTHERS
        THEN
            V_START_AT := NULL;
            RETURN V_START_AT;
    END F_GET_START_AT;

    FUNCTION F_GET_END_AT(JOB_ID_IN VARCHAR2)
        RETURN DATE
    IS
        /******************************************************************************
        Object type: UDF
        Name:  F_GET_STATUS_BEGIN
        IN parameters:
                       job_name_in
        OUT parameters:
                       RETURN ctrl_job.status_begin%TYPE
        Calling: N/A
        -------------------------------------------------------------------------------
        Version:        1.0
        -------------------------------------------------------------------------------
        Project: PDC
        Author:  Teradata - Marcel Samek
        Date:  2010-04-26
        -------------------------------------------------------------------------------
        Description: UDF returns
        -------------------------------------------------------------------------------
        Modified:
        Version:
        Date:
        Modification:
        *******************************************************************************/
        --constants
        C_PROC_NAME      CONSTANT VARCHAR2(64) := 'F_GET_STATUS_BEGIN';
        -- local variables
        V_STEP           VARCHAR2(1024);
        V_ALL_DBG_INFO   PCKG_PLOG.T_VARCHAR2;
        V_DBG_INFO_ID    INTEGER := 0;
        EXIT_CD          NUMBER;
        ERRMSG_OUT       VARCHAR2(2048);
        ERRCODE_OUT      NUMBER;
        ERRLINE_OUT      VARCHAR2(2048);
        V_END_AT         TIMESTAMP;
    BEGIN
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := 'Execute ' || C_PCKG_NAME || '.' || C_PROC_NAME;

        V_STEP := 'set V_START_AT';
        V_DBG_INFO_ID := V_DBG_INFO_ID + 1;
        V_ALL_DBG_INFO(V_DBG_INFO_ID) := ' STEP> ' || V_STEP;

        SELECT   MAX(SSA.STATUS_TS)
          INTO   V_END_AT
          FROM   SESS_STATUS SSA
         WHERE   SSA.STATUS IN (SELECT   STATUS
                                  FROM   CTRL_JOB_STATUS CJSA
                                 WHERE   CJSA.RUNABLE = 'RUNNING')
             AND SSA.JOB_ID = JOB_ID_IN;

        RETURN V_END_AT;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            V_END_AT := NULL;
            RETURN V_END_AT;
        WHEN OTHERS
        THEN
            V_END_AT := NULL;
            RETURN V_END_AT;
    END F_GET_END_AT;


    FUNCTION ISDATE(P_INDATE VARCHAR2, P_FORMAT VARCHAR2)
        RETURN NUMBER
    AS
        V_DUMMY   DATE;
    BEGIN
        SELECT   TO_DATE(P_INDATE, P_FORMAT) INTO V_DUMMY FROM DUAL;

        RETURN 0;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN 1;
    END ISDATE;

    FUNCTION F_GET_DAY_OF_WEEK(DAY_IN DATE)
        RETURN NUMBER
    IS
        /******************************************************************************
        Object type: UDF
        Name:  DAY_OF_WEEK
        IN parameters:
                       DAY_IN
        OUT parameters:
                       RETURN NUMBER
        Calling: N/A
        -------------------------------------------------------------------------------
        Version:        1.0
        -------------------------------------------------------------------------------
        Project: PDC
        Author:  Teradata - Milan Budka
        Date:  2013-08-26
        -------------------------------------------------------------------------------
        Description: Return day of week: monday=1, sunday=7
        -------------------------------------------------------------------------------
        Modified:
        Version:
        Date:
        Modification:
        *******************************************************************************/
        -- local variables
        V_CURR_WEEK_DAY_NR           NUMBER;
	BEGIN
        V_CURR_WEEK_DAY_NR := MOD(ROUND(DAY_IN-to_date('01-01-1900','dd-mm-yyyy')+1),7);
        IF V_CURR_WEEK_DAY_NR = 0 THEN V_CURR_WEEK_DAY_NR := 7;
        END IF;
		RETURN 	V_CURR_WEEK_DAY_NR;
	END F_GET_DAY_OF_WEEK;

  FUNCTION F_DATE_MATCH_RUNPLAN(DATE_IN DATE, RUNPLAN_IN VARCHAR2)
        RETURN NUMBER
    IS
        /******************************************************************************
        Object type: UDF
        Name:  DATE_MATCH_RUNPLAN
        IN parameters:
                      DATE_IN
                      RUNPLAN_IN
        OUT parameters:
                       RETURN NUMBER - 0/1
        Calling: N/A
        -------------------------------------------------------------------------------
        Version:        1.0
        -------------------------------------------------------------------------------
        Project: PDC
        Author:  Teradata - Milan Budka
        Date:  2013-09-06
        -------------------------------------------------------------------------------
        Description: Return if date match specific RUNAPLAN: 1 - match, 0 - doesn't match
        -------------------------------------------------------------------------------
        Modified:
        Version:
        Date:
        Modification:
        *******************************************************************************/
        -- local variables
        V_RP_POSITION_A           VARCHAR2(1);
        V_RP_POSITION_B           VARCHAR2(1);
        V_RP_POSITION_CCC         VARCHAR2(3);
        V_RP_POSITION_DDD         VARCHAR2(3);
        V_RP_POSITION_E           VARCHAR2(1);
        V_CURR_YEAR_DAY_NR        INTEGER;
        V_CURR_YEAR_WEEK_NR       INTEGER;
        V_CURR_YEAR_MONTH_NR      INTEGER;
        V_CURR_YEAR_NR            INTEGER;
        V_CURR_MONTH_DAY_NR       INTEGER;
        V_CURR_MONTH_LASTDAY_NR   INTEGER;
        V_CURR_MONTH_WEEK_NR      INTEGER;
        V_CURR_WEEK_DAY_NR        INTEGER;
        V_MATCH              NUMBER;

  BEGIN
            V_RP_POSITION_A := SUBSTR(RUNPLAN_IN, 1, 1);
            V_RP_POSITION_B := SUBSTR(RUNPLAN_IN, 2, 1);
            V_RP_POSITION_CCC := SUBSTR(RUNPLAN_IN, 3, 3);
            V_RP_POSITION_DDD := SUBSTR(RUNPLAN_IN, 6, 3);
            V_RP_POSITION_E := SUBSTR(RUNPLAN_IN, 9, 1);

            V_CURR_YEAR_DAY_NR := TO_CHAR(DATE_IN, 'DDD'); -- cislo dne v roce
            V_CURR_YEAR_WEEK_NR := TO_CHAR(DATE_IN, 'IW'); -- cislo tydnu v roce
            V_CURR_YEAR_MONTH_NR := TO_CHAR(DATE_IN, 'MM'); -- cislo mesice v roce
            V_CURR_YEAR_NR := TO_CHAR(DATE_IN, 'YYYY'); -- rok
            V_CURR_MONTH_DAY_NR := TO_CHAR(DATE_IN, 'DD'); -- cislo dne v mesici
            V_CURR_MONTH_LASTDAY_NR := TO_CHAR(LAST_DAY(DATE_IN), 'DD'); -- cislo posledniho dne v mesici
            V_CURR_MONTH_WEEK_NR := TO_CHAR(DATE_IN, 'W'); -- cislo tydne v mesici
            -- cislo dne v tydnu, potrebujeme zajistit, aby nedele byla 7
            V_CURR_WEEK_DAY_NR := PCKG_TOOLS.F_GET_DAY_OF_WEEK(DATE_IN);
            -- cislo dne v tydnu

            IF (UPPER(V_RP_POSITION_A) = 'W'
            AND UPPER(V_RP_POSITION_B) = 'R'
            AND TO_NUMBER(V_CURR_WEEK_DAY_NR) BETWEEN TO_NUMBER(V_RP_POSITION_CCC) AND TO_NUMBER(V_RP_POSITION_DDD))
            THEN
                V_MATCH := 1;
            ELSIF (UPPER(V_RP_POSITION_A) = 'M'
               AND UPPER(V_RP_POSITION_B) = 'R'
               AND TO_NUMBER(V_CURR_MONTH_DAY_NR) BETWEEN TO_NUMBER(V_RP_POSITION_CCC) AND TO_NUMBER(V_RP_POSITION_DDD))
            THEN
                V_MATCH := 1;
            ELSIF (UPPER(V_RP_POSITION_A) = 'M'
               AND UPPER(V_RP_POSITION_B) = 'I'
               AND V_CURR_MONTH_DAY_NR = V_CURR_MONTH_LASTDAY_NR)
            THEN
                V_MATCH := 1;
            ELSIF (UPPER(V_RP_POSITION_A) = 'W'
               AND UPPER(V_RP_POSITION_B) = 'C'
               AND ((TO_NUMBER(V_RP_POSITION_CCC) - 1) * 7 + 1) <= TO_NUMBER(V_CURR_MONTH_DAY_NR)
               AND (TO_NUMBER(V_RP_POSITION_CCC) * 7) >= TO_NUMBER(V_CURR_MONTH_DAY_NR)
               AND TO_NUMBER(V_RP_POSITION_DDD) = TO_NUMBER(V_CURR_WEEK_DAY_NR)
               )
            THEN
                V_MATCH := 1;
            ELSE
                V_MATCH := 0;
            END IF;
    RETURN V_MATCH;
	END F_DATE_MATCH_RUNPLAN;
END;

